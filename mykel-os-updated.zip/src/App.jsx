import { Toaster } from "@/components/ui/toaster"
import { Toaster as SonnerToaster } from "@/components/ui/sonner"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider } from '@/lib/AuthContext';
import { LanguageProvider } from '@/lib/LanguageContext';
import MykelLogin from '@/pages/MykelLogin';
import BusinessInvite from './pages/BusinessInvite';
import MykelMeet from './pages/MykelMeet';
import ResetPassword from './pages/ResetPassword';
import LandingPage from './pages/LandingPage';
import { base44 } from '@/api/base44Client';
import { getMykelSession, clearMykelSession } from '@/lib/mykelSession';
import { loadAndApplyAppSettings } from '@/lib/appSettings';
import { useState, useEffect } from 'react';
import ConfirmHost from '@/components/shared/ConfirmHost';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const PUBLIC_PATHS = ['/MykelLogin', '/BusinessInvite', '/MykelMeet', '/reset-password'];

function AuthenticatedApp() {
  const location = useLocation();
  const path = location.pathname;
  const isPublic = PUBLIC_PATHS.some(p => path === p || path.startsWith(p + '/'));

  const [authState, setAuthState] = useState('checking'); // 'checking' | 'in' | 'out'

  useEffect(() => {
    loadAndApplyAppSettings();
  }, []);

  useEffect(() => {
    // Les pages publiques n'ont pas besoin de session
    if (isPublic) { setAuthState('out'); return; }
    // Session Mykel existante → vérifier que le token Base44 est encore valide
    const mykelSession = getMykelSession();
    let done = false;
    const finish = (state) => { if (done) return; done = true; setAuthState(state); };
    const t = setTimeout(() => finish(mykelSession ? 'in' : 'out'), 2500);
    base44.auth.me()
      .then(() => { clearTimeout(t); finish('in'); })
      .catch((err) => {
        clearTimeout(t);
        if (err?.status === 401) {
          // Token Base44 expiré — la session Mykel (30 j) est encore valide
          // mais les appels SDK échouent. Forcer une reconnexion propre.
          clearMykelSession();
          finish('out');
        } else {
          finish(mykelSession ? 'in' : 'out');
        }
      });
    return () => clearTimeout(t);
  }, [isPublic]);

  // Pages publiques rendues telles quelles
  if (path === '/MykelLogin') return <MykelLogin />;
  if (path === '/BusinessInvite') return <BusinessInvite />;
  if (path === '/MykelMeet') return <MykelMeet />;
  if (path === '/reset-password') return <ResetPassword />;

  // Spinner pendant la vérification (pages privées)
  if (authState === 'checking') {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-violet-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Non connecté sur une page privée → landing page
  if (authState === 'out') return <LandingPage />;

  // Connecté → rendu de l'app
  return (
    <Routes>
      <Route path="/" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages).map(([p, Page]) => (
        <Route
          key={p}
          path={`/${p}`}
          element={
            <LayoutWrapper currentPageName={p}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      <Route path="/MykelMeet" element={<MykelMeet />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <NavigationTracker />
            <AuthenticatedApp />
            <ConfirmHost />
          </Router>
          <Toaster />
          <SonnerToaster position="top-center" richColors closeButton />
        </QueryClientProvider>
      </AuthProvider>
    </LanguageProvider>
  )
}

export default App