import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Eye, EyeOff, ArrowRight, Loader2, X, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { setMykelSession } from '@/lib/mykelSession';

async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'mykel_salt_2024');
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function generateToken() {
  return Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('');
}

// Transfer data from base44 account to mykel account
async function transferData(base44User, mykelAccount, onProgress) {
  const fromEmail = base44User.email;

  onProgress('Récupération des données...');
  // 1. Tokens
  const tokensData = await base44.entities.UserTokens.filter({ user_email: fromEmail }).catch(() => []);
  if (tokensData.length > 0) {
    const tok = tokensData[0];
    const existingTok = await base44.entities.UserTokens.filter({ user_email: mykelAccount.email }).catch(() => []);
    if (existingTok.length > 0) {
      await base44.entities.UserTokens.update(existingTok[0].id, {
        tokens: (existingTok[0].tokens || 0) + (tok.tokens || 0),
        owned_apps: [...new Set([...(existingTok[0].owned_apps || []), ...(tok.owned_apps || [])])],
      });
    } else {
      await base44.entities.UserTokens.create({
        user_email: mykelAccount.email,
        tokens: tok.tokens || 0,
        owned_apps: tok.owned_apps || [],
        daily_login_streak: tok.daily_login_streak || 0,
        last_login_date: tok.last_login_date,
        invited_users: tok.invited_users || [],
      });
    }
  }
  onProgress(`✅ Jetons transférés`);

  // 2. Cloud Files
  const files = await base44.entities.CloudFile.filter({ created_by: fromEmail }).catch(() => []);
  for (const file of files) {
    const sharedWith = [...(file.shared_with || [])];
    if (!sharedWith.includes(mykelAccount.email)) sharedWith.push(mykelAccount.email);
    await base44.entities.CloudFile.update(file.id, { shared_with: sharedWith });
  }
  onProgress(`✅ ${files.length} fichier(s) cloud partagés`);

  // 3. Playlists
  const playlists = await base44.entities.Playlist.filter({ created_by: fromEmail }).catch(() => []);
  for (const pl of playlists) {
    await base44.entities.Playlist.create({ name: pl.name, music_file_ids: pl.music_file_ids || [], cover_url: pl.cover_url, description: pl.description });
  }
  onProgress(`✅ ${playlists.length} playlist(s) copiées`);

  // 4. Music Files
  const musicFiles = await base44.entities.MusicFile.filter({ created_by: fromEmail }).catch(() => []);
  for (const mf of musicFiles) {
    await base44.entities.MusicFile.create({ cloud_file_id: mf.cloud_file_id, name: mf.name, file_url: mf.file_url, type: mf.type, duration: mf.duration, artist: mf.artist, album: mf.album, cover_url: mf.cover_url });
  }
  onProgress(`✅ ${musicFiles.length} fichier(s) musicaux copiés`);

  // 5. Mark transfer done + preserve admin
  const accounts = await base44.entities.MykelAccount.filter({ email: mykelAccount.email });
  if (accounts.length > 0) {
    const updateData = { transferred_from: fromEmail, transfer_done: true };
    if (base44User.role === 'admin' && accounts[0].role !== 'admin') updateData.role = 'admin';
    await base44.entities.MykelAccount.update(accounts[0].id, updateData);
    setMykelSession({ ...accounts[0], ...updateData });
  }

  // 6. Wallpaper packs
  const wallpaperPacks = localStorage.getItem(`wallpaper_packs_${fromEmail}`);
  if (wallpaperPacks) localStorage.setItem(`wallpaper_packs_${mykelAccount.email}`, wallpaperPacks);

  onProgress('🎉 Transfert terminé !');
}

export default function MiniMykelLogin({ base44User, onClose, onSuccess }) {
  const [mode, setMode] = useState('login'); // login | register | transferring | done
  const [form, setForm] = useState({ email: '', password: '', name: '', confirm: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [progressLog, setProgressLog] = useState([]);
  const [loggedInAccount, setLoggedInAccount] = useState(null);

  const addProgress = (msg) => setProgressLog(p => [...p, msg]);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) return;
    setLoading(true);
    try {
      const accounts = await base44.entities.MykelAccount.filter({ email: form.email.toLowerCase().trim() });
      if (accounts.length === 0) { toast.error('Aucun compte trouvé'); return; }
      const account = accounts[0];
      const hash = await hashPassword(form.password);
      if (account.password_hash !== hash) { toast.error('Mot de passe incorrect'); return; }
      const token = generateToken();
      const expires = new Date(); expires.setDate(expires.getDate() + 30);
      await base44.entities.MykelAccount.update(account.id, { token, token_expires: expires.toISOString() });
      const session = { ...account, token, expires: expires.toISOString() };
      setMykelSession(session);
      setLoggedInAccount(session);
      // Start transfer
      setMode('transferring');
      setProgressLog([]);
      await transferData(base44User, session, addProgress);
      setMode('done');
    } catch (err) {
      toast.error('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password || !form.name) return;
    if (form.password !== form.confirm) { toast.error('Mots de passe différents'); return; }
    if (form.password.length < 6) { toast.error('Mot de passe trop court'); return; }
    setLoading(true);
    try {
      const existing = await base44.entities.MykelAccount.filter({ email: form.email.toLowerCase().trim() });
      if (existing.length > 0) { toast.error('Un compte existe déjà avec cet email'); return; }
      const hash = await hashPassword(form.password);
      const token = generateToken();
      const expires = new Date(); expires.setDate(expires.getDate() + 30);
      const newAccount = await base44.entities.MykelAccount.create({
        email: form.email.toLowerCase().trim(),
        full_name: form.name.trim(),
        password_hash: hash,
        token,
        token_expires: expires.toISOString(),
        role: base44User?.role === 'admin' ? 'admin' : 'user',
        created_at: new Date().toISOString(),
        transfer_done: false,
      });
      await base44.users.inviteUser(form.email.toLowerCase().trim(), 'user').catch(() => {});
      const session = { ...newAccount, token, expires: expires.toISOString() };
      setMykelSession(session);
      setLoggedInAccount(session);
      // Start transfer
      setMode('transferring');
      setProgressLog([]);
      await transferData(base44User, session, addProgress);
      setMode('done');
    } catch (err) {
      toast.error('Erreur lors de la création');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
      <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-violet-600 to-indigo-600 p-5 text-white flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold">Passer à la nouvelle version</h2>
            <p className="text-violet-200 text-xs mt-0.5">Connectez-vous ou créez un compte Mykel</p>
          </div>
          {mode !== 'transferring' && (
            <button onClick={onClose} className="text-white/70 hover:text-white mt-0.5">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="p-5">
          {/* Login / Register forms */}
          {(mode === 'login' || mode === 'register') && (
            <>
              {/* Tabs */}
              <div className="flex rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden mb-4">
                <button
                  onClick={() => setMode('login')}
                  className={`flex-1 py-2 text-sm font-semibold transition-colors ${mode === 'login' ? 'bg-violet-600 text-white' : 'text-gray-500 hover:bg-gray-50'}`}
                >
                  Se connecter
                </button>
                <button
                  onClick={() => setMode('register')}
                  className={`flex-1 py-2 text-sm font-semibold transition-colors ${mode === 'register' ? 'bg-violet-600 text-white' : 'text-gray-500 hover:bg-gray-50'}`}
                >
                  Créer un compte
                </button>
              </div>

              {mode === 'login' && (
                <form onSubmit={handleLogin} className="space-y-3">
                  <Input type="email" placeholder="Email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className="h-10 rounded-xl" required />
                  <div className="relative">
                    <Input type={showPass ? 'text' : 'password'} placeholder="Mot de passe" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} className="h-10 rounded-xl pr-10" required />
                    <button type="button" onClick={() => setShowPass(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <button type="submit" disabled={loading} className="w-full h-10 rounded-xl font-semibold bg-gradient-to-r from-violet-600 to-indigo-600 text-white flex items-center justify-center gap-2 disabled:opacity-60">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><ArrowRight className="w-4 h-4" /> Se connecter & Transférer</>}
                  </button>
                </form>
              )}

              {mode === 'register' && (
                <form onSubmit={handleRegister} className="space-y-3">
                  <Input placeholder="Nom complet" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="h-10 rounded-xl" required />
                  <Input type="email" placeholder="Email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className="h-10 rounded-xl" required />
                  <div className="relative">
                    <Input type={showPass ? 'text' : 'password'} placeholder="Mot de passe (min. 6 car.)" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} className="h-10 rounded-xl pr-10" required minLength={6} />
                    <button type="button" onClick={() => setShowPass(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <Input type="password" placeholder="Confirmer le mot de passe" value={form.confirm} onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))} className="h-10 rounded-xl" required />
                  <button type="submit" disabled={loading} className="w-full h-10 rounded-xl font-semibold bg-gradient-to-r from-violet-600 to-indigo-600 text-white flex items-center justify-center gap-2 disabled:opacity-60">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><ArrowRight className="w-4 h-4" /> Créer & Transférer</>}
                  </button>
                </form>
              )}

              <p className="text-xs text-gray-400 text-center mt-3">
                Après connexion, toutes vos données seront automatiquement transférées vers votre nouveau compte.
              </p>
            </>
          )}

          {/* Transferring */}
          {mode === 'transferring' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-violet-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm font-medium">Transfert en cours...</span>
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                {progressLog.map((msg, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-300">
                    <CheckCircle className="w-3.5 h-3.5 mt-0.5 text-green-500 flex-shrink-0" />
                    {msg}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Done */}
          {mode === 'done' && (
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <div>
                <p className="font-bold text-gray-900 dark:text-white">Transfert terminé !</p>
                <p className="text-sm text-gray-500 mt-1">Toutes vos données ont été transférées avec succès.</p>
              </div>
              <div className="space-y-1.5 text-left max-h-32 overflow-y-auto">
                {progressLog.map((msg, i) => (
                  <div key={i} className="text-xs text-gray-500">{msg}</div>
                ))}
              </div>
              <Button
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white gap-2"
                onClick={() => { onSuccess(); window.location.reload(); }}
              >
                <CheckCircle className="w-4 h-4" />
                Continuer avec la nouvelle version
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}