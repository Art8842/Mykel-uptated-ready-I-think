import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function DeleteAccount({ user }) {
  const [open, setOpen] = useState(false);
  const [confirmation, setConfirmation] = useState('');
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    if (confirmation !== 'SUPPRIMER') {
      toast.error('Veuillez taper SUPPRIMER pour confirmer');
      return;
    }

    setDeleting(true);
    try {
      // Delete all user's files
      const files = await base44.entities.CloudFile.filter({ created_by: user.email });
      for (const file of files) {
        await base44.entities.CloudFile.delete(file.id);
      }

      // Delete user's storage data
      const storage = await base44.entities.UserStorage.filter({ user_email: user.email });
      if (storage.length > 0) {
        await base44.entities.UserStorage.delete(storage[0].id);
      }

      // Delete user's tokens data
      const tokens = await base44.entities.UserTokens.filter({ user_email: user.email });
      if (tokens.length > 0) {
        await base44.entities.UserTokens.delete(tokens[0].id);
      }

      // Delete music files
      const music = await base44.entities.MusicFile.filter({ created_by: user.email });
      for (const file of music) {
        await base44.entities.MusicFile.delete(file.id);
      }

      // Delete playlists
      const playlists = await base44.entities.Playlist.filter({ created_by: user.email });
      for (const playlist of playlists) {
        await base44.entities.Playlist.delete(playlist.id);
      }

      toast.success('Compte supprimé avec succès');
      setTimeout(() => {
        base44.auth.logout();
      }, 1000);
    } catch (e) {
      toast.error('Erreur lors de la suppression');
      setDeleting(false);
    }
  };

  return (
    <>
      <Button
        variant="destructive"
        onClick={() => setOpen(true)}
        className="select-none min-h-[44px]"
      >
        <AlertTriangle className="w-4 h-4 mr-2" />
        Supprimer mon compte
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-red-600 dark:text-red-400">Supprimer définitivement votre compte</DialogTitle>
            <DialogDescription className="text-gray-600 dark:text-gray-400">
              Cette action est irréversible. Toutes vos données seront supprimées définitivement :
              fichiers, playlists, paramètres, etc.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              Pour confirmer, tapez <strong>SUPPRIMER</strong> ci-dessous :
            </p>
            <Input
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
              placeholder="SUPPRIMER"
              className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={deleting} className="select-none min-h-[44px]">
              Annuler
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={confirmation !== 'SUPPRIMER' || deleting}
              className="select-none min-h-[44px]"
            >
              {deleting ? 'Suppression...' : 'Supprimer définitivement'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}