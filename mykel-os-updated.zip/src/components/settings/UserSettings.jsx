import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Trash2, CheckCircle2, Loader2, Image, X, Check, Globe } from 'lucide-react';
import DeleteAccount from '@/components/settings/DeleteAccount';
import { toast } from 'sonner';
import { useLanguage } from '@/lib/LanguageContext';
import { Link } from 'react-router-dom';
import { isAIDisabled, setAIDisabled } from '@/lib/aiSettings';

// All PACKS wallpapers — sync with MykelStore PACKS
const ALL_PACKS_DATA = {
  nature: {
    name: 'Nature & Paysages', icon: '🌿',
    wallpapers: [
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600',
      'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=600',
      'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600',
      'https://images.unsplash.com/photo-1433086966358-54859d0ed716?w=600',
      'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=600',
      'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=600',
      'https://images.unsplash.com/photo-1510784722466-f2aa240d5e48?w=600',
      'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?w=600',
    ],
  },
  space: {
    name: 'Espace & Cosmos', icon: '🌌',
    wallpapers: [
      'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?w=600',
      'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=600',
      'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=600',
      'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=600',
      'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600',
      'https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=600',
      'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=600',
      'https://images.unsplash.com/photo-1464802686167-b939a6910659?w=600',
    ],
  },
  abstract: {
    name: 'Art Abstrait', icon: '🎨',
    wallpapers: [
      'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=600',
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600',
      'https://images.unsplash.com/photo-1500462918059-b1a0e5145009?w=600',
      'https://images.unsplash.com/photo-1524230572899-a752b3835840?w=600',
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600',
      'https://images.unsplash.com/photo-1550537687-c91072c4792d?w=600',
      'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=600',
      'https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=600',
    ],
  },
  city: {
    name: 'Villes & Architecture', icon: '🏙️',
    wallpapers: [
      'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=600',
      'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=600',
      'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=600',
      'https://images.unsplash.com/photo-1444723121867-7a241cacace9?w=600',
      'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600',
      'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=600',
      'https://images.unsplash.com/photo-1532509853700-a257a45de80b?w=600',
      'https://images.unsplash.com/photo-1496568816309-51d7c20e3b21?w=600',
    ],
  },
  minimal: {
    name: 'Minimaliste', icon: '◻️',
    wallpapers: [
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600',
      'https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=600',
      'https://images.unsplash.com/photo-1557683311-eac922347aa1?w=600',
      'https://images.unsplash.com/photo-1540206395-68808572332f?w=600',
      'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?w=600',
      'https://images.unsplash.com/photo-1490730141103-6cac27aaab94?w=600',
      'https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3?w=600',
    ],
  },
  animals: {
    name: 'Animaux', icon: '🦁',
    wallpapers: [
      'https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=600',
      'https://images.unsplash.com/photo-1474511320723-9a56873867b5?w=600',
      'https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?w=600',
      'https://images.unsplash.com/photo-1504173010664-32509107de5f?w=600',
      'https://images.unsplash.com/photo-1564349683136-77e08dba1ef7?w=600',
      'https://images.unsplash.com/photo-1503066211613-c17ebc9daef0?w=600',
      'https://images.unsplash.com/photo-1549480017-d76466a4b7e8?w=600',
      'https://images.unsplash.com/photo-1471017851983-fc28bf1c756e?w=600',
    ],
  },
};

export default function UserSettings({ open, onClose, user }) {
  const { t, lang, setLanguage, languages } = useLanguage();
  const [developerMode, setDeveloperMode] = useState(() =>
    localStorage.getItem('developer_mode') === 'true'
  );
  const [aiDisabled, setAiDisabled] = useState(() => isAIDisabled());

  // Wallpaper state
  const [appliedWallpaper, setAppliedWallpaper] = useState(() => localStorage.getItem('mykel_wallpaper') || null);
  const [wallpaperOpacity, setWallpaperOpacity] = useState(() => {
    const saved = localStorage.getItem('mykel_wallpaper_opacity');
    return saved ? parseFloat(saved) : 0.85;
  });
  const [purchasedPacks, setPurchasedPacks] = useState([]);
  const [generatedWallpapers, setGeneratedWallpapers] = useState([]);
  const [selectedPack, setSelectedPack] = useState(null);

  useEffect(() => {
    if (open && user) {
      try {
        const stored = localStorage.getItem(`wallpaper_packs_${user.email}`);
        if (stored) setPurchasedPacks(JSON.parse(stored));
        const gen = localStorage.getItem('mykel_generated_wallpapers');
        if (gen) setGeneratedWallpapers(JSON.parse(gen));
      } catch {}
    }
  }, [open, user]);

  // Listen for wallpaper changes
  useEffect(() => {
    const handler = (e) => {
      if (e.detail.url !== undefined) setAppliedWallpaper(e.detail.url);
      if (e.detail.opacity !== undefined) setWallpaperOpacity(e.detail.opacity);
    };
    window.addEventListener('wallpaper-change', handler);
    return () => window.removeEventListener('wallpaper-change', handler);
  }, []);

  const handleApplyWallpaper = (url) => {
    localStorage.setItem('mykel_wallpaper', url);
    setAppliedWallpaper(url);
    window.dispatchEvent(new CustomEvent('wallpaper-change', { detail: { url } }));
    toast.success('Fond d\'écran appliqué !');
  };

  const handleRemoveWallpaper = () => {
    localStorage.removeItem('mykel_wallpaper');
    setAppliedWallpaper(null);
    window.dispatchEvent(new CustomEvent('wallpaper-change', { detail: { url: null } }));
    toast.success('Fond d\'écran retiré');
  };

  const handleOpacityChange = (val) => {
    const opacity = parseFloat(val);
    setWallpaperOpacity(opacity);
    localStorage.setItem('mykel_wallpaper_opacity', String(opacity));
    window.dispatchEvent(new CustomEvent('wallpaper-change', { detail: { opacity } }));
  };

  // Build list of all available wallpapers from purchased packs + AI generated
  const availableWallpapers = [
    ...purchasedPacks.flatMap(packId => {
      const pack = ALL_PACKS_DATA[packId];
      return pack ? pack.wallpapers.map(url => ({ url, source: packId, packName: pack.name })) : [];
    }),
    ...generatedWallpapers.map(url => ({ url, source: 'ai', packName: 'IA' })),
  ];

  // Group by pack
  const packGroups = purchasedPacks
    .filter(packId => ALL_PACKS_DATA[packId])
    .map(packId => ({ id: packId, ...ALL_PACKS_DATA[packId] }));

  const displayedWallpapers = selectedPack
    ? availableWallpapers.filter(w => w.source === selectedPack)
    : availableWallpapers;

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-gray-900 dark:text-white">{t('settings')}</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">

            {/* ── LANGUE ── */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-2">
                <Globe className="w-4 h-4" /> {t('language')}
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {Object.values(languages).map(l => (
                  <button
                    key={l.code}
                    onClick={() => setLanguage(l.code)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border-2 text-sm font-medium transition-all ${
                      lang === l.code
                        ? 'border-violet-500 bg-violet-50 dark:bg-violet-900/20 text-violet-700 dark:text-violet-300'
                        : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-gray-300'
                    }`}
                  >
                    <span>{l.flag}</span>
                    <span className="truncate">{l.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <Separator />

            {/* ── FOND D'ÉCRAN ── */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">{t('wallpaper')}</h3>

              {availableWallpapers.length === 0 ? (
                <div className="p-4 rounded-xl border border-gray-200 dark:border-gray-700 text-center">
                  <Image className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm text-gray-500 mb-3">{t('wallpaper_none')}</p>
                  <Link to="/MykelStore" onClick={onClose}>
                    <Button size="sm" variant="outline" className="gap-2 text-violet-600 border-violet-200 hover:bg-violet-50">
                      <Image className="w-3.5 h-3.5" />
                      {t('wallpaper_buy')}
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Current wallpaper */}
                  {appliedWallpaper && (
                    <div className="flex items-center gap-3 p-3 rounded-xl border border-violet-200 bg-violet-50 dark:bg-violet-900/20 dark:border-violet-700">
                      <img src={appliedWallpaper} alt="Fond actif" className="w-14 h-9 rounded-lg object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-violet-700 dark:text-violet-300">{t('wallpaper_active')}</p>
                      </div>
                      <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-600 h-7 px-2" onClick={handleRemoveWallpaper}>
                        <X className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  )}

                  {/* Opacity slider */}
                  {appliedWallpaper && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-medium text-gray-600 dark:text-gray-400">Opacité du fond d'écran</label>
                        <span className="text-xs text-gray-500">{Math.round(wallpaperOpacity * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="1"
                        step="0.05"
                        value={wallpaperOpacity}
                        onChange={e => handleOpacityChange(e.target.value)}
                        className="w-full h-2 accent-violet-500 cursor-pointer"
                      />
                      <div className="flex justify-between text-xs text-gray-400 mt-1">
                        <span>Transparent</span>
                        <span>Opaque</span>
                      </div>
                    </div>
                  )}

                  {/* Pack filter pills */}
                  {packGroups.length > 1 && (
                    <div className="flex gap-2 flex-wrap">
                      <button
                        onClick={() => setSelectedPack(null)}
                        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${!selectedPack ? 'bg-violet-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200'}`}
                      >
                        Tous
                      </button>
                      {packGroups.map(pack => (
                        <button
                          key={pack.id}
                          onClick={() => setSelectedPack(pack.id === selectedPack ? null : pack.id)}
                          className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${selectedPack === pack.id ? 'bg-violet-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200'}`}
                        >
                          {pack.icon} {pack.name}
                        </button>
                      ))}
                      {generatedWallpapers.length > 0 && (
                        <button
                          onClick={() => setSelectedPack(selectedPack === 'ai' ? null : 'ai')}
                          className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${selectedPack === 'ai' ? 'bg-violet-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200'}`}
                        >
                          ✨ IA
                        </button>
                      )}
                    </div>
                  )}

                  {/* Wallpaper grid */}
                  <div className="grid grid-cols-4 gap-2 max-h-52 overflow-y-auto">
                    {displayedWallpapers.map(({ url, source }, i) => (
                      <div
                        key={`${source}-${i}`}
                        className={`relative rounded-lg overflow-hidden cursor-pointer group border-2 transition-all ${appliedWallpaper === url ? 'border-violet-500 ring-1 ring-violet-300' : 'border-transparent hover:border-violet-300'}`}
                        onClick={() => handleApplyWallpaper(url)}
                      >
                        <img src={url} alt={`Fond ${i + 1}`} className="w-full h-12 object-cover" />
                        {appliedWallpaper === url && (
                          <div className="absolute inset-0 bg-violet-500/20 flex items-center justify-center">
                            <Check className="w-4 h-4 text-white drop-shadow" />
                          </div>
                        )}
                        {source === 'ai' && (
                          <div className="absolute bottom-0.5 right-0.5 bg-purple-600 rounded text-white text-[8px] px-1">IA</div>
                        )}
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all" />
                      </div>
                    ))}
                  </div>

                  <Link to="/MykelStore" onClick={onClose}>
                    <Button size="sm" variant="outline" className="w-full gap-2 text-violet-600 border-violet-200 hover:bg-violet-50 mt-1">
                      <Image className="w-3.5 h-3.5" />
                      {t('wallpaper_more')}
                    </Button>
                  </Link>
                </div>
              )}
            </div>

            <Separator />

            {/* ── INTELLIGENCE ARTIFICIELLE ── */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Intelligence artificielle</h3>
              <div className="p-4 rounded-xl border border-gray-200 dark:border-gray-700">
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="ai_disabled"
                    checked={aiDisabled}
                    onChange={e => {
                      setAiDisabled(e.target.checked);
                      setAIDisabled(e.target.checked);
                    }}
                    className="w-5 h-5 mt-0.5 accent-red-500 cursor-pointer"
                  />
                  <label htmlFor="ai_disabled" className="cursor-pointer flex-1">
                    <p className="font-medium text-gray-900 dark:text-white text-sm">Désactiver toutes les fonctionnalités d'IA</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                      Retire toutes les fonctionnalités d'intelligence artificielle (Mykel IA, IA dans EdiCode, etc.). Vous pouvez les réactiver à tout moment.
                    </p>
                  </label>
                </div>
                {aiDisabled && (
                  <div className="mt-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
                    <p className="text-xs text-amber-700 dark:text-amber-300 font-medium">
                      ⚠️ Non recommandé — L'IA est désactivée. Les applications Mykel IA et les fonctionnalités d'IA dans EdiCode ne sont plus accessibles.
                    </p>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* ── MODE DÉVELOPPEUR ── */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Mode développeur</h3>
              <div className="p-4 rounded-xl border border-gray-200 dark:border-gray-700">
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="developer_mode"
                    checked={developerMode}
                    onChange={e => {
                      setDeveloperMode(e.target.checked);
                      localStorage.setItem('developer_mode', String(e.target.checked));
                      window.dispatchEvent(new CustomEvent('developer-mode-change'));
                    }}
                    className="w-5 h-5 mt-0.5 accent-violet-500 cursor-pointer"
                  />
                  <label htmlFor="developer_mode" className="cursor-pointer flex-1">
                    <p className="font-medium text-gray-900 dark:text-white text-sm">Activer le mode développeur</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                      Ajoute un bouton « Espace développeur » dans le menu de profil pour gérer vos API.
                    </p>
                  </label>
                </div>
              </div>
            </div>

            <Separator />

            {/* ── DANGER ZONE ── */}
            <div>
              <h3 className="text-sm font-semibold text-red-500 mb-3">Zone dangereuse</h3>
              <DeleteAccount user={user} />
            </div>
          </div>
        </DialogContent>
      </Dialog>

    </>
  );
}