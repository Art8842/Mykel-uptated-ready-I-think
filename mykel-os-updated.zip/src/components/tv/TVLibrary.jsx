import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Bookmark, Play, CheckCircle } from 'lucide-react';

export default function TVLibrary({ user, subscriptionType, onContentClick }) {
  const [progress, setProgress] = useState([]);
  const [allContent, setAllContent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [progressData, contentData] = await Promise.all([
        user?.email ? base44.entities.TVWatchProgress.filter({ user_email: user.email }, '-last_watched', 50) : Promise.resolve([]),
        base44.entities.TVContent.filter({ published: true }, '-publish_date', 100),
      ]);
      setProgress(progressData);
      setAllContent(contentData);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-4 border-gray-700 border-t-red-500 rounded-full animate-spin" />
      </div>
    );
  }

  const getContent = (contentId) => allContent.find(c => c.id === contentId);
  const watching = progress.filter(p => !p.completed).map(p => ({ ...getContent(p.content_id), progress: p })).filter(c => c.id);
  const completed = progress.filter(p => p.completed).map(p => ({ ...getContent(p.content_id), progress: p })).filter(c => c.id);

  if (progress.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-500 p-8">
        <Bookmark className="w-16 h-16 mb-4 opacity-30" />
        <p className="text-lg font-medium mb-1">Votre bibliomovie est vide</p>
        <p className="text-sm">Commencez à regarder pour retrouver vos films et séries ici</p>
      </div>
    );
  }

  return (
    <div className="p-4 pb-8">
      {/* En cours de lecture */}
      {watching.length > 0 && (
        <div className="mb-8">
          <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
            <Play className="w-5 h-5 text-red-500" /> En cours de lecture
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {watching.map(item => (
              <button key={item.id} onClick={() => onContentClick(item)} className="group text-left">
                <div className="relative aspect-video rounded-lg overflow-hidden bg-gray-800">
                  <img src={item.poster_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-12 h-12 rounded-full bg-red-600 flex items-center justify-center">
                      <Play className="w-6 h-6 text-white fill-white" />
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-600">
                    <div className="h-full bg-red-600" style={{ width: `${(item.progress.progress_seconds / item.progress.duration_seconds) * 100}%` }} />
                  </div>
                </div>
                <p className="text-sm font-medium mt-1.5 line-clamp-1">{item.title}</p>
                <p className="text-xs text-gray-500">{Math.round((item.progress.progress_seconds / item.progress.duration_seconds) * 100)}% regardé</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Terminés */}
      {completed.length > 0 && (
        <div>
          <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" /> Déjà regardés
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
            {completed.map(item => (
              <button key={item.id} onClick={() => onContentClick(item)} className="group text-left">
                <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-gray-800">
                  <img src={item.poster_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  <div className="absolute top-1 right-1 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                </div>
                <p className="text-xs font-medium mt-1.5 line-clamp-1">{item.title}</p>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}