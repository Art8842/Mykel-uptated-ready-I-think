import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X, Play, Crown, Lock, Globe, Subtitles, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function TVContentModal({ content, user, subscriptionType, onClose, onPlay }) {
  const [episodes, setEpisodes] = useState([]);
  const [mediaTracks, setMediaTracks] = useState([]);
  const [subtitles, setSubtitles] = useState([]);
  const [watchProgress, setWatchProgress] = useState(null);
  const [selectedLanguage, setSelectedLanguage] = useState(content.main_language || 'Français');
  const [selectedSubtitle, setSelectedSubtitle] = useState(null);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showSubMenu, setShowSubMenu] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [content]);

  const loadData = async () => {
    try {
      const [epData, trackData, subData, progressData] = await Promise.all([
        content.content_type === 'series'
          ? base44.entities.TVEpisode.filter({ content_id: content.id })
          : Promise.resolve([]),
        base44.entities.TVMediaTrack.filter({ content_id: content.id }),
        base44.entities.TVSubtitle.filter({ content_id: content.id }),
        user?.email
          ? base44.entities.TVWatchProgress.filter({ user_email: user.email, content_id: content.id })
          : Promise.resolve([]),
      ]);
      setEpisodes(epData.sort((a, b) => a.season - b.season || a.episode_number - b.episode_number));
      setMediaTracks(trackData);
      setSubtitles(subData);
      setWatchProgress(progressData[0] || null);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const canWatch = () => {
    if (!subscriptionType) return false;
    if (content.is_exclusive_plus && subscriptionType !== 'plus') return false;
    return true;
  };

  const hasProgress = watchProgress && !watchProgress.completed && watchProgress.progress_seconds > 10;
  const buttonLabel = hasProgress
    ? `Continuer ${content.title}`
    : `Regarder ${content.title}`;

  const handlePlay = (episode = null) => {
    if (!canWatch()) return;
    const progress = episode
      ? 0 // TODO: episode-specific progress
      : watchProgress?.progress_seconds || 0;
    onPlay(content, episode, progress);
  };

  // Group episodes by season
  const seasons = {};
  episodes.forEach(ep => {
    if (!seasons[ep.season]) seasons[ep.season] = [];
    seasons[ep.season].push(ep);
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-start justify-center overflow-y-auto" onClick={onClose}>
      <div className="bg-gray-900 w-full max-w-2xl min-h-full sm:rounded-2xl sm:my-8 sm:max-h-[90vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        {/* Hero with poster */}
        <div className="relative h-48 sm:h-56">
          <img src={content.featured_image_url || content.poster_url} alt={content.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
          <button onClick={onClose} className="absolute top-3 right-3 w-9 h-9 rounded-full bg-black/60 flex items-center justify-center hover:bg-black/80">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="p-4 sm:p-6 -mt-8 relative">
          {/* Title + badges */}
          <div className="flex items-start gap-3 mb-3">
            <img src={content.poster_url} alt={content.title} className="w-20 h-28 rounded-lg object-cover flex-shrink-0 shadow-xl" />
            <div className="flex-1 pt-4">
              <h2 className="text-xl sm:text-2xl font-bold text-white">{content.title}</h2>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {content.genre && <span className="px-2 py-0.5 bg-gray-800 text-gray-300 text-xs rounded-full">{content.genre}</span>}
                <span className="px-2 py-0.5 bg-gray-800 text-gray-300 text-xs rounded-full">{content.content_type === 'movie' ? 'Film' : 'Série'}</span>
                {content.is_exclusive_plus && (
                  <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-400 text-xs rounded-full flex items-center gap-1">
                    <Crown className="w-3 h-3" /> TV +
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Description */}
          <p className="text-sm text-gray-300 mb-4">{content.description}</p>

          {/* Play button */}
          {canWatch() ? (
            <Button
              onClick={() => content.content_type === 'series' && episodes.length > 0 ? handlePlay(episodes[0]) : handlePlay()}
              className="w-full h-12 bg-red-600 hover:bg-red-700 text-white text-base font-semibold gap-2 mb-3"
            >
              <Play className="w-5 h-5 fill-white" /> {buttonLabel}
            </Button>
          ) : (
            <div className="w-full bg-gray-800 rounded-lg p-4 text-center mb-3">
              <Lock className="w-5 h-5 mx-auto mb-2 text-gray-500" />
              <p className="text-sm text-gray-400">
                {content.is_exclusive_plus
                  ? 'Abonnement Mykel TV + requis pour ce contenu exclusif'
                  : 'Abonnement Mykel TV requis pour regarder'}
              </p>
            </div>
          )}

          {/* Language selector */}
          <div className="relative mb-3">
            <button
              onClick={() => { setShowLangMenu(!showLangMenu); setShowSubMenu(false); }}
              className="w-full flex items-center justify-between px-4 py-2.5 bg-gray-800 rounded-lg text-sm text-white hover:bg-gray-700 transition-colors"
            >
              <span className="flex items-center gap-2"><Globe className="w-4 h-4" /> Langue : {selectedLanguage}</span>
              <ChevronDown className="w-4 h-4" />
            </button>
            {showLangMenu && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 rounded-lg overflow-hidden z-10 shadow-xl">
                <button
                  onClick={() => { setSelectedLanguage(content.main_language || 'Français'); setShowLangMenu(false); }}
                  className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-700 ${selectedLanguage === (content.main_language || 'Français') ? 'text-red-400' : 'text-white'}`}
                >
                  {content.main_language || 'Français'} (Original)
                </button>
                {mediaTracks.map(track => (
                  <button
                    key={track.id}
                    onClick={() => { setSelectedLanguage(track.language); setShowLangMenu(false); }}
                    className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-700 ${selectedLanguage === track.language ? 'text-red-400' : 'text-white'}`}
                  >
                    {track.language}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Subtitle selector */}
          <div className="relative mb-4">
            <button
              onClick={() => { setShowSubMenu(!showSubMenu); setShowLangMenu(false); }}
              className="w-full flex items-center justify-between px-4 py-2.5 bg-gray-800 rounded-lg text-sm text-white hover:bg-gray-700 transition-colors"
            >
              <span className="flex items-center gap-2"><Subtitles className="w-4 h-4" /> Sous-titres : {selectedSubtitle || 'Désactivés'}</span>
              <ChevronDown className="w-4 h-4" />
            </button>
            {showSubMenu && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 rounded-lg overflow-hidden z-10 shadow-xl">
                <button
                  onClick={() => { setSelectedSubtitle(null); setShowSubMenu(false); }}
                  className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-700 ${!selectedSubtitle ? 'text-red-400' : 'text-white'}`}
                >
                  Désactivés
                </button>
                {subtitles.map(sub => (
                  <button
                    key={sub.id}
                    onClick={() => { setSelectedSubtitle(sub.language); setShowSubMenu(false); }}
                    className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-700 ${selectedSubtitle === sub.language ? 'text-red-400' : 'text-white'}`}
                  >
                    {sub.language}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Episodes (for series) */}
          {content.content_type === 'series' && Object.keys(seasons).length > 0 && (
            <div className="space-y-4">
              {Object.entries(seasons).map(([season, eps]) => (
                <div key={season}>
                  <h3 className="text-sm font-bold text-white mb-2">Saison {season}</h3>
                  <div className="space-y-2">
                    {eps.map(ep => (
                      <button
                        key={ep.id}
                        onClick={() => handlePlay(ep)}
                        className="w-full flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg hover:bg-gray-800 transition-colors text-left"
                      >
                        <div className="w-10 h-10 rounded-lg bg-gray-700 flex items-center justify-center flex-shrink-0">
                          <span className="text-sm font-bold text-gray-300">{ep.episode_number}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white line-clamp-1">{ep.title}</p>
                          {ep.duration && <p className="text-xs text-gray-500">{Math.round(ep.duration / 60)} min</p>}
                        </div>
                        <Play className="w-4 h-4 text-gray-500 flex-shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}