import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia, freeInvokeLLM } from '@/lib/freeCore';
import {
  X, Film, Tv, Upload, Plus, Trash2, ChevronLeft, ChevronRight,
  Check, Loader2, Globe, Subtitles, Image, Crown, Languages,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

const LANGUAGES = ['Français', 'English', 'Español', 'Deutsch', 'Italiano', 'Português', '日本語', '中文'];

export default function TVPublishWizard({ user, onClose, onPublished }) {
  const [step, setStep] = useState(1);
  const [type, setType] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [genre, setGenre] = useState('');
  const [mainVideoUrl, setMainVideoUrl] = useState('');
  const [mainLanguage, setMainLanguage] = useState('Français');
  const [languageVersions, setLanguageVersions] = useState([]);
  const [subtitleText, setSubtitleText] = useState('');
  const [subtitleLang, setSubtitleLang] = useState('Français');
  const [translateSubs, setTranslateSubs] = useState([]);
  const [translating, setTranslating] = useState(false);
  const [parentContentId, setParentContentId] = useState('');
  const [existingMovies, setExistingMovies] = useState([]);
  const [episodes, setEpisodes] = useState([]);
  const [posterUrl, setPosterUrl] = useState('');
  const [featuredImageUrl, setFeaturedImageUrl] = useState('');
  const [isExclusivePlus, setIsExclusivePlus] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [publishing, setPublishing] = useState(false);

  useEffect(() => {
    base44.entities.TVContent.filter({ content_type: 'movie', published: true }).then(setExistingMovies);
  }, []);

  const uploadFile = async (file) => {
    const { file_url } = await uploadMedia(file);
    return file_url;
  };

  const handleVideoUpload = async (e, callback) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const url = await uploadFile(file);
      callback(url);
      toast.success('Fichier importé');
    } catch { toast.error('Erreur import'); }
    finally { setUploading(false); }
  };

  const addLanguageVersion = (lang, url) => {
    if (!lang || !url) return;
    setLanguageVersions(prev => [...prev, { language: lang, video_url: url }]);
  };

  const handleTranslateSubs = async () => {
    if (!subtitleText.trim() || translateSubs.length === 0) return;
    setTranslating(true);
    try {
      const newSubs = [...languageVersions.length > 0 ? [] : []];
      for (const lang of translateSubs) {
        if (lang === subtitleLang) continue;
        const result = await freeInvokeLLM({
          prompt: `Traduis le texte suivant en ${lang}. Garde le même nombre de lignes. Ne renvoie que le texte traduit, sans commentaire:\n\n${subtitleText}`,
        });
        newSubs.push({ language: lang, text: result });
      }
      // Store translated subtitles
      setLanguageVersions(prev => prev); // keep existing
      // We'll store all subtitles at publish time
      window._tvTranslatedSubs = [...(window._tvTranslatedSubs || []), ...newSubs];
      toast.success(`Sous-titres traduits en ${translateSubs.length} langue(s)`);
    } catch { toast.error('Erreur traduction'); }
    finally { setTranslating(false); }
  };

  const addEpisode = () => {
    const maxSeason = episodes.length > 0 ? Math.max(...episodes.map(e => e.season)) : 1;
    const seasonEpisodes = episodes.filter(e => e.season === maxSeason);
    const epNum = seasonEpisodes.length + 1;
    setEpisodes(prev => [...prev, {
      season: maxSeason,
      episode_number: epNum,
      title: '',
      video_url: '',
      main_language: 'Français',
      languageVersions: [],
      subtitleText: '',
      subtitleLang: 'Français',
    }]);
  };

  const updateEpisode = (idx, field, value) => {
    setEpisodes(prev => prev.map((e, i) => i === idx ? { ...e, [field]: value } : e));
  };

  const removeEpisode = (idx) => {
    setEpisodes(prev => prev.filter((_, i) => i !== idx));
  };

  const addEpisodeLanguageVersion = (idx, lang, url) => {
    if (!lang || !url) return;
    setEpisodes(prev => prev.map((e, i) =>
      i === idx ? { ...e, languageVersions: [...e.languageVersions, { language: lang, video_url: url }] } : e
    ));
  };

  const handlePublish = async () => {
    if (!title.trim() || !type) { toast.error('Titre et type requis'); return; }
    if (type === 'movie' && !mainVideoUrl) { toast.error('Vidéo du film requise'); return; }
    if (type === 'series' && episodes.length === 0) { toast.error('Au moins un épisode requis'); return; }
    if (!posterUrl) { toast.error('Affiche requise'); return; }

    setPublishing(true);
    try {
      // Create TVContent
      const content = await base44.entities.TVContent.create({
        title: title.trim(),
        description: description.trim(),
        content_type: type,
        poster_url: posterUrl,
        featured_image_url: featuredImageUrl || posterUrl,
        creator_email: user.email,
        creator_name: user.full_name || user.email,
        is_featured: false,
        is_exclusive_plus: isExclusivePlus,
        genre: genre.trim(),
        parent_content_id: type === 'movie' && parentContentId ? parentContentId : null,
        video_url: type === 'movie' ? mainVideoUrl : null,
        main_language: type === 'movie' ? mainLanguage : null,
        published: true,
        publish_date: new Date().toISOString(),
      });

      // Create media tracks and subtitles for movie
      if (type === 'movie') {
        for (const lv of languageVersions) {
          await base44.entities.TVMediaTrack.create({
            content_id: content.id,
            language: lv.language,
            video_url: lv.video_url,
          });
        }
        if (subtitleText.trim()) {
          await base44.entities.TVSubtitle.create({
            content_id: content.id,
            language: subtitleLang,
            subtitle_text: subtitleText,
          });
        }
        // Translated subtitles
        const translatedSubs = window._tvTranslatedSubs || [];
        for (const ts of translatedSubs) {
          await base44.entities.TVSubtitle.create({
            content_id: content.id,
            language: ts.language,
            subtitle_text: ts.text,
          });
        }
      }

      // Create episodes for series
      if (type === 'series') {
        for (const ep of episodes) {
          if (!ep.video_url || !ep.title.trim()) continue;
          const episode = await base44.entities.TVEpisode.create({
            content_id: content.id,
            season: ep.season,
            episode_number: ep.episode_number,
            title: ep.title,
            video_url: ep.video_url,
            main_language: ep.main_language,
          });
          for (const lv of ep.languageVersions || []) {
            await base44.entities.TVMediaTrack.create({
              content_id: content.id,
              episode_id: episode.id,
              language: lv.language,
              video_url: lv.video_url,
            });
          }
          if (ep.subtitleText?.trim()) {
            await base44.entities.TVSubtitle.create({
              content_id: content.id,
              episode_id: episode.id,
              language: ep.subtitleLang,
              subtitle_text: ep.subtitleText,
            });
          }
        }
      }

      window._tvTranslatedSubs = [];
      toast.success(`${type === 'movie' ? 'Film' : 'Série'} publié !`);
      onPublished();
    } catch (e) {
      console.error(e);
      toast.error('Erreur lors de la publication');
    } finally {
      setPublishing(false);
    }
  };

  const canNext = () => {
    if (step === 1) return type && title.trim();
    if (step === 2) return type === 'movie' ? mainVideoUrl : episodes.length > 0 && episodes.every(e => e.video_url && e.title.trim());
    if (step === 3) return true;
    if (step === 4) return posterUrl;
    return false;
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-950 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between z-10">
        <h2 className="text-lg font-bold text-white">Publier sur Mykel TV</h2>
        <button onClick={onClose} className="w-9 h-9 rounded-full hover:bg-gray-800 flex items-center justify-center">
          <X className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Step indicator */}
      <div className="flex items-center justify-center gap-2 py-4">
        {[1, 2, 3, 4].map(s => (
          <div key={s} className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
            step >= s ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-500'
          }`}>
            {step > s ? <Check className="w-4 h-4" /> : s}
          </div>
        ))}
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-32">
        {/* Step 1: Type + basic info */}
        {step === 1 && (
          <div className="space-y-5">
            <div>
              <Label className="text-white mb-3 block">Type de contenu</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setType('movie')}
                  className={`p-4 rounded-xl border-2 transition-all ${type === 'movie' ? 'border-red-500 bg-red-500/10' : 'border-gray-700 bg-gray-800'}`}
                >
                  <Film className="w-8 h-8 mx-auto mb-2 text-white" />
                  <p className="text-white font-medium">Film</p>
                </button>
                <button
                  onClick={() => setType('series')}
                  className={`p-4 rounded-xl border-2 transition-all ${type === 'series' ? 'border-red-500 bg-red-500/10' : 'border-gray-700 bg-gray-800'}`}
                >
                  <Tv className="w-8 h-8 mx-auto mb-2 text-white" />
                  <p className="text-white font-medium">Série</p>
                </button>
              </div>
            </div>
            <div>
              <Label className="text-white mb-2 block">Titre</Label>
              <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Le Dernier Voyage" className="bg-gray-800 border-gray-700 text-white" />
            </div>
            <div>
              <Label className="text-white mb-2 block">Résumé</Label>
              <Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Description du film ou de la série..." className="bg-gray-800 border-gray-700 text-white" rows={3} />
            </div>
            <div>
              <Label className="text-white mb-2 block">Genre</Label>
              <Input value={genre} onChange={e => setGenre(e.target.value)} placeholder="Ex: Science-fiction, Action, Drame..." className="bg-gray-800 border-gray-700 text-white" />
            </div>
          </div>
        )}

        {/* Step 2: Video + languages */}
        {step === 2 && type === 'movie' && (
          <div className="space-y-5">
            <div>
              <Label className="text-white mb-2 block">Vidéo principale</Label>
              {mainVideoUrl ? (
                <div className="p-3 bg-green-900/20 border border-green-700 rounded-lg flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-white flex-1 truncate">Vidéo importée</span>
                  <button onClick={() => setMainVideoUrl('')} className="text-red-400"><Trash2 className="w-4 h-4" /></button>
                </div>
              ) : (
                <label className="block">
                  <div className="p-6 border-2 border-dashed border-gray-700 rounded-lg text-center cursor-pointer hover:border-gray-500">
                    {uploading ? <Loader2 className="w-8 h-8 mx-auto mb-2 animate-spin text-gray-400" /> : <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />}
                    <p className="text-sm text-gray-400">Cliquez pour importer la vidéo</p>
                  </div>
                  <input type="file" accept="video/*" className="hidden" onChange={e => handleVideoUpload(e, setMainVideoUrl)} />
                </label>
              )}
            </div>
            <div>
              <Label className="text-white mb-2 block">Langue de la vidéo principale</Label>
              <select value={mainLanguage} onChange={e => setMainLanguage(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white">
                {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
            {/* Language versions */}
            <div>
              <Label className="text-white mb-2 block">Versions dans d'autres langues</Label>
              <LanguageVersionUploader onAdd={(lang, url) => addLanguageVersion(lang, url)} uploading={uploading} />
              {languageVersions.map((lv, i) => (
                <div key={i} className="flex items-center gap-2 p-2 bg-gray-800 rounded-lg mt-2">
                  <Globe className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-white flex-1">{lv.language}</span>
                  <button onClick={() => setLanguageVersions(prev => prev.filter((_, idx) => idx !== i))} className="text-red-400">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 2 for series: episodes */}
        {step === 2 && type === 'series' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-white">Épisodes ({episodes.length})</Label>
              <Button size="sm" onClick={addEpisode} className="bg-red-600 hover:bg-red-700 gap-1">
                <Plus className="w-4 h-4" /> Ajouter un épisode
              </Button>
            </div>
            {episodes.map((ep, idx) => (
              <div key={idx} className="p-4 bg-gray-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-white">Saison {ep.season} — Épisode {ep.episode_number}</span>
                  <button onClick={() => removeEpisode(idx)} className="text-red-400"><Trash2 className="w-4 h-4" /></button>
                </div>
                <Input value={ep.title} onChange={e => updateEpisode(idx, 'title', e.target.value)} placeholder="Titre de l'épisode" className="bg-gray-700 border-gray-600 text-white" />
                <div className="flex gap-2">
                  <select
                    value={ep.season}
                    onChange={e => updateEpisode(idx, 'season', parseInt(e.target.value))}
                    className="w-24 px-2 py-2 rounded-lg bg-gray-700 border border-gray-600 text-white text-sm"
                  >
                    {Array.from({ length: 10 }, (_, i) => i + 1).map(s => <option key={s} value={s}>S{s}</option>)}
                  </select>
                  <select
                    value={ep.main_language}
                    onChange={e => updateEpisode(idx, 'main_language', e.target.value)}
                    className="flex-1 px-2 py-2 rounded-lg bg-gray-700 border border-gray-600 text-white text-sm"
                  >
                    {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
                {ep.video_url ? (
                  <div className="p-2 bg-green-900/20 border border-green-700 rounded-lg flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-white flex-1">Vidéo importée</span>
                    <button onClick={() => updateEpisode(idx, 'video_url', '')} className="text-red-400"><Trash2 className="w-3 h-3" /></button>
                  </div>
                ) : (
                  <label className="block">
                    <div className="p-3 border-2 border-dashed border-gray-600 rounded-lg text-center cursor-pointer hover:border-gray-400">
                      {uploading ? <Loader2 className="w-5 h-5 mx-auto animate-spin text-gray-400" /> : <Upload className="w-5 h-5 mx-auto text-gray-400" />}
                      <p className="text-xs text-gray-400 mt-1">Importer la vidéo</p>
                    </div>
                    <input type="file" accept="video/*" className="hidden" onChange={e => handleVideoUpload(e, url => updateEpisode(idx, 'video_url', url))} />
                  </label>
                )}
              </div>
            ))}
            {episodes.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Tv className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Ajoutez votre premier épisode</p>
              </div>
            )}
          </div>
        )}

        {/* Step 3: Subtitles + sequel */}
        {step === 3 && (
          <div className="space-y-5">
            {type === 'movie' && (
              <>
                <div>
                  <Label className="text-white mb-2 block">Sous-titres (texte)</Label>
                  <Textarea
                    value={subtitleText}
                    onChange={e => setSubtitleText(e.target.value)}
                    placeholder="Collez le texte des sous-titres ici. Une ligne = un sous-titre. La synchronisation se fait automatiquement."
                    className="bg-gray-800 border-gray-700 text-white"
                    rows={5}
                  />
                </div>
                <div>
                  <Label className="text-white mb-2 block">Langue des sous-titres</Label>
                  <select value={subtitleLang} onChange={e => setSubtitleLang(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white">
                    {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
                {subtitleText.trim() && (
                  <div>
                    <Label className="text-white mb-2 block">Traduire automatiquement en</Label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {LANGUAGES.filter(l => l !== subtitleLang).map(l => (
                        <button
                          key={l}
                          onClick={() => setTranslateSubs(prev => prev.includes(l) ? prev.filter(x => x !== l) : [...prev, l])}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium ${translateSubs.includes(l) ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-400'}`}
                        >
                          {l}
                        </button>
                      ))}
                    </div>
                    {translateSubs.length > 0 && (
                      <Button size="sm" onClick={handleTranslateSubs} disabled={translating} className="gap-2">
                        {translating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Languages className="w-4 h-4" />}
                        Traduire en {translateSubs.length} langue(s)
                      </Button>
                    )}
                  </div>
                )}
                <div>
                  <Label className="text-white mb-2 block">Suite d'un autre film (optionnel)</Label>
                  <select value={parentContentId} onChange={e => setParentContentId(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white">
                    <option value="">Aucune (film indépendant)</option>
                    {existingMovies.map(m => <option key={m.id} value={m.id}>{m.title}</option>)}
                  </select>
                </div>
              </>
            )}
            {type === 'series' && (
              <div className="text-center py-12 text-gray-500">
                <Subtitles className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Les sous-titres et versions linguistiques des épisodes peuvent être gérés après publication.</p>
              </div>
            )}
          </div>
        )}

        {/* Step 4: Images + exclusive + publish */}
        {step === 4 && (
          <div className="space-y-5">
            <div>
              <Label className="text-white mb-2 block">Affiche principale</Label>
              {posterUrl ? (
                <div className="relative">
                  <img src={posterUrl} alt="Affiche" className="w-32 h-44 rounded-lg object-cover" />
                  <button onClick={() => setPosterUrl('')} className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ) : (
                <label className="block">
                  <div className="p-6 border-2 border-dashed border-gray-700 rounded-lg text-center cursor-pointer hover:border-gray-500">
                    {uploading ? <Loader2 className="w-8 h-8 mx-auto mb-2 animate-spin text-gray-400" /> : <Image className="w-8 h-8 mx-auto mb-2 text-gray-400" />}
                    <p className="text-sm text-gray-400">Importer l'affiche</p>
                  </div>
                  <input type="file" accept="image/*" className="hidden" onChange={e => handleVideoUpload(e, setPosterUrl)} />
                </label>
              )}
            </div>
            <div>
              <Label className="text-white mb-2 block">Image mise en avant (optionnel)</Label>
              {featuredImageUrl ? (
                <div className="relative">
                  <img src={featuredImageUrl} alt="Mise en avant" className="w-full h-32 rounded-lg object-cover" />
                  <button onClick={() => setFeaturedImageUrl('')} className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ) : (
                <label className="block">
                  <div className="p-4 border-2 border-dashed border-gray-700 rounded-lg text-center cursor-pointer hover:border-gray-500">
                    {uploading ? <Loader2 className="w-5 h-5 mx-auto animate-spin text-gray-400" /> : <Image className="w-5 h-5 mx-auto text-gray-400" />}
                    <p className="text-xs text-gray-400 mt-1">Importer l'image de mise en avant</p>
                  </div>
                  <input type="file" accept="image/*" className="hidden" onChange={e => handleVideoUpload(e, setFeaturedImageUrl)} />
                </label>
              )}
            </div>
            <div className={`p-4 rounded-xl border-2 transition-all ${isExclusivePlus ? 'border-yellow-500 bg-yellow-500/10' : 'border-gray-700 bg-gray-800'}`}>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={isExclusivePlus} onChange={e => setIsExclusivePlus(e.target.checked)} className="w-5 h-5" />
                <div className="flex-1">
                  <p className="text-white font-medium flex items-center gap-2">
                    <Crown className="w-4 h-4 text-yellow-500" /> Exclusivité Mykel TV +
                  </p>
                  <p className="text-xs text-gray-500">Ce contenu sera exclusivement accessible aux abonnés TV +</p>
                </div>
              </label>
            </div>
          </div>
        )}
      </div>

      {/* Footer navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 p-4 flex items-center justify-between max-w-2xl mx-auto">
        <Button variant="outline" onClick={() => step > 1 ? setStep(step - 1) : onClose()} className="gap-1">
          <ChevronLeft className="w-4 h-4" /> {step > 1 ? 'Retour' : 'Annuler'}
        </Button>
        {step < 4 ? (
          <Button onClick={() => setStep(step + 1)} disabled={!canNext() || uploading} className="bg-red-600 hover:bg-red-700 gap-1">
            Suivant <ChevronRight className="w-4 h-4" />
          </Button>
        ) : (
          <Button onClick={handlePublish} disabled={!canNext() || publishing || uploading} className="bg-green-600 hover:bg-green-700 gap-2">
            {publishing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Publier
          </Button>
        )}
      </div>
    </div>
  );
}

function LanguageVersionUploader({ onAdd, uploading }) {
  const [lang, setLang] = useState('English');
  const [url, setUrl] = useState('');

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await uploadMedia(file);
    setUrl(file_url);
  };

  return (
    <div className="flex gap-2">
      <select value={lang} onChange={e => setLang(e.target.value)} className="px-2 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white text-sm">
        {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
      </select>
      <label className="flex-1 cursor-pointer">
        <div className="px-3 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white text-sm text-center hover:bg-gray-700">
          {url ? `✓ ${lang}` : uploading ? 'Import...' : 'Importer vidéo'}
        </div>
        <input type="file" accept="video/*" className="hidden" onChange={handleUpload} />
      </label>
      <Button size="sm" onClick={() => { onAdd(lang, url); setUrl(''); }} disabled={!url} className="bg-gray-700 hover:bg-gray-600">
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );
}