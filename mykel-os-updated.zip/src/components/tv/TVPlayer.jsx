import React, { useState, useEffect, useRef, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Play, Pause, SkipForward, SkipBack, Maximize, Minimize,
  Globe, Subtitles, X, ChevronDown, Volume2, VolumeX,
} from 'lucide-react';

export default function TVPlayer({ content, episode, startProgress = 0, subscriptionType, user, onClose }) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const controlsTimeout = useRef(null);
  const progressInterval = useRef(null);

  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [mediaTracks, setMediaTracks] = useState([]);
  const [subtitles, setSubtitles] = useState([]);
  const [selectedLanguage, setSelectedLanguage] = useState(episode?.main_language || content.main_language || 'Français');
  const [selectedSubtitle, setSelectedSubtitle] = useState(null);
  const [currentSubtitleText, setCurrentSubtitleText] = useState('');
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showSubMenu, setShowSubMenu] = useState(false);
  const [showAd, setShowAd] = useState(false);
  const [adData, setAdData] = useState(null);

  // Load tracks and subtitles
  useEffect(() => {
    const load = async () => {
      const filter = episode
        ? { content_id: content.id, episode_id: episode.id }
        : { content_id: content.id };
      const [tracks, subs] = await Promise.all([
        base44.entities.TVMediaTrack.filter(filter),
        base44.entities.TVSubtitle.filter(filter),
      ]);
      setMediaTracks(tracks);
      setSubtitles(subs);
    };
    load();
  }, [content, episode]);

  // Check for ads
  useEffect(() => {
    if (subscriptionType === 'ads') {
      base44.entities.Advertisement.filter({ is_active_in_tv: true, file_type: 'video' }).then(ads => {
        if (ads.length > 0) {
          setAdData(ads[Math.floor(Math.random() * ads.length)]);
          setShowAd(true);
        }
      });
    }
  }, [subscriptionType]);

  // Current video URL
  const currentVideoUrl = useMemo(() => {
    const track = mediaTracks.find(t => t.language === selectedLanguage);
    if (track) return track.video_url;
    return episode?.video_url || content.video_url;
  }, [mediaTracks, selectedLanguage, episode, content]);

  // Set start progress when video loads
  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      if (startProgress > 0 && startProgress < videoRef.current.duration) {
        videoRef.current.currentTime = startProgress;
      }
    }
  };

  // Controls
  const togglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) { videoRef.current.play(); setPlaying(true); }
      else { videoRef.current.pause(); setPlaying(false); }
    }
  };

  const skipForward = () => { if (videoRef.current) videoRef.current.currentTime += 15; };
  const skipBackward = () => { if (videoRef.current) videoRef.current.currentTime -= 15; };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setMuted(videoRef.current.muted);
    }
  };

  const seek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    if (videoRef.current) videoRef.current.currentTime = pct * duration;
  };

  // Track time
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => setCurrentTime(video.currentTime);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    video.addEventListener('timeupdate', onTime);
    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    return () => {
      video.removeEventListener('timeupdate', onTime);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
    };
  }, [currentVideoUrl]);

  // Save watch progress
  const progressRecRef = useRef({ key: null, id: null });
  useEffect(() => {
    progressInterval.current = setInterval(async () => {
      if (videoRef.current && playing && user?.email) {
        const t = videoRef.current.currentTime;
        const d = videoRef.current.duration;
        if (!d) return;
        try {
          // Un seul enregistrement par contenu : on mémorise son id pour éviter
          // une lecture à chaque sauvegarde de progression
          const key = `${content.id}:${episode?.id || ''}`;
          if (progressRecRef.current.key !== key) {
            const found = await base44.entities.TVWatchProgress.filter({
              user_email: user.email,
              content_id: content.id,
              episode_id: episode?.id || null,
            });
            progressRecRef.current = { key, id: found[0]?.id || null };
          }
          const existing = progressRecRef.current.id ? [{ id: progressRecRef.current.id }] : [];
          const data = {
            progress_seconds: t,
            duration_seconds: d,
            last_watched: new Date().toISOString(),
            completed: t / d > 0.95,
          };
          if (existing.length > 0) {
            await base44.entities.TVWatchProgress.update(existing[0].id, data);
          } else {
            const created = await base44.entities.TVWatchProgress.create({
              user_email: user.email,
              content_id: content.id,
              episode_id: episode?.id || null,
              ...data,
            });
            progressRecRef.current = { key, id: created.id };
          }
        } catch {}
      }
    }, 10000);
    return () => clearInterval(progressInterval.current);
  }, [playing, user, content, episode]);

  // Subtitle sync
  useEffect(() => {
    if (!selectedSubtitle) { setCurrentSubtitleText(''); return; }
    const sub = subtitles.find(s => s.language === selectedSubtitle);
    if (!sub || !duration) return;
    const segments = sub.subtitle_text.split('\n').filter(s => s.trim());
    if (segments.length === 0) return;
    const segDur = duration / segments.length;
    const idx = Math.min(Math.floor(currentTime / segDur), segments.length - 1);
    setCurrentSubtitleText(segments[idx] || '');
  }, [currentTime, selectedSubtitle, subtitles, duration]);

  // Auto-hide controls
  const resetControlsTimer = () => {
    setShowControls(true);
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
    controlsTimeout.current = setTimeout(() => {
      if (playing) setShowControls(false);
    }, 3000);
  };

  useEffect(() => {
    resetControlsTimer();
    return () => { if (controlsTimeout.current) clearTimeout(controlsTimeout.current); };
  }, [playing]);

  // Fullscreen change listener
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const fmt = (s) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const title = episode ? `${content.title} — S${episode.season}E${episode.episode_number}: ${episode.title}` : content.title;

  // Ad overlay
  if (showAd && adData) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col">
        <div className="flex items-center justify-between p-4 bg-gray-900">
          <span className="text-sm text-gray-400">Publicité</span>
          <span className="text-xs text-gray-500">La vidéo commence après la pub</span>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <video
            src={adData.file_url}
            autoPlay
            className="max-w-full max-h-full"
            onEnded={() => setShowAd(false)}
            controls
          />
        </div>
        <div className="p-4 bg-gray-900 flex justify-center">
          <button
            onClick={() => setShowAd(false)}
            className="text-xs text-gray-500 hover:text-gray-300 underline"
          >
            Passer la publicité
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 bg-black flex flex-col"
      onMouseMove={resetControlsTimer}
      onClick={resetControlsTimer}
    >
      {/* Video */}
      <video
        ref={videoRef}
        src={currentVideoUrl}
        className="flex-1 w-full h-full object-contain"
        onLoadedMetadata={handleLoadedMetadata}
        onClick={togglePlay}
        autoPlay
        playsInline
      />

      {/* Subtitle overlay */}
      {currentSubtitleText && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 max-w-[80%] text-center pointer-events-none">
          <span className="inline-block bg-black/80 text-white px-4 py-1.5 rounded-lg text-base sm:text-lg">
            {currentSubtitleText}
          </span>
        </div>
      )}

      {/* Controls overlay */}
      <div
        className={`absolute inset-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, transparent 20%, transparent 80%, rgba(0,0,0,0.8) 100%)' }}
      >
        {/* Top bar */}
        <div className="absolute top-0 left-0 right-0 flex items-center justify-between p-4">
          <h2 className="text-white text-base sm:text-lg font-semibold line-clamp-1">{title}</h2>
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-black/50 flex items-center justify-center hover:bg-black/70">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Center controls */}
        <div className="absolute inset-0 flex items-center justify-center gap-6">
          <button onClick={skipBackward} className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center hover:bg-black/70 text-white">
            <SkipBack className="w-6 h-6" />
          </button>
          <button onClick={togglePlay} className="w-16 h-16 rounded-full bg-white flex items-center justify-center hover:bg-gray-200">
            {playing ? <Pause className="w-8 h-8 text-black fill-black" /> : <Play className="w-8 h-8 text-black fill-black ml-1" />}
          </button>
          <button onClick={skipForward} className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center hover:bg-black/70 text-white">
            <SkipForward className="w-6 h-6" />
          </button>
        </div>

        {/* Bottom bar */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          {/* Progress bar */}
          <div className="flex items-center gap-3 mb-3">
            <span className="text-xs text-white font-mono">{fmt(currentTime)}</span>
            <div
              className="flex-1 h-1.5 bg-white/30 rounded-full cursor-pointer group relative"
              onClick={seek}
            >
              <div
                className="h-full bg-red-600 rounded-full relative"
                style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-red-600 rounded-full opacity-0 group-hover:opacity-100" />
              </div>
            </div>
            <span className="text-xs text-white font-mono">{fmt(duration)}</span>
          </div>

          {/* Control buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* Language */}
              <div className="relative">
                <button
                  onClick={(e) => { e.stopPropagation(); setShowLangMenu(!showLangMenu); setShowSubMenu(false); }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm"
                >
                  <Globe className="w-4 h-4" /> {selectedLanguage} <ChevronDown className="w-3 h-3" />
                </button>
                {showLangMenu && (
                  <div className="absolute bottom-full left-0 mb-2 bg-gray-900 rounded-lg overflow-hidden shadow-xl min-w-[150px] border border-gray-700">
                    <button
                      onClick={(e) => { e.stopPropagation(); setSelectedLanguage(episode?.main_language || content.main_language || 'Français'); setShowLangMenu(false); }}
                      className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-800 ${selectedLanguage === (episode?.main_language || content.main_language || 'Français') ? 'text-red-400' : 'text-white'}`}
                    >
                      {episode?.main_language || content.main_language || 'Français'} (Original)
                    </button>
                    {mediaTracks.map(t => (
                      <button
                        key={t.id}
                        onClick={(e) => { e.stopPropagation(); setSelectedLanguage(t.language); setShowLangMenu(false); }}
                        className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-800 ${selectedLanguage === t.language ? 'text-red-400' : 'text-white'}`}
                      >
                        {t.language}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Subtitles */}
              <div className="relative">
                <button
                  onClick={(e) => { e.stopPropagation(); setShowSubMenu(!showSubMenu); setShowLangMenu(false); }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm ${selectedSubtitle ? 'bg-red-600 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}
                >
                  <Subtitles className="w-4 h-4" /> {selectedSubtitle || 'ST'} <ChevronDown className="w-3 h-3" />
                </button>
                {showSubMenu && (
                  <div className="absolute bottom-full left-0 mb-2 bg-gray-900 rounded-lg overflow-hidden shadow-xl min-w-[150px] border border-gray-700">
                    <button
                      onClick={(e) => { e.stopPropagation(); setSelectedSubtitle(null); setShowSubMenu(false); }}
                      className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-800 ${!selectedSubtitle ? 'text-red-400' : 'text-white'}`}
                    >
                      Désactivés
                    </button>
                    {subtitles.map(s => (
                      <button
                        key={s.id}
                        onClick={(e) => { e.stopPropagation(); setSelectedSubtitle(s.language); setShowSubMenu(false); }}
                        className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-800 ${selectedSubtitle === s.language ? 'text-red-400' : 'text-white'}`}
                      >
                        {s.language}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Mute */}
              <button onClick={(e) => { e.stopPropagation(); toggleMute(); }} className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
                {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>

            {/* Fullscreen */}
            <button onClick={(e) => { e.stopPropagation(); toggleFullscreen(); }} className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}