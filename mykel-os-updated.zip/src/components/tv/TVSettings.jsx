import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { X, LifeBuoy, Film, Upload, ChevronRight, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function TVSettings({ user, isCreator, onClose, onPublish, onCreatorToggled, onGoToStore }) {
  const [creatorName, setCreatorName] = useState('');
  const [togglingCreator, setTogglingCreator] = useState(false);
  const [showCreatorForm, setShowCreatorForm] = useState(false);

  const handleToggleCreator = async () => {
    if (isCreator) {
      // Deactivate creator
      setTogglingCreator(true);
      try {
        const profiles = await base44.entities.TVCreatorProfile.filter({ user_email: user.email, active: true });
        for (const p of profiles) {
          await base44.entities.TVCreatorProfile.update(p.id, { active: false });
        }
        onCreatorToggled();
        toast.success('Mode créateur désactivé');
      } catch { toast.error('Erreur'); }
      finally { setTogglingCreator(false); }
    } else {
      setShowCreatorForm(true);
    }
  };

  const handleCreateCreator = async () => {
    if (!creatorName.trim()) { toast.error('Entrez un nom de créateur'); return; }
    setTogglingCreator(true);
    try {
      await base44.entities.TVCreatorProfile.create({
        user_email: user.email,
        stage_name: creatorName.trim(),
        active: true,
      });
      setShowCreatorForm(false);
      onCreatorToggled();
      toast.success('Mode créateur activé !');
    } catch { toast.error('Erreur'); }
    finally { setTogglingCreator(false); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-gray-900 rounded-2xl w-full max-w-md overflow-hidden" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800">
          <h2 className="text-lg font-bold text-white">Paramètres</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-gray-800 flex items-center justify-center">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          {/* Support */}
          <button
            onClick={() => { onClose(); window.location.href = '/ReportBug'; }}
            className="w-full flex items-center gap-3 p-3 rounded-xl bg-gray-800 hover:bg-gray-700 transition-colors text-left"
          >
            <LifeBuoy className="w-5 h-5 text-blue-400" />
            <div className="flex-1">
              <p className="text-sm font-medium text-white">Support</p>
              <p className="text-xs text-gray-500">Signaler un problème ou obtenir de l'aide</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>

          {/* Subscription */}
          <button
            onClick={onGoToStore}
            className="w-full flex items-center gap-3 p-3 rounded-xl bg-gray-800 hover:bg-gray-700 transition-colors text-left"
          >
            <Film className="w-5 h-5 text-red-400" />
            <div className="flex-1">
              <p className="text-sm font-medium text-white">Abonnements Mykel TV</p>
              <p className="text-xs text-gray-500">Gérer votre abonnement TV</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>

          {/* Creator toggle */}
          <div className="p-3 rounded-xl bg-gray-800">
            <div className="flex items-center gap-3">
              <Upload className="w-5 h-5 text-purple-400" />
              <div className="flex-1">
                <p className="text-sm font-medium text-white">Mode créateur</p>
                <p className="text-xs text-gray-500">Publier films et séries sur Mykel TV</p>
              </div>
              <button
                onClick={handleToggleCreator}
                disabled={togglingCreator}
                className={`w-11 h-6 rounded-full transition-colors relative ${isCreator ? 'bg-green-500' : 'bg-gray-600'}`}
              >
                <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${isCreator ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>

            {isCreator && (
              <button
                onClick={onPublish}
                className="w-full mt-3 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-semibold hover:opacity-90 transition-opacity"
              >
                <Upload className="w-4 h-4" /> Publier un film ou une série
              </button>
            )}
          </div>

          {/* Creator form */}
          {showCreatorForm && (
            <div className="p-3 rounded-xl bg-purple-900/20 border border-purple-700">
              <p className="text-sm font-medium text-white mb-2">Nom de créateur</p>
              <input
                value={creatorName}
                onChange={e => setCreatorName(e.target.value)}
                placeholder="Ex: Studio Mykel"
                className="w-full px-3 py-2 rounded-lg bg-gray-800 text-white text-sm border border-gray-700 mb-2"
              />
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1" onClick={() => setShowCreatorForm(false)}>Annuler</Button>
                <Button size="sm" className="flex-1 bg-purple-600 hover:bg-purple-700" onClick={handleCreateCreator} disabled={togglingCreator}>
                  {togglingCreator ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Activer
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}