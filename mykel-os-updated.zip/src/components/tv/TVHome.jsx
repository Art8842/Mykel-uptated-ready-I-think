import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Play, Info, Crown } from 'lucide-react';

export default function TVHome({ user, subscriptionType, onContentClick }) {
  const [featured, setFeatured] = useState(null);
  const [movies, setMovies] = useState([]);
  const [series, setSeries] = useState([]);
  const [watchProgress, setWatchProgress] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [allContent, progressData] = await Promise.all([
        base44.entities.TVContent.filter({ published: true }, '-publish_date', 50),
        user?.email ? base44.entities.TVWatchProgress.filter({ user_email: user.email }, '-last_watched', 20) : Promise.resolve([]),
      ]);

      const featuredItem = allContent.find(c => c.is_featured) || allContent[0];
      setFeatured(featuredItem);
      setMovies(allContent.filter(c => c.content_type === 'movie'));
      setSeries(allContent.filter(c => c.content_type === 'series'));
      setWatchProgress(progressData.filter(p => !p.completed));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-4 border-gray-700 border-t-red-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="pb-4">
      {/* Featured hero */}
      {featured && (
        <div className="relative h-64 sm:h-80 md:h-96 overflow-hidden">
          <img src={featured.featured_image_url || featured.poster_url} alt={featured.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6">
            <span className="inline-block px-2 py-0.5 bg-red-600 text-white text-xs font-bold rounded mb-2">À LA UNE</span>
            <h2 className="text-2xl sm:text-3xl font-black mb-2">{featured.title}</h2>
            <p className="text-sm text-gray-300 line-clamp-2 mb-3 max-w-xl">{featured.description}</p>
            <div className="flex gap-2">
              <button
                onClick={() => onContentClick(featured)}
                className="flex items-center gap-2 px-5 py-2 bg-white text-black rounded-lg font-semibold text-sm hover:bg-gray-200 transition-colors"
              >
                <Play className="w-4 h-4 fill-black" /> Regarder
              </button>
              <button
                onClick={() => onContentClick(featured)}
                className="flex items-center gap-2 px-5 py-2 bg-gray-700/80 text-white rounded-lg font-semibold text-sm hover:bg-gray-600 transition-colors"
              >
                <Info className="w-4 h-4" /> Plus d'infos
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Continue watching */}
      {watchProgress.length > 0 && (
        <ContentRow
          title="Reprendre la lecture"
          items={watchProgress.map(p => {
            const content = [...movies, ...series].find(c => c.id === p.content_id);
            return content ? { ...content, progress: p } : null;
          }).filter(Boolean)}
          onContentClick={onContentClick}
        />
      )}

      {/* Popular movies */}
      {movies.length > 0 && (
        <ContentRow title="Films populaires" items={movies} onContentClick={onContentClick} />
      )}

      {/* Popular series */}
      {series.length > 0 && (
        <ContentRow title="Séries populaires" items={series} onContentClick={onContentClick} />
      )}

      {/* Exclusive TV+ */}
      {[...movies, ...series].filter(c => c.is_exclusive_plus).length > 0 && (
        <ContentRow
          title="Exclusivités TV +"
          items={[...movies, ...series].filter(c => c.is_exclusive_plus)}
          onContentClick={onContentClick}
          exclusive
        />
      )}
    </div>
  );
}

function ContentRow({ title, items, onContentClick, exclusive }) {
  return (
    <div className="mt-6 px-4">
      <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
        {exclusive && <Crown className="w-5 h-5 text-yellow-500" />}
        {title}
      </h3>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {items.map(item => (
          <button
            key={item.id}
            onClick={() => onContentClick(item)}
            className="flex-shrink-0 w-28 sm:w-32 group"
          >
            <div className="relative w-28 h-40 sm:w-32 sm:h-44 rounded-lg overflow-hidden bg-gray-800">
              <img src={item.poster_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              {item.is_exclusive_plus && (
                <div className="absolute top-1 right-1 bg-yellow-500 text-black text-xs font-bold px-1.5 py-0.5 rounded">+</div>
              )}
              {item.progress && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-600">
                  <div className="h-full bg-red-600" style={{ width: `${(item.progress.progress_seconds / item.progress.duration_seconds) * 100}%` }} />
                </div>
              )}
            </div>
            <p className="text-xs font-medium mt-1.5 line-clamp-1 text-left">{item.title}</p>
          </button>
        ))}
      </div>
    </div>
  );
}