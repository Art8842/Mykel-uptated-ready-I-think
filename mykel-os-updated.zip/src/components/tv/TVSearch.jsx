import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, X, Crown } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function TVSearch({ user, subscriptionType, onContentClick }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [allContent, setAllContent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.TVContent.filter({ published: true }, '-publish_date', 100)
      .then(data => { setAllContent(data); setResults(data); })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!query.trim()) { setResults(allContent); return; }
    const q = query.toLowerCase();
    setResults(allContent.filter(c =>
      c.title?.toLowerCase().includes(q) ||
      c.genre?.toLowerCase().includes(q) ||
      c.description?.toLowerCase().includes(q)
    ));
  }, [query, allContent]);

  return (
    <div className="p-4">
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
        <Input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Rechercher un film, une série, un genre..."
          className="pl-10 pr-10 h-12 rounded-full bg-gray-800 border-gray-700 text-white placeholder-gray-500"
        />
        {query && (
          <button onClick={() => setQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="w-8 h-8 border-4 border-gray-700 border-t-red-500 rounded-full animate-spin" />
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-20 text-gray-500">
          <Search className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Aucun résultat pour "{query}"</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
          {results.map(item => (
            <button
              key={item.id}
              onClick={() => onContentClick(item)}
              className="group text-left"
            >
              <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-gray-800">
                <img src={item.poster_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                {item.is_exclusive_plus && (
                  <div className="absolute top-1 right-1 bg-yellow-500 text-black text-xs font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5">
                    <Crown className="w-2.5 h-2.5" />+
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                  <span className="text-xs text-gray-300">{item.content_type === 'movie' ? 'Film' : 'Série'}</span>
                </div>
              </div>
              <p className="text-xs font-medium mt-1.5 line-clamp-1">{item.title}</p>
              {item.genre && <p className="text-xs text-gray-500 line-clamp-1">{item.genre}</p>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}