import React from 'react';
import { 
  MousePointer, Pencil, Brush, Eraser, 
  Square, Circle, Minus, Type, Image,
  Palette, Undo, Redo, Trash2,
  Save, Download, Share2, ZoomIn, ZoomOut,
  Pipette, Move, RotateCcw
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const colors = [
  '#000000', '#434343', '#666666', '#999999', '#ffffff',
  '#ff0000', '#ff4500', '#ff6347', '#ff7f50', '#ffa500',
  '#ffff00', '#9acd32', '#32cd32', '#00ff00', '#00fa9a',
  '#00ffff', '#00bfff', '#1e90ff', '#0000ff', '#4b0082',
  '#8b00ff', '#9400d3', '#ff00ff', '#ff1493', '#ff69b4',
  '#8b4513', '#a0522d', '#d2691e', '#deb887', '#f5deb3'
];

const tools = [
  { id: 'select', icon: MousePointer, label: 'Sélection' },
  { id: 'pencil', icon: Pencil, label: 'Crayon' },
  { id: 'brush', icon: Brush, label: 'Pinceau' },
  { id: 'eraser', icon: Eraser, label: 'Gomme' },
  { id: 'line', icon: Minus, label: 'Ligne' },
  { id: 'rectangle', icon: Square, label: 'Rectangle' },
  { id: 'circle', icon: Circle, label: 'Cercle' },
  { id: 'text', icon: Type, label: 'Texte' },
];

export default function DrawToolbar({ 
  currentTool,
  onToolChange,
  currentColor,
  onColorChange,
  currentFillColor,
  onFillColorChange,
  strokeWidth,
  onStrokeWidthChange,
  onUndo,
  onRedo,
  onClear,
  onSave,
  onExport,
  onShare,
  canUndo,
  canRedo,
  saving,
  canvasBackground,
  onBackgroundChange
}) {
  return (
    <div className="bg-white border-b border-gray-200">
      {/* Menu Bar */}
      <div className="flex items-center px-2 py-1 border-b border-gray-100 text-sm overflow-x-auto flex-nowrap scrollbar-hide">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Fichier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onSave} className="gap-2">
              <Save className="w-4 h-4" /> Enregistrer
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onExport('png')} className="gap-2">
              <Download className="w-4 h-4" /> Exporter en PNG
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onExport('svg')} className="gap-2">
              <Download className="w-4 h-4" /> Exporter en SVG
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Modifier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onUndo} disabled={!canUndo} className="gap-2">
              <Undo className="w-4 h-4" /> Annuler
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onRedo} disabled={!canRedo} className="gap-2">
              <Redo className="w-4 h-4" /> Rétablir
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onClear} className="gap-2 text-red-600">
              <Trash2 className="w-4 h-4" /> Tout effacer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={onShare} className="h-7 gap-1">
            <Share2 className="w-4 h-4" />
            Partager
          </Button>
          <Button 
            variant="default" 
            size="sm" 
            onClick={onSave}
            disabled={saving}
            className="h-7 bg-purple-600 hover:bg-purple-700"
          >
            {saving ? 'Enregistrement...' : 'Enregistrer'}
          </Button>
        </div>
      </div>

      {/* Tools Toolbar */}
      <div className="flex items-center gap-1 px-2 py-2 overflow-x-auto flex-nowrap scrollbar-hide">
        {/* Undo/Redo */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 w-9 p-0"
                onClick={onUndo}
                disabled={!canUndo}
              >
                <Undo className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Annuler</TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 w-9 p-0"
                onClick={onRedo}
                disabled={!canRedo}
              >
                <Redo className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Rétablir</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <Separator orientation="vertical" className="h-8 mx-2" />

        {/* Tools */}
        {tools.map((tool) => (
          <TooltipProvider key={tool.id}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={currentTool === tool.id ? "secondary" : "ghost"}
                  size="sm"
                  className={`h-9 w-9 p-0 ${currentTool === tool.id ? 'bg-purple-100 text-purple-700' : ''}`}
                  onClick={() => onToolChange(tool.id)}
                >
                  <tool.icon className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>{tool.label}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ))}
        
        <Separator orientation="vertical" className="h-8 mx-2" />

        {/* Stroke Color */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-9 w-9 p-0 relative">
              <div 
                className="w-5 h-5 rounded border border-gray-300"
                style={{ backgroundColor: currentColor }}
              />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur du trait</p>
            <div className="grid grid-cols-6 gap-1">
              {colors.map(color => (
                <button
                  key={color}
                  className={`w-6 h-6 rounded border transition-transform hover:scale-110 ${
                    currentColor === color ? 'ring-2 ring-purple-500 ring-offset-1' : 'border-gray-300'
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => onColorChange(color)}
                />
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Fill Color */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-9 w-12 p-0 relative gap-1">
              <Palette className="w-3 h-3" />
              <div 
                className="w-4 h-4 rounded border border-gray-300"
                style={{ backgroundColor: currentFillColor || 'transparent' }}
              />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur de remplissage</p>
            <button
              className={`w-full py-1 px-2 mb-2 text-sm rounded border ${
                !currentFillColor ? 'border-purple-500 bg-purple-50' : 'border-gray-300'
              }`}
              onClick={() => onFillColorChange(null)}
            >
              Transparent
            </button>
            <div className="grid grid-cols-6 gap-1">
              {colors.map(color => (
                <button
                  key={color}
                  className={`w-6 h-6 rounded border transition-transform hover:scale-110 ${
                    currentFillColor === color ? 'ring-2 ring-purple-500 ring-offset-1' : 'border-gray-300'
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => onFillColorChange(color)}
                />
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Background Color */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-9 px-2 gap-1">
              <span className="text-xs">Fond</span>
              <div 
                className="w-4 h-4 rounded border border-gray-300"
                style={{ backgroundColor: canvasBackground || '#ffffff' }}
              />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur de fond</p>
            <div className="grid grid-cols-6 gap-1">
              {colors.map(color => (
                <button
                  key={color}
                  className={`w-6 h-6 rounded border transition-transform hover:scale-110 ${
                    canvasBackground === color ? 'ring-2 ring-purple-500 ring-offset-1' : 'border-gray-300'
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => onBackgroundChange(color)}
                />
              ))}
            </div>
          </PopoverContent>
        </Popover>
        
        <Separator orientation="vertical" className="h-8 mx-2" />

        {/* Stroke Width */}
        <div className="flex items-center gap-2 px-2">
          <span className="text-xs text-gray-500">Épaisseur:</span>
          <Slider
            value={[strokeWidth]}
            onValueChange={([value]) => onStrokeWidthChange(value)}
            min={1}
            max={50}
            step={1}
            className="w-24"
          />
          <span className="text-xs text-gray-600 w-6">{strokeWidth}</span>
        </div>
        
        <Separator orientation="vertical" className="h-8 mx-2" />

        {/* Clear */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 w-9 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                onClick={onClear}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Tout effacer</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
}