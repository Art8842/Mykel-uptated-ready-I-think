import React, { useState, useRef, useEffect } from 'react';
import { cn } from "@/lib/utils";
import { promptAction } from '@/lib/confirm';

export default function DrawCanvas({ 
  elements,
  currentTool,
  currentColor,
  currentStrokeWidth,
  currentFillColor,
  onAddElement,
  onUpdateElement,
  onSelectElement,
  selectedElement,
  canvasBackground
}) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState([]);
  const [startPoint, setStartPoint] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const getMousePos = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = 1200 / rect.width;
    const scaleY = 800 / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  };

  const handleMouseDown = (e) => {
    const pos = getMousePos(e);
    
    if (currentTool === 'select') {
      // Check if clicking on an element
      const clickedElement = [...elements].reverse().find(el => {
        if (el.type === 'path') {
          // Simple bounding box check for paths
          const points = el.points;
          if (points.length === 0) return false;
          const minX = Math.min(...points.map(p => p.x));
          const maxX = Math.max(...points.map(p => p.x));
          const minY = Math.min(...points.map(p => p.y));
          const maxY = Math.max(...points.map(p => p.y));
          return pos.x >= minX - 10 && pos.x <= maxX + 10 && pos.y >= minY - 10 && pos.y <= maxY + 10;
        }
        return pos.x >= el.x && pos.x <= el.x + el.width && 
               pos.y >= el.y && pos.y <= el.y + el.height;
      });
      
      if (clickedElement) {
        onSelectElement(clickedElement.id);
        setIsDragging(true);
        setDragOffset({ x: pos.x - (clickedElement.x || 0), y: pos.y - (clickedElement.y || 0) });
      } else {
        onSelectElement(null);
      }
      return;
    }
    
    setIsDrawing(true);
    setStartPoint(pos);
    
    if (currentTool === 'pencil' || currentTool === 'brush' || currentTool === 'eraser') {
      setCurrentPath([pos]);
    }
  };

  const handleMouseMove = (e) => {
    const pos = getMousePos(e);
    
    if (isDragging && selectedElement) {
      const element = elements.find(el => el.id === selectedElement);
      if (element) {
        onUpdateElement(selectedElement, {
          x: pos.x - dragOffset.x,
          y: pos.y - dragOffset.y
        });
      }
      return;
    }
    
    if (!isDrawing) return;
    
    if (currentTool === 'pencil' || currentTool === 'brush' || currentTool === 'eraser') {
      setCurrentPath(prev => [...prev, pos]);
    }
  };

  const handleMouseUp = (e) => {
    if (isDragging) {
      setIsDragging(false);
      return;
    }
    
    if (!isDrawing) return;
    
    const pos = getMousePos(e);
    const id = Date.now().toString();
    
    if (currentTool === 'pencil' || currentTool === 'brush') {
      if (currentPath.length > 1) {
        onAddElement({
          id,
          type: 'path',
          points: currentPath,
          color: currentColor,
          strokeWidth: currentTool === 'brush' ? currentStrokeWidth * 2 : currentStrokeWidth
        });
      }
    } else if (currentTool === 'eraser') {
      // For eraser, draw with background color
      if (currentPath.length > 1) {
        onAddElement({
          id,
          type: 'path',
          points: currentPath,
          color: canvasBackground || '#ffffff',
          strokeWidth: currentStrokeWidth * 3
        });
      }
    } else if (currentTool === 'rectangle') {
      const width = pos.x - startPoint.x;
      const height = pos.y - startPoint.y;
      onAddElement({
        id,
        type: 'rectangle',
        x: width > 0 ? startPoint.x : pos.x,
        y: height > 0 ? startPoint.y : pos.y,
        width: Math.abs(width),
        height: Math.abs(height),
        color: currentColor,
        fillColor: currentFillColor,
        strokeWidth: currentStrokeWidth
      });
    } else if (currentTool === 'circle') {
      const width = pos.x - startPoint.x;
      const height = pos.y - startPoint.y;
      onAddElement({
        id,
        type: 'circle',
        x: width > 0 ? startPoint.x : pos.x,
        y: height > 0 ? startPoint.y : pos.y,
        width: Math.abs(width),
        height: Math.abs(height),
        color: currentColor,
        fillColor: currentFillColor,
        strokeWidth: currentStrokeWidth
      });
    } else if (currentTool === 'line') {
      onAddElement({
        id,
        type: 'line',
        x1: startPoint.x,
        y1: startPoint.y,
        x2: pos.x,
        y2: pos.y,
        color: currentColor,
        strokeWidth: currentStrokeWidth
      });
    } else if (currentTool === 'text') {
      promptAction({ title: 'Entrez le texte', placeholder: 'Votre texte…', confirmLabel: 'Ajouter' }).then((text) => {
        if (text) {
          onAddElement({ id, type: 'text', x: pos.x, y: pos.y, text, color: currentColor, fontSize: 24 });
        }
      });
    }
    
    setIsDrawing(false);
    setCurrentPath([]);
    setStartPoint(null);
  };

  const renderElement = (element) => {
    const isSelected = selectedElement === element.id;
    
    switch (element.type) {
      case 'path':
        if (element.points.length < 2) return null;
        const pathD = element.points.reduce((acc, point, i) => {
          return acc + (i === 0 ? `M ${point.x} ${point.y}` : ` L ${point.x} ${point.y}`);
        }, '');
        return (
          <path
            key={element.id}
            d={pathD}
            stroke={element.color}
            strokeWidth={element.strokeWidth}
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={cn(isSelected && "filter drop-shadow-lg")}
          />
        );
        
      case 'rectangle':
        return (
          <rect
            key={element.id}
            x={element.x}
            y={element.y}
            width={element.width}
            height={element.height}
            stroke={element.color}
            strokeWidth={element.strokeWidth}
            fill={element.fillColor || 'transparent'}
            className={cn(isSelected && "filter drop-shadow-lg")}
          />
        );
        
      case 'circle':
        return (
          <ellipse
            key={element.id}
            cx={element.x + element.width / 2}
            cy={element.y + element.height / 2}
            rx={element.width / 2}
            ry={element.height / 2}
            stroke={element.color}
            strokeWidth={element.strokeWidth}
            fill={element.fillColor || 'transparent'}
            className={cn(isSelected && "filter drop-shadow-lg")}
          />
        );
        
      case 'line':
        return (
          <line
            key={element.id}
            x1={element.x1}
            y1={element.y1}
            x2={element.x2}
            y2={element.y2}
            stroke={element.color}
            strokeWidth={element.strokeWidth}
            strokeLinecap="round"
            className={cn(isSelected && "filter drop-shadow-lg")}
          />
        );
        
      case 'text':
        return (
          <text
            key={element.id}
            x={element.x}
            y={element.y}
            fill={element.color}
            fontSize={element.fontSize}
            fontFamily="Arial"
            className={cn(isSelected && "filter drop-shadow-lg")}
          >
            {element.text}
          </text>
        );
        
      default:
        return null;
    }
  };

  const renderCurrentDrawing = () => {
    if (!isDrawing || !startPoint) return null;
    
    if ((currentTool === 'pencil' || currentTool === 'brush' || currentTool === 'eraser') && currentPath.length > 1) {
      const pathD = currentPath.reduce((acc, point, i) => {
        return acc + (i === 0 ? `M ${point.x} ${point.y}` : ` L ${point.x} ${point.y}`);
      }, '');
      return (
        <path
          d={pathD}
          stroke={currentTool === 'eraser' ? (canvasBackground || '#ffffff') : currentColor}
          strokeWidth={currentTool === 'eraser' ? currentStrokeWidth * 3 : (currentTool === 'brush' ? currentStrokeWidth * 2 : currentStrokeWidth)}
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity={0.7}
        />
      );
    }
    
    return null;
  };

  return (
    <div className="flex-1 flex items-center justify-center bg-gray-300 p-2 md:p-8 overflow-auto">
      <div 
        className="relative shadow-2xl w-full max-w-full"
        style={{ backgroundColor: canvasBackground || '#ffffff' }}
      >
        <svg
          ref={canvasRef}
          width="100%"
          height="100%"
          viewBox="0 0 1200 800"
          preserveAspectRatio="xMidYMid meet"
          className={cn(
            "cursor-crosshair",
            currentTool === 'select' && "cursor-default"
          )}
          onPointerDown={handleMouseDown}
          onPointerMove={handleMouseMove}
          onPointerUp={handleMouseUp}
          onPointerLeave={handleMouseUp}
          style={{ backgroundColor: canvasBackground || '#ffffff', touchAction: 'none' }}
        >
          {elements.map(renderElement)}
          {renderCurrentDrawing()}
          
          {/* Selection box */}
          {selectedElement && (() => {
            const el = elements.find(e => e.id === selectedElement);
            if (!el || el.type === 'path' || el.type === 'line') return null;
            return (
              <rect
                x={el.x - 4}
                y={el.y - 4}
                width={(el.width || 0) + 8}
                height={(el.height || 0) + 8}
                fill="none"
                stroke="#3b82f6"
                strokeWidth={2}
                strokeDasharray="5,5"
              />
            );
          })()}
        </svg>
      </div>
    </div>
  );
}