// Gestion des pages du document Mykel Word (lecture / écriture du HTML multi-pages)
export const PAGE_BREAK = '<hr class="page-break"/>';

export function createWordPage() {
  const mobile = window.innerWidth < 768;
  const page = document.createElement('div');
  page.className = 'word-page bg-white shadow-lg rounded-sm outline-none';
  page.contentEditable = 'true';
  Object.assign(page.style, {
    width: mobile ? '100%' : '210mm',
    minHeight: mobile ? '60vh' : '297mm',
    maxWidth: mobile ? '100%' : '210mm',
    fontFamily: 'Arial',
    fontSize: mobile ? '11pt' : '12pt',
    lineHeight: '1.5',
    padding: mobile ? '1rem' : '2.5cm',
    boxSizing: 'border-box',
    overflowWrap: 'break-word',
    wordBreak: 'break-word',
  });
  return page;
}

export function readPagesHtml(container) {
  if (!container) return null;
  const pages = container.querySelectorAll('.word-page');
  if (pages.length === 0) return null;
  return Array.from(pages).map((p) => p.innerHTML).join(PAGE_BREAK);
}

// Écrit TOUTES les pages (avant : seules la 1re page était rechargée)
export function writePagesHtml(container, html) {
  const first = container?.querySelector('.word-page');
  if (!first) return false;
  container.querySelectorAll('.word-page').forEach((p, i) => { if (i > 0) p.remove(); });
  const parts = (html || '').split(PAGE_BREAK);
  first.innerHTML = parts[0] || '';
  let prev = first;
  parts.slice(1).forEach((part) => {
    const page = createWordPage();
    page.innerHTML = part;
    prev.after(page);
    prev = page;
  });
  return true;
}

export function lastPage(container) {
  const pages = container?.querySelectorAll('.word-page');
  return pages?.length ? pages[pages.length - 1] : null;
}