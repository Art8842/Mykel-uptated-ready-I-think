import React from 'react';
import { 
  Bold, Italic, Underline, Strikethrough, Subscript, Superscript,
  AlignLeft, AlignCenter, AlignRight, AlignJustify,
  List, ListOrdered, Indent, Outdent,
  Link, Image, Table, Quote, Code,
  Undo, Redo, Type, Palette, Highlighter,
  FileText, Save, Download, Printer, Share2,
  ChevronDown, Plus, Minus, Search, Replace
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { promptAction } from '@/lib/confirm';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const fonts = [
  'Arial', 'Times New Roman', 'Calibri', 'Georgia', 'Verdana', 
  'Helvetica', 'Courier New', 'Trebuchet MS', 'Impact', 'Comic Sans MS',
  'Palatino Linotype', 'Lucida Console', 'Tahoma', 'Century Gothic'
];

const fontSizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72];

const textColors = [
  '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#efefef', '#f3f3f3', '#ffffff',
  '#980000', '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#4a86e8', '#0000ff', '#9900ff', '#ff00ff',
  '#e6b8af', '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#c9daf8', '#cfe2f3', '#d9d2e9', '#ead1dc'
];

const highlightColors = [
  '#ffff00', '#00ff00', '#00ffff', '#ff00ff', '#ff0000', '#0000ff', 
  '#ffc0cb', '#ffa500', '#add8e6', '#90ee90'
];

export default function WordToolbar({ 
  onCommand, 
  onSave, 
  onExport,
  onShare,
  saving,
  currentStyles = {} 
}) {
  const execCommand = (command, value = null) => {
    document.execCommand(command, false, value);
    onCommand && onCommand(command, value);
  };

  const ToolbarButton = ({ icon: Icon, command, value, tooltip, active }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={active ? "secondary" : "ghost"}
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => execCommand(command, value)}
          >
            <Icon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <div className="bg-white border-b border-gray-200">
      {/* Menu Bar */}
      <div className="flex items-center px-2 py-1 border-b border-gray-100 text-sm overflow-x-auto flex-nowrap scrollbar-hide">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Fichier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onSave} className="gap-2">
              <Save className="w-4 h-4" /> Enregistrer
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <Download className="w-4 h-4" /> Télécharger
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onExport('pdf')}>
                  Document PDF (.pdf)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('docx')}>
                  Microsoft Word (.docx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('html')}>
                  Page Web (.html)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('txt')}>
                  Texte brut (.txt)
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => window.print()} className="gap-2">
              <Printer className="w-4 h-4" /> Imprimer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Modifier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => execCommand('undo')} className="gap-2">
              <Undo className="w-4 h-4" /> Annuler
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => execCommand('redo')} className="gap-2">
              <Redo className="w-4 h-4" /> Rétablir
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => execCommand('cut')} className="gap-2">
              Couper
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => execCommand('copy')} className="gap-2">
              Copier
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => execCommand('paste')} className="gap-2">
              Coller
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => execCommand('selectAll')} className="gap-2">
              Tout sélectionner
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Insertion
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => {}} className="gap-2 opacity-50 cursor-not-allowed">
              <Image className="w-4 h-4" /> Image
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => {}} className="gap-2 opacity-50 cursor-not-allowed">
              <Link className="w-4 h-4" /> Lien
            </DropdownMenuItem>
            <DropdownMenuItem onClick={async () => {
              const sel = window.getSelection();
              const range = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null;
              const cols = await promptAction({ title: 'Nombre de colonnes', defaultValue: '3', confirmLabel: 'Suivant' });
              if (!cols) return;
              const rows = await promptAction({ title: 'Nombre de lignes', defaultValue: '3', confirmLabel: 'Insérer' });
              if (range) {
                const node = range.startContainer;
                (node.nodeType === 1 ? node : node.parentElement)?.closest('[contenteditable="true"]')?.focus();
                sel.removeAllRanges();
                sel.addRange(range);
              }
              if (cols && rows) {
                let table = '<table style="border-collapse: collapse; width: 100%;">';
                for (let i = 0; i < parseInt(rows); i++) {
                  table += '<tr>';
                  for (let j = 0; j < parseInt(cols); j++) {
                    table += '<td style="border: 1px solid #ddd; padding: 8px;">&nbsp;</td>';
                  }
                  table += '</tr>';
                }
                table += '</table>';
                execCommand('insertHTML', table);
              }
            }} className="gap-2">
              <Table className="w-4 h-4" /> Tableau
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => execCommand('insertHorizontalRule')} className="gap-2">
              Ligne horizontale
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => {
              const date = new Date().toLocaleDateString('fr-FR');
              execCommand('insertText', date);
            }} className="gap-2">
              Date
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Format
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>Texte</DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => execCommand('bold')}>Gras</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('italic')}>Italique</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('underline')}>Souligné</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('strikeThrough')}>Barré</DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>Paragraphe</DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => execCommand('justifyLeft')}>Aligner à gauche</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('justifyCenter')}>Centrer</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('justifyRight')}>Aligner à droite</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('justifyFull')}>Justifier</DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>Style</DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => execCommand('formatBlock', 'h1')}>Titre 1</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('formatBlock', 'h2')}>Titre 2</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('formatBlock', 'h3')}>Titre 3</DropdownMenuItem>
                <DropdownMenuItem onClick={() => execCommand('formatBlock', 'p')}>Normal</DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => execCommand('removeFormat')}>
              Effacer la mise en forme
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="ml-auto flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onShare}
            className="h-7 gap-1"
          >
            <Share2 className="w-4 h-4" />
            Partager
          </Button>
          <Button 
            variant="default" 
            size="sm" 
            onClick={onSave}
            disabled={saving}
            className="h-7 bg-blue-600 hover:bg-blue-700"
          >
            {saving ? 'Enregistrement...' : 'Enregistrer'}
          </Button>
        </div>
      </div>

      {/* Formatting Toolbar */}
      <div className="flex items-center gap-1 px-2 py-1.5 overflow-x-auto flex-nowrap scrollbar-hide">
        {/* Undo/Redo */}
        <ToolbarButton icon={Undo} command="undo" tooltip="Annuler (Ctrl+Z)" />
        <ToolbarButton icon={Redo} command="redo" tooltip="Rétablir (Ctrl+Y)" />
        
        <Separator orientation="vertical" className="h-6 mx-1" />
        
        {/* Font Family */}
        <Select 
          defaultValue="Arial"
          onValueChange={(value) => execCommand('fontName', value)}
        >
          <SelectTrigger className="w-36 h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {fonts.map(font => (
              <SelectItem key={font} value={font} style={{ fontFamily: font }}>
                {font}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Font Size */}
        <Select 
          defaultValue="12"
          onValueChange={(value) => execCommand('fontSize', value > 24 ? 7 : value > 18 ? 6 : value > 14 ? 5 : value > 12 ? 4 : value > 10 ? 3 : value > 8 ? 2 : 1)}
        >
          <SelectTrigger className="w-16 h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {fontSizes.map(size => (
              <SelectItem key={size} value={size.toString()}>
                {size}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Text Formatting */}
        <ToolbarButton icon={Bold} command="bold" tooltip="Gras (Ctrl+B)" />
        <ToolbarButton icon={Italic} command="italic" tooltip="Italique (Ctrl+I)" />
        <ToolbarButton icon={Underline} command="underline" tooltip="Souligné (Ctrl+U)" />
        <ToolbarButton icon={Strikethrough} command="strikeThrough" tooltip="Barré" />
        <ToolbarButton icon={Subscript} command="subscript" tooltip="Indice" />
        <ToolbarButton icon={Superscript} command="superscript" tooltip="Exposant" />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Text Color */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <div className="flex flex-col items-center">
                <Type className="h-4 w-4" />
                <div className="h-1 w-4 bg-black rounded-full mt-0.5" />
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-52 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur du texte</p>
            <div className="grid grid-cols-10 gap-1">
              {textColors.map(color => (
                <button
                  key={color}
                  className="w-5 h-5 rounded border border-gray-300 hover:scale-110 transition-transform"
                  style={{ backgroundColor: color }}
                  onClick={() => execCommand('foreColor', color)}
                />
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Highlight */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Highlighter className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-40 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Surlignage</p>
            <div className="grid grid-cols-5 gap-1">
              {highlightColors.map(color => (
                <button
                  key={color}
                  className="w-6 h-6 rounded border border-gray-300 hover:scale-110 transition-transform"
                  style={{ backgroundColor: color }}
                  onClick={() => execCommand('hiliteColor', color)}
                />
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Alignment */}
        <ToolbarButton icon={AlignLeft} command="justifyLeft" tooltip="Aligner à gauche" />
        <ToolbarButton icon={AlignCenter} command="justifyCenter" tooltip="Centrer" />
        <ToolbarButton icon={AlignRight} command="justifyRight" tooltip="Aligner à droite" />
        <ToolbarButton icon={AlignJustify} command="justifyFull" tooltip="Justifier" />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Lists */}
        <ToolbarButton icon={List} command="insertUnorderedList" tooltip="Liste à puces" />
        <ToolbarButton icon={ListOrdered} command="insertOrderedList" tooltip="Liste numérotée" />
        <ToolbarButton icon={Outdent} command="outdent" tooltip="Diminuer le retrait" />
        <ToolbarButton icon={Indent} command="indent" tooltip="Augmenter le retrait" />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Insert */}
        <ToolbarButton icon={Quote} command="formatBlock" value="blockquote" tooltip="Citation" />
        <ToolbarButton icon={Code} command="formatBlock" value="pre" tooltip="Code" />
      </div>
    </div>
  );
}