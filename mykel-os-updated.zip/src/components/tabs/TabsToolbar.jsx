import React from 'react';
import { 
  Bold, Italic, Underline, Strikethrough,
  AlignLeft, AlignCenter, AlignRight,
  Type, Palette, DollarSign, Percent, Calendar,
  Merge, SplitSquareHorizontal, Filter, SortAsc, SortDesc,
  PlusCircle, MinusCircle, Trash2,
  Save, Download, Upload, Printer, Share2,
  Undo, Redo, Copy, Scissors, ClipboardPaste,
  ChevronDown, Grid3X3, BarChart3, PieChart, LineChart, Table2,
  Lock, Unlock, Eye, EyeOff, Search
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const fonts = ['Arial', 'Times New Roman', 'Calibri', 'Verdana', 'Courier New', 'Georgia'];
const fontSizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 36];

const cellColors = [
  '#ffffff', '#f3f3f3', '#d9d9d9', '#cccccc', '#666666', '#000000',
  '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#0000ff',
  '#9900ff', '#ff00ff', '#fce5cd', '#d9ead3', '#cfe2f3', '#d9d2e9'
];

const borderStyles = [
  { id: 'all', label: 'Toutes les bordures' },
  { id: 'outer', label: 'Bordures extérieures' },
  { id: 'inner', label: 'Bordures intérieures' },
  { id: 'horizontal', label: 'Bordures horizontales' },
  { id: 'vertical', label: 'Bordures verticales' },
  { id: 'none', label: 'Aucune bordure' },
];

export default function TabsToolbar({ 
  onCommand, 
  onSave, 
  onExport,
  onShare,
  saving,
  selectedCell,
  onFormulaChange,
  formula
}) {
  const ToolbarButton = ({ icon: Icon, tooltip, onClick, active }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={active ? "secondary" : "ghost"}
            size="sm"
            className="h-8 w-8 p-0"
            onClick={onClick}
          >
            <Icon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <div className="bg-white border-b border-gray-200">
      {/* Menu Bar */}
      <div className="flex items-center px-2 py-1 border-b border-gray-100 text-sm overflow-x-auto flex-nowrap scrollbar-hide">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Fichier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onSave} className="gap-2">
              <Save className="w-4 h-4" /> Enregistrer
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <Download className="w-4 h-4" /> Télécharger
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onExport('xlsx')}>
                  Microsoft Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('csv')}>
                  CSV (.csv)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('pdf')}>
                  PDF (.pdf)
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => window.print()} className="gap-2">
              <Printer className="w-4 h-4" /> Imprimer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Modifier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onCommand('undo')} className="gap-2">
              <Undo className="w-4 h-4" /> Annuler
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('redo')} className="gap-2">
              <Redo className="w-4 h-4" /> Rétablir
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('cut')} className="gap-2">
              <Scissors className="w-4 h-4" /> Couper
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('copy')} className="gap-2">
              <Copy className="w-4 h-4" /> Copier
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('paste')} className="gap-2">
              <ClipboardPaste className="w-4 h-4" /> Coller
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('deleteRow')} className="gap-2">
              <MinusCircle className="w-4 h-4" /> Supprimer la ligne
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('deleteColumn')} className="gap-2">
              <MinusCircle className="w-4 h-4" /> Supprimer la colonne
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Insertion
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onCommand('insertRowAbove')} className="gap-2">
              <PlusCircle className="w-4 h-4" /> Ligne au-dessus
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('insertRowBelow')} className="gap-2">
              <PlusCircle className="w-4 h-4" /> Ligne en-dessous
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('insertColumnLeft')} className="gap-2">
              <PlusCircle className="w-4 h-4" /> Colonne à gauche
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('insertColumnRight')} className="gap-2">
              <PlusCircle className="w-4 h-4" /> Colonne à droite
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <BarChart3 className="w-4 h-4" /> Graphique
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onCommand('insertChart', 'bar')}>
                  <BarChart3 className="w-4 h-4 mr-2" /> Barres
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('insertChart', 'line')}>
                  <LineChart className="w-4 h-4 mr-2" /> Lignes
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('insertChart', 'pie')}>
                  <PieChart className="w-4 h-4 mr-2" /> Secteurs
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Format
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>Nombre</DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onCommand('format', 'number')}>
                  Nombre
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('format', 'currency')}>
                  <DollarSign className="w-4 h-4 mr-2" /> Monétaire
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('format', 'percent')}>
                  <Percent className="w-4 h-4 mr-2" /> Pourcentage
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('format', 'date')}>
                  <Calendar className="w-4 h-4 mr-2" /> Date
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('format', 'text')}>
                  Texte brut
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>Alignement</DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onCommand('align', 'left')}>
                  <AlignLeft className="w-4 h-4 mr-2" /> Gauche
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('align', 'center')}>
                  <AlignCenter className="w-4 h-4 mr-2" /> Centre
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('align', 'right')}>
                  <AlignRight className="w-4 h-4 mr-2" /> Droite
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('merge')}>
              <Merge className="w-4 h-4 mr-2" /> Fusionner les cellules
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('unmerge')}>
              <SplitSquareHorizontal className="w-4 h-4 mr-2" /> Dissocier les cellules
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Données
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onCommand('sortAsc')} className="gap-2">
              <SortAsc className="w-4 h-4" /> Trier A → Z
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('sortDesc')} className="gap-2">
              <SortDesc className="w-4 h-4" /> Trier Z → A
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('filter')} className="gap-2">
              <Filter className="w-4 h-4" /> Créer un filtre
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={onShare} className="h-7 gap-1">
            <Share2 className="w-4 h-4" />
            Partager
          </Button>
          <Button 
            variant="default" 
            size="sm" 
            onClick={onSave}
            disabled={saving}
            className="h-7 bg-green-600 hover:bg-green-700"
          >
            {saving ? 'Enregistrement...' : 'Enregistrer'}
          </Button>
        </div>
      </div>

      {/* Formula Bar */}
      <div className="flex items-center gap-2 px-2 py-1 border-b border-gray-100">
        <div className="w-16 h-7 flex items-center justify-center bg-gray-100 rounded text-sm font-mono">
          {selectedCell || 'A1'}
        </div>
        <div className="text-gray-400">fx</div>
        <Input
          value={formula}
          onChange={(e) => onFormulaChange(e.target.value)}
          className="flex-1 h-7 font-mono text-sm"
          placeholder="Entrez une formule ou une valeur"
        />
      </div>

      {/* Formatting Toolbar */}
      <div className="flex items-center gap-1 px-2 py-1.5 overflow-x-auto flex-nowrap scrollbar-hide">
        <ToolbarButton icon={Undo} tooltip="Annuler" onClick={() => onCommand('undo')} />
        <ToolbarButton icon={Redo} tooltip="Rétablir" onClick={() => onCommand('redo')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />
        
        {/* Font */}
        <Select defaultValue="Arial" onValueChange={(v) => onCommand('fontFamily', v)}>
          <SelectTrigger className="w-28 h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {fonts.map(font => (
              <SelectItem key={font} value={font} style={{ fontFamily: font }}>
                {font}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select defaultValue="11" onValueChange={(v) => onCommand('fontSize', v)}>
          <SelectTrigger className="w-16 h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {fontSizes.map(size => (
              <SelectItem key={size} value={size.toString()}>{size}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={Bold} tooltip="Gras" onClick={() => onCommand('bold')} />
        <ToolbarButton icon={Italic} tooltip="Italique" onClick={() => onCommand('italic')} />
        <ToolbarButton icon={Underline} tooltip="Souligné" onClick={() => onCommand('underline')} />
        <ToolbarButton icon={Strikethrough} tooltip="Barré" onClick={() => onCommand('strikethrough')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Text Color */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Type className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-44 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur du texte</p>
            <div className="grid grid-cols-6 gap-1">
              {cellColors.map(color => (
                <button
                  key={color}
                  className="w-5 h-5 rounded border border-gray-300"
                  style={{ backgroundColor: color }}
                  onClick={() => onCommand('textColor', color)}
                />
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Fill Color */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Palette className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-44 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur de remplissage</p>
            <div className="grid grid-cols-6 gap-1">
              {cellColors.map(color => (
                <button
                  key={color}
                  className="w-5 h-5 rounded border border-gray-300"
                  style={{ backgroundColor: color }}
                  onClick={() => onCommand('fillColor', color)}
                />
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Borders */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Grid3X3 className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            {borderStyles.map(style => (
              <DropdownMenuItem key={style.id} onClick={() => onCommand('border', style.id)}>
                {style.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={AlignLeft} tooltip="Aligner à gauche" onClick={() => onCommand('align', 'left')} />
        <ToolbarButton icon={AlignCenter} tooltip="Centrer" onClick={() => onCommand('align', 'center')} />
        <ToolbarButton icon={AlignRight} tooltip="Aligner à droite" onClick={() => onCommand('align', 'right')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Number Format */}
        <ToolbarButton icon={DollarSign} tooltip="Format monétaire" onClick={() => onCommand('format', 'currency')} />
        <ToolbarButton icon={Percent} tooltip="Format pourcentage" onClick={() => onCommand('format', 'percent')} />

        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={Merge} tooltip="Fusionner" onClick={() => onCommand('merge')} />
        <ToolbarButton icon={Filter} tooltip="Filtrer" onClick={() => onCommand('filter')} />
      </div>
    </div>
  );
}