import React, { useState, useRef, useCallback, useEffect } from 'react';
import { cn } from "@/lib/utils";

const COLS = 26; // A-Z
const ROWS = 100;

const getColumnLabel = (index) => {
  let label = '';
  while (index >= 0) {
    label = String.fromCharCode(65 + (index % 26)) + label;
    index = Math.floor(index / 26) - 1;
  }
  return label;
};

const getCellId = (row, col) => `${getColumnLabel(col)}${row + 1}`;

const parseCellId = (cellId) => {
  const match = cellId.match(/^([A-Z]+)(\d+)$/);
  if (!match) return null;
  const col = match[1].split('').reduce((acc, char) => acc * 26 + char.charCodeAt(0) - 64, 0) - 1;
  const row = parseInt(match[2]) - 1;
  return { row, col };
};

// Simple formula parser
const evaluateFormula = (formula, cells) => {
  if (!formula.startsWith('=')) return formula;
  
  let expr = formula.substring(1).toUpperCase();
  
  // Handle SUM, AVERAGE, MIN, MAX, COUNT
  const functions = {
    SUM: (values) => values.reduce((a, b) => a + (parseFloat(b) || 0), 0),
    AVERAGE: (values) => {
      const nums = values.filter(v => !isNaN(parseFloat(v)));
      return nums.length ? nums.reduce((a, b) => a + parseFloat(b), 0) / nums.length : 0;
    },
    MIN: (values) => Math.min(...values.filter(v => !isNaN(parseFloat(v))).map(parseFloat)),
    MAX: (values) => Math.max(...values.filter(v => !isNaN(parseFloat(v))).map(parseFloat)),
    COUNT: (values) => values.filter(v => v !== '' && v !== undefined).length,
    COUNTA: (values) => values.filter(v => v !== '' && v !== undefined).length,
  };

  // Parse function calls like SUM(A1:A10)
  for (const [funcName, func] of Object.entries(functions)) {
    const funcRegex = new RegExp(`${funcName}\\(([A-Z]+\\d+):([A-Z]+\\d+)\\)`, 'g');
    expr = expr.replace(funcRegex, (match, start, end) => {
      const startPos = parseCellId(start);
      const endPos = parseCellId(end);
      if (!startPos || !endPos) return 0;
      
      const values = [];
      for (let r = Math.min(startPos.row, endPos.row); r <= Math.max(startPos.row, endPos.row); r++) {
        for (let c = Math.min(startPos.col, endPos.col); c <= Math.max(startPos.col, endPos.col); c++) {
          const cellId = getCellId(r, c);
          values.push(cells[cellId]?.value || '');
        }
      }
      return func(values);
    });
  }

  // Replace cell references with values
  expr = expr.replace(/([A-Z]+\d+)/g, (match) => {
    const val = cells[match]?.value;
    if (val === undefined || val === '') return 0;
    if (!isNaN(parseFloat(val))) return parseFloat(val);
    return `"${val}"`;
  });

  // Evaluate the expression
  try {
    // Only allow safe characters
    if (/^[\d\s+\-*/().,"]+$/.test(expr)) {
      return eval(expr);
    }
    return '#ERROR!';
  } catch (e) {
    return '#ERROR!';
  }
};

export default function Spreadsheet({ 
  cells, 
  styles,
  onCellChange, 
  onCellSelect,
  selectedCell,
  onSelectionChange
}) {
  const [selection, setSelection] = useState({ start: null, end: null });
  const [isSelecting, setIsSelecting] = useState(false);
  const [editingCell, setEditingCell] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [columnWidths, setColumnWidths] = useState({});
  const [rowHeights, setRowHeights] = useState({});
  const tableRef = useRef(null);

  const handleCellClick = (row, col, e) => {
    const cellId = getCellId(row, col);
    
    if (e.shiftKey && selection.start) {
      setSelection({ ...selection, end: { row, col } });
    } else {
      setSelection({ start: { row, col }, end: { row, col } });
    }
    
    onCellSelect(cellId);
    setEditingCell(null);
  };

  const handleCellDoubleClick = (row, col) => {
    const cellId = getCellId(row, col);
    setEditingCell(cellId);
    setEditValue(cells[cellId]?.formula || cells[cellId]?.value || '');
  };

  const handleCellKeyDown = (e, row, col) => {
    const cellId = getCellId(row, col);
    
    if (e.key === 'Enter') {
      if (editingCell === cellId) {
        finishEditing();
        // Move to next row
        if (row < ROWS - 1) {
          handleCellClick(row + 1, col, e);
        }
      } else {
        handleCellDoubleClick(row, col);
      }
      e.preventDefault();
    } else if (e.key === 'Tab') {
      finishEditing();
      // Move to next column
      if (col < COLS - 1) {
        handleCellClick(row, col + 1, e);
      }
      e.preventDefault();
    } else if (e.key === 'Escape') {
      setEditingCell(null);
    } else if (!editingCell && e.key.length === 1 && !e.ctrlKey && !e.metaKey) {
      // Start typing in cell
      setEditingCell(cellId);
      setEditValue(e.key);
    } else if (!editingCell) {
      // Arrow key navigation
      let newRow = row;
      let newCol = col;
      
      if (e.key === 'ArrowUp' && row > 0) newRow--;
      else if (e.key === 'ArrowDown' && row < ROWS - 1) newRow++;
      else if (e.key === 'ArrowLeft' && col > 0) newCol--;
      else if (e.key === 'ArrowRight' && col < COLS - 1) newCol++;
      else if (e.key === 'Delete' || e.key === 'Backspace') {
        onCellChange(cellId, '', '');
        return;
      }
      
      if (newRow !== row || newCol !== col) {
        handleCellClick(newRow, newCol, e);
        e.preventDefault();
      }
    }
  };

  const finishEditing = () => {
    if (editingCell && editValue !== undefined) {
      const isFormula = editValue.startsWith('=');
      const displayValue = isFormula ? evaluateFormula(editValue, cells) : editValue;
      onCellChange(editingCell, displayValue, isFormula ? editValue : null);
    }
    setEditingCell(null);
  };

  const handleMouseDown = (row, col, e) => {
    if (e.button !== 0) return;
    setIsSelecting(true);
    setSelection({ start: { row, col }, end: { row, col } });
    onCellSelect(getCellId(row, col));
  };

  const handleMouseMove = (row, col) => {
    if (isSelecting) {
      setSelection(prev => ({ ...prev, end: { row, col } }));
    }
  };

  const handleMouseUp = () => {
    setIsSelecting(false);
    if (selection.start && selection.end) {
      onSelectionChange && onSelectionChange(selection);
    }
  };

  const isInSelection = (row, col) => {
    if (!selection.start || !selection.end) return false;
    const minRow = Math.min(selection.start.row, selection.end.row);
    const maxRow = Math.max(selection.start.row, selection.end.row);
    const minCol = Math.min(selection.start.col, selection.end.col);
    const maxCol = Math.max(selection.start.col, selection.end.col);
    return row >= minRow && row <= maxRow && col >= minCol && col <= maxCol;
  };

  const getCellStyle = (cellId) => {
    const style = styles[cellId] || {};
    return {
      fontFamily: style.fontFamily || 'Arial',
      fontSize: style.fontSize ? `${style.fontSize}px` : '13px',
      fontWeight: style.bold ? 'bold' : 'normal',
      fontStyle: style.italic ? 'italic' : 'normal',
      textDecoration: [
        style.underline && 'underline',
        style.strikethrough && 'line-through'
      ].filter(Boolean).join(' ') || 'none',
      color: style.textColor || '#000000',
      backgroundColor: style.fillColor || 'transparent',
      textAlign: style.align || 'left',
    };
  };

  return (
    <div 
      className="flex-1 overflow-auto bg-white"
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <table 
        ref={tableRef}
        className="border-collapse w-max"
        style={{ tableLayout: 'fixed' }}
      >
        <thead className="sticky top-0 z-20">
          <tr>
            <th className="w-12 h-7 bg-gray-100 border border-gray-300 sticky left-0 z-30" />
            {Array.from({ length: COLS }, (_, i) => (
              <th 
                key={i}
                className="h-7 bg-gray-100 border border-gray-300 text-xs font-medium text-gray-600 select-none"
                style={{ width: columnWidths[i] || 100, minWidth: 50 }}
              >
                {getColumnLabel(i)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: ROWS }, (_, rowIndex) => (
            <tr key={rowIndex}>
              <th 
                className="w-12 bg-gray-100 border border-gray-300 text-xs font-medium text-gray-600 sticky left-0 z-10 select-none"
                style={{ height: rowHeights[rowIndex] || 24 }}
              >
                {rowIndex + 1}
              </th>
              {Array.from({ length: COLS }, (_, colIndex) => {
                const cellId = getCellId(rowIndex, colIndex);
                const cell = cells[cellId];
                const isEditing = editingCell === cellId;
                const isSelected = selectedCell === cellId;
                const inSelection = isInSelection(rowIndex, colIndex);
                
                return (
                  <td
                    key={colIndex}
                    className={cn(
                      "border border-gray-200 p-0 relative",
                      inSelection && "bg-blue-50",
                      isSelected && "ring-2 ring-green-500 ring-inset z-10"
                    )}
                    style={{ 
                      width: columnWidths[colIndex] || 100,
                      height: rowHeights[rowIndex] || 24,
                      ...getCellStyle(cellId)
                    }}
                    onClick={(e) => handleCellClick(rowIndex, colIndex, e)}
                    onDoubleClick={() => handleCellDoubleClick(rowIndex, colIndex)}
                    onMouseDown={(e) => handleMouseDown(rowIndex, colIndex, e)}
                    onMouseMove={() => handleMouseMove(rowIndex, colIndex)}
                    tabIndex={0}
                    onKeyDown={(e) => handleCellKeyDown(e, rowIndex, colIndex)}
                  >
                    {isEditing ? (
                      <input
                        type="text"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={finishEditing}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === 'Tab') {
                            e.preventDefault();
                            finishEditing();
                          }
                        }}
                        className="absolute inset-0 w-full h-full px-1 outline-none border-2 border-blue-500 bg-white z-20"
                        style={{ ...getCellStyle(cellId) }}
                        autoFocus
                        onFocus={(e) => e.target.setSelectionRange(e.target.value.length, e.target.value.length)}
                      />
                    ) : (
                      <div className="px-1 truncate h-full flex items-center">
                        {cell?.value ?? ''}
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}