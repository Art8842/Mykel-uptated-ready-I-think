import React from 'react';
import { Loader2 } from 'lucide-react';

export default function PrimaryButton({ children, loading, disabled, ...props }) {
  return (
    <button
      {...props}
      disabled={loading || disabled}
      className="w-full h-11 rounded-xl font-semibold text-white shadow-lg shadow-blue-500/30 transition-all hover:shadow-xl hover:brightness-110 active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      style={{ background: 'linear-gradient(180deg, #3b82f6 0%, #2563eb 100%)' }}
    >
      {loading && <Loader2 className="w-4 h-4 animate-spin" />}
      {children}
    </button>
  );
}