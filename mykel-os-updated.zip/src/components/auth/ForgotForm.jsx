import React, { useState } from 'react';
import { Mail, CheckCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AuthField from './AuthField';
import PrimaryButton from './PrimaryButton';
import AuthAlert from './AuthAlert';
import { parseAuthError } from '@/lib/authErrors';

export default function ForgotForm({ onBack }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await base44.auth.resetPasswordRequest(email);
      setSent(true);
    } catch (err) {
      setError(parseAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <div className="text-center space-y-4 py-8">
        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto">
          <CheckCircle className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Email envoyé</h1>
        <p className="text-sm text-gray-500">Un lien de réinitialisation a été envoyé à <strong>{email}</strong>.</p>
        <PrimaryButton onClick={onBack}>Retour à la connexion</PrimaryButton>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="text-center space-y-1 mb-2">
        <h1 className="text-2xl font-bold text-gray-900">Mot de passe oublié</h1>
        <p className="text-sm text-gray-500">Entrez votre email pour recevoir un lien de réinitialisation.</p>
      </div>
      {error && <AuthAlert>{error}</AuthAlert>}
      <AuthField icon={Mail} label="Email" type="email" value={email} onChange={setEmail} placeholder="vous@exemple.com" autoComplete="email" />
      <PrimaryButton type="submit" loading={loading}>Envoyer le lien</PrimaryButton>
      <button type="button" onClick={onBack} className="w-full text-center text-sm text-gray-500 hover:text-gray-700">← Retour à la connexion</button>
    </form>
  );
}