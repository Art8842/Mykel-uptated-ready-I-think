import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AuthField from './AuthField';
import PasswordField from './PasswordField';
import PrimaryButton from './PrimaryButton';
import AuthAlert from './AuthAlert';
import GoogleButton from './GoogleButton';
import OtpForm from './OtpForm';
import { parseAuthError } from '@/lib/authErrors';
import { setMykelSession } from '@/lib/mykelSession';

export default function RegisterForm({ onSwitch }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState('form'); // 'form' | 'otp'

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (password.length < 8) { setError('Le mot de passe doit faire au moins 8 caractères.'); return; }
    setLoading(true);
    try {
      await base44.auth.register({ email, password });
      setStep('otp');
    } catch (err) {
      setError(parseAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const onVerified = async () => {
    const me = await base44.auth.me();
    setMykelSession({
      id: me.id, email: me.email, full_name: me.full_name, role: me.role,
      token: 'platform', token_expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(),
    });
    window.location.href = '/Dashboard';
  };

  if (step === 'otp') {
    return <OtpForm email={email} password={password} onSuccess={onVerified} onBack={() => setStep('form')} />;
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="text-center space-y-1 mb-2">
        <h1 className="text-2xl font-bold text-gray-900">Créer un compte</h1>
        <p className="text-sm text-gray-500">Gratuit, sans carte bancaire</p>
      </div>
      {error && <AuthAlert>{error}</AuthAlert>}
      <AuthField icon={Mail} label="Email" type="email" value={email} onChange={setEmail} placeholder="vous@exemple.com" autoComplete="email" />
      <PasswordField label="Mot de passe" value={password} onChange={setPassword} placeholder="••••••••" autoComplete="new-password" />
      <PrimaryButton type="submit" loading={loading}>Créer mon compte</PrimaryButton>
      <GoogleButton />
      <p className="text-center text-sm text-gray-500 pt-2">
        Déjà un compte ?{' '}
        <button type="button" onClick={onSwitch} className="text-blue-600 hover:text-blue-700 font-semibold">Se connecter</button>
      </p>
    </form>
  );
}