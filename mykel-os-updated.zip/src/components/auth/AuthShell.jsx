import React from 'react';
import MykelLogo from './MykelLogo';

export default function AuthShell({ children }) {
  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Brand panel (desktop) */}
      <div className="hidden lg:flex flex-col w-[44%] relative overflow-hidden"
        style={{ background: 'linear-gradient(160deg, #1e3a8a 0%, #2563eb 45%, #6366f1 100%)' }}>
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full blur-3xl" style={{ background: 'rgba(147,197,253,0.25)' }} />
        <div className="absolute bottom-0 right-0 w-[28rem] h-[28rem] rounded-full blur-3xl" style={{ background: 'rgba(196,181,253,0.25)' }} />
        <div className="relative z-10 p-10 flex flex-col h-full text-white">
          <MykelLogo size={44} />
          <div className="mt-auto space-y-6">
            <h2 className="text-4xl font-bold leading-tight">Votre espace numérique,<br />en un seul endroit.</h2>
            <p className="text-blue-100 text-lg max-w-md">Cloud, Musique, TV, IA, Bureautique… réunis sur une plateforme élégante et sécurisée.</p>
            <div className="grid grid-cols-4 gap-3 pt-4">
              {['Cloud', 'Music', 'TV', 'IA'].map(s => (
                <div key={s} className="rounded-2xl px-3 py-3 text-center text-xs font-semibold backdrop-blur-md"
                  style={{ background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.2)' }}>
                  {s}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="lg:hidden mb-8 flex justify-center">
            <MykelLogo size={40} />
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}