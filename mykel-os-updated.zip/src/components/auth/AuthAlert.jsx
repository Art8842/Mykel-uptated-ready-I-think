import React from 'react';
import { AlertCircle } from 'lucide-react';

export default function AuthAlert({ children, variant = 'error' }) {
  const styles = variant === 'error'
    ? 'bg-red-50 text-red-700 border-red-200'
    : 'bg-green-50 text-green-700 border-green-200';
  return (
    <div className={`flex items-start gap-2 rounded-xl border px-3 py-2.5 text-sm ${styles}`}>
      {variant === 'error' && <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />}
      <span>{children}</span>
    </div>
  );
}