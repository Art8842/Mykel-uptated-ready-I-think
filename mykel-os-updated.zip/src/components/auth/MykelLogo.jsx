import React from 'react';
import { Cloud } from 'lucide-react';

export default function MykelLogo({ size = 40 }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/30"
        style={{
          width: size,
          height: size,
          background: 'linear-gradient(180deg, #60a5fa 0%, #2563eb 55%, #1d4ed8 100%)',
          boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.5), 0 6px 14px rgba(37,99,235,0.35)',
        }}
      >
        <Cloud className="text-white" style={{ width: size * 0.55, height: size * 0.55, filter: 'drop-shadow(0 1px 1px rgba(0,0,0,0.15))' }} />
      </div>
      <span className="font-bold tracking-tight text-gray-900" style={{ fontSize: size * 0.5 }}>Mykel</span>
    </div>
  );
}