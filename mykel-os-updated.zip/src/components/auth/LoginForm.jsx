import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AuthField from './AuthField';
import PasswordField from './PasswordField';
import PrimaryButton from './PrimaryButton';
import AuthAlert from './AuthAlert';
import GoogleButton from './GoogleButton';
import { parseAuthError } from '@/lib/authErrors';
import { setMykelSession } from '@/lib/mykelSession';

export default function LoginForm({ onSwitch, onForgot }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      const me = await base44.auth.me();
      setMykelSession({
        id: me.id,
        email: me.email,
        full_name: me.full_name,
        role: me.role,
        token: 'platform',
        token_expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(),
      });
      const url = new URLSearchParams(window.location.search).get('returnUrl');
      window.location.href = url && url.startsWith('/') && !url.startsWith('//') ? url : '/Dashboard';
    } catch (err) {
      setError(parseAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="text-center space-y-1 mb-2">
        <h1 className="text-2xl font-bold text-gray-900">Bienvenue</h1>
        <p className="text-sm text-gray-500">Connectez-vous à votre compte Mykel</p>
      </div>
      {error && <AuthAlert>{error}</AuthAlert>}
      <AuthField icon={Mail} label="Email" type="email" value={email} onChange={setEmail} placeholder="vous@exemple.com" autoComplete="email" />
      <PasswordField label="Mot de passe" value={password} onChange={setPassword} placeholder="••••••••" autoComplete="current-password" />
      <div className="flex justify-end">
        <button type="button" onClick={onForgot} className="text-sm text-blue-600 hover:text-blue-700 font-medium">Mot de passe oublié ?</button>
      </div>
      <PrimaryButton type="submit" loading={loading}>Se connecter</PrimaryButton>
      <GoogleButton />
      <p className="text-center text-sm text-gray-500 pt-2">
        Pas de compte ?{' '}
        <button type="button" onClick={onSwitch} className="text-blue-600 hover:text-blue-700 font-semibold">Créer un compte</button>
      </p>
    </form>
  );
}