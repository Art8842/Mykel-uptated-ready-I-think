import React, { useState, useRef } from 'react';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PrimaryButton from './PrimaryButton';
import AuthAlert from './AuthAlert';
import { parseAuthError } from '@/lib/authErrors';

export default function OtpForm({ email, password, onSuccess, onBack }) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resending, setResending] = useState(false);

  const verify = async (e) => {
    e?.preventDefault();
    if (code.length < 6) { setError('Saisissez les 6 chiffres.'); return; }
    setError('');
    setLoading(true);
    try {
      await base44.auth.verifyOtp({ email, otpCode: code });
      await base44.auth.loginViaEmailPassword(email, password);
      onSuccess();
    } catch (err) {
      setError(parseAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    setResending(true);
    try {
      await base44.auth.register({ email, password });
    } catch {}
    setResending(false);
  };

  return (
    <form onSubmit={verify} className="space-y-5">
      <div className="text-center space-y-1">
        <h1 className="text-2xl font-bold text-gray-900">Vérifiez votre email</h1>
        <p className="text-sm text-gray-500">Un code à 6 chiffres a été envoyé à <strong>{email}</strong>.</p>
      </div>
      {error && <AuthAlert>{error}</AuthAlert>}
      <div className="flex justify-center">
        <InputOTP maxLength={6} value={code} onChange={setCode}>
          <InputOTPGroup>
            {[0,1,2,3,4,5].map(i => <InputOTPSlot key={i} index={i} />)}
          </InputOTPGroup>
        </InputOTP>
      </div>
      <PrimaryButton type="submit" loading={loading}>Vérifier & se connecter</PrimaryButton>
      <div className="flex items-center justify-between text-sm">
        <button type="button" onClick={onBack} className="text-gray-500 hover:text-gray-700">← Retour</button>
        <button type="button" onClick={resend} disabled={resending} className="text-blue-600 hover:text-blue-700 font-medium">
          {resending ? 'Envoi…' : 'Renvoyer le code'}
        </button>
      </div>
    </form>
  );
}