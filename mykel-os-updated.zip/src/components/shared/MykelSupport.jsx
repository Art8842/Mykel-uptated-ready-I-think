import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { freeInvokeLLM } from '@/lib/freeCore';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Send, MessageSquare, Lock } from 'lucide-react';

export default function MykelSupport({ open, onClose, user }) {
  const [messages, setMessages] = useState([
    { role: 'ai', content: 'Bonjour ! Je suis le support Mykel Cloud. Comment puis-je vous aider ?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [locked, setLocked] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading || locked) return;
    const userMsg = input.trim();
    setInput('');
    const newMsgs = [...messages, { role: 'user', content: userMsg }];
    setMessages(newMsgs);
    setLoading(true);

    try {
      const history = newMsgs.map(m => `${m.role === 'user' ? 'Utilisateur' : 'Support'}: ${m.content}`).join('\n');
      const response = await freeInvokeLLM({
        prompt: `Tu es un agent de support pour Mykel Cloud (suite bureautique cloud : Drive, Word, Tableur, Présentation, Dessin, Musique, IA).
Tu dois recueillir les informations nécessaires pour résoudre le problème de l'utilisateur (nom, description du problème, étapes pour reproduire, etc.).
Quand tu as toutes les informations nécessaires, réponds UNIQUEMENT avec le JSON suivant (rien d'autre) :
{"done": true, "summary": "résumé du problème en français"}

Historique de la conversation :
${history}

Réponds en français. Si tu n'as pas encore toutes les infos, pose la prochaine question.`,
      });

      // Check if AI signals it has all info
      try {
        const parsed = JSON.parse(response);
        if (parsed.done) {
          await base44.entities.SupportTicket.create({
            user_email: user?.email || 'inconnu',
            user_name: user?.full_name || '',
            summary: parsed.summary,
            conversation: newMsgs,
            status: 'open',
            created_at: new Date().toISOString(),
          });
          setMessages(prev => [...prev, {
            role: 'ai',
            content: '✅ J\'ai récupéré toutes les informations nécessaires. Merci d\'avoir contacté le support Mykel.'
          }]);
          setLocked(true);
          return;
        }
      } catch {}

      setMessages(prev => [...prev, { role: 'ai', content: response }]);
    } catch {
      setMessages(prev => [...prev, { role: 'ai', content: 'Une erreur s\'est produite. Veuillez réessayer.' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setMessages([{ role: 'ai', content: 'Bonjour ! Je suis le support Mykel Cloud. Comment puis-je vous aider ?' }]);
    setInput('');
    setLocked(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 max-w-md p-0 overflow-hidden flex flex-col" style={{ maxHeight: '80vh' }}>
        <DialogHeader className="p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-white" />
            </div>
            <div>
              <DialogTitle className="text-gray-900 dark:text-white text-base">Support Mykel</DialogTitle>
              <p className="text-xs text-gray-500 dark:text-gray-400">Assistance en ligne</p>
            </div>
          </div>
        </DialogHeader>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ minHeight: '200px' }}>
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] px-3 py-2 rounded-xl text-sm leading-relaxed ${
                m.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
              }`}>{m.content}</div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="px-3 py-2 bg-gray-100 dark:bg-gray-800 rounded-xl">
                <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        {locked ? (
          <div className="p-3 border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
            <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 dark:bg-gray-800 rounded-xl opacity-70">
              <Lock className="w-4 h-4 text-gray-400 flex-shrink-0" />
              <p className="text-xs text-gray-500 dark:text-gray-400">Votre demande a été envoyée. Délai de traitement : 1 à 72 heures.</p>
            </div>
          </div>
        ) : (
          <div className="flex gap-2 p-3 border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
            <input
              className="flex-1 bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white placeholder:text-gray-400"
              placeholder="Décrivez votre problème..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage()}
            />
            <Button size="icon" onClick={sendMessage} disabled={loading || !input.trim()} className="flex-shrink-0">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}