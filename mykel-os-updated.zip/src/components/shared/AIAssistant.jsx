import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { MessageCircle, X, Send, Loader2, Sparkles } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { callAIText } from '@/components/utils/aiClient';

export default function AIAssistant({ systemContext = '', onInsertText, onCreateFile, fileId }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: 'user', content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const systemPrompt = systemContext || "Tu es un assistant utile dans l'application Mykel Cloud.";
      const fullPrompt = `${systemPrompt}\n\nHistorique:\n${newMessages.map(m => `${m.role === 'user' ? 'Utilisateur' : 'Assistant'}: ${m.content}`).join('\n')}\n\nRéponds de façon concise et pratique.`;
      
      const response = await callAIText(fullPrompt);
      const assistantMsg = { role: 'assistant', content: response };
      setMessages([...newMessages, assistantMsg]);

      if (onInsertText && (input.toLowerCase().includes('insère') || input.toLowerCase().includes('écris') || input.toLowerCase().includes('rédige'))) {
        onInsertText(response);
      }
    } catch (e) {
      setMessages([...newMessages, { role: 'assistant', content: "Désolé, une erreur s'est produite." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Toggle button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-600 hover:bg-green-700 text-white rounded-full shadow-lg flex items-center justify-center transition-all"
      >
        {open ? <X className="w-6 h-6" /> : <Sparkles className="w-6 h-6" />}
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 flex flex-col" style={{ maxHeight: '70vh' }}>
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-green-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Mykel IA</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
            {messages.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">Comment puis-je t'aider ?</p>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-xl px-3 py-2 text-sm ${
                  msg.role === 'user'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 dark:bg-gray-800 rounded-xl px-3 py-2">
                  <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t border-gray-200 dark:border-gray-700 flex gap-2">
            <Input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage()}
              placeholder="Écrire un message..."
              className="text-sm"
              style={{ fontSize: '16px' }}
            />
            <Button size="icon" onClick={sendMessage} disabled={loading} className="bg-green-600 hover:bg-green-700 flex-shrink-0">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </>
  );
}