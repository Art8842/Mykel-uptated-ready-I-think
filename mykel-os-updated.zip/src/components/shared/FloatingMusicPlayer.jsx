import React, { useState, useEffect } from 'react';
import { useMusicPlayer } from './MusicPlayerContext';
import { Music, Play, Pause, SkipForward, SkipBack, X, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { extractColorFromImage } from '@/components/music/AlbumColorTheme';

export default function FloatingMusicPlayer() {
  const player = useMusicPlayer();
  const [open, setOpen] = useState(false);
  const [accentColor, setAccentColor] = useState(null); // { r, g, b, hex }

  const { currentTrack, isPlaying, togglePlay, handleNext, handlePrev, stop } = player || {};

  // Extract album color when track changes
  useEffect(() => {
    const coverUrl = currentTrack?.cover_url || currentTrack?.album_cover_url;
    if (!coverUrl) { setAccentColor(null); return; }
    extractColorFromImage(coverUrl).then(color => setAccentColor(color));
  }, [currentTrack?.id]);

  const accent = accentColor?.hex || '#7c3aed'; // purple fallback
  const accentDark = accentColor
    ? `rgba(${accentColor.r}, ${accentColor.g}, ${accentColor.b}, 0.85)`
    : 'rgba(124, 58, 237, 0.85)';
  const accentLight = accentColor
    ? `rgba(${accentColor.r}, ${accentColor.g}, ${accentColor.b}, 0.15)`
    : 'rgba(124, 58, 237, 0.15)';

  if (!player || !currentTrack) return null;

  const formatTime = (s) => {
    if (!s || isNaN(s)) return '0:00';
    return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  };

  return (
    <div className="fixed top-3 right-3 z-50">
      {open ? (
        <div
          className="border rounded-2xl shadow-2xl p-3 w-64 backdrop-blur-md"
          style={{ background: 'rgba(15,15,25,0.92)', borderColor: accentColor ? `${accent}55` : '#374151' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <div className="w-5 h-5 rounded flex items-center justify-center" style={{ background: accent }}>
                <Music className="w-3 h-3 text-white" />
              </div>
              <span className="text-white text-xs font-semibold">Lecture en cours</span>
            </div>
            <button onClick={() => setOpen(false)} className="text-gray-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Track info */}
          <div className="flex items-center gap-2 mb-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden" style={{ background: accentLight }}>
              {currentTrack.cover_url || currentTrack.album_cover_url
                ? <img src={currentTrack.cover_url || currentTrack.album_cover_url} className="w-full h-full rounded-lg object-cover" alt="" />
                : <Music className="w-5 h-5 text-white/60" />
              }
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs font-medium truncate">{currentTrack.name || currentTrack.title}</p>
              <p className="text-gray-400 text-xs truncate">{currentTrack.artist || currentTrack.stage_name || 'Artiste inconnu'}</p>
            </div>
          </div>

          {/* Progress */}
          <div className="flex items-center gap-1.5 mb-2 text-xs text-gray-500">
            <span>{formatTime(player.currentTime)}</span>
            <div className="flex-1 h-1 bg-gray-700 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: player.duration ? `${(player.currentTime / player.duration) * 100}%` : '0%',
                  background: accent
                }}
              />
            </div>
            <span>{formatTime(player.duration)}</span>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between">
            <button onClick={handlePrev} className="text-gray-400 hover:text-white p-1">
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              onClick={togglePlay}
              className="w-9 h-9 rounded-full flex items-center justify-center text-white transition-transform hover:scale-105"
              style={{ background: accent }}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <button onClick={handleNext} className="text-gray-400 hover:text-white p-1">
              <SkipForward className="w-4 h-4" />
            </button>
            <Link to={createPageUrl('MykelMusic')} className="text-gray-400 p-1 transition-colors" style={{ '--hover-color': accent }} title="Aller à Mykel Music"
              onMouseEnter={e => e.currentTarget.style.color = accent}
              onMouseLeave={e => e.currentTarget.style.color = ''}
            >
              <ExternalLink className="w-4 h-4" />
            </Link>
            <button onClick={() => { stop(); setOpen(false); }} className="text-gray-500 hover:text-red-400 p-1" title="Fermer le lecteur">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 text-white rounded-full px-3 py-1.5 shadow-lg hover:opacity-90 transition-all"
          style={{ background: accentDark, border: `1px solid ${accent}55` }}
        >
          <div className="w-5 h-5 rounded flex items-center justify-center" style={{ background: `${accent}55` }}>
            {isPlaying
              ? <div className="flex items-end gap-0.5 h-3">
                  <div className="w-0.5 bg-white animate-bounce" style={{ height: '60%', animationDelay: '0ms' }} />
                  <div className="w-0.5 bg-white animate-bounce" style={{ height: '100%', animationDelay: '150ms' }} />
                  <div className="w-0.5 bg-white animate-bounce" style={{ height: '40%', animationDelay: '300ms' }} />
                </div>
              : <Music className="w-3 h-3 text-white" />
            }
          </div>
          <span className="text-xs font-medium max-w-[100px] truncate">{currentTrack.name || currentTrack.title}</span>
        </button>
      )}
    </div>
  );
}