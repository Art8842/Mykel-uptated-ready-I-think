import React, { useState, useCallback } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { registerConfirmHost } from '@/lib/confirm';

export default function ConfirmHost() {
  const [req, setReq] = useState(null);
  const [resolver, setResolver] = useState(null);
  const [inputValue, setInputValue] = useState('');

  const handle = useCallback((options) => {
    const opts = typeof options === 'string' ? { title: options } : options;
    return new Promise((resolve) => {
      setReq(opts);
      setInputValue(opts.defaultValue || '');
      setResolver(() => resolve);
    });
  }, []);

  React.useEffect(() => registerConfirmHost(handle), [handle]);

  const close = (result) => {
    if (resolver) resolver(result);
    setReq(null);
    setResolver(null);
  };

  const isPrompt = req?.mode === 'prompt';

  return (
    <Dialog open={!!req} onOpenChange={(open) => { if (!open) close(isPrompt ? null : false); }}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{req?.title || 'Confirmer'}</DialogTitle>
        </DialogHeader>
        {req?.message && <p className="text-sm text-gray-600 dark:text-gray-300">{req.message}</p>}
        {isPrompt && (
          <Input
            autoFocus
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') close(inputValue); }}
            placeholder={req?.placeholder || ''}
          />
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => close(isPrompt ? null : false)}>
            {req?.cancelLabel || 'Annuler'}
          </Button>
          <Button
            variant={req?.destructive ? 'destructive' : 'default'}
            onClick={() => close(isPrompt ? inputValue : true)}
          >
            {req?.confirmLabel || 'Confirmer'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}