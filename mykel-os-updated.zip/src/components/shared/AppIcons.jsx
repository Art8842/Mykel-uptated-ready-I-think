import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  PenTool, Crop, Scissors, Box, Code2, Edit,
  ShoppingBag, Music, Sparkles, Globe, MessageCircle, Tv, Video,
  FileText, Table, Presentation,
} from 'lucide-react';

const APP_STYLES = {
  word:       { gradient: 'from-blue-500 to-blue-600',         Icon: FileText },
  tabs:       { gradient: 'from-emerald-500 to-teal-600',       Icon: Table },
  sliders:    { gradient: 'from-orange-500 to-amber-600',      Icon: Presentation },
  draws:      { gradient: 'from-fuchsia-500 to-purple-600',    Icon: PenTool },
  snapfix:    { gradient: 'from-pink-500 to-rose-600',          Icon: Crop },
  removebg:   { gradient: 'from-red-500 to-rose-600',           Icon: Scissors },
  '3d':       { gradient: 'from-sky-500 to-cyan-600',           Icon: Box },
  edicode:    { gradient: 'from-green-500 to-emerald-600',      Icon: Code2 },
  store:      { gradient: 'from-indigo-500 to-blue-600',        Icon: ShoppingBag },
  music:      { gradient: 'from-purple-500 to-fuchsia-600',    Icon: Music },
  ia:         { gradient: 'from-teal-500 to-cyan-600',          Icon: Sparkles },
  search:     { gradient: 'from-sky-500 to-indigo-600',        Icon: Globe },
  chat:       { gradient: 'from-violet-500 to-purple-600',      Icon: MessageCircle },
  tv:         { gradient: 'from-red-500 to-rose-700',           Icon: Tv },
  meet:       { gradient: 'from-blue-500 to-indigo-600',        Icon: Video },
  whiteboard: { gradient: 'from-amber-500 to-orange-600',      Icon: Edit },
};

// ── Custom logos cache (module-level) ──
let customLogos = {};
let loaded = false;
const listeners = new Set();

export async function reloadCustomLogos() {
  try {
    const results = await base44.entities.AppSettings.filter({ key: 'custom_logos' });
    if (results.length > 0 && results[0].value) {
      customLogos = JSON.parse(results[0].value);
    } else {
      customLogos = {};
    }
  } catch {
    customLogos = {};
  }
  loaded = true;
  listeners.forEach(fn => fn(customLogos));
  window.dispatchEvent(new CustomEvent('logos-updated'));
}

reloadCustomLogos();

export function useCustomLogos() {
  const [logos, setLogos] = useState(customLogos);
  useEffect(() => {
    const fn = (newLogos) => setLogos(newLogos);
    listeners.add(fn);
    if (loaded) setLogos(customLogos);
    return () => { listeners.delete(fn); };
  }, []);
  return logos;
}

export function AppIcon({ id, size = 56, className = '', rounded = '' }) {
  const customLogos = useCustomLogos();
  const style = APP_STYLES[id];
  if (!style) return null;

  // Custom logo image takes priority
  if (customLogos[id]) {
    return (
      <img
        src={customLogos[id]}
        alt={id}
        className={`${rounded} ${className} object-cover flex-shrink-0`}
        style={{ width: size, height: size, borderRadius: '28%' }}
      />
    );
  }

  const s = size;
  return (
    <div
      className={`relative bg-gradient-to-br ${style.gradient} ${rounded} ${className} flex items-center justify-center flex-shrink-0 transition-all duration-200 hover:scale-105 hover:shadow-md`}
      style={{
        width: s,
        height: s,
        borderRadius: '28%',
        boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
      }}
    >
      <style.Icon
        className="text-white"
        style={{ width: s * 0.44, height: s * 0.44 }}
        strokeWidth={1.8}
      />
    </div>
  );
}

/** Map CloudFile type → AppIcon id (for document-type files) */
export const FILE_TYPE_ICON = {
  document: 'word',
  spreadsheet: 'tabs',
  presentation: 'sliders',
  drawing: 'draws',
};

export default AppIcon;