import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { MessageSquare, Send, X, Check, Loader2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function CommentsPanel({ fileId, user, onClose }) {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');

  const loadComments = async () => {
    if (!fileId) return;
    try {
      const list = await base44.entities.Comment.filter({ file_id: fileId });
      list.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
      setComments(list);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { loadComments(); }, [fileId]);

  useEffect(() => {
    if (!fileId) return undefined;
    const unsub = base44.entities.Comment.subscribe(() => { loadComments(); });
    return unsub;
  }, [fileId]);

  const send = async () => {
    if (!text.trim() || !user) return;
    try {
      await base44.entities.Comment.create({
        file_id: fileId,
        user_email: user.email,
        user_name: user.full_name || user.email,
        text: text.trim(),
      });
      setText('');
      loadComments();
    } catch {
      toast.error('Erreur lors de l\'envoi du commentaire');
    }
  };

  const resolve = async (c) => {
    try {
      await base44.entities.Comment.update(c.id, { resolved: !c.resolved });
      loadComments();
    } catch {}
  };

  const remove = async (c) => {
    try {
      await base44.entities.Comment.delete(c.id);
      loadComments();
    } catch {}
  };

  return (
    <div className="fixed right-0 top-0 bottom-0 w-full max-w-sm bg-white dark:bg-gray-900 border-l border-gray-200 dark:border-gray-700 z-50 flex flex-col animate-fade-up shadow-2xl">
      <div className="flex items-center gap-2 p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
        <MessageSquare className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        <span className="font-semibold text-gray-900 dark:text-white">Commentaires</span>
        <button onClick={onClose} className="ml-auto text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-gray-400" /></div>
        ) : comments.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <MessageSquare className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Aucun commentaire pour le moment.</p>
            <p className="text-xs mt-1">Démarrez la discussion ci-dessous.</p>
          </div>
        ) : (
          comments.map(c => (
            <div key={c.id} className={`p-3 rounded-xl ${c.resolved ? 'bg-green-50 dark:bg-green-900/20 opacity-60' : 'bg-gray-50 dark:bg-gray-800'}`}>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-indigo-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {(c.user_name || '?')[0].toUpperCase()}
                </div>
                <span className="text-sm font-medium text-gray-900 dark:text-white truncate">{c.user_name || c.user_email}</span>
                {c.resolved && <Check className="w-4 h-4 text-green-500 flex-shrink-0" />}
              </div>
              <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap break-words">{c.text}</p>
              <div className="flex gap-2 mt-2">
                <button onClick={() => resolve(c)} className="text-xs text-gray-400 hover:text-green-500 transition-colors">
                  {c.resolved ? 'Rouvrir' : 'Résoudre'}
                </button>
                {c.user_email === user?.email && (
                  <button onClick={() => remove(c)} className="text-xs text-gray-400 hover:text-red-500 transition-colors">
                    Supprimer
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
      <div className="p-3 border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
        <div className="flex gap-2">
          <Input
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
            placeholder="Écrire un commentaire..."
            className="flex-1"
          />
          <Button onClick={send} disabled={!text.trim()} size="icon" className="flex-shrink-0">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}