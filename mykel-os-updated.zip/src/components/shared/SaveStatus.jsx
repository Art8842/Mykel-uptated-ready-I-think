import React from 'react';
import { Cloud, CloudOff, Loader2, Check } from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';

const LABELS = {
  fr: { saving: 'Enregistrement…', dirty: 'Modifications en attente…', error: 'Non enregistré — nouvelle tentative…', saved: 'Enregistré', at: 'à', cloud: 'dans Mykel Cloud' },
  en: { saving: 'Saving…', dirty: 'Unsaved changes…', error: 'Not saved — retrying…', saved: 'Saved', at: 'at', cloud: 'to Mykel Cloud' },
  es: { saving: 'Guardando…', dirty: 'Cambios pendientes…', error: 'No guardado — reintentando…', saved: 'Guardado', at: 'a las', cloud: 'en Mykel Cloud' },
  de: { saving: 'Speichern…', dirty: 'Ungespeicherte Änderungen…', error: 'Nicht gespeichert — neuer Versuch…', saved: 'Gespeichert', at: 'um', cloud: 'in Mykel Cloud' },
  pt: { saving: 'Salvando…', dirty: 'Alterações pendentes…', error: 'Não salvo — tentando novamente…', saved: 'Salvo', at: 'às', cloud: 'no Mykel Cloud' },
  ar: { saving: 'جارٍ الحفظ…', dirty: 'تغييرات غير محفوظة…', error: 'لم يتم الحفظ — إعادة المحاولة…', saved: 'تم الحفظ', at: 'في', cloud: 'في Mykel Cloud' },
};

export default function SaveStatus({ status, lastSaved, dark = false }) {
  const { lang } = useLanguage();
  const L = LABELS[lang] || LABELS.fr;
  const muted = dark ? 'text-white/40' : 'text-gray-500';
  const base = 'flex items-center gap-1.5 text-xs whitespace-nowrap';

  if (status === 'saving') {
    return <span className={`${base} ${muted}`}><Loader2 className="w-3 h-3 animate-spin" />{L.saving}</span>;
  }
  if (status === 'error') {
    return <span className={`${base} text-red-500`}><CloudOff className="w-3 h-3" />{L.error}</span>;
  }
  if (status === 'dirty') {
    return <span className={`${base} ${muted}`}><Cloud className="w-3 h-3" />{L.dirty}</span>;
  }
  if (status === 'saved') {
    const time = lastSaved ? `${L.at} ${lastSaved.toLocaleTimeString(lang, { hour: '2-digit', minute: '2-digit' })}` : L.cloud;
    return <span className={`${base} ${muted}`}><Check className="w-3 h-3 text-emerald-500" />{L.saved} {time}</span>;
  }
  return <span className={`${base} ${muted}`}><Cloud className="w-3 h-3" />Mykel Cloud</span>;
}