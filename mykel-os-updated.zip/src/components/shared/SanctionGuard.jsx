import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Timer component showing countdown until unban
function UnbanTimer({ bannedUntil, onExpired }) {
  const [remaining, setRemaining] = useState('');
  const [expired, setExpired] = useState(false);

  useEffect(() => {
    const update = () => {
      const diff = new Date(bannedUntil) - new Date();
      if (diff <= 0) {
        setRemaining('');
        setExpired(true);
        onExpired?.();
        return;
      }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setRemaining(`${d > 0 ? d + 'j ' : ''}${h}h ${m}m ${s}s`);
    };
    update();
    const t = setInterval(update, 1000);
    return () => clearInterval(t);
  }, [bannedUntil]);

  if (expired) return null;
  return <span className="font-mono text-red-300">{remaining}</span>;
}

// Shown when user is banned from the full platform or Mykel Music specifically
export default function SanctionGuard({ scope, children }) {
  const navigate = useNavigate();
  const [sanction, setSanction] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expired, setExpired] = useState(false);

  useEffect(() => { checkSanction(); }, []);

  const checkSanction = async () => {
    try {
      const user = await base44.auth.me();
      const sanctions = await base44.entities.UserSanction.filter({ user_email: user.email, active: true });
      const now = new Date();
      const active = sanctions.find(s => {
        if (!s.active) return false;
        if (s.scope !== scope && scope !== 'platform') return false;
        if (scope === 'platform' && s.scope !== 'platform') return false;
        if (s.permanent) return true;
        if (s.banned_until && new Date(s.banned_until) > now) return true;
        return false;
      });
      setSanction(active || null);

      // Mark as notified
      if (active && !active.user_acknowledged) {
        await base44.entities.UserSanction.update(active.id, { user_acknowledged: true });
      }
    } catch {}
    finally { setLoading(false); }
  };

  const openSupport = () => navigate(createPageUrl('Dashboard'));

  if (loading) return null;
  if (!sanction || expired) return children;

  const isBan = sanction.sanction_type === 'ban';
  const isMusicOnly = sanction.scope === 'mykel_music';

  if (!isBan) {
    // Warning: show overlay but allow access
    return (
      <>
        <WarningOverlay sanction={sanction} onClose={() => setSanction(null)} onSupport={openSupport} />
        {children}
      </>
    );
  }

  // Full ban screen
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-red-950">
      <div className="max-w-sm w-full mx-4 bg-red-900 rounded-2xl border-2 border-red-600 p-8 text-center space-y-6 shadow-2xl">
        <div className="w-16 h-16 bg-red-700 rounded-2xl flex items-center justify-center mx-auto">
          <span className="text-4xl">🚫</span>
        </div>
        <div>
          <h1 className="text-white font-bold text-xl mb-2">
            {isMusicOnly ? 'Accès à Mykel Music refusé' : 'Vous avez été banni'}
          </h1>
          <p className="text-red-200 text-sm">
            Raison : <span className="text-white font-medium">{sanction.reason}</span>
          </p>
        </div>

        {sanction.permanent ? (
          <div className="p-4 bg-red-800 rounded-xl">
            <p className="text-red-200 text-sm font-medium">Bannissement définitif</p>
            <p className="text-red-300 text-xs mt-1">Aucun accès possible.</p>
          </div>
        ) : (
          <div className="p-4 bg-red-800 rounded-xl space-y-2">
            <p className="text-red-200 text-xs">Vous pourrez accéder dans :</p>
            <UnbanTimer bannedUntil={sanction.banned_until} onExpired={() => { setExpired(true); setSanction(null); }} />
          </div>
        )}

        <div className="space-y-3">
          {!sanction.permanent && isMusicOnly && (
            <Button
              disabled={!expired}
              onClick={() => { setExpired(true); setSanction(null); }}
              className="w-full bg-purple-600 hover:bg-purple-700 disabled:opacity-40"
            >
              Ouvrir Mykel Music
            </Button>
          )}
          {!sanction.permanent && !isMusicOnly && (
            <Button
              disabled={!expired}
              onClick={() => { setExpired(true); setSanction(null); }}
              className="w-full bg-white text-red-900 hover:bg-red-100 disabled:opacity-40"
            >
              Ouvrir Mykel
            </Button>
          )}
          {isMusicOnly && (
            <Button variant="outline" className="w-full border-red-500 text-red-200 hover:bg-red-800" onClick={() => navigate(createPageUrl('Dashboard'))}>
              Retour à l'accueil
            </Button>
          )}
          <Button variant="ghost" className="w-full text-red-300 hover:text-white hover:bg-red-800 text-sm" onClick={openSupport}>
            📩 Contacter le support
          </Button>
        </div>
      </div>
    </div>
  );
}

function WarningOverlay({ sanction, onClose, onSupport }) {
  const [acknowledged, setAcknowledged] = useState(false);
  if (acknowledged) return null;
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="max-w-sm w-full mx-4 bg-orange-900 rounded-2xl border-2 border-orange-500 p-8 text-center space-y-4 shadow-2xl">
        <div className="w-14 h-14 bg-orange-600 rounded-2xl flex items-center justify-center mx-auto">
          <span className="text-3xl">⚠️</span>
        </div>
        <div>
          <h1 className="text-white font-bold text-xl mb-2">Avertissement</h1>
          <p className="text-orange-100 text-sm">
            Raison : <span className="text-white font-medium">{sanction.reason}</span>
          </p>
        </div>
        <div className="space-y-2">
          <Button className="w-full bg-orange-600 hover:bg-orange-700" onClick={() => { setAcknowledged(true); onClose(); }}>
            J'ai compris
          </Button>
          <Button variant="ghost" className="w-full text-orange-300 hover:text-white text-sm" onClick={onSupport}>
            📩 Contacter le support
          </Button>
        </div>
      </div>
    </div>
  );
}