import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from 'lucide-react';

/**
 * Affiche les annonces actives pour une cible donnée.
 * target: 'home' | 'app'
 * targetApp: clé de l'app (ex: 'MykelWord') — requis si target='app'
 */
export default function AnnouncementModal({ target, targetApp }) {
  const [announcements, setAnnouncements] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState({});

  useEffect(() => {
    loadAnnouncements();
  }, [target, targetApp]);

  const loadAnnouncements = async () => {
    try {
      const all = await base44.entities.Announcement.filter({ active: true });
      const relevant = target === 'app'
        ? all.filter(a => a.target === 'app' && a.target_app === targetApp)
        : all.filter(a => a.target === 'home');

      // Filter out ones user has permanently dismissed
      const dismissed = JSON.parse(localStorage.getItem('dismissed_announcements') || '{}');
      const toShow = relevant.filter(a => !dismissed[a.id]);

      // Filter based on frequency (once = only if not seen, always = always)
      const seen = JSON.parse(localStorage.getItem('seen_announcements') || '{}');
      const filtered = toShow.filter(a => {
        if (a.frequency === 'always') return true;
        return !seen[a.id];
      });

      if (filtered.length > 0) {
        setAnnouncements(filtered);
        setCurrentIndex(0);
        setOpen(true);
        // Mark as seen
        const newSeen = { ...seen };
        filtered.forEach(a => { newSeen[a.id] = true; });
        localStorage.setItem('seen_announcements', JSON.stringify(newSeen));
      }
    } catch {
      // Silently fail
    }
  };

  const handleDismiss = (ann) => {
    const dismissed = JSON.parse(localStorage.getItem('dismissed_announcements') || '{}');
    dismissed[ann.id] = true;
    localStorage.setItem('dismissed_announcements', JSON.stringify(dismissed));
    handleNext();
  };

  const handleButtonAction = (ann, btn) => {
    const action = btn.action || 'close';
    if (action === 'dismiss' || action === 'accept') {
      const dismissed = JSON.parse(localStorage.getItem('dismissed_announcements') || '{}');
      dismissed[ann.id] = true;
      localStorage.setItem('dismissed_announcements', JSON.stringify(dismissed));
      // Record acceptance
      if (action === 'accept') {
        const accepted = JSON.parse(localStorage.getItem('accepted_announcements') || '{}');
        accepted[ann.id] = { date: new Date().toISOString(), label: btn.label };
        localStorage.setItem('accepted_announcements', JSON.stringify(accepted));
      }
    }
    if (action === 'decline') {
      const declined = JSON.parse(localStorage.getItem('declined_announcements') || '{}');
      declined[ann.id] = { date: new Date().toISOString(), label: btn.label };
      localStorage.setItem('declined_announcements', JSON.stringify(declined));
    }
    if (action === 'link' && btn.url) {
      window.open(btn.url, '_blank');
    }
    handleNext();
  };

  const handleNext = () => {
    if (currentIndex < announcements.length - 1) {
      setCurrentIndex(i => i + 1);
    } else {
      setOpen(false);
    }
  };

  if (!open || announcements.length === 0) return null;

  const current = announcements[currentIndex];
  const hasCustomButtons = current.buttons && current.buttons.length > 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-md bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
        <div className="flex flex-col gap-4 py-2">
          <div>
            <p className="text-gray-800 dark:text-gray-100 text-base leading-relaxed whitespace-pre-wrap font-medium text-left">{current.text}</p>
          </div>
          <div className="flex flex-col gap-2 w-full pt-2">
            {hasCustomButtons ? (
              <div className="flex flex-col gap-2 w-full">
                {current.buttons.map((btn, i) => {
                  const isAccept = btn.action === 'accept' || btn.action === 'dismiss';
                  const isDecline = btn.action === 'decline';
                  return (
                    <Button
                      key={i}
                      onClick={() => handleButtonAction(current, btn)}
                      className={`w-full ${isDecline ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' : isAccept ? 'bg-blue-600 hover:bg-blue-700 text-white' : ''}`}
                      variant={isDecline ? 'secondary' : 'default'}
                    >
                      {btn.label}
                    </Button>
                  );
                })}
              </div>
            ) : (
              <>
                <Button onClick={handleNext} className="w-full">
                  {currentIndex < announcements.length - 1 ? 'Suivant' : 'Fermer'}
                </Button>
                {current.dismissible && (
                  <Button variant="ghost" onClick={() => handleDismiss(current)} className="w-full text-sm text-gray-400 hover:text-gray-600">
                    Ne plus afficher cette information
                  </Button>
                )}
              </>
            )}
          </div>
          {announcements.length > 1 && (
            <p className="text-xs text-gray-400 text-center">{currentIndex + 1} / {announcements.length}</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}