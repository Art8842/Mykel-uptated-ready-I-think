import React from 'react';

/**
 * AILoader - Animated AI loading indicator
 * Replaces boring spinners with beautiful star/sparkle animation
 * Usage: <AILoader size="md" text="Traitement IA en cours..." />
 */
export default function AILoader({ size = 'md', text, color = 'purple', className = '' }) {
  const sizes = {
    sm: { container: 32, star: 6, orbit: 14 },
    md: { container: 56, star: 8, orbit: 22 },
    lg: { container: 80, star: 10, orbit: 32 },
    xl: { container: 120, star: 14, orbit: 48 },
  };
  const s = sizes[size] || sizes.md;

  const colors = {
    purple: { primary: '#a855f7', secondary: '#ec4899', glow: 'rgba(168,85,247,0.4)' },
    pink: { primary: '#ec4899', secondary: '#f97316', glow: 'rgba(236,72,153,0.4)' },
    blue: { primary: '#3b82f6', secondary: '#06b6d4', glow: 'rgba(59,130,246,0.4)' },
    white: { primary: '#ffffff', secondary: '#cbd5e1', glow: 'rgba(255,255,255,0.3)' },
  };
  const c = colors[color] || colors.purple;

  return (
    <div className={`flex flex-col items-center gap-3 ${className}`}>
      <div style={{ width: s.container, height: s.container, position: 'relative' }}>
        <style>{`
          @keyframes ai-orbit-1 {
            0%   { transform: rotate(0deg)   translateX(${s.orbit}px) rotate(0deg); }
            100% { transform: rotate(360deg) translateX(${s.orbit}px) rotate(-360deg); }
          }
          @keyframes ai-orbit-2 {
            0%   { transform: rotate(120deg)   translateX(${s.orbit}px) rotate(-120deg); }
            100% { transform: rotate(480deg)   translateX(${s.orbit}px) rotate(-480deg); }
          }
          @keyframes ai-orbit-3 {
            0%   { transform: rotate(240deg)   translateX(${s.orbit}px) rotate(-240deg); }
            100% { transform: rotate(600deg)   translateX(${s.orbit}px) rotate(-600deg); }
          }
          @keyframes ai-orbit-4 {
            0%   { transform: rotate(60deg)    translateX(${s.orbit * 0.65}px) rotate(-60deg); }
            100% { transform: rotate(420deg)   translateX(${s.orbit * 0.65}px) rotate(-420deg); }
          }
          @keyframes ai-center-pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50%       { opacity: 0.6; transform: scale(0.8); }
          }
          @keyframes ai-glow {
            0%, 100% { box-shadow: 0 0 ${s.container * 0.3}px ${c.glow}; }
            50%       { box-shadow: 0 0 ${s.container * 0.6}px ${c.glow}, 0 0 ${s.container * 0.2}px ${c.primary}40; }
          }
          @keyframes ai-star-twinkle {
            0%, 100% { opacity: 1; transform: scale(1) rotate(0deg); }
            25%       { opacity: 0.7; transform: scale(0.7) rotate(45deg); }
            75%       { opacity: 0.9; transform: scale(1.2) rotate(-15deg); }
          }
        `}</style>

        {/* Glow background */}
        <div style={{
          position: 'absolute', inset: 0,
          borderRadius: '50%',
          animation: `ai-glow 2s ease-in-out infinite`,
        }} />

        {/* Center star */}
        <div style={{
          position: 'absolute',
          top: '50%', left: '50%',
          transform: 'translate(-50%, -50%)',
          animation: 'ai-center-pulse 1.5s ease-in-out infinite',
        }}>
          <StarShape size={s.star * 1.5} color={c.primary} />
        </div>

        {/* Orbiting stars */}
        {[
          { anim: 'ai-orbit-1', dur: '1.8s', color: c.primary, starSize: s.star },
          { anim: 'ai-orbit-2', dur: '1.8s', color: c.secondary, starSize: s.star * 0.8 },
          { anim: 'ai-orbit-3', dur: '1.8s', color: c.primary, starSize: s.star * 0.6 },
          { anim: 'ai-orbit-4', dur: '2.4s', color: c.secondary, starSize: s.star * 0.5 },
        ].map((item, i) => (
          <div
            key={i}
            style={{
              position: 'absolute',
              top: '50%', left: '50%',
              marginTop: -item.starSize / 2,
              marginLeft: -item.starSize / 2,
              animation: `${item.anim} ${item.dur} linear infinite`,
              animationDelay: `${i * 0.15}s`,
            }}
          >
            <div style={{ animation: `ai-star-twinkle ${1.2 + i * 0.3}s ease-in-out infinite`, animationDelay: `${i * 0.2}s` }}>
              <StarShape size={item.starSize} color={item.color} />
            </div>
          </div>
        ))}
      </div>

      {text && (
        <p style={{ color: c.primary }} className="text-sm font-medium animate-pulse text-center">{text}</p>
      )}
    </div>
  );
}

function StarShape({ size, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg"
      style={{ filter: `drop-shadow(0 0 ${size * 0.3}px ${color})` }}>
      <path d="M12 2L13.5 9H20.5L15 13.5L17 20.5L12 16.5L7 20.5L9 13.5L3.5 9H10.5L12 2Z"/>
    </svg>
  );
}

/** Inline AI badge shown next to content being processed */
export function AISparkle({ size = 16, color = '#a855f7' }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', position: 'relative' }}>
      <style>{`
        @keyframes sparkle-rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes sparkle-pulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:0.6; transform:scale(0.8); } }
      `}</style>
      <svg width={size} height={size} viewBox="0 0 24 24" fill={color}
        style={{ animation: 'sparkle-rotate 2s linear infinite', filter: `drop-shadow(0 0 3px ${color})` }}>
        <path d="M12 2L13.5 9H20.5L15 13.5L17 20.5L12 16.5L7 20.5L9 13.5L3.5 9H10.5L12 2Z"/>
      </svg>
    </span>
  );
}