import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Search, Loader2, AlertCircle, Globe, X, ExternalLink } from 'lucide-react';
import { Input } from '@/components/ui/input';

const BROWSERLESS_TOKEN = '2V1YYONuj1TfvB26b77d07cf59b5f667d2117944928f7609e';
const SCREENSHOT_ENDPOINT = `https://production-sfo.browserless.io/screenshot?token=${BROWSERLESS_TOKEN}`;

const QUICK_LINKS = [
  { label: 'Google', url: 'https://www.google.com', icon: '🔍' },
  { label: 'YouTube', url: 'https://www.youtube.com', icon: '▶️' },
  { label: 'Wikipedia', url: 'https://fr.wikipedia.org', icon: '📖' },
  { label: 'GitHub', url: 'https://github.com', icon: '🐙' },
  { label: 'X / Twitter', url: 'https://x.com', icon: '𝕏' },
  { label: 'Reddit', url: 'https://www.reddit.com', icon: '🤖' },
];

function buildUrl(input) {
  const trimmed = input.trim();
  if (!trimmed) return null;
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  if (/^[\w-]+\.[\w.-]+/.test(trimmed) && !trimmed.includes(' ')) return 'https://' + trimmed;
  return `https://www.google.com/search?q=${encodeURIComponent(trimmed)}`;
}

export default function NavigateurMykel({ initialUrl = '', showSearchBar = true, showQuickLinks = true }) {
  const [inputUrl, setInputUrl] = useState('');
  const [currentUrl, setCurrentUrl] = useState('');
  const [screenshotUrl, setScreenshotUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [searchInput, setSearchInput] = useState('');
  const historyRef = useRef([]);
  const historyIndexRef = useRef(-1);

  useEffect(() => { historyRef.current = history; }, [history]);
  useEffect(() => { historyIndexRef.current = historyIndex; }, [historyIndex]);

  const loadUrl = (targetUrl, pushHistory = true) => {
    if (!BROWSERLESS_TOKEN) {
      setError('Ajoute ta clé Browserless dans [API_BROWSERLESS]');
      return;
    }

    setLoading(true);
    setError('');

    // Use GET request — images loaded via <img> tags bypass CORS restrictions
    const screenshot = `${SCREENSHOT_ENDPOINT}&url=${encodeURIComponent(targetUrl)}`;
    setScreenshotUrl(screenshot);
    setCurrentUrl(targetUrl);
    setInputUrl(targetUrl);

    if (pushHistory) {
      const newHistory = [...historyRef.current.slice(0, historyIndexRef.current + 1), targetUrl];
      historyRef.current = newHistory;
      historyIndexRef.current = newHistory.length - 1;
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  // Load initial URL on mount
  useEffect(() => {
    if (initialUrl) {
      setInputUrl(initialUrl);
      loadUrl(initialUrl);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (e) => {
    e?.preventDefault();
    const target = buildUrl(inputUrl);
    if (target) loadUrl(target);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    const url = `https://www.google.com/search?q=${encodeURIComponent(searchInput.trim())}`;
    loadUrl(url);
    setSearchInput('');
  };

  const goBack = () => {
    if (historyIndex > 0) {
      const ni = historyIndex - 1;
      setHistoryIndex(ni);
      loadUrl(history[ni], false);
    }
  };

  const openExternal = () => {
    if (currentUrl) window.open(currentUrl, '_blank', 'noopener,noreferrer');
  };

  const handleImgLoad = () => setLoading(false);
  const handleImgError = () => {
    setLoading(false);
    setError('Ce site ne peut pas être chargé');
  };

  return (
    <div className="h-full flex flex-col bg-gray-950">
      {/* Search bar — clean, centered, NOT a browser URL bar */}
      {showSearchBar && (
        <div className="p-4 bg-gray-900 flex-shrink-0">
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                value={inputUrl}
                onChange={e => setInputUrl(e.target.value)}
                placeholder="Rechercher ou entrer une URL..."
                className="pl-12 pr-10 h-12 rounded-full bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus-visible:ring-2 focus-visible:ring-blue-500"
              />
              {inputUrl && (
                <button type="button" onClick={() => setInputUrl('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </form>
        </div>
      )}

      {/* Viewport */}
      <div className="flex-1 overflow-auto relative">
        {/* Floating controls — subtle, appears over the preview */}
        {currentUrl && !error && (
          <>
            {historyIndex > 0 && (
              <button
                onClick={goBack}
                className="absolute top-4 left-4 z-50 w-10 h-10 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/80 transition-all shadow-lg"
                title="Retour"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="absolute top-4 right-4 z-50 flex items-center gap-2">
              <button
                onClick={openExternal}
                className="w-10 h-10 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/80 transition-all shadow-lg"
                title="Ouvrir dans un nouvel onglet"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
              <span className="px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-medium pointer-events-none shadow-lg">
                Aperçu
              </span>
            </div>
          </>
        )}

        {/* Content */}
        {error ? (
          <div className="flex flex-col items-center justify-center h-full text-white p-8">
            <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
            <p className="text-lg text-center">{error}</p>
          </div>
        ) : screenshotUrl ? (
          <div className="relative min-h-full flex justify-center p-4">
            {loading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-gray-950 z-10">
                <Loader2 className="w-12 h-12 animate-spin text-blue-500 mb-4" />
                <p className="text-lg">Génération de l'aperçu...</p>
              </div>
            )}
            <img
              src={screenshotUrl}
              alt="Aperçu du site"
              className="max-w-full rounded-lg shadow-2xl"
              style={{ maxHeight: '90vh' }}
              onLoad={handleImgLoad}
              onError={handleImgError}
            />
          </div>
        ) : showQuickLinks ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-8 p-6 bg-gradient-to-b from-gray-900 to-gray-950 h-full">
            <div className="flex flex-col items-center gap-3">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center shadow-lg">
                <Globe className="w-9 h-9 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white">Mykel Search</h1>
              <p className="text-sm text-gray-400">Recherchez sur le web ou entrez une URL</p>
            </div>
            <form onSubmit={handleSearchSubmit} className="w-full max-w-xl">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  value={searchInput}
                  onChange={e => setSearchInput(e.target.value)}
                  placeholder="Rechercher sur Google..."
                  className="pl-12 pr-4 h-14 text-base rounded-full border border-gray-700 shadow-sm bg-gray-800 text-white focus-visible:ring-2 focus-visible:ring-blue-500"
                  autoFocus
                />
                {searchInput && (
                  <button type="button" onClick={() => setSearchInput('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </form>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-4">
              {QUICK_LINKS.map(link => (
                <button key={link.url} onClick={() => loadUrl(link.url)} className="flex flex-col items-center gap-2 p-3 rounded-2xl hover:bg-gray-800 transition-all group">
                  <div className="w-12 h-12 bg-gray-800 rounded-xl shadow-sm flex items-center justify-center text-2xl group-hover:shadow-md transition-all border border-gray-700">
                    {link.icon}
                  </div>
                  <span className="text-xs text-gray-400 font-medium">{link.label}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-white">
            <Loader2 className="w-12 h-12 animate-spin text-blue-500 mb-4" />
            <p className="text-lg">Chargement...</p>
          </div>
        )}
      </div>
    </div>
  );
}