import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2, Upload, Film, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ClipUploadDialog({ track, onClose, onSaved }) {
  const [clipUrl, setClipUrl] = useState(track?.clip_url || '');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef(null);

  const upload = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await uploadMedia(file);
      setClipUrl(file_url);
      toast.success('Clip importé');
    } catch { toast.error('Erreur upload'); }
    finally { setUploading(false); }
  };

  const save = async () => {
    setSaving(true);
    try {
      await base44.entities.MusicTrack.update(track.id, { clip_url: clipUrl || null });
      toast.success(clipUrl ? 'Clip associé' : 'Clip retiré');
      onSaved?.();
      onClose();
    } catch { toast.error('Erreur'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-gray-900 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-white">Clip vidéo — {track?.title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <p className="text-white/60 text-sm">Associez un clip vidéo à ce morceau. Les auditeurs pourront le regarder depuis le lecteur.</p>
          <input type="file" ref={fileRef} accept="video/*" className="hidden"
            onChange={e => { const f = e.target.files?.[0]; if (f) upload(f); }} />
          <Button variant="outline" className="w-full border-gray-600 text-white/70" onClick={() => fileRef.current?.click()} disabled={uploading}>
            {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
            {clipUrl ? 'Changer la vidéo' : 'Choisir une vidéo'}
          </Button>
          {clipUrl && (
            <div className="space-y-2">
              <video src={clipUrl} controls className="w-full rounded-lg max-h-48" />
              <button
                onClick={() => setClipUrl('')}
                className="w-full flex items-center justify-center gap-2 text-red-400 hover:text-red-300 text-sm py-2"
              >
                <Trash2 className="w-4 h-4" /> Retirer le clip
              </button>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" className="text-white/60" onClick={onClose}>Annuler</Button>
          <Button className="bg-purple-600 hover:bg-purple-700" disabled={saving} onClick={save}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Film className="w-4 h-4 mr-2" />}
            Enregistrer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}