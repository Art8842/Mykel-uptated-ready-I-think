import React, { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';

export default function ClipPlayer({ clipUrl, title, startTime, onClose }) {
  const videoRef = useRef(null);
  const [closing, setClosing] = useState(false);

  useEffect(() => {
    if (videoRef.current && startTime) {
      videoRef.current.currentTime = startTime;
    }
    videoRef.current?.play().catch(() => {});
  }, [startTime]);

  const handleClose = () => {
    const t = videoRef.current?.currentTime || 0;
    setClosing(true);
    onClose(t);
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black flex items-center justify-center">
      <button
        onClick={handleClose}
        className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
      >
        <X className="w-5 h-5" />
      </button>
      {title && (
        <p className="absolute top-5 left-5 text-white/80 text-sm font-medium">{title} — Clip</p>
      )}
      <video
        ref={videoRef}
        src={clipUrl}
        controls
        autoPlay
        className="max-w-full max-h-full"
        onEnded={handleClose}
      />
    </div>
  );
}