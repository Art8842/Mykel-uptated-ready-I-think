import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, ChevronRight } from 'lucide-react';
import VerifiedBadge from '@/components/music/VerifiedBadge';

export default function EditorialSection({ onOpenPlaylist }) {
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.EditorialPlaylist.filter({ is_published: true }, '-created_date', 20)
      .then(list => setPlaylists(list))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading || playlists.length === 0) return null;

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <VerifiedBadge type="editorial" size={20} />
        <h2 className="text-white font-bold text-xl">Sélections de l'équipe éditoriale</h2>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
        {playlists.map(pl => (
          <button
            key={pl.id}
            onClick={() => onOpenPlaylist(pl)}
            className="flex-shrink-0 w-44 text-left group"
          >
            <div className="w-44 h-44 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-600 overflow-hidden mb-2 relative">
              {pl.cover_url
                ? <img src={pl.cover_url} className="w-full h-full object-cover" alt="" />
                : <div className="w-full h-full flex items-center justify-center"><Sparkles className="w-10 h-10 text-white/50" /></div>
              }
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 w-10 h-10 bg-white rounded-full flex items-center justify-center transition-all">
                  <ChevronRight className="w-5 h-5 text-emerald-900" />
                </div>
              </div>
            </div>
            <p className="font-medium text-white text-sm truncate">{pl.name}</p>
            <p className="text-xs text-white/40 truncate">par {pl.editor_name || 'Mykel'} · {pl.track_ids?.length || 0} titre(s)</p>
          </button>
        ))}
      </div>
    </div>
  );
}