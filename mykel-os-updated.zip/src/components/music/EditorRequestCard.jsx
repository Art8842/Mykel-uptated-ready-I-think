import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, CheckCircle, Clock, XCircle, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function EditorRequestCard({ user }) {
  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [motivation, setMotivation] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user?.email) return;
    base44.entities.EditorRequest.filter({ user_email: user.email }, '-created_date', 1)
      .then(list => setRequest(list[0] || null))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user]);

  const submit = async () => {
    if (!motivation.trim()) { toast.error('Expliquez votre motivation'); return; }
    setSubmitting(true);
    try {
      const created = await base44.entities.EditorRequest.create({
        user_email: user.email,
        user_name: user.full_name || user.email,
        motivation: motivation.trim(),
        status: 'pending',
      });
      setRequest(created);
      setMotivation('');
      toast.success('Demande envoyée ! Un administrateur l\'examinera.');
    } catch { toast.error('Erreur lors de l\'envoi'); }
    finally { setSubmitting(false); }
  };

  if (loading) return <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 animate-spin text-purple-400" /></div>;

  if (request?.status === 'approved') {
    return (
      <div className="flex items-start gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/30">
        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-white font-medium text-sm">Vous êtes éditeur Mykel Music</p>
          <p className="text-white/50 text-xs mt-0.5">Vous pouvez créer des playlists éditoriales depuis le menu ⋮ de Mykel Music.</p>
        </div>
      </div>
    );
  }

  if (request?.status === 'pending') {
    return (
      <div className="flex items-start gap-3 p-4 rounded-xl bg-white/5 border border-white/10">
        <Clock className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-white font-medium text-sm">Demande en attente</p>
          <p className="text-white/50 text-xs mt-0.5">Votre demande est en cours d'examen par un administrateur.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-start gap-3 p-4 rounded-xl bg-purple-500/10 border border-purple-500/30">
        <Sparkles className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-white font-medium text-sm">Devenez éditeur Mykel Music</p>
          <p className="text-white/50 text-xs mt-0.5">Créez des playlists éditoriales mises en avant sur la page d'accueil de Mykel Music.</p>
        </div>
      </div>
      {request?.status === 'rejected' && (
        <div className="flex items-start gap-3 p-3 rounded-xl bg-red-500/10 border border-red-500/30">
          <XCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
          <p className="text-red-300 text-xs">Votre précédente demande a été refusée. Vous pouvez en soumettre une nouvelle.</p>
        </div>
      )}
      <textarea
        value={motivation}
        onChange={e => setMotivation(e.target.value)}
        rows={3}
        placeholder="Expliquez pourquoi vous souhaitez devenir éditeur..."
        className="w-full bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm resize-none placeholder:text-white/40"
      />
      <Button onClick={submit} disabled={submitting} className="w-full bg-purple-600 hover:bg-purple-700">
        {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
        Soumettre ma demande
      </Button>
    </div>
  );
}