import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Music, Users, Play, Pause, Clock, ChevronDown, Disc3, BarChart3, Video, Upload, X, Crown, Calendar } from 'lucide-react';
import { useMusicPlayer } from '@/components/shared/MusicPlayerContext';
import VerifiedBadge from '@/components/music/VerifiedBadge';
import ClipUploadDialog from '@/components/music/ClipUploadDialog';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

function formatListeners(n) {
  if (!n) return '0';
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'Md';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}

export default function ArtistPage({ creator, tracks, onBack, currentTrack, isPlaying, onPlay, user, allCreators }) {
  const now = new Date();
  const [view, setView] = useState('main'); // 'main' | 'details' | 'discography' | 'album'
  const [selectedAlbum, setSelectedAlbum] = useState(null);
  const [clipTrack, setClipTrack] = useState(null);
  const [showClipUpload, setShowClipUpload] = useState(null);
  const [watchingClip, setWatchingClip] = useState(null);
  const [localTracks, setLocalTracks] = useState(tracks);

  useEffect(() => { setLocalTracks(tracks); }, [tracks]);

  const artistTracks = localTracks.filter(t => t.creator_email === creator.user_email || t.stage_name === creator.stage_name);

  // Group tracks by album
  const albums = useMemo(() => {
    const map = new Map();
    for (const t of artistTracks) {
      if (t.album_name) {
        if (!map.has(t.album_name)) {
          map.set(t.album_name, { name: t.album_name, cover_url: t.album_cover_url, tracks: [], release_date: t.album_id });
        }
        map.get(t.album_name).tracks.push(t);
      }
    }
    return Array.from(map.values());
  }, [artistTracks]);

  // Artist ranking
  const ranking = useMemo(() => {
    if (!allCreators || allCreators.length === 0) return null;
    const sorted = [...allCreators].sort((a, b) => (b.monthly_listeners || 0) - (a.monthly_listeners || 0));
    const rank = sorted.findIndex(c => c.user_email === creator.user_email) + 1;
    return { rank, total: sorted.length };
  }, [allCreators, creator]);

  const handlePlay = async (track) => {
    const pub = track.publish_at ? new Date(track.publish_at) : null;
    if (pub && pub > now) return; // Don't play future tracks
    onPlay(track);
    if (!user || !creator.auto_listeners) return;
    const month = new Date().toISOString().slice(0, 7);
    const key = `listened_${creator.user_email}_${month}`;
    const listenedTracks = JSON.parse(localStorage.getItem(key) || '[]');
    if (!listenedTracks.includes(track.id)) {
      listenedTracks.push(track.id);
      localStorage.setItem(key, JSON.stringify(listenedTracks));
    }
    if (listenedTracks.length === 3) {
      try {
        const profiles = await base44.entities.MusicCreatorProfile.filter({ user_email: creator.user_email });
        if (profiles.length > 0 && profiles[0].auto_listeners !== false) {
          const currentListeners = profiles[0].monthly_listeners || 0;
          await base44.entities.MusicCreatorProfile.update(profiles[0].id, {
            monthly_listeners: currentListeners + 1
          });
        }
      } catch {}
    }
  };

  const handleClipUploaded = (trackId, clipUrl) => {
    setLocalTracks(prev => prev.map(t => t.id === trackId ? { ...t, clip_url: clipUrl } : t));
  };

  // ── CLIP PLAYER VIEW ──
  if (watchingClip) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => setWatchingClip(null)} className="text-white/70 hover:text-white gap-2 -ml-2">
            <ArrowLeft className="w-4 h-4" /> Retour à la musique
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handlePlay(watchingClip)} className="text-white/70 hover:text-white gap-2">
            <Music className="w-4 h-4" /> Passer à la musique
          </Button>
        </div>
        <div className="flex flex-col items-center gap-4">
          <div className="w-full max-w-2xl aspect-video rounded-2xl overflow-hidden bg-black">
            {watchingClip.clip_url?.match(/\.(mp4|webm|ogg|mov)/i) || watchingClip.clip_url?.includes('video') ? (
              <video src={watchingClip.clip_url} controls autoPlay className="w-full h-full object-contain" />
            ) : (
              <iframe src={watchingClip.clip_url} className="w-full h-full" allowFullScreen allow="autoplay; encrypted-media" />
            )}
          </div>
          <div className="text-center">
            <p className="text-white font-bold text-lg">{watchingClip.title}</p>
            <p className="text-white/50 text-sm">{watchingClip.stage_name}</p>
          </div>
        </div>
      </div>
    );
  }

  // ── DETAILS VIEW ──
  if (view === 'details') {
    return (
      <div className="space-y-6 animate-fade-up">
        <Button variant="ghost" size="sm" onClick={() => setView('main')} className="text-white/70 hover:text-white gap-2 -ml-2">
          <ArrowLeft className="w-4 h-4" /> Retour
        </Button>
        <div className="bg-white/5 rounded-2xl p-6 space-y-6">
          <h2 className="text-white font-bold text-xl flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-purple-400" /> Plus de détails
          </h2>
          {/* Monthly listeners */}
          <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
              <Users className="w-7 h-7 text-white" />
            </div>
            <div>
              <p className="text-3xl font-bold text-white">{formatListeners(creator.monthly_listeners || 0)}</p>
              <p className="text-white/50 text-sm">auditeurs mensuels</p>
            </div>
          </div>
          {/* Ranking */}
          {ranking && (
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center">
                <Crown className="w-7 h-7 text-white" />
              </div>
              <div>
                {ranking.rank <= 100 ? (
                  <>
                    <p className="text-3xl font-bold text-white">#{ranking.rank}</p>
                    <p className="text-white/50 text-sm">classement des artistes (top 100)</p>
                  </>
                ) : (
                  <>
                    <p className="text-xl font-bold text-white">Non classé</p>
                    <p className="text-white/50 text-sm">{formatListeners(creator.monthly_listeners || 0)} auditeurs mensuels (au-delà du top 100)</p>
                  </>
                )}
              </div>
            </div>
          )}
          {/* Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-white/5 rounded-xl text-center">
              <p className="text-2xl font-bold text-purple-400">{artistTracks.filter(t => { const p = t.publish_at ? new Date(t.publish_at) : null; return !p || p <= now; }).length}</p>
              <p className="text-white/50 text-xs mt-1">Titres publiés</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl text-center">
              <p className="text-2xl font-bold text-purple-400">{albums.length}</p>
              <p className="text-white/50 text-xs mt-1">Albums</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── DISCOGRAPHY VIEW ──
  if (view === 'discography') {
    return (
      <div className="space-y-6 animate-fade-up">
        <Button variant="ghost" size="sm" onClick={() => setView('main')} className="text-white/70 hover:text-white gap-2 -ml-2">
          <ArrowLeft className="w-4 h-4" /> Retour
        </Button>
        <h2 className="text-white font-bold text-xl flex items-center gap-2">
          <Disc3 className="w-5 h-5 text-purple-400" /> Discographie
        </h2>
        {albums.length === 0 ? (
          <p className="text-white/40 text-sm text-center py-8">Aucun album.</p>
        ) : (
          <div className="space-y-3">
            {albums.map(album => (
              <button
                key={album.name}
                onClick={() => { setSelectedAlbum(album); setView('album'); }}
                className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-all text-left"
              >
                <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden flex-shrink-0">
                  {album.cover_url
                    ? <img src={album.cover_url} className="w-full h-full object-cover" alt="" />
                    : <Disc3 className="w-8 h-8 text-white m-auto mt-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{album.name}</p>
                  <p className="text-white/50 text-xs">{album.tracks.length} titre(s)</p>
                </div>
                <ChevronDown className="w-5 h-5 text-white/30 -rotate-90 flex-shrink-0" />
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  // ── ALBUM VIEW ──
  if (view === 'album' && selectedAlbum) {
    return (
      <div className="space-y-6 animate-fade-up">
        <Button variant="ghost" size="sm" onClick={() => setView('discography')} className="text-white/70 hover:text-white gap-2 -ml-2">
          <ArrowLeft className="w-4 h-4" /> Discographie
        </Button>
        <div className="flex flex-col items-center gap-4">
          <div className="w-40 h-40 rounded-2xl bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden shadow-2xl">
            {selectedAlbum.cover_url
              ? <img src={selectedAlbum.cover_url} className="w-full h-full object-cover" alt="" />
              : <Disc3 className="w-20 h-20 text-white m-auto mt-10" />}
          </div>
          <h2 className="text-white font-bold text-2xl">{selectedAlbum.name}</h2>
          <p className="text-white/50 text-sm">{selectedAlbum.tracks.length} titre(s)</p>
        </div>
        <div className="space-y-2">
          {selectedAlbum.tracks.map((track, i) => {
            const isActive = currentTrack?.id === track.id;
            const pub = track.publish_at ? new Date(track.publish_at) : null;
            const isPending = pub && pub > now;
            return (
              <div key={track.id} className={`flex items-center gap-3 p-3 rounded-xl transition-all ${isActive ? 'bg-purple-600/40' : 'hover:bg-white/5'}`}>
                <span className="text-white/40 text-sm w-6 text-center">{i + 1}</span>
                <button className="flex items-center gap-3 flex-1 text-left min-w-0" onClick={() => !isPending && handlePlay(track)}>
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0 overflow-hidden relative">
                    {track.album_cover_url
                      ? <img src={track.album_cover_url} className="w-full h-full object-cover" alt="" />
                      : <Music className="w-6 h-6 text-white m-auto mt-3" />}
                    {isActive && <div className="absolute inset-0 bg-black/40 flex items-center justify-center">{isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}</div>}
                    {isPending && <div className="absolute inset-0 bg-black/60 flex items-center justify-center"><Clock className="w-5 h-5 text-purple-300" /></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-medium truncate ${isActive ? 'text-purple-300' : 'text-white'}`}>{track.title}</p>
                    <p className="text-white/50 text-xs truncate">{track.stage_name}</p>
                  </div>
                  {isPending && <span className="text-xs text-purple-400">À venir</span>}
                </button>
                {track.clip_url && (
                  <button onClick={() => setWatchingClip(track)} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-purple-400 flex-shrink-0" title="Voir le clip">
                    <Video className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // ── MAIN ARTIST PAGE ──
  return (
    <div className="space-y-6 animate-fade-up">
      <Button variant="ghost" size="sm" onClick={onBack} className="text-white/70 hover:text-white gap-2 -ml-2">
        <ArrowLeft className="w-4 h-4" /> Retour
      </Button>

      {/* Banner + Avatar */}
      <div className="relative w-full rounded-2xl overflow-hidden">
        {/* Banner */}
        <div className="w-full h-32 md:h-48 bg-gradient-to-br from-purple-900 via-gray-800 to-pink-900 overflow-hidden">
          {creator.banner_url
            ? <img src={creator.banner_url} className="w-full h-full object-cover" alt="" />
            : <div className="w-full h-full flex items-center justify-center">
                <div className="w-full h-full bg-gradient-to-br from-purple-600/30 via-transparent to-pink-600/30" />
              </div>}
        </div>
        {/* Avatar — half on banner, left side */}
        <div className="absolute -bottom-10 left-4 md:left-6">
          <div className="w-20 h-20 md:w-28 md:h-28 rounded-2xl md:rounded-full overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600 border-4 border-gray-950 shadow-xl">
            {creator.avatar_url
              ? <img src={creator.avatar_url} className="w-full h-full object-cover" alt="" />
              : <div className="w-full h-full flex items-center justify-center text-white text-3xl font-bold">{creator.stage_name?.[0]?.toUpperCase()}</div>}
          </div>
        </div>
      </div>

      {/* Artist info — offset for avatar */}
      <div className="pt-10 md:pt-12 px-1">
        <h2 className="text-white text-2xl font-bold flex items-center gap-2">
          {creator.stage_name}
          {creator.certified && <VerifiedBadge type="artist" size={18} />}
        </h2>
        <div className="flex items-center gap-2 mt-1">
          <Users className="w-4 h-4 text-white/50" />
          <span className="text-white/60 text-sm">{formatListeners(creator.monthly_listeners || 0)} auditeurs mensuels</span>
        </div>
        {creator.bio && <p className="text-white/50 text-sm mt-2 max-w-md line-clamp-2">{creator.bio}</p>}
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap gap-3">
        <Button
          onClick={() => setView('discography')}
          className="bg-white/10 hover:bg-white/20 text-white gap-2 rounded-full"
        >
          <Disc3 className="w-4 h-4" /> Voir la discographie
        </Button>
        <Button
          onClick={() => setView('details')}
          variant="outline"
          className="border-white/20 text-white hover:bg-white/10 gap-2 rounded-full"
        >
          <ChevronDown className="w-4 h-4" /> Plus de détails
        </Button>
      </div>

      {/* Tracks */}
      <div>
        <h3 className="text-white font-semibold mb-3">Titres</h3>
        {artistTracks.length === 0 ? (
          <div className="text-center py-10 text-white/40">
            <Music className="w-10 h-10 mx-auto mb-2" />
            <p>Aucun titre disponible</p>
          </div>
        ) : (
          <div className="space-y-2">
            {artistTracks.map(track => {
              const isActive = currentTrack?.id === track.id;
              const pub = track.publish_at ? new Date(track.publish_at) : null;
              const isPending = pub && pub > now;
              const isOwner = user?.email === creator.user_email;
              return (
                <div
                  key={track.id}
                  className={`flex items-center gap-3 p-3 rounded-xl transition-all ${isActive ? 'bg-purple-600/40 border border-purple-500/50' : 'hover:bg-white/5'}`}
                >
                  <button className="flex items-center gap-3 flex-1 text-left min-w-0" onClick={() => !isPending && handlePlay(track)}>
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0 overflow-hidden relative">
                      {track.album_cover_url
                        ? <img src={track.album_cover_url} className="w-full h-full object-cover" alt="" />
                        : <Music className="w-6 h-6 text-white m-auto mt-3" />}
                      {isActive && <div className="absolute inset-0 bg-black/40 flex items-center justify-center">{isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}</div>}
                      {isPending && <div className="absolute inset-0 bg-black/60 flex items-center justify-center"><Clock className="w-5 h-5 text-purple-300" /></div>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium truncate flex items-center gap-1.5 ${isActive ? 'text-purple-300' : 'text-white'}`}>
                        <span className="truncate">{track.title}</span>
                        {track.is_ai_generated && <span className="flex-shrink-0 px-1 py-0 rounded text-[10px] font-bold bg-purple-600 text-white leading-4">IA</span>}
                        {track.is_explicit && <span className="flex-shrink-0 px-1 py-0 rounded text-[10px] font-bold bg-gray-600 text-white border border-gray-400 leading-4">E</span>}
                      </p>
                      <p className="text-white/50 text-xs truncate">{track.album_name || 'Single'}</p>
                    </div>
                    {isPending && <span className="text-xs text-purple-400 flex-shrink-0">À venir</span>}
                  </button>
                  {/* Watch clip button */}
                  {track.clip_url && (
                    <button onClick={() => setWatchingClip(track)} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-purple-400 flex-shrink-0" title="Voir le clip">
                      <Video className="w-4 h-4" />
                    </button>
                  )}
                  {/* 3-dot menu for owner: import clip */}
                  {isOwner && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/50 hover:text-white flex-shrink-0">
                          <Music className="w-4 h-4" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-gray-900 border-gray-700 text-white">
                        <DropdownMenuItem onClick={() => setShowClipUpload(track)} className="cursor-pointer hover:bg-white/10">
                          <Upload className="w-4 h-4 mr-2" />
                          {track.clip_url ? 'Remplacer le clip' : 'Importer un clip'}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Clip upload dialog */}
      {showClipUpload && (
        <ClipUploadDialog
          track={showClipUpload}
          onClose={() => setShowClipUpload(null)}
          onUploaded={(clipUrl) => {
            handleClipUploaded(showClipUpload.id, clipUrl);
            setShowClipUpload(null);
            toast.success('Clip importé !');
          }}
        />
      )}
    </div>
  );
}