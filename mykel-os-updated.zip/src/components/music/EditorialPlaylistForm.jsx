import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Upload, Search, Check, Music } from 'lucide-react';
import { toast } from 'sonner';

export default function EditorialPlaylistForm({ playlist, userEmail, userName, publicTracks, onClose, onSaved }) {
  const [name, setName] = useState(playlist?.name || '');
  const [description, setDescription] = useState(playlist?.description || '');
  const [coverUrl, setCoverUrl] = useState(playlist?.cover_url || '');
  const [selectedIds, setSelectedIds] = useState(playlist?.track_ids || []);
  const [search, setSearch] = useState('');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const coverRef = useRef(null);

  const uploadCover = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await uploadMedia(file);
      setCoverUrl(file_url);
    } catch { toast.error('Erreur upload couverture'); }
    finally { setUploading(false); }
  };

  const toggleTrack = (id) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const filtered = publicTracks.filter(t => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (t.title || '').toLowerCase().includes(q) || (t.stage_name || '').toLowerCase().includes(q);
  });

  const save = async () => {
    if (!name.trim()) { toast.error('Donnez un nom à la playlist'); return; }
    setSaving(true);
    try {
      const data = {
        name: name.trim(),
        description: description.trim(),
        cover_url: coverUrl,
        track_ids: selectedIds,
        editor_email: userEmail,
        editor_name: userName,
        is_published: true,
      };
      if (playlist) {
        await base44.entities.EditorialPlaylist.update(playlist.id, data);
        toast.success('Playlist mise à jour');
      } else {
        await base44.entities.EditorialPlaylist.create(data);
        toast.success('Playlist créée');
      }
      onSaved?.();
    } catch (e) {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg bg-gray-900 border-gray-700 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">{playlist ? 'Modifier la playlist' : 'Nouvelle playlist éditoriale'}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label className="text-white/80">Nom *</Label>
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Hits de l'été"
              className="mt-1 bg-gray-800 border-gray-600 text-white" />
          </div>

          <div>
            <Label className="text-white/80">Description</Label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2}
              className="w-full mt-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm resize-none" />
          </div>

          <div>
            <Label className="text-white/80">Couverture</Label>
            <input type="file" ref={coverRef} accept="image/*" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) uploadCover(f); }} />
            <div className="flex items-center gap-3 mt-1">
              <Button variant="outline" className="border-gray-600 text-white/70" onClick={() => coverRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                {coverUrl ? 'Changer' : 'Choisir'}
              </Button>
              {coverUrl && <img src={coverUrl} className="w-12 h-12 rounded-lg object-cover" alt="" />}
            </div>
          </div>

          <div>
            <Label className="text-white/80">Titres ({selectedIds.length} sélectionné(s))</Label>
            <div className="relative mt-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Rechercher un titre..."
                className="w-full pl-9 pr-3 py-2 bg-gray-800 border border-gray-600 text-white rounded-lg text-sm placeholder:text-white/40"
              />
            </div>
            <div className="mt-2 max-h-64 overflow-y-auto space-y-1 border border-gray-700 rounded-lg p-1">
              {filtered.length === 0 ? (
                <p className="text-white/40 text-sm text-center py-4">Aucun titre</p>
              ) : filtered.slice(0, 100).map(t => {
                const checked = selectedIds.includes(t.id);
                return (
                  <button
                    key={t.id}
                    onClick={() => toggleTrack(t.id)}
                    className={`w-full flex items-center gap-3 p-2 rounded-lg text-left transition-all ${checked ? 'bg-purple-600/30' : 'hover:bg-white/5'}`}
                  >
                    <div className={`w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 ${checked ? 'bg-purple-600 border-purple-600' : 'border-gray-500'}`}>
                      {checked && <Check className="w-3 h-3 text-white" />}
                    </div>
                    <div className="w-9 h-9 rounded bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden flex-shrink-0">
                      {t.album_cover_url
                        ? <img src={t.album_cover_url} className="w-full h-full object-cover" alt="" />
                        : <Music className="w-4 h-4 text-white m-auto mt-2.5" />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm truncate">{t.title}</p>
                      <p className="text-white/40 text-xs truncate">{t.stage_name}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="ghost" className="flex-1 text-white/60" onClick={onClose}>Annuler</Button>
            <Button className="flex-1 bg-purple-600 hover:bg-purple-700" disabled={saving} onClick={save}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {playlist ? 'Mettre à jour' : 'Créer'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}