import { BadgeCheck } from 'lucide-react';

export default function VerifiedBadge({ type = 'artist', size = 14, className = '' }) {
  const color = type === 'editorial' ? 'text-emerald-400' : 'text-sky-400';
  const label = type === 'editorial' ? 'Équipe éditoriale Mykel' : 'Artiste certifié';
  return <BadgeCheck className={`${color} inline-block flex-shrink-0`} style={{ width: size, height: size }} aria-label={label} title={label} />;
}