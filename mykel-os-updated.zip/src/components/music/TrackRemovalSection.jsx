import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Music, Loader2, Trash2, RotateCcw, AlertTriangle, Check } from 'lucide-react';
import { toast } from 'sonner';

const REMOVAL_REASONS = [
  { value: 'droits_auteur', label: 'Non respect des droits d\'auteur' },
  { value: 'paroles_inappropriees', label: 'Paroles inappropriées' },
  { value: 'conditions_utilisation', label: 'Non respect des conditions d\'utilisation' },
  { value: 'autre', label: 'Autre' },
];

export default function TrackRemovalSection({ preselectedTrackId = null }) {
  const [allTracks, setAllTracks] = useState([]);
  const [removals, setRemovals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrack, setSelectedTrack] = useState(null);
  const [removalDialog, setRemovalDialog] = useState(false);
  const [selectedReason, setSelectedReason] = useState('');
  const [reasonDetail, setReasonDetail] = useState('');
  const [removing, setRemoving] = useState(false);
  const [republishDialog, setRepublishDialog] = useState(null);
  const [activeTab, setActiveTab] = useState('tracks');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (preselectedTrackId && allTracks.length > 0) {
      const track = allTracks.find(t => t.id === preselectedTrackId);
      if (track) {
        setSelectedTrack(track);
        setRemovalDialog(true);
      }
    }
  }, [preselectedTrackId, allTracks]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [tracks, removalList] = await Promise.all([
        base44.entities.MusicTrack.list(),
        base44.entities.TrackRemoval.list('-removed_at', 100),
      ]);
      // Filter out already removed tracks from the list
      const removedIds = new Set(removalList.filter(r => r.status !== 'republished').map(r => r.track_id));
      setAllTracks(tracks.filter(t => !removedIds.has(t.id)));
      setRemovals(removalList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async () => {
    if (!selectedTrack || !selectedReason) return;
    if (selectedReason === 'autre' && !reasonDetail.trim()) {
      toast.error('Veuillez préciser les détails');
      return;
    }
    setRemoving(true);
    try {
      // Find all playlists containing this track
      const playlists = await base44.entities.Playlist.list();
      const affectedPlaylists = playlists.filter(pl =>
        (pl.music_file_ids || []).includes(selectedTrack.id)
      );

      // Remove from all playlists
      await Promise.all(affectedPlaylists.map(pl =>
        base44.entities.Playlist.update(pl.id, {
          music_file_ids: (pl.music_file_ids || []).filter(id => id !== selectedTrack.id)
        })
      ));

      // Create removal record (keeps track data for potential restoration)
      await base44.entities.TrackRemoval.create({
        track_id: selectedTrack.id,
        track_title: selectedTrack.title,
        creator_email: selectedTrack.creator_email,
        stage_name: selectedTrack.stage_name,
        reason: selectedReason,
        reason_detail: selectedReason === 'autre' ? reasonDetail : '',
        status: 'removed',
        removed_at: new Date().toISOString(),
        track_data: selectedTrack,
        playlist_ids: affectedPlaylists.map(pl => pl.id),
        creator_notified: false,
      });

      // Mark the track as removed (set published=false so it's invisible)
      await base44.entities.MusicTrack.update(selectedTrack.id, { published: false, _removed: true });

      toast.success(`"${selectedTrack.title}" supprimé avec succès`);
      setRemovalDialog(false);
      setSelectedTrack(null);
      setSelectedReason('');
      setReasonDetail('');
      await loadData();
    } catch (e) {
      toast.error('Erreur lors de la suppression');
    } finally {
      setRemoving(false);
    }
  };

  const handleAcceptRepublication = async (removal) => {
    try {
      // Restore the track
      await base44.entities.MusicTrack.update(removal.track_id, {
        published: true,
        _removed: false,
      });

      // Restore to playlists
      await Promise.all((removal.playlist_ids || []).map(async plId => {
        try {
          const pl = await base44.entities.Playlist.filter({ id: plId });
          if (pl.length > 0) {
            const ids = pl[0].music_file_ids || [];
            if (!ids.includes(removal.track_id)) {
              await base44.entities.Playlist.update(plId, {
                music_file_ids: [...ids, removal.track_id]
              });
            }
          }
        } catch {}
      }));

      await base44.entities.TrackRemoval.update(removal.id, { status: 'republished' });
      toast.success('Musique republiée');
      setRepublishDialog(null);
      await loadData();
    } catch {
      toast.error('Erreur lors de la republication');
    }
  };

  const handleRejectRepublication = async (removal) => {
    await base44.entities.TrackRemoval.update(removal.id, { status: 'removed' });
    toast.success('Demande de republication refusée');
    setRepublishDialog(null);
    await loadData();
  };

  const getReasonLabel = (reason) => REMOVAL_REASONS.find(r => r.value === reason)?.label || reason;

  const pendingRequests = removals.filter(r => r.status === 'republication_requested');
  const removedTracks = removals.filter(r => r.status === 'removed');

  if (loading) return (
    <div className="flex justify-center py-12">
      <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
    </div>
  );

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Démarches de suppression</h2>
        <p className="text-sm text-gray-500 mt-1">Sélectionnez un titre pour lancer une procédure de suppression.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        {[
          { id: 'tracks', label: 'Titres actifs' },
          { id: 'removed', label: `Supprimés (${removedTracks.length})` },
          { id: 'requests', label: `Demandes republication (${pendingRequests.length})`, alert: pendingRequests.length > 0 },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`pb-3 px-1 text-sm font-medium border-b-2 transition-all flex items-center gap-2 ${
              activeTab === tab.id
                ? 'border-slate-900 text-slate-900 dark:border-white dark:text-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab.label}
            {tab.alert && <span className="w-2 h-2 rounded-full bg-red-500" />}
          </button>
        ))}
      </div>

      {/* Active tracks list */}
      {activeTab === 'tracks' && (
        <div className="space-y-2">
          {allTracks.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Music className="w-10 h-10 mx-auto mb-3 text-gray-300" />
              <p>Aucun titre actif trouvé</p>
            </div>
          ) : (
            allTracks.map(track => (
              <div
                key={track.id}
                onClick={() => { setSelectedTrack(track); setRemovalDialog(true); }}
                className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center gap-4 cursor-pointer hover:border-red-300 hover:bg-red-50 dark:hover:bg-red-950/20 transition-all"
              >
                {track.album_cover_url
                  ? <img src={track.album_cover_url} className="w-12 h-12 rounded-lg object-cover flex-shrink-0" alt="" />
                  : <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center flex-shrink-0"><Music className="w-5 h-5 text-purple-500" /></div>
                }
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 dark:text-white truncate">{track.title}</p>
                  <p className="text-xs text-gray-500">{track.stage_name} · {track.album_name || 'Single'}</p>
                </div>
                <Button variant="outline" size="sm" className="text-red-500 border-red-200 hover:bg-red-50 flex-shrink-0">
                  <Trash2 className="w-3 h-3 mr-1" />
                  Supprimer
                </Button>
              </div>
            ))
          )}
        </div>
      )}

      {/* Removed tracks */}
      {activeTab === 'removed' && (
        <div className="space-y-2">
          {removedTracks.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Check className="w-10 h-10 mx-auto mb-3 text-gray-300" />
              <p>Aucun titre supprimé</p>
            </div>
          ) : (
            removedTracks.map(r => (
              <div key={r.id} className="bg-white dark:bg-gray-900 rounded-xl border border-red-200 dark:border-red-800 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 dark:text-white">{r.track_title}</p>
                    <p className="text-xs text-gray-500">{r.stage_name} · {r.creator_email}</p>
                    <div className="flex gap-2 mt-2">
                      <Badge className="bg-red-100 text-red-700 text-xs">{getReasonLabel(r.reason)}</Badge>
                      {r.reason_detail && <span className="text-xs text-gray-400 italic">"{r.reason_detail}"</span>}
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      Supprimé le {r.removed_at ? new Date(r.removed_at).toLocaleDateString('fr-FR') : 'date inconnue'}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Republication requests */}
      {activeTab === 'requests' && (
        <div className="space-y-2">
          {pendingRequests.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <RotateCcw className="w-10 h-10 mx-auto mb-3 text-gray-300" />
              <p>Aucune demande en attente</p>
            </div>
          ) : (
            pendingRequests.map(r => (
              <div key={r.id} className="bg-white dark:bg-gray-900 rounded-xl border border-amber-200 dark:border-amber-800 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 dark:text-white">{r.track_title}</p>
                    <p className="text-xs text-gray-500">{r.stage_name} · {r.creator_email}</p>
                    <div className="flex gap-2 mt-2">
                      <Badge className="bg-amber-100 text-amber-700 text-xs">Demande de republication</Badge>
                      <Badge className="bg-red-100 text-red-700 text-xs">{getReasonLabel(r.reason)}</Badge>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white gap-1"
                      onClick={() => setRepublishDialog(r)}
                    >
                      <Check className="w-3 h-3" />
                      Accepter
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-500 border-red-200 hover:bg-red-50 gap-1"
                      onClick={() => handleRejectRepublication(r)}
                    >
                      Refuser
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Removal Dialog */}
      <Dialog open={removalDialog} onOpenChange={(open) => { if (!open) { setRemovalDialog(false); setSelectedTrack(null); setSelectedReason(''); setReasonDetail(''); } }}>
        <DialogContent className="bg-white dark:bg-gray-900 max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Supprimer le titre
            </DialogTitle>
          </DialogHeader>
          {selectedTrack && (
            <div className="space-y-4">
              <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-3 flex items-center gap-3">
                {selectedTrack.album_cover_url
                  ? <img src={selectedTrack.album_cover_url} className="w-12 h-12 rounded-lg object-cover" alt="" />
                  : <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center"><Music className="w-5 h-5 text-purple-500" /></div>
                }
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">{selectedTrack.title}</p>
                  <p className="text-xs text-gray-500">{selectedTrack.stage_name}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Raison de la suppression</p>
                <div className="space-y-2">
                  {REMOVAL_REASONS.map(r => (
                    <button
                      key={r.value}
                      onClick={() => setSelectedReason(r.value)}
                      className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${
                        selectedReason === r.value
                          ? 'border-red-500 bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-400'
                          : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>

              {selectedReason === 'autre' && (
                <div>
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Précisez la raison</p>
                  <Textarea
                    value={reasonDetail}
                    onChange={e => setReasonDetail(e.target.value)}
                    placeholder="Décrivez la raison de suppression..."
                    rows={3}
                  />
                </div>
              )}

              <p className="text-xs text-gray-400 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 rounded-lg p-3">
                ⚠️ Cette action supprimera la musique de Mykel Music et de toutes les playlists. Le créateur sera notifié. La musique reste sauvegardée 30 jours pour une éventuelle republication.
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setRemovalDialog(false)}>Annuler</Button>
            <Button
              onClick={handleRemove}
              disabled={removing || !selectedReason || (selectedReason === 'autre' && !reasonDetail.trim())}
              className="bg-red-600 hover:bg-red-700 text-white gap-2"
            >
              {removing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Confirmer la suppression
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Republish confirmation dialog */}
      <Dialog open={!!republishDialog} onOpenChange={() => setRepublishDialog(null)}>
        <DialogContent className="bg-white dark:bg-gray-900 max-w-sm">
          <DialogHeader>
            <DialogTitle>Accepter la republication ?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            La musique <strong>"{republishDialog?.track_title}"</strong> sera remise en ligne et restaurée dans les playlists d'origine.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRepublishDialog(null)}>Annuler</Button>
            <Button className="bg-green-600 hover:bg-green-700 text-white" onClick={() => handleAcceptRepublication(republishDialog)}>
              <Check className="w-4 h-4 mr-1" />
              Republier
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}