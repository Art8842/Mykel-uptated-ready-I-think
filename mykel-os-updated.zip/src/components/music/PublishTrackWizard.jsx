import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Upload, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

const MUSIC_GENRES = [
  // Pop
  'Pop', 'Synth-Pop', 'Electropop', 'Indie Pop', 'Art Pop', 'Dream Pop', 'Dance Pop', 'K-Pop', 'J-Pop',
  // Rock
  'Rock', 'Indie Rock', 'Alternative Rock', 'Hard Rock', 'Punk Rock', 'Post-Punk', 'New Wave',
  'Prog Rock', 'Psychedelic Rock', 'Shoegaze', 'Grunge', 'Emo', 'Metal', 'Heavy Metal',
  'Death Metal', 'Black Metal', 'Metalcore', 'Nu-Metal', 'Doom Metal',
  // Hip-Hop / Rap
  'Hip-Hop', 'Rap', 'Trap', 'Drill', 'Lo-Fi Hip-Hop', 'Boom Bap', 'Cloud Rap', 'Mumble Rap',
  'Conscious Hip-Hop', 'Gangsta Rap', 'Southern Hip-Hop', 'Afro Trap',
  // Electronic
  'Électronique', 'House', 'Deep House', 'Tech House', 'Progressive House', 'Future House',
  'Techno', 'Minimal Techno', 'Industrial Techno', 'Trance', 'Psytrance', 'Ambient',
  'Drum and Bass', 'Dubstep', 'Future Bass', 'EDM', 'Garage', 'UK Garage', 'Jungle',
  'Chillwave', 'Vaporwave', 'Hyperpop', 'IDM', 'Noise', 'Glitch',
  // R&B / Soul
  'R&B', 'Soul', 'Neo-Soul', 'Funk', 'Motown', 'Contemporary R&B', 'New Jack Swing',
  // Jazz
  'Jazz', 'Smooth Jazz', 'Bebop', 'Fusion Jazz', 'Jazz Manouche', 'Nu-Jazz', 'Acid Jazz',
  // Classique
  'Classique', 'Baroque', 'Romantique', 'Contemporain', 'Opéra', 'Musique de chambre',
  // Latin
  'Latin', 'Reggaeton', 'Salsa', 'Bachata', 'Merengue', 'Cumbia', 'Bossa Nova', 'Samba',
  // Reggae / Dub
  'Reggae', 'Dancehall', 'Dub', 'Ska',
  // Afro
  'Afrobeats', 'Afro-Pop', 'Afro-Fusion', 'Amapiano', 'Highlife', 'Afro-House',
  // World
  'World Music', 'Musique Africaine', 'Musique Arabe', 'Musique Indienne', 'Musique Celtique',
  'Musique Flamenca', 'Cumbia', 'Zouk', 'Kompa', 'Mbalax',
  // Country / Folk
  'Country', 'Folk', 'Bluegrass', 'Americana', 'Folk Rock', 'Singer-Songwriter',
  // Blues
  'Blues', 'Electric Blues', 'Delta Blues', 'Chicago Blues',
  // Gospel / Spirituel
  'Gospel', 'Gospel Hip-Hop', 'Contemporain Chrétien', 'Musique Spirituelle',
  // Podcast
  'Podcast — Actualités', 'Podcast — Société', 'Podcast — Science & Tech', 'Podcast — Culture',
  'Podcast — Sport', 'Podcast — Humour', 'Podcast — True Crime', 'Podcast — Business',
  'Podcast — Histoire', 'Podcast — Développement personnel',
  // Autres
  'Spoken Word', 'ASMR', 'Méditation', 'Bruit Blanc', 'Musique de jeu vidéo', 'Soundtrack', 'Autre',
];

export default function PublishTrackWizard({ open, onClose, creatorProfile, onPublished }) {
  const [step, setStep] = useState(1);
  const [title, setTitle] = useState('');
  const [audioFile, setAudioFile] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [selectedAlbumId, setSelectedAlbumId] = useState('');
  const [albums, setAlbums] = useState([]);
  const [loadingAlbums, setLoadingAlbums] = useState(false);
  const [newAlbumName, setNewAlbumName] = useState('');
  const [newAlbumCoverFile, setNewAlbumCoverFile] = useState(null);
  const [newAlbumCoverUrl, setNewAlbumCoverUrl] = useState('');
  const [albumReleaseDate, setAlbumReleaseDate] = useState('');
  const [publishDate, setPublishDate] = useState('');
  const [publishTime, setPublishTime] = useState('');
  const [publishSecond, setPublishSecond] = useState('00');
  const [announce, setAnnounce] = useState(false);
  const [announceNow, setAnnounceNow] = useState(true);
  const [announceDate, setAnnounceDate] = useState('');
  const [announceTime, setAnnounceTime] = useState('');
  const [trackType, setTrackType] = useState('music');
  // Copyright / Rights fields
  const [genre, setGenre] = useState('');
  const [isAI, setIsAI] = useState(false);
  const [isExplicit, setIsExplicit] = useState(false);
  const [ownsMasterRights, setOwnsMasterRights] = useState(true);
  const [soundsUsed, setSoundsUsed] = useState('');
  const [mastersUsed, setMastersUsed] = useState('');
  const [addAnotherToAlbum, setAddAnotherToAlbum] = useState(false);

  const audioRef = useRef(null);
  const coverRef = useRef(null);

  const resetAll = () => {
    setStep(1); setTitle(''); setAudioFile(null); setAudioUrl('');
    setSelectedAlbumId(''); setNewAlbumName(''); setNewAlbumCoverFile(null);
    setNewAlbumCoverUrl(''); setAlbumReleaseDate(''); setPublishDate('');
    setPublishTime(''); setPublishSecond('00'); setAnnounce(false);
    setAnnounceNow(true); setAnnounceDate(''); setAnnounceTime('');
    setGenre(''); setIsAI(false); setIsExplicit(false);
    setOwnsMasterRights(true); setSoundsUsed(''); setMastersUsed('');
    setAddAnotherToAlbum(false);
  };

  const handleOpen = async () => {
    setLoadingAlbums(true);
    try {
      const list = await base44.entities.MusicAlbum.filter({ creator_email: creatorProfile.user_email });
      setAlbums(list);
    } catch {}
    finally { setLoadingAlbums(false); }
  };

  React.useEffect(() => { if (open) handleOpen(); }, [open]);

  const uploadAudio = async (file) => {
    setUploading(true);
    setAudioUrl('');
    setAudioFile(file);
    try {
      const result = await uploadMedia(file);
      if (result?.file_url) {
        setAudioUrl(result.file_url);
        toast.success('Fichier importé !');
      } else throw new Error('Pas de file_url');
    } catch (e) {
      toast.error('Erreur d\'import. Réessayez.');
      setAudioFile(null);
    } finally { setUploading(false); }
  };

  const uploadAlbumCover = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await uploadMedia(file);
      setNewAlbumCoverUrl(file_url);
    } catch { toast.error('Erreur upload couverture'); }
    finally { setUploading(false); }
  };

  const getPublishDateTime = () => {
    if (!publishDate || !publishTime) return null;
    return `${publishDate}T${publishTime}:${publishSecond || '00'}`;
  };

  const handlePublish = async () => {
    setUploading(true);
    try {
      let albumId = selectedAlbumId;
      let albumCover = '';
      let albumNameFinal = '';

      if (selectedAlbumId === 'new') {
        const pubDt = albumReleaseDate ? `${albumReleaseDate}T00:00:00` : null;
        const newAlbum = await base44.entities.MusicAlbum.create({
          creator_email: creatorProfile.user_email,
          stage_name: creatorProfile.stage_name,
          name: newAlbumName,
          cover_url: newAlbumCoverUrl,
          release_date: pubDt,
          published: false
        });
        albumId = newAlbum.id;
        albumCover = newAlbumCoverUrl;
        albumNameFinal = newAlbumName;
      } else {
        const album = albums.find(a => a.id === selectedAlbumId);
        albumCover = album?.cover_url || '';
        albumNameFinal = album?.name || '';
      }

      // Timer fix: if no track-level publish date but album has a release date, use album release date
      let publishAt = getPublishDateTime();
      if (!publishAt) {
        if (selectedAlbumId === 'new' && albumReleaseDate) {
          publishAt = `${albumReleaseDate}T00:00:00`;
        } else {
          const album = albums.find(a => a.id === selectedAlbumId);
          if (album?.release_date) {
            publishAt = album.release_date;
          } else {
            publishAt = new Date().toISOString();
          }
        }
      }
      let announceAt = null;
      if (announce) {
        if (announceNow) announceAt = new Date().toISOString();
        else if (announceDate && announceTime) announceAt = `${announceDate}T${announceTime}:00`;
      }

      await base44.entities.MusicTrack.create({
        creator_email: creatorProfile.user_email,
        stage_name: creatorProfile.stage_name,
        title,
        file_url: audioUrl,
        album_id: albumId || null,
        album_name: albumNameFinal,
        album_cover_url: albumCover,
        track_type: trackType,
        genre: genre || null,
        is_ai_generated: isAI,
        is_explicit: isExplicit,
        publish_at: publishAt,
        announce_at: announceAt,
        published: false,
        announced: !!announceAt
      });

      toast.success('Publication programmée !');
      onPublished?.();

      // Multi-song: if user wants to add another song to the same album
      if (addAnotherToAlbum && albumId) {
        setSelectedAlbumId(albumId);
        setTitle('');
        setAudioFile(null);
        setAudioUrl('');
        setGenre('');
        setIsAI(false);
        setIsExplicit(false);
        setOwnsMasterRights(true);
        setSoundsUsed('');
        setMastersUsed('');
        setPublishDate('');
        setPublishTime('');
        setPublishSecond('00');
        setAnnounce(false);
        setAnnounceNow(true);
        setAnnounceDate('');
        setAnnounceTime('');
        setAddAnotherToAlbum(false);
        setStep(1);
      } else {
        resetAll();
        onClose();
      }
    } catch (e) {
      toast.error('Erreur lors de la publication');
    } finally {
      setUploading(false);
    }
  };

  const isNewAlbum = selectedAlbumId === 'new';
  // Total steps: 1=Info, 2=Album, 3=NewAlbum(if new), 4=Rights, 5=Publish, 6=Confirm
  const totalSteps = isNewAlbum ? 6 : 5;

  return (
    <Dialog open={open} onOpenChange={() => { resetAll(); onClose(); }}>
      <DialogContent className="max-w-sm bg-gray-900 border-gray-700 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">Nouvelle publication — Étape {step}/{totalSteps}</DialogTitle>
        </DialogHeader>

        {/* Step 1: Title & audio */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <Label className="text-white/80">Type</Label>
              <select value={trackType} onChange={e => setTrackType(e.target.value)}
                className="w-full mt-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm">
                <option value="music">🎵 Musique</option>
                <option value="podcast">🎙️ Podcast</option>
              </select>
            </div>
            <div>
              <Label className="text-white/80">Nom de la chanson / épisode</Label>
              <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Titre..."
                className="mt-1 bg-gray-800 border-gray-600 text-white" />
            </div>
            <div>
              <Label className="text-white/80">Fichier audio ou vidéo</Label>
              <input type="file" ref={audioRef} accept="audio/*,video/*" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) uploadAudio(f); e.target.value = ''; }} />
              <Button variant="outline" className="w-full mt-1 border-gray-600 text-white/70" onClick={() => audioRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                {uploading ? 'Import en cours...' : audioFile ? audioFile.name : 'Choisir un fichier audio ou vidéo'}
              </Button>
              {audioUrl && <p className="text-green-400 text-xs mt-1">✓ Fichier prêt</p>}
            </div>
            <Button
              className="w-full bg-purple-600 hover:bg-purple-700"
              disabled={!title.trim() || (!audioUrl && !uploading) || uploading}
              onClick={() => { if (title.trim() && audioUrl) setStep(2); }}
            >
              {uploading ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Import en cours...</> : <>Suivant <ChevronRight className="w-4 h-4 ml-1" /></>}
            </Button>
          </div>
        )}

        {/* Step 2: Album selection */}
        {step === 2 && (
          <div className="space-y-4">
            <Label className="text-white/80">Album</Label>
            {loadingAlbums ? <Loader2 className="w-5 h-5 animate-spin text-purple-400" /> : (
              <select value={selectedAlbumId} onChange={e => setSelectedAlbumId(e.target.value)}
                className="w-full bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm">
                <option value="">— Aucun album —</option>
                {albums.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                <option value="new">+ Nouvel album</option>
              </select>
            )}
            <div className="flex gap-2">
              <Button variant="ghost" className="flex-1 text-white/60" onClick={() => setStep(1)}>Retour</Button>
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700" onClick={() => setStep(isNewAlbum ? 3 : 4)}>
                Suivant <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: New album info */}
        {step === 3 && isNewAlbum && (
          <div className="space-y-4">
            <div>
              <Label className="text-white/80">Nom de l'album</Label>
              <Input value={newAlbumName} onChange={e => setNewAlbumName(e.target.value)} placeholder="Nom de l'album..."
                className="mt-1 bg-gray-800 border-gray-600 text-white" />
            </div>
            <div>
              <Label className="text-white/80">Pochette de l'album</Label>
              <input type="file" ref={coverRef} accept="image/*" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) { setNewAlbumCoverFile(f); uploadAlbumCover(f); } }} />
              <Button variant="outline" className="w-full mt-1 border-gray-600 text-white/70" onClick={() => coverRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                {newAlbumCoverFile ? newAlbumCoverFile.name : 'Choisir une image'}
              </Button>
              {newAlbumCoverUrl && <img src={newAlbumCoverUrl} className="w-20 h-20 rounded-lg mt-2 object-cover" alt="" />}
            </div>
            <div>
              <Label className="text-white/80">Date de sortie de l'album</Label>
              <Input type="date" value={albumReleaseDate} onChange={e => setAlbumReleaseDate(e.target.value)}
                className="mt-1 bg-gray-800 border-gray-600 text-white" />
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" className="flex-1 text-white/60" onClick={() => setStep(2)}>Retour</Button>
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700" disabled={!newAlbumName.trim()} onClick={() => setStep(4)}>
                Suivant <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 4: Droits d'auteur / Genre / IA / Explicit */}
        {step === 4 && (
          <div className="space-y-4">
            <p className="text-sm text-white/70 font-semibold border-b border-white/10 pb-2">📜 Droits d'auteur, création & licence</p>
            
            {/* Genre */}
            <div>
              <Label className="text-white/80 text-sm">Genre musical *</Label>
              <select value={genre} onChange={e => setGenre(e.target.value)}
                className="w-full mt-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm">
                <option value="">— Sélectionner un genre —</option>
                {MUSIC_GENRES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>

            {/* AI Generated */}
            <div className="flex items-start gap-3 p-3 rounded-xl border border-gray-700 cursor-pointer" onClick={() => setIsAI(!isAI)}>
              <input type="checkbox" checked={isAI} onChange={() => setIsAI(!isAI)} className="w-4 h-4 mt-0.5 accent-purple-500" onClick={e => e.stopPropagation()} />
              <div>
                <p className="text-sm text-white font-medium flex items-center gap-2">
                  Musique IA
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-bold bg-purple-600 text-white">IA</span>
                </p>
                <p className="text-xs text-white/50 mt-0.5">Cette musique a été générée ou assistée par intelligence artificielle. Un badge "IA" sera affiché à côté du titre.</p>
              </div>
            </div>

            {/* Explicit */}
            <div className="flex items-start gap-3 p-3 rounded-xl border border-gray-700 cursor-pointer" onClick={() => setIsExplicit(!isExplicit)}>
              <input type="checkbox" checked={isExplicit} onChange={() => setIsExplicit(!isExplicit)} className="w-4 h-4 mt-0.5 accent-red-500" onClick={e => e.stopPropagation()} />
              <div>
                <p className="text-sm text-white font-medium flex items-center gap-2">
                  Titre explicite
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-bold bg-gray-600 text-white border border-gray-400">E</span>
                </p>
                <p className="text-xs text-white/50 mt-0.5">Ce titre contient du contenu explicite (paroles, thèmes). Un badge "E" sera affiché.</p>
              </div>
            </div>

            {/* Master Rights */}
            <div className="space-y-3 p-3 rounded-xl border border-gray-700">
              <p className="text-sm text-white/70 font-semibold">🎚️ Droits des masters & samples</p>
              <div>
                <Label className="text-white/60 text-xs">Sons / samples utilisés</Label>
                <textarea value={soundsUsed} onChange={e => setSoundsUsed(e.target.value)} rows={2}
                  placeholder="Listez les samples, boucles ou sons tiers utilisés..."
                  className="w-full mt-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-xs resize-none" />
              </div>
              <div>
                <Label className="text-white/60 text-xs">Masters utilisés</Label>
                <textarea value={mastersUsed} onChange={e => setMastersUsed(e.target.value)} rows={2}
                  placeholder="Précisez les masters utilisés (enregistrements originaux)..."
                  className="w-full mt-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-xs resize-none" />
              </div>
              <div className="flex items-start gap-3 cursor-pointer" onClick={() => setOwnsMasterRights(!ownsMasterRights)}>
                <input type="checkbox" checked={ownsMasterRights} onChange={() => setOwnsMasterRights(!ownsMasterRights)} className="w-4 h-4 mt-0.5 accent-green-500" onClick={e => e.stopPropagation()} />
                <div>
                  <p className="text-sm text-white font-medium">Je possède les droits des masters</p>
                  <p className="text-xs text-white/50 mt-0.5">Cochez si vous êtes propriétaire des droits des masters utilisés dans ce titre.</p>
                </div>
              </div>
              {!ownsMasterRights && (
                <div className="p-3 rounded-lg bg-amber-900/30 border border-amber-600/50">
                  <p className="text-xs text-amber-300 font-medium">
                    ⚠️ Avertissement : Si vous ne possédez pas les droits des masters, la musique ne pourra pas être rémunérée, ou seulement partiellement si le propriétaire des droits masters vous les cède. Assurez-vous d'avoir les autorisations nécessaires.
                  </p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button variant="ghost" className="flex-1 text-white/60" onClick={() => setStep(isNewAlbum ? 3 : 2)}>Retour</Button>
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700" disabled={!genre} onClick={() => setStep(5)}>
                Suivant <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 5: Publish date/time */}
        {step === 5 && (
          <div className="space-y-4">
            <p className="text-sm text-white/60">Date et heure de publication (optionnel — laisser vide pour publier immédiatement)</p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label className="text-white/80 text-xs">Date</Label>
                <Input type="date" value={publishDate} onChange={e => setPublishDate(e.target.value)}
                  className="mt-1 bg-gray-800 border-gray-600 text-white text-sm" />
              </div>
              <div>
                <Label className="text-white/80 text-xs">Heure</Label>
                <Input type="time" value={publishTime} onChange={e => setPublishTime(e.target.value)}
                  className="mt-1 bg-gray-800 border-gray-600 text-white text-sm" />
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-xl border border-gray-700">
              <input type="checkbox" id="announce" checked={announce} onChange={e => setAnnounce(e.target.checked)} className="w-4 h-4 accent-purple-500" />
              <label htmlFor="announce" className="text-sm text-white/80 cursor-pointer">Annoncer ce titre</label>
            </div>

            {announce && (
              <div className="pl-4 space-y-3 border-l-2 border-purple-500">
                <div className="space-y-2">
                  <button onClick={() => setAnnounceNow(true)} className={`w-full text-left px-3 py-2 rounded-lg border text-sm ${announceNow ? 'border-purple-500 bg-purple-950/30' : 'border-gray-700'}`}>
                    📣 Annoncer maintenant
                  </button>
                  <button onClick={() => setAnnounceNow(false)} className={`w-full text-left px-3 py-2 rounded-lg border text-sm ${!announceNow ? 'border-purple-500 bg-purple-950/30' : 'border-gray-700'}`}>
                    🕐 Annoncer plus tard
                  </button>
                </div>
                {!announceNow && (
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-white/60 text-xs">Date annonce</Label>
                      <Input type="date" value={announceDate} onChange={e => setAnnounceDate(e.target.value)}
                        className="mt-1 bg-gray-800 border-gray-600 text-white text-sm" />
                    </div>
                    <div>
                      <Label className="text-white/60 text-xs">Heure annonce</Label>
                      <Input type="time" value={announceTime} onChange={e => setAnnounceTime(e.target.value)}
                        className="mt-1 bg-gray-800 border-gray-600 text-white text-sm" />
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2">
              <Button variant="ghost" className="flex-1 text-white/60" onClick={() => setStep(4)}>Retour</Button>
              <Button
                className="flex-1 bg-purple-600 hover:bg-purple-700"
                onClick={() => setStep(6)}
              >
                Suivant <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 6: Confirm */}
        {step === 6 && (
          <div className="space-y-4">
            <div className="p-4 bg-gray-800 rounded-xl space-y-2 text-sm">
              <p className="text-white font-medium">Récapitulatif</p>
              <p className="text-white/60">Titre : <span className="text-white">{title}</span></p>
              <p className="text-white/60">Album : <span className="text-white">{isNewAlbum ? newAlbumName : (albums.find(a => a.id === selectedAlbumId)?.name || 'Aucun')}</span></p>
              <p className="text-white/60">Genre : <span className="text-white">{genre}</span></p>
              <div className="flex gap-2 flex-wrap">
                {isAI && <span className="px-1.5 py-0.5 rounded text-xs font-bold bg-purple-600 text-white">IA</span>}
                {isExplicit && <span className="px-1.5 py-0.5 rounded text-xs font-bold bg-gray-600 text-white border border-gray-400">E</span>}
                {!ownsMasterRights && <span className="px-1.5 py-0.5 rounded text-xs font-bold bg-amber-600 text-white">⚠ Masters</span>}
              </div>
              <p className="text-white/60">Publication : <span className="text-white">{publishDate ? `${publishDate} à ${publishTime}` : (albumReleaseDate ? `À la sortie de l'album` : 'Immédiate')}</span></p>
              {announce && <p className="text-white/60">Annonce : <span className="text-purple-400">{announceNow ? 'Maintenant' : `${announceDate} ${announceTime}`}</span></p>}
            </div>
            {/* Multi-song option */}
            {selectedAlbumId && selectedAlbumId !== '' && selectedAlbumId !== 'new' && (
              <div className="flex items-start gap-3 p-3 rounded-xl border border-gray-700 cursor-pointer" onClick={() => setAddAnotherToAlbum(!addAnotherToAlbum)}>
                <input type="checkbox" checked={addAnotherToAlbum} onChange={() => setAddAnotherToAlbum(!addAnotherToAlbum)} className="w-4 h-4 mt-0.5 accent-purple-500" onClick={e => e.stopPropagation()} />
                <div>
                  <p className="text-sm text-white font-medium">Ajouter un autre titre à cet album</p>
                  <p className="text-xs text-white/50 mt-0.5">Après publication, revenir à l'étape 1 pour ajouter un nouveau titre au même album.</p>
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Button variant="ghost" className="flex-1 text-white/60" onClick={() => setStep(5)}>Retour</Button>
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700" disabled={uploading} onClick={handlePublish}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Publier
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}