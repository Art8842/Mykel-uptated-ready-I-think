import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { AlertTriangle, RotateCcw, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const REASON_LABELS = {
  droits_auteur: 'Non respect des droits d\'auteur',
  paroles_inappropriees: 'Paroles inappropriées',
  conditions_utilisation: 'Non respect des conditions d\'utilisation',
  autre: 'Autre',
};

export default function TrackRemovalAlert({ userEmail }) {
  const [pendingAlert, setPendingAlert] = useState(null);
  const [countdown, setCountdown] = useState(20);
  const [canDismiss, setCanDismiss] = useState(false);
  const [requestingRepub, setRequestingRepub] = useState(false);

  useEffect(() => {
    if (!userEmail) return;
    checkAlerts();
  }, [userEmail]);

  const checkAlerts = async () => {
    try {
      const removals = await base44.entities.TrackRemoval.filter({
        creator_email: userEmail,
        creator_notified: false,
        status: 'removed',
      });
      if (removals.length > 0) {
        setPendingAlert(removals[0]);
      }
    } catch {}
  };

  useEffect(() => {
    if (!pendingAlert) return;
    setCountdown(20);
    setCanDismiss(false);
    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setCanDismiss(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [pendingAlert]);

  const handleDismiss = async () => {
    if (!canDismiss || !pendingAlert) return;
    await base44.entities.TrackRemoval.update(pendingAlert.id, { creator_notified: true });
    setPendingAlert(null);
  };

  const handleRequestRepublication = async () => {
    if (!pendingAlert) return;
    setRequestingRepub(true);
    try {
      await base44.entities.TrackRemoval.update(pendingAlert.id, {
        status: 'republication_requested',
        creator_notified: true,
      });
      toast.success('Demande de republication envoyée à l\'admin');
      setPendingAlert(null);
    } catch {
      toast.error('Erreur lors de la demande');
    } finally {
      setRequestingRepub(false);
    }
  };

  if (!pendingAlert) return null;

  const reasonLabel = REASON_LABELS[pendingAlert.reason] || pendingAlert.reason;
  const fullReason = pendingAlert.reason === 'autre' && pendingAlert.reason_detail
    ? `${reasonLabel} : ${pendingAlert.reason_detail}`
    : reasonLabel;

  return (
    <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-red-500/50 rounded-2xl max-w-lg w-full p-8 text-center space-y-6 shadow-2xl shadow-red-500/20">
        <div className="flex justify-center">
          <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center">
            <AlertTriangle className="w-10 h-10 text-red-400" />
          </div>
        </div>

        <div>
          <h2 className="text-white text-2xl font-bold mb-2">Titre supprimé</h2>
          <p className="text-white/70 text-sm leading-relaxed">
            Votre titre <strong className="text-white">"{pendingAlert.track_title}"</strong> a été supprimé de Mykel Music par l'équipe d'administration.
          </p>
        </div>

        <div className="bg-red-950/40 border border-red-500/30 rounded-xl p-4">
          <p className="text-red-300 text-sm font-medium mb-1">Raison :</p>
          <p className="text-white text-sm">{fullReason}</p>
        </div>

        <p className="text-white/50 text-xs">
          Ce titre a été retiré de Mykel Music et de toutes les playlists. Si vous pensez qu'il s'agit d'une erreur, vous pouvez faire une demande de republication.
        </p>

        <div className="flex flex-col gap-3">
          <Button
            variant="outline"
            className="border-white/20 text-white/60 hover:bg-white/10 gap-2"
            onClick={handleRequestRepublication}
            disabled={requestingRepub}
          >
            {requestingRepub ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
            Demander une republication
          </Button>

          <Button
            onClick={handleDismiss}
            disabled={!canDismiss}
            className={`font-bold gap-2 ${canDismiss ? 'bg-white text-gray-900 hover:bg-gray-100' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}
          >
            {canDismiss ? 'J\'ai compris' : `J'ai compris (${countdown}s)`}
          </Button>
        </div>
      </div>
    </div>
  );
}