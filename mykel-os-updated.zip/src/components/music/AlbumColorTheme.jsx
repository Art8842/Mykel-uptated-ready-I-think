/**
 * Extract dominant color from an image URL and apply it as theme
 */
export async function extractColorFromImage(imgUrl) {
  if (!imgUrl) return null;
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 50; canvas.height = 50;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, 50, 50);
        const data = ctx.getImageData(0, 0, 50, 50).data;

        let r = 0, g = 0, b = 0, count = 0;
        for (let i = 0; i < data.length; i += 16) {
          r += data[i]; g += data[i+1]; b += data[i+2];
          count++;
        }
        r = Math.round(r / count);
        g = Math.round(g / count);
        b = Math.round(b / count);

        // Boost saturation
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const factor = 1.5;
        r = Math.min(255, Math.round(128 + (r - 128) * factor));
        g = Math.min(255, Math.round(128 + (g - 128) * factor));
        b = Math.min(255, Math.round(128 + (b - 128) * factor));

        resolve({ r, g, b, hex: `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}` });
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = imgUrl;
  });
}

export function applyAlbumTheme(color) {
  if (!color) return;
  const el = document.documentElement;
  // Convert RGB to HSL
  const r = color.r / 255, g = color.g / 255, b = color.b / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;
  if (max === min) { h = s = 0; }
  else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  const hDeg = Math.round(h * 360);
  const sPct = Math.round(s * 100);
  const lPct = Math.max(30, Math.min(70, Math.round(l * 100)));

  el.style.setProperty('--music-theme-h', hDeg);
  el.style.setProperty('--music-theme', `${hDeg} ${sPct}% ${lPct}%`);
  el.setAttribute('data-music-theme', 'true');
}

export function resetAlbumTheme() {
  const el = document.documentElement;
  el.style.removeProperty('--music-theme');
  el.removeAttribute('data-music-theme');
}