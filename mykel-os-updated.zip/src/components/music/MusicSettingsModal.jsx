import React, { useState, useEffect, useRef } from 'react';
// SupportChat is defined in this file below
import { base44 } from '@/api/base44Client';
import { freeInvokeLLM } from '@/lib/freeCore';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Send, Lock } from 'lucide-react';
import { toast } from 'sonner';

// Sub-component: Creator Registration Form
function CreatorRegistrationForm({ onValidate, onCancel }) {
  const [step, setStep] = useState(1);
  const [creatorType, setCreatorType] = useState('');
  const [stageName, setStageName] = useState('');
  const [otherPlatforms, setOtherPlatforms] = useState('');

  const canConfirm = creatorType && stageName.trim();

  return (
    <div className="space-y-4">
      {step === 1 && (
        <>
          <p className="text-sm text-gray-600 dark:text-gray-300">Vous êtes créateur de :</p>
          {[
            { value: 'music', label: '🎵 Musique' },
            { value: 'podcast', label: '🎙️ Podcast' },
            { value: 'both', label: '🎵🎙️ Les deux' },
          ].map(opt => (
            <button
              key={opt.value}
              onClick={() => setCreatorType(opt.value)}
              className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${
                creatorType === opt.value ? 'border-purple-500 bg-purple-50 dark:bg-purple-950/30' : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              {opt.label}
            </button>
          ))}
          <Button className="w-full" disabled={!creatorType} onClick={() => setStep(2)}>Suivant</Button>
        </>
      )}

      {step === 2 && (
        <>
          <Label>Nom de scène / Pseudo</Label>
          <p className="text-xs text-gray-500">Si c'est une entreprise qui crée les podcasts, indiquez le nom de l'entreprise.</p>
          <Input
            value={stageName}
            onChange={e => setStageName(e.target.value)}
            placeholder="Votre nom de scène..."
            className="dark:bg-gray-800 dark:border-gray-600 dark:text-white"
          />
          <Button className="w-full" disabled={!stageName.trim()} onClick={() => setStep(3)}>Suivant</Button>
          <Button variant="ghost" className="w-full" onClick={() => setStep(1)}>Retour</Button>
        </>
      )}

      {step === 3 && (
        <>
          <Label>Êtes-vous déjà présent sur d'autres plateformes ?</Label>
          <Input
            value={otherPlatforms}
            onChange={e => setOtherPlatforms(e.target.value)}
            placeholder="Spotify, Apple Music, SoundCloud... (ou laisser vide)"
            className="dark:bg-gray-800 dark:border-gray-600 dark:text-white"
          />
          <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl">
            <p className="text-xs text-red-600 dark:text-red-400 font-medium">⚠️ Attention — action irréversible</p>
            <p className="text-xs text-red-500 dark:text-red-400 mt-1">Une fois validé, votre type de compte ne pourra plus être modifié sauf par un administrateur.</p>
          </div>
          <Button
            className="w-full bg-purple-600 hover:bg-purple-700"
            disabled={!canConfirm}
            onClick={() => onValidate({ creatorType, stageName, otherPlatforms })}
          >
            Valider définitivement le compte créateur
          </Button>
          <Button variant="ghost" className="w-full" onClick={() => setStep(2)}>Retour</Button>
        </>
      )}
    </div>
  );
}

// Sub-component: Support Chat
function SupportChat({ user }) {
  const [messages, setMessages] = useState([
    { role: 'ai', content: 'Bonjour ! Je suis le support Mykel Music. Comment puis-je vous aider ?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [locked, setLocked] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async () => {
    if (!input.trim() || locked || loading) return;
    const userMsg = input.trim();
    setInput('');
    const newMsgs = [...messages, { role: 'user', content: userMsg }];
    setMessages(newMsgs);
    setLoading(true);

    try {
      const history = newMsgs.map(m => `${m.role === 'user' ? 'Utilisateur' : 'Support'}: ${m.content}`).join('\n');
      const response = await freeInvokeLLM({
        prompt: `Tu es un agent de support pour Mykel Music. Tu dois recueillir les informations nécessaires pour résoudre le problème de l'utilisateur (nom, description du problème, étapes pour reproduire, etc.).
Quand tu as toutes les informations nécessaires, réponds UNIQUEMENT avec le JSON suivant (rien d'autre) :
{"done": true, "summary": "résumé du problème en français"}

Historique de la conversation :
${history}

Réponds en français. Si tu n'as pas encore toutes les infos, pose la prochaine question.`,
      });

      // Check if AI signals it has all info
      try {
        const parsed = JSON.parse(response);
        if (parsed.done) {
          // Save ticket
          await base44.entities.SupportTicket.create({
            user_email: user.email,
            user_name: user.full_name || user.email,
            summary: parsed.summary,
            conversation: newMsgs,
            status: 'open',
            created_at: new Date().toISOString()
          });
          setMessages(prev => [...prev, {
            role: 'ai',
            content: '✅ J\'ai récupéré toutes les informations nécessaires. Merci d\'avoir contacté le support.'
          }]);
          setLocked(true);
          return;
        }
      } catch {}

      setMessages(prev => [...prev, { role: 'ai', content: response }]);
    } catch {
      setMessages(prev => [...prev, { role: 'ai', content: 'Désolé, une erreur est survenue.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-72">
      <div className="flex-1 overflow-y-auto space-y-2 p-2">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-3 py-2 rounded-xl text-sm ${
              m.role === 'user'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
            }`}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800">
              <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {locked ? (
        <div className="p-2 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 dark:bg-gray-800 rounded-xl opacity-60">
            <Lock className="w-4 h-4 text-gray-400" />
            <p className="text-xs text-red-500 font-medium">Votre demande a été envoyée à nos agents. Votre problème sera traité dans un délai de 1 à 72 heures. Si le problème n'est toujours pas réglé après le délai, veuillez contacter le support une nouvelle fois.</p>
          </div>
        </div>
      ) : (
        <div className="flex gap-2 p-2 border-t border-gray-200 dark:border-gray-700">
          <Input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && send()}
            placeholder="Votre message..."
            disabled={loading}
            className="dark:bg-gray-800 dark:border-gray-600 dark:text-white"
          />
          <Button size="icon" onClick={send} disabled={loading || !input.trim()} className="bg-purple-600 hover:bg-purple-700">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}

export default function MusicSettingsModal({ open, onClose, user }) {
  const [accountType, setAccountType] = useState('listener'); // 'listener' | 'creator'
  const [creatorProfile, setCreatorProfile] = useState(null);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [showCreatorForm, setShowCreatorForm] = useState(false);
  const [showSupport, setShowSupport] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open && user) loadProfile();
  }, [open, user]);

  const loadProfile = async () => {
    setLoadingProfile(true);
    try {
      const profiles = await base44.entities.MusicCreatorProfile.filter({ user_email: user.email });
      if (profiles.length > 0 && profiles[0].active && profiles[0].validated) {
        setCreatorProfile(profiles[0]);
        setAccountType('creator');
      } else {
        setAccountType('listener');
        setCreatorProfile(null);
      }
    } catch {}
    finally { setLoadingProfile(false); }
  };

  const handleTypeChange = (val) => {
    if (val === 'creator' && !creatorProfile) {
      setShowCreatorForm(true);
    } else {
      setAccountType(val);
    }
  };

  const handleValidateCreator = async (data) => {
    setSaving(true);
    try {
      const profile = await base44.entities.MusicCreatorProfile.create({
        user_email: user.email,
        creator_type: data.creatorType,
        stage_name: data.stageName,
        other_platforms: data.otherPlatforms,
        active: true,
        validated: true
      });
      setCreatorProfile(profile);
      setAccountType('creator');
      setShowCreatorForm(false);
      toast.success('Compte créateur activé !');
    } catch { toast.error('Erreur lors de la validation'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-gray-900 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-white">
            {showSupport ? '🎧 Support Mykel Music' : showCreatorForm ? '🎵 Compte Créateur' : '⚙️ Paramètres'}
          </DialogTitle>
        </DialogHeader>

        {loadingProfile ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>
        ) : showSupport ? (
          <>
            <SupportChat user={user} />
            <Button variant="ghost" className="text-white/60" onClick={() => setShowSupport(false)}>← Retour</Button>
          </>
        ) : showCreatorForm ? (
          <>
            <CreatorRegistrationForm
              onValidate={handleValidateCreator}
              onCancel={() => setShowCreatorForm(false)}
            />
            {!saving && (
              <Button variant="ghost" className="text-white/60" onClick={() => setShowCreatorForm(false)}>← Retour</Button>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <div>
              <Label className="text-white/80 text-sm">Type de compte</Label>
              <div className="flex gap-2 items-center mt-2">
                <select
                  value={accountType}
                  onChange={e => handleTypeChange(e.target.value)}
                  disabled={!!creatorProfile}
                  className="flex-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm disabled:opacity-60"
                >
                  <option value="listener">Compte Auditeur</option>
                  <option value="creator">Compte Créateur</option>
                </select>
              </div>
              {creatorProfile && (
                <p className="text-xs text-purple-400 mt-1">Connecté en tant que : <strong>{creatorProfile.stage_name}</strong></p>
              )}
              {creatorProfile && (
                <p className="text-xs text-gray-500 mt-1">Le type de compte ne peut être modifié que par un administrateur.</p>
              )}
            </div>

            <div className="border-t border-gray-700 pt-4">
              <Button
                variant="ghost"
                className="w-full text-purple-300 hover:bg-purple-950/30 text-sm"
                onClick={() => setShowSupport(true)}
              >
                💬 Faire une demande au support Mykel Music
              </Button>
            </div>

            <Button onClick={onClose} className="w-full bg-purple-600 hover:bg-purple-700">Fermer</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}