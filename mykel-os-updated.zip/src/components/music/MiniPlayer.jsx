import React from 'react';
import { Music, Mic, Play, Pause } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function MiniPlayer({ currentTrack, isPlaying, onPlayPause, onOpenFull }) {
  if (!currentTrack) return null;

  return (
    <div 
      onClick={onOpenFull}
      className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-purple-900 to-purple-800 border-t border-purple-700 p-3 cursor-pointer hover:from-purple-800 hover:to-purple-700 transition-all z-40"
    >
      <div className="max-w-screen-xl mx-auto flex items-center gap-3">
        {/* Album Art */}
        <div className="w-12 h-12 bg-purple-950 rounded flex items-center justify-center flex-shrink-0">
          {currentTrack.cover_url ? (
            <img src={currentTrack.cover_url} alt="" className="w-full h-full rounded object-cover" />
          ) : currentTrack.type === 'music' ? (
            <Music className="w-5 h-5 text-purple-300" />
          ) : (
            <Mic className="w-5 h-5 text-purple-300" />
          )}
        </div>

        {/* Track Info */}
        <div className="flex-1 min-w-0">
          <p className="text-white font-semibold text-sm truncate">{currentTrack.name}</p>
          <p className="text-purple-200 text-xs truncate">{currentTrack.artist || 'Artiste inconnu'}</p>
        </div>

        {/* Play/Pause Button */}
        <Button
          size="icon"
          onClick={(e) => {
            e.stopPropagation();
            onPlayPause();
          }}
          className="bg-white text-purple-900 hover:bg-purple-100 h-10 w-10 rounded-full flex-shrink-0"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </Button>
      </div>
    </div>
  );
}