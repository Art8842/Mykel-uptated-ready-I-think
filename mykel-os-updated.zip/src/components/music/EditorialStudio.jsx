import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Plus, Trash2, Music, Loader2, Pencil } from 'lucide-react';
import EditorialPlaylistForm from './EditorialPlaylistForm';
import { confirmAction } from '@/lib/confirm';
import { toast } from 'sonner';

export default function EditorialStudio({ userEmail, userName, publicTracks, onBack }) {
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.EditorialPlaylist.filter({ editor_email: userEmail }, '-created_date', 50);
      setPlaylists(list);
    } catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleDelete = async (pl) => {
    const ok = await confirmAction({
      title: 'Supprimer la playlist éditoriale ?',
      message: `"${pl.name}" sera supprimée définitivement.`,
      destructive: true,
      confirmLabel: 'Supprimer',
    });
    if (!ok) return;
    try {
      await base44.entities.EditorialPlaylist.delete(pl.id);
      toast.success('Playlist supprimée');
      load();
    } catch { toast.error('Erreur lors de la suppression'); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-purple-950 to-gray-950 overflow-y-auto">
      <div className="sticky top-0 z-10 bg-purple-950/80 backdrop-blur-md p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-white/80 hover:text-white"><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="text-white font-bold text-lg">Studio éditorial</h1>
        </div>
        <button
          onClick={() => { setEditing(null); setShowForm(true); }}
          className="px-4 py-2 rounded-full bg-purple-600 hover:bg-purple-700 text-white text-sm font-medium flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Nouvelle playlist
        </button>
      </div>

      <div className="p-4 max-w-3xl mx-auto pb-20">
        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
        ) : playlists.length === 0 ? (
          <div className="text-center py-20 text-white/40">
            <Music className="w-12 h-12 mx-auto mb-4" />
            <p>Aucune playlist éditoriale.<br />Créez votre première sélection !</p>
          </div>
        ) : (
          <div className="space-y-3">
            {playlists.map(pl => (
              <div key={pl.id} className="bg-white/5 rounded-xl p-4 flex items-center gap-4">
                <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden flex-shrink-0">
                  {pl.cover_url
                    ? <img src={pl.cover_url} className="w-full h-full object-cover" alt="" />
                    : <Music className="w-6 h-6 text-white m-auto mt-4" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{pl.name}</p>
                  <p className="text-white/50 text-xs">{pl.track_ids?.length || 0} titre(s)</p>
                  {pl.description && <p className="text-white/30 text-xs truncate">{pl.description}</p>}
                </div>
                <button
                  onClick={() => { setEditing(pl); setShowForm(true); }}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/40 hover:text-white"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(pl)}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-500/20 text-white/40 hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {showForm && (
        <EditorialPlaylistForm
          playlist={editing}
          userEmail={userEmail}
          userName={userName}
          publicTracks={publicTracks}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSaved={() => { setShowForm(false); setEditing(null); load(); }}
        />
      )}
    </div>
  );
}