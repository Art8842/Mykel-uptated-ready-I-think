import React, { useEffect, useState } from 'react';
import { 
  Music, Mic, Play, Pause, SkipBack, SkipForward, 
  Volume2, X, Shuffle
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useMusicPlayer } from '@/components/shared/MusicPlayerContext';
import { extractColorFromImage, resetAlbumTheme } from '@/components/music/AlbumColorTheme';

export default function FullPlayer({ onClose }) {
  const { 
    currentTrack, isPlaying, currentTime, duration, volume,
    togglePlay, handleNext, handlePrev, handleSeek, setVolume, queue, queueIndex, playTrack
  } = useMusicPlayer();

  const [themeColor, setThemeColor] = useState(null);
  const [shuffleMode, setShuffleMode] = useState(false);

  // Extract dominant color from album art
  useEffect(() => {
    const coverUrl = currentTrack?.cover_url || currentTrack?.album_cover_url;
    if (!coverUrl) { setThemeColor(null); return; }

    extractColorFromImage(coverUrl).then(color => {
      setThemeColor(color);
    });

    return () => {};
  }, [currentTrack?.cover_url, currentTrack?.album_cover_url]);

  useEffect(() => {
    return () => resetAlbumTheme();
  }, []);

  if (!currentTrack) return null;

  const formatTime = (s) => {
    if (!s || isNaN(s)) return '0:00';
    return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  };

  const progress = duration ? (currentTime / duration) * 100 : 0;

  const bgGradient = themeColor
    ? `linear-gradient(135deg, rgb(${themeColor.r * 0.3},${themeColor.g * 0.3},${themeColor.b * 0.3}) 0%, rgb(${Math.round(themeColor.r * 0.15)},${Math.round(themeColor.g * 0.15)},${Math.round(themeColor.b * 0.15)}) 50%, #000 100%)`
    : 'linear-gradient(135deg, #4a1080 0%, #1a0a30 50%, #000 100%)';

  const accentColor = themeColor
    ? `rgb(${themeColor.r},${themeColor.g},${themeColor.b})`
    : 'rgb(168, 85, 247)';

  const handleShuffleNext = () => {
    if (shuffleMode && queue.length > 1) {
      const availableIdxs = queue.map((_, i) => i).filter(i => i !== queueIndex);
      const nextIdx = availableIdxs[Math.floor(Math.random() * availableIdxs.length)];
      playTrack(queue[nextIdx], queue, nextIdx);
    } else {
      handleNext();
    }
  };

  const coverUrl = currentTrack.cover_url || currentTrack.album_cover_url;

  return (
    <div className="fixed inset-0 z-50 flex flex-col overflow-hidden" style={{ background: bgGradient }}>
      {/* Animated background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {themeColor && (
          <>
            <div
              className="absolute -top-20 -left-20 w-80 h-80 rounded-full opacity-20 blur-3xl animate-pulse"
              style={{ background: accentColor }}
            />
            <div
              className="absolute -bottom-20 -right-20 w-96 h-96 rounded-full opacity-10 blur-3xl animate-pulse"
              style={{ background: accentColor, animationDelay: '1s' }}
            />
          </>
        )}
      </div>

      {/* Header */}
      <div className="relative flex items-center justify-between p-4 pt-6">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={onClose}
          className="text-white hover:bg-white/10"
        >
          <X className="w-6 h-6" />
        </Button>
        <div className="text-center">
          <p className="text-white/50 text-xs uppercase tracking-widest">Lecture en cours</p>
          {currentTrack.album_name && <p className="text-white/70 text-xs mt-0.5">{currentTrack.album_name}</p>}
        </div>
        <div className="w-10" />
      </div>

      {/* Album Art */}
      <div className="relative flex justify-center px-8 py-4">
        <div
          className="w-72 h-72 md:w-80 md:h-80 rounded-2xl shadow-2xl overflow-hidden transition-all duration-500"
          style={{ boxShadow: themeColor ? `0 20px 60px rgba(${themeColor.r},${themeColor.g},${themeColor.b},0.5)` : '0 20px 60px rgba(0,0,0,0.5)' }}
        >
          {coverUrl ? (
            <img src={coverUrl} alt="" className="w-full h-full object-cover" />
          ) : currentTrack.type === 'podcast' ? (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              <Mic className="w-24 h-24 text-gray-400" />
            </div>
          ) : (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              <Music className="w-24 h-24 text-gray-400" />
            </div>
          )}
        </div>
      </div>

      {/* Track Info */}
      <div className="relative px-8 mb-4">
        <h3 className="text-white text-2xl font-bold truncate">{currentTrack.name || currentTrack.title}</h3>
        <p className="text-white/60 mt-1">{currentTrack.artist || currentTrack.stage_name || 'Artiste inconnu'}</p>
        {currentTrack.is_explicit && <span className="text-xs px-1.5 py-0.5 rounded bg-gray-600 text-white border border-gray-400 font-bold mt-1 inline-block">E</span>}
        {currentTrack.is_ai_generated && <span className="text-xs px-1.5 py-0.5 rounded bg-purple-700 text-white font-bold mt-1 ml-1 inline-block">IA</span>}
      </div>

      {/* Progress Bar */}
      <div className="relative px-8 mb-6">
        <div
          className="w-full h-1 bg-white/20 rounded-full cursor-pointer relative"
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const pct = (e.clientX - rect.left) / rect.width;
            handleSeek(pct * duration);
          }}
        >
          <div
            className="h-full rounded-full transition-all duration-150"
            style={{ width: `${progress}%`, background: accentColor }}
          />
          <div
            className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-lg transition-all"
            style={{ left: `${progress}%`, transform: `translateX(-50%) translateY(-50%)` }}
          />
        </div>
        <div className="flex justify-between text-xs text-white/40 mt-2">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="relative flex items-center justify-center gap-8 px-8 mb-8">
        <button
          onClick={() => setShuffleMode(s => !s)}
          className={`transition-all ${shuffleMode ? 'text-white' : 'text-white/40'} hover:text-white`}
        >
          <Shuffle className="w-6 h-6" />
        </button>
        <button onClick={handlePrev} className="text-white hover:text-white/70 transition-all">
          <SkipBack className="w-8 h-8" />
        </button>
        <button
          onClick={togglePlay}
          className="w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-95"
          style={{ background: accentColor }}
        >
          {isPlaying ? <Pause className="w-7 h-7 text-white" /> : <Play className="w-7 h-7 text-white ml-1" />}
        </button>
        <button onClick={handleShuffleNext} className="text-white hover:text-white/70 transition-all">
          <SkipForward className="w-8 h-8" />
        </button>
        <div className="w-6" />
      </div>

      {/* Volume */}
      <div className="relative flex items-center gap-3 px-8 mb-6">
        <Volume2 className="w-4 h-4 text-white/40 flex-shrink-0" />
        <Slider
          value={[volume]}
          max={100}
          step={1}
          onValueChange={(v) => setVolume(v[0])}
          className="flex-1"
        />
        <span className="text-white/40 text-xs w-8 text-right">{volume}%</span>
      </div>

      {/* Queue preview */}
      {queue.length > 1 && (
        <div className="relative px-8 pb-6">
          <p className="text-white/30 text-xs uppercase tracking-wider mb-2">Suivant</p>
          {queue.slice(queueIndex + 1, queueIndex + 3).map((t, i) => (
            <div key={t.id} className="flex items-center gap-3 py-1">
              <div className="w-8 h-8 rounded overflow-hidden bg-white/10 flex-shrink-0">
                {t.cover_url || t.album_cover_url
                  ? <img src={t.cover_url || t.album_cover_url} className="w-full h-full object-cover" alt="" />
                  : <Music className="w-4 h-4 text-white/40 m-auto mt-2" />
                }
              </div>
              <div className="min-w-0">
                <p className="text-white/60 text-sm truncate">{t.name || t.title}</p>
                <p className="text-white/30 text-xs truncate">{t.artist || t.stage_name}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}