import React, { useState, useMemo, useEffect } from 'react';
import { ArrowLeft, Play, Shuffle, Music, X, Heart, Check } from 'lucide-react';
import { useMusicPlayer } from '@/components/shared/MusicPlayerContext';
import { base44 } from '@/api/base44Client';
import VerifiedBadge from '@/components/music/VerifiedBadge';
import { toast } from 'sonner';

export default function EditorialPlaylistView({ playlist, publicTracks, onBack }) {
  const { playTrack } = useMusicPlayer();
  const [shuffled, setShuffled] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // Check if already saved
    base44.entities.Playlist.filter({ name: playlist.name, editor_email: playlist.editor_email })
      .then(list => { if (list.length > 0) setSaved(true); })
      .catch(() => {});
  }, [playlist]);

  const handleSaveToLibrary = async () => {
    if (saving) return;
    setSaving(true);
    try {
      const u = await base44.auth.me();
      await base44.entities.Playlist.create({
        name: playlist.name,
        cover_url: playlist.cover_url || '',
        music_file_ids: playlist.track_ids || [],
        created_by: u.email,
        is_editorial_copy: true,
      });
      setSaved(true);
      toast.success('Playlist sauvegardée dans votre bibliothèque !');
    } catch {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  const tracks = useMemo(() => {
    const ids = playlist.track_ids || [];
    const map = new Map(publicTracks.map(t => [t.id, t]));
    return ids.map(id => map.get(id)).filter(Boolean);
  }, [playlist, publicTracks]);

  const normalized = tracks.map(t => ({
    ...t,
    name: t.title,
    cover_url: t.album_cover_url,
  }));

  const playAll = () => {
    if (normalized.length === 0) return;
    playTrack(normalized[0], normalized, 0);
  };

  const shuffle = () => {
    if (normalized.length === 0) return;
    const shuffled = [...normalized].sort(() => Math.random() - 0.5);
    playTrack(shuffled[0], shuffled, 0);
    setShuffled(true);
  };

  const playOne = (idx) => {
    playTrack(normalized[idx], normalized, idx);
  };

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-purple-950 to-gray-950 overflow-y-auto">
      <div className="sticky top-0 z-10 bg-gradient-to-b from-purple-950 to-transparent p-4">
        <button onClick={onBack} className="flex items-center gap-2 text-white/80 hover:text-white">
          <ArrowLeft className="w-5 h-5" /> Retour
        </button>
      </div>

      <div className="px-6 pb-32 max-w-3xl mx-auto">
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-48 h-48 rounded-2xl bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden mb-4 shadow-2xl">
            {playlist.cover_url
              ? <img src={playlist.cover_url} className="w-full h-full object-cover" alt="" />
              : <div className="w-full h-full flex items-center justify-center"><Music className="w-16 h-16 text-white/50" /></div>
            }
          </div>
          <div className="flex items-center justify-center gap-1.5 mb-1">
            <VerifiedBadge type="editorial" size={18} />
            <p className="text-emerald-300 text-sm font-medium">Sélection de l'équipe éditoriale</p>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">{playlist.name}</h1>
          {playlist.description && <p className="text-white/60 max-w-md">{playlist.description}</p>}
          <p className="text-white/40 text-sm mt-1">par {playlist.editor_name || 'Mykel'} · {normalized.length} titre(s)</p>

          <div className="flex gap-3 mt-6">
            <button
              onClick={playAll}
              disabled={normalized.length === 0}
              className="px-6 py-3 rounded-full bg-purple-600 hover:bg-purple-700 text-white font-semibold flex items-center gap-2 disabled:opacity-40 transition-all hover:scale-105"
            >
              <Play className="w-5 h-5" /> Lire
            </button>
            <button
              onClick={shuffle}
              disabled={normalized.length === 0}
              className="px-6 py-3 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold flex items-center gap-2 disabled:opacity-40 transition-all hover:scale-105"
            >
              <Shuffle className="w-5 h-5" /> Aléatoire
            </button>
            <button
              onClick={handleSaveToLibrary}
              disabled={saving}
              className={`px-6 py-3 rounded-full font-semibold flex items-center gap-2 transition-all hover:scale-105 ${
                saved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              {saved ? <Check className="w-5 h-5" /> : <Heart className="w-5 h-5" />}
              {saved ? 'Sauvegardée' : 'Sauvegarder'}
            </button>
          </div>
        </div>

        <div className="space-y-1">
          {normalized.length === 0 ? (
            <p className="text-center text-white/40 py-8">Aucun titre dans cette playlist.</p>
          ) : normalized.map((track, i) => (
            <button
              key={track.id}
              onClick={() => playOne(i)}
              className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/10 transition-all text-left"
            >
              <span className="text-white/40 text-sm w-6 text-center">{i + 1}</span>
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden flex-shrink-0">
                {track.cover_url
                  ? <img src={track.cover_url} className="w-full h-full object-cover" alt="" />
                  : <Music className="w-6 h-6 text-white m-auto mt-3" />
                }
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-medium truncate">{track.name}</p>
                <p className="text-white/50 text-xs truncate">{track.stage_name}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}