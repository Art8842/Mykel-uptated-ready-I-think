import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import {
  Plus, Key, Link as LinkIcon, Check, Eye, Trash2,
  ArrowRight, Code, X,
} from 'lucide-react';

const STORAGE_KEY = 'developer_apis';

function getApis() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch { return []; }
}

function saveApis(apis) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(apis));
}

export default function DeveloperSpace({ open, onClose }) {
  const [apis, setApis] = useState([]);
  const [step, setStep] = useState('list'); // list | name | details
  const [newApiName, setNewApiName] = useState('');
  const [newApiKey, setNewApiKey] = useState('');
  const [newApiLink, setNewApiLink] = useState('');
  const [viewingApi, setViewingApi] = useState(null);

  useEffect(() => {
    if (open) {
      setApis(getApis());
      setStep('list');
      setViewingApi(null);
    }
  }, [open]);

  const handleAddClick = () => {
    setStep('name');
    setNewApiName('');
    setNewApiKey('');
    setNewApiLink('');
  };

  const handleContinue = () => {
    if (!newApiName.trim()) {
      toast.error('Veuillez entrer un nom d\'API');
      return;
    }
    setStep('details');
  };

  const handleValidate = () => {
    if (!newApiKey.trim()) {
      toast.error('Veuillez entrer la clé API');
      return;
    }
    const newApi = {
      id: Date.now().toString(),
      name: newApiName.trim(),
      key: newApiKey.trim(),
      link: newApiLink.trim(),
      created_at: new Date().toISOString(),
    };
    const updated = [...apis, newApi];
    saveApis(updated);
    setApis(updated);
    setStep('list');
    toast.success('API ajoutée avec succès');
  };

  const handleDelete = (id) => {
    const updated = apis.filter(a => a.id !== id);
    saveApis(updated);
    setApis(updated);
    setViewingApi(null);
    toast.success('API supprimée');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-white dark:bg-gray-900 max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-gray-900 dark:text-white">
            <Code className="w-5 h-5 text-violet-600" />
            Espace Développeur
          </DialogTitle>
        </DialogHeader>

        {/* ── List view ── */}
        {step === 'list' && !viewingApi && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">API</h3>
                <Button size="sm" onClick={handleAddClick} className="gap-1.5">
                  <Plus className="w-3.5 h-3.5" />
                  Ajouter une API
                </Button>
              </div>

              {apis.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <Key className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">Aucune API enregistrée</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {apis.map(api => (
                    <div
                      key={api.id}
                      className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800"
                    >
                      <div className="w-9 h-9 rounded-lg bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center flex-shrink-0">
                        <Key className="w-4 h-4 text-violet-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-gray-900 dark:text-white truncate">{api.name}</p>
                        <p className="text-xs text-gray-500 truncate">
                          {api.link || 'Aucun lien défini'}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setViewingApi(api)}
                        className="gap-1.5 flex-shrink-0"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Voir
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Add API - Step 1: Name ── */}
        {step === 'name' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span className="px-2 py-0.5 bg-violet-600 text-white rounded-full">1</span>
              <span className="px-2 py-0.5 bg-gray-100 dark:bg-gray-800 rounded-full">2</span>
            </div>
            <div>
              <Label className="text-sm font-medium">Nom de l'API</Label>
              <Input
                placeholder="Ex: OpenAI, Stripe, Google Maps..."
                value={newApiName}
                onChange={e => setNewApiName(e.target.value)}
                className="mt-1.5"
                autoFocus
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep('list')} className="flex-1">Annuler</Button>
              <Button onClick={handleContinue} disabled={!newApiName.trim()} className="flex-1 gap-2">
                Continuer <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}

        {/* ── Add API - Step 2: Key + Link ── */}
        {step === 'details' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span className="px-2 py-0.5 bg-green-600 text-white rounded-full">✓</span>
              <span className="px-2 py-0.5 bg-violet-600 text-white rounded-full">2</span>
            </div>
            <div>
              <Label className="text-sm font-medium">Clé API</Label>
              <Input
                placeholder="Entrez votre clé API..."
                value={newApiKey}
                onChange={e => setNewApiKey(e.target.value)}
                className="mt-1.5 font-mono text-sm"
                autoFocus
              />
            </div>
            <div>
              <Label className="text-sm font-medium">Lien à mettre dans le code</Label>
              <Input
                placeholder="https://api.exemple.com/v1/..."
                value={newApiLink}
                onChange={e => setNewApiLink(e.target.value)}
                className="mt-1.5 font-mono text-sm"
              />
              <p className="text-xs text-gray-500 mt-1">L'URL de base de l'API à utiliser dans vos requêtes.</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep('name')} className="flex-1">Retour</Button>
              <Button onClick={handleValidate} disabled={!newApiKey.trim()} className="flex-1 gap-2 bg-green-600 hover:bg-green-700">
                <Check className="w-4 h-4" />
                Valider
              </Button>
            </div>
          </div>
        )}

        {/* ── View API ── */}
        {viewingApi && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white">{viewingApi.name}</h3>
              <Button variant="ghost" size="icon" onClick={() => setViewingApi(null)} className="w-8 h-8">
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-3">
              <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
                <div className="flex items-center gap-2 mb-1">
                  <Key className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-500">Clé API</span>
                </div>
                <p className="font-mono text-sm text-gray-900 dark:text-white break-all">{viewingApi.key}</p>
              </div>
              <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
                <div className="flex items-center gap-2 mb-1">
                  <LinkIcon className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-500">Lien</span>
                </div>
                <p className="font-mono text-sm text-gray-900 dark:text-white break-all">{viewingApi.link || 'Aucun lien défini'}</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => handleDelete(viewingApi.id)}
              className="w-full gap-2 text-red-500 border-red-200 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
              Supprimer cette API
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}