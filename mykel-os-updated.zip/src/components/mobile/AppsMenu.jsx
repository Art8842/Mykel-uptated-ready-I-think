import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  FolderPlus, Upload, FileText, Table, Presentation, Palette, Box,
} from 'lucide-react';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { useLanguage } from '@/lib/LanguageContext';
import { AppIcon } from '@/components/shared/AppIcons';

const APPS = [
  { id: 'store',   labelKey: 'store',        page: '/MykelStore' },
  { id: 'music',   labelKey: 'mykel_music',  page: '/MykelMusic' },
  { id: 'ia',      labelKey: 'mykel_ia',     page: '/MykelIA' },
  { id: 'search',  labelKey: 'mykel_search', page: '/MykelSearch' },
  { id: 'chat',    labelKey: 'mykel_chat',   page: '/MykelChat' },
  { id: 'tv',      labelKey: 'mykel_tv',     page: '/MykelTV' },
];

const CREATE_ITEMS = [
  { icon: FolderPlus,    label: 'Dossier',         bg: 'bg-gray-100',    color: 'text-gray-700', action: 'folder' },
  { icon: Upload,        label: 'Fichier',         bg: 'bg-gray-100',    color: 'text-gray-700', action: 'upload' },
  { icon: FolderPlus,    label: 'Dossier complet',  bg: 'bg-gray-100',    color: 'text-gray-700', action: 'uploadFolder' },
  { icon: FileText,      label: 'Word',            bg: 'bg-blue-100',    color: 'text-blue-600', action: 'doc' },
  { icon: Table,         label: 'Tabs',            bg: 'bg-green-100',   color: 'text-green-600', action: 'sheet' },
  { icon: Presentation,  label: 'Sliders',        bg: 'bg-orange-100',  color: 'text-orange-600', action: 'slide' },
  { icon: Palette,       label: 'Draw',            bg: 'bg-purple-100',  color: 'text-purple-600', action: 'draw' },
  { icon: Box,           label: '3D',              bg: 'bg-cyan-100',    color: 'text-cyan-600', action: '3d' },
];

export default function AppsMenu({ open, onOpenChange, onNewDocument, onNewFolder, onUpload, onUploadFolder }) {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleCreate = (action) => {
    onOpenChange(false);
    switch (action) {
      case 'folder':       onNewFolder(); break;
      case 'upload':       onUpload(); break;
      case 'uploadFolder': onUploadFolder(); break;
      case 'doc':          onNewDocument('document'); break;
      case 'sheet':        onNewDocument('spreadsheet'); break;
      case 'slide':        onNewDocument('presentation'); break;
      case 'draw':         onNewDocument('drawing'); break;
      case '3d':           navigate('/Mykel3D'); break;
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="rounded-t-2xl p-0 max-h-[85vh] overflow-y-auto">
        <div className="p-5 pb-8">
          {/* Handle bar */}
          <div className="flex justify-center mb-4">
            <div className="w-10 h-1.5 rounded-full bg-gray-300" />
          </div>

          {/* Ajouter section */}
          <h3 className="text-sm font-bold text-black mb-3 px-1">Ajouter</h3>
          <div className="grid grid-cols-4 gap-2 mb-6">
            {CREATE_ITEMS.map((item, i) => (
              <button
                key={i}
                onClick={() => handleCreate(item.action)}
                className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl hover:bg-gray-100 transition-all"
              >
                <div className={`w-11 h-11 rounded-xl ${item.bg} flex items-center justify-center`}>
                  <item.icon className={`w-5 h-5 ${item.color}`} />
                </div>
                <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{item.label}</span>
              </button>
            ))}
          </div>

          {/* Applications section */}
          <h3 className="text-sm font-bold text-black mb-3 px-1">{t('applications')}</h3>
          <div className="grid grid-cols-3 gap-2">
            {APPS.map((app) => {
              const linkProps = app.external
                ? { to: app.page, target: '_blank', rel: 'noopener noreferrer' }
                : { to: app.page };
              return (
                <Link
                  key={app.id}
                  {...linkProps}
                  onClick={() => onOpenChange(false)}
                  className="flex flex-col items-center gap-2 p-3 rounded-2xl hover:bg-gray-100 transition-all"
                >
                  <AppIcon id={app.id} size={48} />
                  <span className="text-xs font-medium text-black text-center leading-tight">{t(app.labelKey)}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}