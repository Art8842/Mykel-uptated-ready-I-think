import React from 'react';
import { Home, Cloud, LayoutGrid, Menu } from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';

export default function BottomTabs({ currentView, onViewChange, onOpenApps }) {
  const { t } = useLanguage();

  const tabs = [
    { id: 'accueil', icon: Home, label: t('home') },
    { id: 'cloud', icon: Cloud, label: t('cloud') },
    { id: 'logiciels', icon: LayoutGrid, label: t('logiciels') },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-100/80 shadow-[0_-2px_20px_rgba(0,0,0,0.04)] flex items-center justify-around py-2 pb-safe z-40">
      {tabs.map((tab) => {
        const active = currentView === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onViewChange(tab.id)}
            className={`flex flex-col items-center gap-1 px-3 py-1.5 transition-all ${
              active ? 'text-blue-600' : 'text-gray-400'
            }`}
          >
            <tab.icon className="w-6 h-6" strokeWidth={active ? 2.5 : 2} />
            <span className="text-[11px] font-medium">{tab.label}</span>
          </button>
        );
      })}
      <button
        onClick={onOpenApps}
        className="flex flex-col items-center gap-1 px-3 py-1.5 text-gray-400 transition-all"
      >
        <Menu className="w-6 h-6" strokeWidth={2} />
        <span className="text-[11px] font-medium">Apps</span>
      </button>
    </div>
  );
}