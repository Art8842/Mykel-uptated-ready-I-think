import React from 'react';
import { Mic, MicOff, Video, VideoOff, MonitorUp, PhoneOff } from 'lucide-react';

export default function MeetControls({ micOn, camOn, onToggleMic, onToggleCam, onShare, onLeave }) {
  const btn = (on, Icon, OffIcon, onClick) => (
    <button
      onClick={onClick}
      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all active:scale-95 ${
        on ? 'bg-white/15 text-white hover:bg-white/25' : 'bg-red-500 text-white hover:bg-red-600'
      }`}
    >
      {on ? <Icon className="w-5 h-5" /> : <OffIcon className="w-5 h-5" />}
    </button>
  );

  return (
    <div className="flex items-center gap-3 px-4 py-3 bg-black/40 backdrop-blur-md rounded-2xl">
      {btn(micOn, Mic, MicOff, onToggleMic)}
      {btn(camOn, Video, VideoOff, onToggleCam)}
      <button
        onClick={onShare}
        className="w-12 h-12 rounded-full bg-white/15 text-white hover:bg-white/25 flex items-center justify-center transition-all active:scale-95"
      >
        <MonitorUp className="w-5 h-5" />
      </button>
      <button
        onClick={onLeave}
        className="h-12 px-5 rounded-full bg-red-600 hover:bg-red-700 text-white font-medium flex items-center gap-2 transition-all active:scale-95"
      >
        <PhoneOff className="w-5 h-5" /> Quitter
      </button>
    </div>
  );
}