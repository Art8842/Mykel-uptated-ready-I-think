import React, { useEffect, useRef } from 'react';
import { MicOff, Pin } from 'lucide-react';

export default function VideoTile({ stream, name, isLocal, micOn, className = '' }) {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current && stream) {
      ref.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className={`relative rounded-2xl overflow-hidden bg-gray-900 ${className}`}>
      <video
        ref={ref}
        autoPlay
        playsInline
        muted={isLocal}
        className="w-full h-full object-cover"
      />
      <div className="absolute bottom-2 left-2 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/50 backdrop-blur-sm text-white text-xs font-medium">
        {isLocal && !micOn && <MicOff className="w-3 h-3" />}
        {name || (isLocal ? 'Vous' : 'Participant')}
      </div>
    </div>
  );
}