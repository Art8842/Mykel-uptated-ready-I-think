import React, { useState, useRef, useEffect, useCallback } from 'react';

const CANVAS_WIDTH = 960;
const CANVAS_HEIGHT = 540;

export default function SlideCanvas({ 
  slide, 
  onElementSelect,
  onElementUpdate,
  onElementDelete,
  selectedElement,
  isPresenting = false,
  readOnly = false
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const [scale, setScale] = useState(1);
  const [editingTextId, setEditingTextId] = useState(null);
  const [textValue, setTextValue] = useState('');

  // Ref-based drag state to avoid stale closure bugs
  const drag = useRef({
    active: false, isResize: false,
    elementId: null,
    startMX: 0, startMY: 0,
    startEX: 0, startEY: 0,
    startW: 0, startH: 0,
  });

  // Compute scale via ResizeObserver so canvas always fits
  useEffect(() => {
    if (isPresenting) return;
    const container = containerRef.current;
    if (!container) return;
    const compute = () => {
      const w = container.clientWidth - 80;
      const h = container.clientHeight - 80;
      const s = Math.min(w / CANVAS_WIDTH, h / CANVAS_HEIGHT, 1);
      setScale(s > 0.1 ? s : 0.1);
    };
    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(container);
    return () => ro.disconnect();
  }, [isPresenting]);

  // Keyboard delete
  useEffect(() => {
    const onKey = (e) => {
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedElement && !editingTextId) {
        const tag = document.activeElement?.tagName?.toLowerCase();
        if (tag !== 'input' && tag !== 'textarea') {
          onElementDelete(selectedElement);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedElement, editingTextId, onElementDelete]);

  const handleCanvasMouseDown = (e) => {
    if (e.target === canvasRef.current) {
      onElementSelect(null);
      setEditingTextId(null);
    }
  };

  const startDrag = (e, element, isResize = false) => {
    e.stopPropagation();
    e.preventDefault();
    if (editingTextId === element.id && !isResize) return;
    onElementSelect(element.id);
    drag.current = {
      active: !isResize, isResize,
      elementId: element.id,
      startMX: e.clientX, startMY: e.clientY,
      startEX: element.x, startEY: element.y,
      startW: element.width, startH: element.height,
    };
  };

  const handleMouseMove = useCallback((e) => {
    const d = drag.current;
    if (!d.active && !d.isResize) return;
    const dx = (e.clientX - d.startMX) / scale;
    const dy = (e.clientY - d.startMY) / scale;
    if (d.active) {
      onElementUpdate(d.elementId, {
        x: Math.round(d.startEX + dx),
        y: Math.round(d.startEY + dy),
      });
    } else {
      onElementUpdate(d.elementId, {
        width: Math.max(50, Math.round(d.startW + dx)),
        height: Math.max(20, Math.round(d.startH + dy)),
      });
    }
  }, [scale, onElementUpdate]);

  const handleMouseUp = useCallback(() => {
    drag.current.active = false;
    drag.current.isResize = false;
  }, []);

  const ResizeHandle = ({ element }) => (
    <div
      style={{
        position: 'absolute', bottom: -5, right: -5,
        width: 12, height: 12,
        background: '#3b82f6', border: '2px solid white',
        borderRadius: 2, cursor: 'se-resize', zIndex: 10,
      }}
      onPointerDown={(e) => { e.stopPropagation(); startDrag(e, element, true); }}
    />
  );

  const renderElement = (element) => {
    const isSelected = selectedElement === element.id && !isPresenting;
    const isEditing = editingTextId === element.id;

    const base = {
      position: 'absolute',
      left: element.x,
      top: element.y,
      width: element.width,
      height: element.height,
      cursor: (isPresenting || readOnly) ? 'default' : (isEditing ? 'text' : 'move'),
      ...(element.rotation ? { transform: `rotate(${element.rotation}deg)` } : {}),
    };
    const sel = isSelected ? { outline: '2px solid #3b82f6', outlineOffset: '1px' } : {};

    switch (element.type) {
      case 'text':
        return (
          <div
            key={element.id}
            style={{
              ...base, ...sel,
              fontFamily: element.fontFamily || 'Arial',
              fontSize: `${element.fontSize || 24}px`,
              fontWeight: element.bold ? 'bold' : 'normal',
              fontStyle: element.italic ? 'italic' : 'normal',
              textDecoration: element.underline ? 'underline' : 'none',
              color: element.textColor || '#000000',
              backgroundColor: element.fillColor || 'transparent',
              textAlign: element.align || 'left',
              padding: '8px',
              boxSizing: 'border-box',
              overflow: 'hidden',
              userSelect: 'none',
            }}
            onPointerDown={(e) => {
              if (isPresenting || isEditing) return;
              if (isSelected) { setEditingTextId(element.id); setTextValue(element.content || ''); }
              else { startDrag(e, element); }
            }}
            onDoubleClick={() => !isPresenting && (setEditingTextId(element.id), setTextValue(element.content || ''))}
          >
            {isEditing ? (
              <textarea
                autoFocus
                value={textValue}
                onChange={(e) => { setTextValue(e.target.value); onElementUpdate(element.id, { content: e.target.value }); }}
                onBlur={() => setEditingTextId(null)}
                onPointerDown={(e) => e.stopPropagation()}
                style={{
                  width: '100%', height: '100%',
                  background: 'transparent', border: 'none', outline: 'none', resize: 'none',
                  fontFamily: element.fontFamily || 'Arial',
                  fontSize: `${element.fontSize || 24}px`,
                  fontWeight: element.bold ? 'bold' : 'normal',
                  color: element.textColor || '#000000',
                  textAlign: element.align || 'left',
                  padding: 0, cursor: 'text', userSelect: 'text', lineHeight: 1.3,
                }}
              />
            ) : (
              <span style={{ whiteSpace: 'pre-wrap', lineHeight: 1.3, display: 'block' }}>
                {element.content || 'Double-cliquez pour éditer'}
              </span>
            )}
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      case 'image':
        return (
          <div key={element.id} style={{ ...base, ...sel }}
            onPointerDown={(e) => !isPresenting && startDrag(e, element)}>
            <img src={element.src} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain', pointerEvents: 'none', display: 'block' }} />
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      case 'rectangle':
        return (
          <div key={element.id}
            style={{ ...base, ...sel, backgroundColor: element.fillColor || '#3b82f6', borderRadius: element.borderRadius || 0, border: element.borderColor ? `2px solid ${element.borderColor}` : 'none' }}
            onPointerDown={(e) => !isPresenting && startDrag(e, element)}>
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      case 'circle':
        return (
          <div key={element.id}
            style={{ ...base, ...sel, backgroundColor: element.fillColor || '#3b82f6', borderRadius: '50%' }}
            onPointerDown={(e) => !isPresenting && startDrag(e, element)}>
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      case 'triangle':
        return (
          <div key={element.id} style={{ ...base, ...sel }}
            onPointerDown={(e) => !isPresenting && startDrag(e, element)}>
            <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ display: 'block' }}>
              <polygon points="50,0 100,100 0,100" fill={element.fillColor || '#3b82f6'} stroke={element.borderColor || 'none'} strokeWidth={element.borderColor ? '2' : '0'} vectorEffect="non-scaling-stroke" />
            </svg>
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      case 'arrow':
        return (
          <div key={element.id} style={{ ...base, ...sel }}
            onPointerDown={(e) => !isPresenting && startDrag(e, element)}>
            <svg width="100%" height="100%" viewBox="0 0 100 40" preserveAspectRatio="none" style={{ display: 'block' }}>
              <polygon points="0,12 70,12 70,0 100,20 70,40 70,28 0,28" fill={element.fillColor || '#3b82f6'} />
            </svg>
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      case 'line':
        return (
          <div key={element.id} style={{ ...base, ...sel, height: Math.max(element.height, 8) }}
            onPointerDown={(e) => !isPresenting && startDrag(e, element)}>
            <svg width="100%" height="100%" style={{ display: 'block' }}>
              <line x1="0" y1="50%" x2="100%" y2="50%" stroke={element.fillColor || '#3b82f6'} strokeWidth={element.strokeWidth || 3} />
            </svg>
            {isSelected && <ResizeHandle element={element} />}
          </div>
        );

      default:
        return null;
    }
  };

  if (isPresenting) {
    const screenW = window.innerWidth;
    const screenH = window.innerHeight;
    const ps = Math.min(screenW / CANVAS_WIDTH, screenH / CANVAS_HEIGHT);
    return (
      <div style={{ width: '100vw', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000' }}>
        <div style={{ width: CANVAS_WIDTH, height: CANVAS_HEIGHT, transform: `scale(${ps})`, transformOrigin: 'center center', backgroundColor: slide.background || '#ffffff', position: 'relative', flexShrink: 0 }}>
          {slide.elements.map(renderElement)}
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="flex-1 flex items-center justify-center bg-gray-200 overflow-hidden">
      <div
        ref={canvasRef}
        className="relative shadow-2xl"
        style={{
          width: CANVAS_WIDTH, height: CANVAS_HEIGHT,
          backgroundColor: slide.background || '#ffffff',
          transform: `scale(${scale})`,
          transformOrigin: 'center center',
          flexShrink: 0,
          touchAction: 'none',
        }}
        onPointerDown={handleCanvasMouseDown}
        onPointerMove={handleMouseMove}
        onPointerUp={handleMouseUp}
        onPointerLeave={handleMouseUp}
      >
        {slide?.elements?.map(renderElement)}
      </div>
    </div>
  );
}