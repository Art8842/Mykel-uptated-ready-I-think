import React from 'react';
import { Plus, Copy, Trash2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion, Reorder } from 'framer-motion';

const THUMB_SCALE = 0.15;

export default function SlideThumbnails({ 
  slides, 
  currentSlideIndex,
  onSlideSelect,
  onAddSlide,
  onDuplicateSlide,
  onDeleteSlide,
  onReorder
}) {
  const renderMiniElement = (element) => {
    const style = {
      position: 'absolute',
      left: element.x * THUMB_SCALE,
      top: element.y * THUMB_SCALE,
      width: element.width * THUMB_SCALE,
      height: element.height * THUMB_SCALE,
      fontSize: (element.fontSize || 24) * THUMB_SCALE,
      fontFamily: element.fontFamily || 'Arial',
      fontWeight: element.bold ? 'bold' : 'normal',
      color: element.textColor || '#000000',
      backgroundColor: element.fillColor || 'transparent',
      borderRadius: element.type === 'circle' ? '50%' : (element.borderRadius || 0) * THUMB_SCALE,
      overflow: 'hidden',
    };

    if (element.type === 'text') {
      return (
        <div key={element.id} style={style} className="truncate">
          {element.content}
        </div>
      );
    }

    if (element.type === 'image') {
      return (
        <img
          key={element.id}
          src={element.src}
          alt=""
          style={style}
          className="object-contain"
        />
      );
    }

    if (element.type === 'triangle') {
      return (
        <div key={element.id} style={{ ...style, backgroundColor: 'transparent' }}>
          <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
            <polygon
              points="50,0 100,100 0,100"
              fill={element.fillColor || '#3b82f6'}
            />
          </svg>
        </div>
      );
    }

    if (element.type === 'arrow') {
      return (
        <div key={element.id} style={{ ...style, backgroundColor: 'transparent' }}>
          <svg width="100%" height="100%" viewBox="0 0 100 50" preserveAspectRatio="none">
            <polygon
              points="0,15 70,15 70,0 100,25 70,50 70,35 0,35"
              fill={element.fillColor || '#3b82f6'}
            />
          </svg>
        </div>
      );
    }

    return (
      <div
        key={element.id}
        style={{
          ...style,
          backgroundColor: element.fillColor || '#3b82f6'
        }}
      />
    );
  };

  return (
    <div className="w-48 bg-gray-100 border-r border-gray-300 flex flex-col overflow-hidden">
      <div className="p-2 border-b border-gray-300">
        <Button
          variant="outline"
          size="sm"
          onClick={onAddSlide}
          className="w-full gap-1"
        >
          <Plus className="w-4 h-4" />
          Nouvelle diapo
        </Button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={cn(
              "group relative cursor-pointer rounded-lg overflow-hidden transition-all",
              currentSlideIndex === index
                ? "ring-2 ring-orange-500 ring-offset-2"
                : "hover:ring-2 hover:ring-gray-400"
            )}
            onClick={() => onSlideSelect(index)}
          >
            {/* Slide Number */}
            <div className="absolute top-1 left-1 z-10 bg-black/60 text-white text-xs px-1.5 py-0.5 rounded">
              {index + 1}
            </div>

            {/* Thumbnail */}
            <div
              className="relative bg-white"
              style={{
                width: 144,
                height: 81,
                backgroundColor: slide.background || '#ffffff'
              }}
            >
              {slide.elements.map(renderMiniElement)}
            </div>

            {/* Actions */}
            <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 flex gap-1 transition-opacity">
              <button
                onClick={(e) => { e.stopPropagation(); onDuplicateSlide(index); }}
                className="p-1 bg-white/90 rounded hover:bg-white transition-colors"
              >
                <Copy className="w-3 h-3" />
              </button>
              {slides.length > 1 && (
                <button
                  onClick={(e) => { e.stopPropagation(); onDeleteSlide(index); }}
                  className="p-1 bg-white/90 rounded hover:bg-red-100 text-red-600 transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}