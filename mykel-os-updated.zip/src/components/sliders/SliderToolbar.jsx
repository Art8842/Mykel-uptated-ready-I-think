import React from 'react';
import { 
  Bold, Italic, Underline, Strikethrough,
  AlignLeft, AlignCenter, AlignRight,
  Type, Palette, Image, Square, Circle, Triangle,
  Play, Presentation as PresentationIcon, 
  Plus, Minus, Copy, Trash2,
  Save, Download, Printer, Share2,
  Undo, Redo, ChevronDown, Maximize,
  ArrowRight, MoveHorizontal, Layers, Grid, MousePointer
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const fonts = ['Arial', 'Times New Roman', 'Calibri', 'Georgia', 'Verdana', 'Impact', 'Comic Sans MS'];
const fontSizes = [8, 10, 12, 14, 18, 24, 32, 40, 48, 60, 72, 96];

const colors = [
  '#000000', '#434343', '#666666', '#999999', '#ffffff',
  '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff',
  '#0000ff', '#9900ff', '#ff00ff', '#f4cccc', '#fce5cd',
  '#fff2cc', '#d9ead3', '#d0e0e3', '#cfe2f3', '#d9d2e9'
];

const transitions = [
  { id: 'none', label: 'Aucune' },
  { id: 'fade', label: 'Fondu' },
  { id: 'slide', label: 'Glissement' },
  { id: 'zoom', label: 'Zoom' },
  { id: 'flip', label: 'Retournement' },
];

export default function SliderToolbar({ 
  onCommand, 
  onSave, 
  onExport,
  onShare,
  onPresent,
  saving,
  selectedElement,
  currentSlide
}) {
  const ToolbarButton = ({ icon: Icon, tooltip, onClick, active }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={active ? "secondary" : "ghost"}
            size="sm"
            className="h-8 w-8 p-0"
            onClick={onClick}
          >
            <Icon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <div className="bg-white border-b border-gray-200">
      {/* Menu Bar */}
      <div className="flex items-center px-2 py-1 border-b border-gray-100 text-sm overflow-x-auto flex-nowrap scrollbar-hide">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Fichier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onSave} className="gap-2">
              <Save className="w-4 h-4" /> Enregistrer
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <Download className="w-4 h-4" /> Télécharger
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onExport('pptx')}>
                  Microsoft PowerPoint (.pptx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('pdf')}>
                  PDF (.pdf)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('png')}>
                  Image PNG (.png)
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => window.print()} className="gap-2">
              <Printer className="w-4 h-4" /> Imprimer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Modifier
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onCommand('undo')} className="gap-2">
              <Undo className="w-4 h-4" /> Annuler
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('redo')} className="gap-2">
              <Redo className="w-4 h-4" /> Rétablir
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('duplicate')} className="gap-2">
              <Copy className="w-4 h-4" /> Dupliquer
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('delete')} className="gap-2 text-red-600">
              <Trash2 className="w-4 h-4" /> Supprimer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Insertion
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onCommand('addTextBox')} className="gap-2">
              <Type className="w-4 h-4" /> Zone de texte
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('addImage')} className="gap-2">
              <Image className="w-4 h-4" /> Image
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <Square className="w-4 h-4" /> Forme
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onCommand('addShape', 'rectangle')}>
                  <Square className="w-4 h-4 mr-2" /> Rectangle
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('addShape', 'circle')}>
                  <Circle className="w-4 h-4 mr-2" /> Cercle
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('addShape', 'triangle')}>
                  <Triangle className="w-4 h-4 mr-2" /> Triangle
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('addShape', 'arrow')}>
                  <ArrowRight className="w-4 h-4 mr-2" /> Flèche
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onCommand('addShape', 'line')}>
                  <MoveHorizontal className="w-4 h-4 mr-2" /> Ligne
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('addSlide')} className="gap-2">
              <Plus className="w-4 h-4" /> Nouvelle diapositive
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Diapositive
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onCommand('addSlide')} className="gap-2">
              <Plus className="w-4 h-4" /> Nouvelle diapositive
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('duplicateSlide')} className="gap-2">
              <Copy className="w-4 h-4" /> Dupliquer la diapositive
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCommand('deleteSlide')} className="gap-2 text-red-600">
              <Trash2 className="w-4 h-4" /> Supprimer la diapositive
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <Palette className="w-4 h-4" /> Arrière-plan
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent className="w-44 p-2">
                <div className="grid grid-cols-5 gap-1">
                  {colors.map(color => (
                    <button
                      key={color}
                      className="w-6 h-6 rounded border border-gray-300"
                      style={{ backgroundColor: color }}
                      onClick={() => onCommand('slideBackground', color)}
                    />
                  ))}
                </div>
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger className="gap-2">
                <Play className="w-4 h-4" /> Transition
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                {transitions.map(t => (
                  <DropdownMenuItem key={t.id} onClick={() => onCommand('transition', t.id)}>
                    {t.label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuSubContent>
            </DropdownMenuSub>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-sm font-normal">
              Affichage
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onPresent} className="gap-2">
              <Maximize className="w-4 h-4" /> Présenter
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onCommand('toggleGrid')} className="gap-2">
              <Grid className="w-4 h-4" /> Grille
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="ml-auto flex items-center gap-2">
          <Button 
            variant="default" 
            size="sm" 
            onClick={onPresent}
            className="h-7 gap-1 bg-orange-500 hover:bg-orange-600"
          >
            <Play className="w-4 h-4" />
            Présenter
          </Button>
          <Button variant="ghost" size="sm" onClick={onShare} className="h-7 gap-1">
            <Share2 className="w-4 h-4" />
            Partager
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onSave}
            disabled={saving}
            className="h-7"
          >
            {saving ? 'Enregistrement...' : 'Enregistrer'}
          </Button>
        </div>
      </div>

      {/* Formatting Toolbar */}
      <div className="flex items-center gap-1 px-2 py-1.5 overflow-x-auto flex-nowrap scrollbar-hide">
        <ToolbarButton icon={MousePointer} tooltip="Sélection" onClick={() => onCommand('tool', 'select')} />
        <ToolbarButton icon={Type} tooltip="Zone de texte" onClick={() => onCommand('addTextBox')} />
        <ToolbarButton icon={Image} tooltip="Image" onClick={() => onCommand('addImage')} />
        <ToolbarButton icon={Square} tooltip="Rectangle" onClick={() => onCommand('addShape', 'rectangle')} />
        <ToolbarButton icon={Circle} tooltip="Cercle" onClick={() => onCommand('addShape', 'circle')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={Undo} tooltip="Annuler" onClick={() => onCommand('undo')} />
        <ToolbarButton icon={Redo} tooltip="Rétablir" onClick={() => onCommand('redo')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />
        
        {/* Font (when text selected) */}
        <Select defaultValue="Arial" onValueChange={(v) => onCommand('fontFamily', v)}>
          <SelectTrigger className="w-28 h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {fonts.map(font => (
              <SelectItem key={font} value={font} style={{ fontFamily: font }}>
                {font}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select defaultValue="24" onValueChange={(v) => onCommand('fontSize', v)}>
          <SelectTrigger className="w-16 h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {fontSizes.map(size => (
              <SelectItem key={size} value={size.toString()}>{size}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={Bold} tooltip="Gras" onClick={() => onCommand('bold')} />
        <ToolbarButton icon={Italic} tooltip="Italique" onClick={() => onCommand('italic')} />
        <ToolbarButton icon={Underline} tooltip="Souligné" onClick={() => onCommand('underline')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Text Color */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Type className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-44 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Couleur du texte</p>
            <div className="grid grid-cols-5 gap-1">
              {colors.map(color => (
                <button
                  key={color}
                  className="w-6 h-6 rounded border border-gray-300"
                  style={{ backgroundColor: color }}
                  onClick={() => onCommand('textColor', color)}
                />
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Fill Color */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Palette className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-44 p-2">
            <p className="text-xs font-medium text-gray-500 mb-2">Remplissage</p>
            <div className="grid grid-cols-5 gap-1">
              {colors.map(color => (
                <button
                  key={color}
                  className="w-6 h-6 rounded border border-gray-300"
                  style={{ backgroundColor: color }}
                  onClick={() => onCommand('fillColor', color)}
                />
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={AlignLeft} tooltip="Aligner à gauche" onClick={() => onCommand('align', 'left')} />
        <ToolbarButton icon={AlignCenter} tooltip="Centrer" onClick={() => onCommand('align', 'center')} />
        <ToolbarButton icon={AlignRight} tooltip="Aligner à droite" onClick={() => onCommand('align', 'right')} />
        
        <Separator orientation="vertical" className="h-6 mx-1" />

        <ToolbarButton icon={Layers} tooltip="Avancer" onClick={() => onCommand('bringForward')} />
        <ToolbarButton icon={Layers} tooltip="Reculer" onClick={() => onCommand('sendBackward')} />
      </div>
    </div>
  );
}