import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Gift, Loader2, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

const FIELDS = [
  { key: 'pollinations_key', label: 'Clé API Pollinations', placeholder: 'pk_...', help: 'Clé publishable Pollinations (optionnel — pour des limites plus élevées)' },
  { key: 'ai_proxy_url', label: 'URL Proxy IA personnalisé', placeholder: 'https://mon-worker.workers.dev', help: 'Worker Cloudflare ou proxy custom pour les appels IA' },
  { key: 'cloudinary_cloud', label: 'Cloud Cloudinary', placeholder: 'my-cloud-name', help: 'Nom du cloud Cloudinary pour le stockage média' },
  { key: 'cloudinary_preset', label: 'Preset Cloudinary (non signé)', placeholder: 'mykel_unsigned', help: 'Preset « Unsigned » créé dans Cloudinary → Settings → Upload. Avec le nom du cloud, les images, vidéos et audios sont envoyés sur Cloudinary sans consommer de crédits.' },
];

export default function FreeServicesSection() {
  const [values, setValues] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const settings = await base44.entities.AppSettings.list();
        const map = {};
        for (const f of FIELDS) {
          const s = settings.find(x => x.key === f.key);
          map[f.key] = s?.value || '';
        }
        setValues(map);
      } catch {}
      finally { setLoading(false); }
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      const settings = await base44.entities.AppSettings.list();
      for (const f of FIELDS) {
        const existing = settings.find(x => x.key === f.key);
        if (existing) {
          await base44.entities.AppSettings.update(existing.id, { value: values[f.key] || '' });
        } else {
          await base44.entities.AppSettings.create({ key: f.key, value: values[f.key] || '' });
        }
        const lsKey = `mykel_${f.key}`;
        if (values[f.key]) localStorage.setItem(lsKey, values[f.key]);
        else localStorage.removeItem(lsKey);
      }
      toast.success('Services gratuits configurés');
    } catch { toast.error('Erreur lors de la sauvegarde'); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-purple-500" /></div>;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-1 flex items-center gap-2">
          <Gift className="w-5 h-5 text-green-500" /> Services gratuits
        </h2>
        <p className="text-sm text-gray-500">Configurez les services externes gratuits pour éviter la consommation de crédits d'intégration.</p>
      </div>
      <div className="space-y-4 max-w-xl">
        {FIELDS.map(f => (
          <div key={f.key} className="space-y-1.5">
            <Label>{f.label}</Label>
            <Input
              value={values[f.key] || ''}
              onChange={(e) => setValues(v => ({ ...v, [f.key]: e.target.value }))}
              placeholder={f.placeholder}
            />
            <p className="text-xs text-gray-400">{f.help}</p>
          </div>
        ))}
        <Button onClick={save} disabled={saving} className="bg-green-600 hover:bg-green-700">
          {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
          Enregistrer
        </Button>
      </div>
    </div>
  );
}