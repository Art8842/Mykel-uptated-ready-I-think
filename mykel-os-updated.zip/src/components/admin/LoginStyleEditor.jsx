import React, { useState, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Plus, Trash2, Save, Loader2, Eye, Image as ImageIcon, Move, X } from 'lucide-react';

const DEFAULT_STYLE = {
  bgColor: '#f5f3ff',
  bgColor2: '#ede9fe',
  btnColor: '#7c3aed',
  btnTextColor: '#ffffff',
  logoText: 'M',
  logoSubtitle: 'Votre espace numérique personnel',
  loginBtnLabel: 'Se connecter',
  registerBtnLabel: 'Créer mon compte',
  oldVersionBtnLabel: "Passer par l'ancienne version",
  customTexts: [],
  blockPosition: 'center',
  logoImageUrl: '',
  images: [], // [{ url, x, y, width, label }]
};

function getStyle() {
  try {
    const saved = localStorage.getItem('mykel_login_style');
    return saved ? { ...DEFAULT_STYLE, ...JSON.parse(saved) } : { ...DEFAULT_STYLE };
  } catch { return { ...DEFAULT_STYLE }; }
}

// Interactive mini-preview of the login page where images can be dragged
function LoginPagePreview({ style, onImageMove, onImageDelete }) {
  const containerRef = useRef(null);
  const dragging = useRef(null); // { index, startX, startY, origX, origY }

  const handleMouseDown = (e, index) => {
    e.preventDefault();
    const rect = containerRef.current.getBoundingClientRect();
    dragging.current = {
      index,
      startX: e.clientX,
      startY: e.clientY,
      origX: style.images[index].x,
      origY: style.images[index].y,
      rectW: rect.width,
      rectH: rect.height,
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseMove = useCallback((e) => {
    if (!dragging.current) return;
    const { index, startX, startY, origX, origY, rectW, rectH } = dragging.current;
    const dx = ((e.clientX - startX) / rectW) * 100;
    const dy = ((e.clientY - startY) / rectH) * 100;
    onImageMove(index, Math.max(0, Math.min(95, origX + dx)), Math.max(0, Math.min(95, origY + dy)));
  }, [onImageMove]);

  const handleMouseUp = useCallback(() => {
    dragging.current = null;
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);
  }, [handleMouseMove]);

  // Position of the login block
  const blockLeft = style.blockPosition === 'left' ? '5%'
    : style.blockPosition === 'right' ? '65%'
    : '50%';
  const blockTransform = style.blockPosition === 'center' ? 'translateX(-50%)' : 'none';

  return (
    <div
      ref={containerRef}
      className="relative w-full rounded-xl border-2 border-violet-200 overflow-hidden select-none"
      style={{
        height: 280,
        background: `linear-gradient(135deg, ${style.bgColor} 0%, ${style.bgColor2} 100%)`,
        cursor: 'default',
      }}
    >
      {/* Simulated login block */}
      <div
        className="absolute top-1/2 bg-white/80 rounded-xl shadow-lg p-3 flex flex-col items-center gap-1 pointer-events-none"
        style={{
          left: blockLeft,
          transform: `${blockTransform} translateY(-50%)`,
          width: 110,
          backdropFilter: 'blur(8px)',
        }}
      >
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold mb-1"
          style={{ background: style.btnColor }}
        >
          {style.logoImageUrl
            ? <img src={style.logoImageUrl} className="w-full h-full object-cover rounded-lg" alt="logo" />
            : style.logoText
          }
        </div>
        <p className="text-[7px] text-gray-500 text-center leading-tight">{style.logoSubtitle}</p>
        <div className="w-full h-4 rounded mt-1" style={{ background: style.btnColor, opacity: 0.9 }} />
        <div className="w-full h-4 rounded mt-0.5 border border-gray-300" />
        <p className="text-[6px] text-gray-400 mt-1">{style.oldVersionBtnLabel?.slice(0, 20)}…</p>
      </div>

      {/* Custom images, draggable */}
      {(style.images || []).map((img, i) => (
        <div
          key={i}
          className="absolute group"
          style={{ left: `${img.x}%`, top: `${img.y}%`, cursor: 'grab' }}
          onMouseDown={(e) => handleMouseDown(e, i)}
        >
          <img
            src={img.url}
            alt={img.label || `Image ${i + 1}`}
            draggable={false}
            style={{ width: img.width || 80, height: 'auto', borderRadius: 6, boxShadow: '0 2px 8px rgba(0,0,0,0.18)', display: 'block' }}
          />
          <button
            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
            onMouseDown={(e) => { e.stopPropagation(); onImageDelete(i); }}
          >
            <X className="w-2.5 h-2.5" />
          </button>
          <div className="absolute bottom-0 left-0 right-0 text-center text-[6px] bg-black/40 text-white rounded-b opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            <Move className="inline w-2 h-2" /> Glisser
          </div>
        </div>
      ))}

      {/* Custom texts */}
      {(style.customTexts || []).map((ct, i) => (
        <div
          key={i}
          className="absolute bottom-3 left-0 right-0 text-center pointer-events-none"
          style={{ color: ct.color, fontSize: `calc(${ct.size || '14px'} * 0.5)` }}
        >
          {ct.text}
        </div>
      ))}

      <div className="absolute top-2 right-2 bg-black/20 text-white text-[8px] px-2 py-0.5 rounded-full pointer-events-none">
        Aperçu interactif
      </div>
    </div>
  );
}

export default function LoginStyleEditor() {
  const [style, setStyle] = useState(getStyle());
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadingImg, setUploadingImg] = useState(false);

  const updateField = (key, value) => setStyle(s => ({ ...s, [key]: value }));

  // Images
  const handleAddImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImg(true);
    try {
      const { file_url } = await uploadMedia(file);
      setStyle(s => ({
        ...s,
        images: [...(s.images || []), { url: file_url, x: 5, y: 10, width: 120, label: file.name }],
      }));
      toast.success('Image ajoutée — glissez-la dans l\'aperçu pour la positionner');
    } catch { toast.error('Erreur upload image'); }
    finally { setUploadingImg(false); e.target.value = ''; }
  };

  const handleImageMove = useCallback((index, x, y) => {
    setStyle(s => ({
      ...s,
      images: s.images.map((img, i) => i === index ? { ...img, x, y } : img),
    }));
  }, []);

  const handleImageDelete = (index) => {
    setStyle(s => ({ ...s, images: s.images.filter((_, i) => i !== index) }));
  };

  const updateImageField = (index, field, value) => {
    setStyle(s => ({
      ...s,
      images: s.images.map((img, i) => i === index ? { ...img, [field]: value } : img),
    }));
  };

  // Texts
  const addTextZone = () => {
    setStyle(s => ({ ...s, customTexts: [...(s.customTexts || []), { text: '', color: '#374151', size: '14px' }] }));
  };
  const removeTextZone = (i) => {
    setStyle(s => ({ ...s, customTexts: s.customTexts.filter((_, idx) => idx !== i) }));
  };
  const updateTextZone = (i, field, value) => {
    setStyle(s => ({
      ...s,
      customTexts: s.customTexts.map((ct, idx) => idx === i ? { ...ct, [field]: value } : ct),
    }));
  };

  // Logo upload
  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await uploadMedia(file);
      updateField('logoImageUrl', file_url);
      toast.success('Logo uploadé');
    } catch { toast.error('Erreur upload logo'); }
    finally { setUploading(false); }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      localStorage.setItem('mykel_login_style', JSON.stringify(style));
      // Use list() + find for reliability — filter() can silently fail on string fields
      const allSettings = await base44.entities.AppSettings.list();
      const existing = allSettings.find(s => s.key === 'login_style');
      if (existing) {
        await base44.entities.AppSettings.update(existing.id, { value: JSON.stringify(style) });
      } else {
        await base44.entities.AppSettings.create({ key: 'login_style', value: JSON.stringify(style) });
      }
      toast.success('Style sauvegardé et synchronisé sur tous les appareils !');
    } catch (e) {
      console.error('Login style save error:', e);
      toast.error('Erreur: ' + (e.message || 'Sauvegarde impossible'));
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setStyle({ ...DEFAULT_STYLE });
    localStorage.removeItem('mykel_login_style');
    toast.success('Style réinitialisé');
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Style de la page de connexion</h2>
          <p className="text-sm text-gray-500 mt-1">Personnalisez l'apparence de la page de connexion Mykel.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleReset}>Réinitialiser</Button>
          <Button variant="outline" size="sm" onClick={() => window.open('/MykelLogin', '_blank')} className="gap-1">
            <Eye className="w-3 h-3" /> Aperçu
          </Button>
        </div>
      </div>

      {/* Interactive Preview */}
      <div className="space-y-2">
        <Label className="font-semibold">Aperçu interactif — glissez les images pour les repositionner</Label>
        <LoginPagePreview style={style} onImageMove={handleImageMove} onImageDelete={handleImageDelete} />
      </div>

      {/* Images section */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <Label className="font-semibold">Images décoratives</Label>
          <label className="cursor-pointer">
            <Button asChild size="sm" variant="outline" disabled={uploadingImg} className="gap-1">
              <span>
                {uploadingImg ? <Loader2 className="w-3 h-3 animate-spin" /> : <ImageIcon className="w-3 h-3" />}
                Ajouter une image
              </span>
            </Button>
            <input type="file" accept="image/*" className="hidden" onChange={handleAddImage} />
          </label>
        </div>
        {(style.images || []).length === 0 && (
          <p className="text-sm text-gray-400 text-center py-3">Aucune image. Ajoutez-en une et glissez-la sur l'aperçu pour la positionner.</p>
        )}
        {(style.images || []).map((img, i) => (
          <div key={i} className="flex items-center gap-3 border border-gray-100 rounded-xl p-3 bg-gray-50 dark:bg-gray-800">
            <img src={img.url} alt="" className="w-14 h-14 object-cover rounded-lg border flex-shrink-0" />
            <div className="flex-1 space-y-1.5">
              <div className="flex items-center gap-2">
                <label className="text-xs text-gray-500 w-16 flex-shrink-0">Taille (px)</label>
                <Input
                  type="number"
                  value={img.width || 120}
                  onChange={e => updateImageField(i, 'width', parseInt(e.target.value) || 120)}
                  className="h-7 text-xs w-20"
                  min={20} max={800}
                />
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <Move className="w-3 h-3" />
                Position : X={Math.round(img.x)}% Y={Math.round(img.y)}%
                <span className="text-gray-300">(glissez dans l'aperçu)</span>
              </div>
            </div>
            <button onClick={() => handleImageDelete(i)} className="text-red-400 hover:text-red-600 flex-shrink-0">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Position du bloc */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5 space-y-3">
        <Label className="font-semibold">Position du bloc de connexion</Label>
        <div className="flex gap-3">
          {['left', 'center', 'right'].map(pos => (
            <button
              key={pos}
              onClick={() => updateField('blockPosition', pos)}
              className={`flex-1 py-3 rounded-xl border-2 text-sm font-medium transition-all capitalize ${style.blockPosition === pos ? 'border-violet-500 bg-violet-50 text-violet-700' : 'border-gray-200 text-gray-500 hover:border-gray-300'}`}
            >
              {pos === 'left' ? '⬅️ Gauche' : pos === 'center' ? '↔️ Centre' : '➡️ Droite'}
            </button>
          ))}
        </div>
      </div>

      {/* Couleurs */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5 space-y-4">
        <Label className="font-semibold">Couleurs</Label>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Fond (couleur 1)', field: 'bgColor' },
            { label: 'Fond (couleur 2)', field: 'bgColor2' },
            { label: 'Couleur des boutons', field: 'btnColor' },
            { label: 'Texte des boutons', field: 'btnTextColor' },
          ].map(({ label, field }) => (
            <div key={field}>
              <label className="text-xs text-gray-500 mb-1 block">{label}</label>
              <div className="flex items-center gap-2">
                <input type="color" value={style[field]} onChange={e => updateField(field, e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border border-gray-200" />
                <span className="text-xs font-mono text-gray-600">{style[field]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Logo */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5 space-y-4">
        <Label className="font-semibold">Logo & Titre</Label>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Lettre du logo (si pas d'image)</label>
            <Input value={style.logoText} onChange={e => updateField('logoText', e.target.value)} maxLength={3} className="h-9" />
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Image logo (optionnel)</label>
            <div className="flex items-center gap-2">
              {style.logoImageUrl && <img src={style.logoImageUrl} className="w-9 h-9 rounded-lg object-cover border" alt="logo" />}
              <label className="cursor-pointer">
                <Button asChild size="sm" variant="outline" disabled={uploading}>
                  <span>{uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Choisir'}</span>
                </Button>
                <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
              </label>
              {style.logoImageUrl && <button onClick={() => updateField('logoImageUrl', '')} className="text-red-400 text-xs hover:text-red-600">Suppr.</button>}
            </div>
          </div>
        </div>
        <div>
          <label className="text-xs text-gray-500 mb-1 block">Sous-titre</label>
          <Input value={style.logoSubtitle} onChange={e => updateField('logoSubtitle', e.target.value)} className="h-9" />
        </div>
      </div>

      {/* Textes des boutons */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5 space-y-4">
        <Label className="font-semibold">Textes des boutons</Label>
        <div className="space-y-3">
          {[
            { label: 'Bouton Se connecter', field: 'loginBtnLabel' },
            { label: 'Bouton Créer un compte', field: 'registerBtnLabel' },
            { label: 'Bouton Ancienne version', field: 'oldVersionBtnLabel' },
          ].map(({ label, field }) => (
            <div key={field}>
              <label className="text-xs text-gray-500 mb-1 block">{label}</label>
              <Input value={style[field]} onChange={e => updateField(field, e.target.value)} className="h-9" />
            </div>
          ))}
        </div>
      </div>

      {/* Zones de texte personnalisées */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <Label className="font-semibold">Zones de texte personnalisées</Label>
          <Button size="sm" variant="outline" onClick={addTextZone} className="gap-1">
            <Plus className="w-3 h-3" /> Ajouter
          </Button>
        </div>
        {(style.customTexts || []).length === 0 && (
          <p className="text-sm text-gray-400 text-center py-4">Aucune zone de texte. Cliquez sur Ajouter.</p>
        )}
        {(style.customTexts || []).map((ct, i) => (
          <div key={i} className="border border-gray-100 rounded-xl p-3 space-y-2 bg-gray-50 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-gray-500">Zone {i + 1}</span>
              <button onClick={() => removeTextZone(i)} className="text-red-400 hover:text-red-600">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <Input placeholder="Texte affiché sur la page..." value={ct.text} onChange={e => updateTextZone(i, 'text', e.target.value)} className="h-9" />
            <div className="flex gap-3">
              <div className="flex items-center gap-2">
                <label className="text-xs text-gray-500">Couleur</label>
                <input type="color" value={ct.color || '#374151'} onChange={e => updateTextZone(i, 'color', e.target.value)} className="w-8 h-8 rounded cursor-pointer border border-gray-200" />
              </div>
              <div className="flex items-center gap-2 flex-1">
                <label className="text-xs text-gray-500">Taille</label>
                <Input value={ct.size || '14px'} onChange={e => updateTextZone(i, 'size', e.target.value)} placeholder="14px" className="h-8 text-xs" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Save */}
      <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
        Enregistrer le style
      </Button>
    </div>
  );
}