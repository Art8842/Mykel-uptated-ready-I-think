import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { freeInvokeLLM } from '@/lib/freeCore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Plus, Trash2, Loader2, Send, Sparkles, Check, X,
  RefreshCw, Calendar, ChevronDown, ChevronUp
} from 'lucide-react';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

export default function UpdateSection() {
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);

  const loadUpdates = async () => {
    try {
      const list = await base44.entities.PlatformUpdate.filter({ active: true });
      // Sort by validated_at desc
      list.sort((a, b) => new Date(b.validated_at || 0) - new Date(a.validated_at || 0));
      setUpdates(list);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { loadUpdates(); }, []);

  const deleteUpdate = async (id) => {
    await base44.entities.PlatformUpdate.update(id, { active: false });
    loadUpdates();
    toast.success('Mise à jour archivée');
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Mises à jour</h2>
          <p className="text-sm text-gray-500 mt-1">
            Validez une mise à jour en discutant avec l'IA. Les utilisateurs pourront ensuite demander à Mykel IA ce qu'apporte chaque mise à jour.
          </p>
        </div>
        <Button onClick={() => setChatOpen(true)} className="gap-2 bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4" />
          Valider une update
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
        </div>
      ) : updates.length === 0 ? (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center text-gray-500">
          <RefreshCw className="w-10 h-10 mx-auto mb-3 text-gray-300" />
          <p>Aucune mise à jour validée</p>
        </div>
      ) : (
        <div className="space-y-3">
          {updates.map((update, i) => (
            <UpdateCard key={update.id} update={update} onDelete={() => deleteUpdate(update.id)} />
          ))}
        </div>
      )}

      {chatOpen && (
        <UpdateChatBot
          onClose={() => setChatOpen(false)}
          onValidated={() => { setChatOpen(false); loadUpdates(); }}
        />
      )}
    </div>
  );
}

function UpdateCard({ update, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            {update.version && (
              <span className="text-xs font-bold bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">v{update.version}</span>
            )}
            {update.validated_at && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {new Date(update.validated_at).toLocaleDateString('fr-FR')}
              </span>
            )}
          </div>
          <p className="text-sm text-gray-900 dark:text-white font-medium line-clamp-2">{update.summary}</p>
          {update.features?.length > 0 && (
            <>
              <button
                onClick={() => setExpanded(e => !e)}
                className="flex items-center gap-1 text-xs text-blue-500 hover:text-blue-600 mt-2"
              >
                {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                {update.features.length} changements détaillés
              </button>
              {expanded && (
                <ul className="mt-2 space-y-1">
                  {update.features.map((f, i) => (
                    <li key={i} className="text-xs text-gray-600 dark:text-gray-400 flex items-start gap-2">
                      <span className="text-blue-500 mt-0.5">•</span>
                      {f}
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </div>
        <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:text-red-600 flex-shrink-0" onClick={onDelete}>
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}

function UpdateChatBot({ onClose, onValidated }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Bonjour ! Je vais vous aider à documenter cette mise à jour. 🎉\n\nDites-moi, **que change ou qu'ajoute cette mise à jour ?** Décrivez-moi les nouveautés, les améliorations, les corrections de bugs, etc." }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [validated, setValidated] = useState(false);
  const [summary, setSummary] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    const newMessages = [...messages, { role: 'user', content: userMsg }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const conversationText = newMessages.map(m =>
        `${m.role === 'user' ? 'Admin' : 'IA'}: ${m.content}`
      ).join('\n');

      const prompt = `Tu es un assistant qui aide un administrateur à documenter une mise à jour de la plateforme Mykel.

Voici la conversation jusqu'à présent :
${conversationText}

L'admin vient de dire: "${userMsg}"

Ton rôle:
1. Pose des questions pour comprendre exactement ce que change la mise à jour
2. Demande des précisions si nécessaire (nom de la fonctionnalité, ce qu'elle fait, comment l'utiliser)
3. Si tu penses avoir assez d'informations, propose un RÉSUMÉ structuré de la mise à jour avec:
   - Un résumé global (1-2 phrases)
   - Une liste des fonctionnalités/changements (un par ligne, précis et descriptif)

Si tu as assez d'informations pour faire un résumé complet, commence ta réponse par "=== RÉSUMÉ ===" suivi du résumé structuré. Sinon, continue à poser des questions.

Réponds en français, de manière claire et professionnelle.`;

      const response = await freeInvokeLLM({ prompt });

      // Check if AI provided a summary
      if (response.includes('=== RÉSUMÉ ===')) {
        const summaryPart = response.split('=== RÉSUMÉ ===')[1].trim();
        setSummary(summaryPart);
      }

      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: "Désolé, une erreur s'est produite. Réessayez." }]);
    } finally {
      setLoading(false);
    }
  };

  const handleValidate = async () => {
    if (!summary) { toast.error("L'IA n'a pas encore produit de résumé. Continuez la discussion."); return; }
    setLoading(true);
    try {
      // Parse the summary to extract features
      const lines = summary.split('\n').map(l => l.trim()).filter(Boolean);
      const features = lines.filter(l =>
        l.startsWith('-') || l.startsWith('•') || l.startsWith('*') ||
        /^\d+\./.test(l)
      ).map(l => l.replace(/^[-•*]\s*/, '').replace(/^\d+\.\s*/, ''));

      const globalSummary = lines.find(l => !l.startsWith('-') && !l.startsWith('•') && !l.startsWith('*') && !/^\d+\./.test(l)) || summary.split('\n')[0];

      // Extract version if mentioned
      const versionMatch = summary.match(/v?(\d+\.\d+\.\d+)/);
      const version = versionMatch ? versionMatch[1] : '';

      const created = await base44.entities.PlatformUpdate.create({
        version,
        summary: globalSummary || summary,
        features: features.length > 0 ? features : [summary],
        conversation: messages.map(m => ({ role: m.role, content: m.content })),
        validated_at: new Date().toISOString(),
        active: true,
      });

      setValidated(true);
      toast.success('Mise à jour validée et enregistrée !');
      setTimeout(() => onValidated(), 1500);
    } catch (e) {
      toast.error('Erreur lors de la validation');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-2xl border border-gray-200 dark:border-gray-700 flex flex-col" style={{ maxHeight: '85vh' }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Valider une mise à jour</h3>
              <p className="text-xs text-blue-200">Discutez avec l'IA pour documenter la mise à jour</p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/70 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
              }`}>
                {msg.role === 'assistant'
                  ? <ReactMarkdown className="prose prose-sm dark:prose-invert max-w-none">{msg.content}</ReactMarkdown>
                  : msg.content
                }
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 dark:bg-gray-800 rounded-2xl px-4 py-2.5">
                <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Summary preview */}
        {summary && !validated && (
          <div className="px-4 pb-2">
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Check className="w-4 h-4 text-green-600" />
                <p className="text-sm font-medium text-green-700 dark:text-green-400">Résumé prêt à valider</p>
              </div>
              <p className="text-xs text-green-600 dark:text-green-500">Vérifiez le résumé ci-dessus (=== RÉSUMÉ ===). Si correct, cliquez sur Valider.</p>
            </div>
          </div>
        )}

        {/* Input + Validate */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          {validated ? (
            <div className="flex items-center justify-center gap-2 py-3 text-green-600">
              <Check className="w-5 h-5" />
              <span className="font-medium">Mise à jour validée avec succès !</span>
            </div>
          ) : (
            <>
              <div className="flex gap-2 mb-2">
                <Input
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                  placeholder="Décrivez les changements de la mise à jour..."
                  className="flex-1"
                  disabled={loading}
                />
                <Button onClick={sendMessage} disabled={loading || !input.trim()} size="icon">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              {summary && (
                <Button onClick={handleValidate} disabled={loading} className="w-full gap-2 bg-green-600 hover:bg-green-700">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  Valider cette mise à jour
                </Button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}