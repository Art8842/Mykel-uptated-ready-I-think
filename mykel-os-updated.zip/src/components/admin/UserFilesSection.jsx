import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { confirmAction } from '@/lib/confirm';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, FolderOpen, ArrowLeft, Trash2, Eye } from 'lucide-react';
import { toast } from 'sonner';

// Presence status helpers
function PresenceBadge({ presence }) {
  const stale = presence && Date.now() - new Date(presence.last_activity).getTime() > 3 * 60 * 1000;
  if (!presence || stale) return <Badge className="bg-gray-400 text-white text-xs">Hors ligne</Badge>;
  if (presence.status === 'active') {
    const label = presence.activity_label || 'En ligne';
    return <Badge className="bg-green-500 text-white text-xs animate-pulse">{label}</Badge>;
  }
  if (presence.status === 'passive') return <Badge className="bg-yellow-500 text-white text-xs">Passif</Badge>;
  return <Badge className="bg-gray-400 text-white text-xs">Hors ligne</Badge>;
}

const TYPE_ICONS = {
  folder: '📁', document: '📄', spreadsheet: '📊', presentation: '📊', drawing: '🎨',
  image: '🖼️', pdf: '📕', video: '🎬', audio: '🎵', archive: '🗜️', other: '📎'
};

function formatSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024) return bytes + ' o';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
  return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
}

function FilePreviewDialog({ file, onClose }) {
  if (!file) return null;
  const isImage = file.type === 'image' || (file.file_url && /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(file.file_url));
  const isAudio = file.type === 'audio' || (file.file_url && /\.(mp3|wav|ogg|m4a|flac)$/i.test(file.file_url));
  const isVideo = file.type === 'video' || (file.file_url && /\.(mp4|webm|mov|avi)$/i.test(file.file_url));
  return (
    <Dialog open={!!file} onOpenChange={onClose}>
      <DialogContent className="bg-white dark:bg-gray-900 max-w-2xl">
        <DialogHeader>
          <DialogTitle className="truncate">{file.name}</DialogTitle>
        </DialogHeader>
        <div className="flex justify-center items-center min-h-[200px]">
          {isImage && <img src={file.file_url} className="max-w-full max-h-[60vh] rounded-lg object-contain" alt={file.name} />}
          {isAudio && <audio controls src={file.file_url} className="w-full" />}
          {isVideo && <video controls src={file.file_url} className="max-w-full max-h-[60vh] rounded-lg" />}
          {!isImage && !isAudio && !isVideo && (
            <div className="text-center text-gray-400">
              <p className="text-4xl mb-3">{TYPE_ICONS[file.type] || '📎'}</p>
              <p className="text-sm">Aperçu non disponible</p>
              {file.file_url && <a href={file.file_url} target="_blank" rel="noreferrer" className="text-blue-500 text-sm underline mt-2 block">Ouvrir le lien</a>}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function UserFileBrowser({ user, onBack }) {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [breadcrumbs, setBreadcrumbs] = useState([]);
  const [previewFile, setPreviewFile] = useState(null);

  useEffect(() => { loadFiles(); }, [currentFolderId]);

  const loadFiles = async () => {
    setLoading(true);
    try {
      // Fetch all files then filter client-side to bypass per-user security
      const all = await base44.entities.CloudFile.list('-created_date', 500);
      const userFiles = all.filter(f => f.created_by === user.email && !f.is_trashed);
      let list;
      if (currentFolderId) {
        list = userFiles.filter(f => f.parent_folder_id === currentFolderId);
      } else {
        list = userFiles.filter(f => !f.parent_folder_id);
      }
      list.sort((a, b) => {
        if (a.type === 'folder' && b.type !== 'folder') return -1;
        if (a.type !== 'folder' && b.type === 'folder') return 1;
        return (a.name || '').localeCompare(b.name || '');
      });
      setFiles(list);
    } catch (e) { console.error(e); toast.error('Impossible de charger les fichiers'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (file) => {
    if (!await confirmAction({ title: `Supprimer "${file.name}" ?`, message: `Du compte de ${user.full_name || user.email}`, destructive: true })) return;
    await base44.entities.CloudFile.delete(file.id);
    toast.success('Fichier supprimé');
    loadFiles();
  };

  const handleFolderClick = (folder) => {
    setBreadcrumbs(prev => [...prev, folder]);
    setCurrentFolderId(folder.id);
  };

  const handleBreadcrumb = (crumb) => {
    if (!crumb) { setBreadcrumbs([]); setCurrentFolderId(null); return; }
    const idx = breadcrumbs.findIndex(b => b.id === crumb.id);
    setBreadcrumbs(breadcrumbs.slice(0, idx + 1));
    setCurrentFolderId(crumb.id);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack} className="gap-1">
          <ArrowLeft className="w-4 h-4" />
          Retour aux utilisateurs
        </Button>
        <div>
          <p className="font-semibold text-gray-900 dark:text-white">{user.full_name || user.email}</p>
          <p className="text-xs text-gray-500">{user.email}</p>
        </div>
      </div>

      {/* Breadcrumbs */}
      <div className="flex items-center gap-1 text-sm flex-wrap">
        <button onClick={() => handleBreadcrumb(null)} className="text-blue-600 hover:underline">Racine</button>
        {breadcrumbs.map((crumb, i) => (
          <React.Fragment key={crumb.id}>
            <span className="text-gray-400">/</span>
            <button onClick={() => handleBreadcrumb(crumb)} className="text-blue-600 hover:underline">{crumb.name}</button>
          </React.Fragment>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin" /></div>
      ) : files.length === 0 ? (
        <div className="text-center py-10 text-gray-400">
          <FolderOpen className="w-10 h-10 mx-auto mb-2" />
          <p>Aucun fichier ici</p>
        </div>
      ) : (
        <div className="space-y-2">
          {files.map(file => (
            <div key={file.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-3 flex items-center justify-between gap-3">
              <button
                className="flex items-center gap-3 flex-1 text-left min-w-0"
                onClick={() => file.type === 'folder' ? handleFolderClick(file) : setPreviewFile(file)}
              >
                <span className="text-2xl">{TYPE_ICONS[file.type] || '📎'}</span>
                <div className="min-w-0">
                  <p className="font-medium text-sm text-gray-900 dark:text-white truncate">{file.name}</p>
                  {file.size && <p className="text-xs text-gray-400">{formatSize(file.size)}</p>}
                </div>
              </button>
              <div className="flex items-center gap-1 flex-shrink-0">
                {file.type !== 'folder' && file.file_url && (
                  <Button size="sm" variant="ghost" className="text-blue-400 hover:text-blue-600 hover:bg-blue-50" onClick={() => setPreviewFile(file)}>
                    <Eye className="w-4 h-4" />
                  </Button>
                )}
                <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-600 hover:bg-red-50" onClick={() => handleDelete(file)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
      <FilePreviewDialog file={previewFile} onClose={() => setPreviewFile(null)} />
    </div>
  );
}

export default function UserFilesSection() {
  const [users, setUsers] = useState([]);
  const [presences, setPresences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState(null);
  const presenceIntervalRef = useRef(null);

  useEffect(() => {
    loadAll();
    // Poll presences every 15 seconds
    presenceIntervalRef.current = setInterval(loadPresences, 15000);
    return () => clearInterval(presenceIntervalRef.current);
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [userList, presenceList] = await Promise.all([
        base44.entities.User.list(),
        base44.entities.UserPresence.list(),
      ]);
      setUsers(userList);
      setPresences(presenceList);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const loadPresences = async () => {
    try {
      const list = await base44.entities.UserPresence.list();
      setPresences(list);
    } catch {}
  };

  const getPresence = (email) => presences.find(p => p.user_email === email);

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  if (selectedUser) {
    return <UserFileBrowser user={selectedUser} onBack={() => setSelectedUser(null)} />;
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Fichiers & Dossiers des Utilisateurs</h2>
        <p className="text-sm text-gray-500 mt-1">Accédez aux fichiers de chaque utilisateur pour modération. Présence mise à jour en direct.</p>
      </div>
      <div className="space-y-3">
        {users.map(user => {
          const presence = getPresence(user.email);
          return (
            <button
              key={user.id}
              onClick={() => setSelectedUser(user)}
              className="w-full bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between gap-3 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                  {(user.full_name || user.email)?.[0]?.toUpperCase()}
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white text-sm">{user.full_name || user.email}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                  {presence?.current_page && presence.status !== 'offline' && (
                    <p className="text-xs text-gray-400 mt-0.5">📍 {presence.current_page}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <PresenceBadge presence={presence} />
                <FolderOpen className="w-4 h-4 text-gray-400" />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}