import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Save, Plus, Trash2, ArrowUp, ArrowDown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const DEFAULT_CONTENT = {
  hero: { title: 'Mykel', subtitle: 'Votre espace numérique tout-en-un', body: 'Cloud, Musique, TV, IA, Bureautique... Tous vos services préférés réunis en une seule plateforme.', bg_color: '#7c3aed', text_color: '#ffffff', button_text: "S'inscrire gratuitement" },
  features: [
    { icon: 'Cloud', title: 'Mykel Cloud', description: 'Stockez vos fichiers en toute sécurité.' },
    { icon: 'Music', title: 'Mykel Music', description: 'Écoutez votre musique préférée.' },
    { icon: 'Tv', title: 'Mykel TV', description: 'Films et séries en streaming.' },
    { icon: 'Sparkles', title: 'Mykel IA', description: 'Assistant IA intelligent.' },
    { icon: 'FileText', title: 'Suite Bureautique', description: 'Documents, tableaux, présentations.' },
    { icon: 'Wand2', title: 'Mykel SnapFix', description: 'Retouche photo et création visuelle.' },
  ],
  cta: { title: 'Prêt à commencer ?', body: "Rejoignez Mykel dès aujourd'hui.", button_text: 'Créer mon compte', bg_color: '#1e1b4b' },
};

const ICON_OPTIONS = ['Cloud', 'Music', 'Tv', 'Sparkles', 'FileText', 'Wand2', 'Building2'];

export default function LandingPageEditor() {
  const [content, setContent] = useState(DEFAULT_CONTENT);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('hero');

  useEffect(() => { loadContent(); }, []);

  const loadContent = async () => {
    try {
      const settings = await base44.entities.AppSettings.list();
      const landingSetting = settings.find(s => s.key === 'landing_page_content');
      if (landingSetting?.value) {
        try { setContent(JSON.parse(landingSetting.value)); } catch {}
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const saveContent = async () => {
    setSaving(true);
    try {
      const settings = await base44.entities.AppSettings.list();
      const existing = settings.find(s => s.key === 'landing_page_content');
      if (existing) await base44.entities.AppSettings.update(existing.id, { value: JSON.stringify(content) });
      else await base44.entities.AppSettings.create({ key: 'landing_page_content', value: JSON.stringify(content) });
      toast.success('Page d\'accueil sauvegardée');
    } catch (e) { toast.error('Erreur lors de la sauvegarde'); }
    finally { setSaving(false); }
  };

  const updateHero = (key, value) => setContent(c => ({ ...c, hero: { ...c.hero, [key]: value } }));
  const updateCta = (key, value) => setContent(c => ({ ...c, cta: { ...c.cta, [key]: value } }));

  const updateFeature = (i, key, value) => setContent(c => ({ ...c, features: c.features.map((f, idx) => idx === i ? { ...f, [key]: value } : f) }));
  const addFeature = () => setContent(c => ({ ...c, features: [...c.features, { icon: 'Sparkles', title: 'Nouveau service', description: 'Description du service' }] }));
  const removeFeature = (i) => setContent(c => ({ ...c, features: c.features.filter((_, idx) => idx !== i) }));
  const moveFeature = (i, dir) => {
    setContent(c => {
      const features = [...c.features];
      const j = i + dir;
      if (j < 0 || j >= features.length) return c;
      [features[i], features[j]] = [features[j], features[i]];
      return { ...c, features };
    });
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-violet-600" /></div>;

  const TABS = [
    { id: 'hero', label: 'Héro' },
    { id: 'features', label: 'Services' },
    { id: 'cta', label: "Appel à l'action" },
  ];

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Éditeur de la page d'accueil</h2>
          <p className="text-sm text-gray-500 mt-1">Modifiez les textes, couleurs et services affichés sur la page d'accueil publique.</p>
        </div>
        <Button onClick={saveContent} disabled={saving} className="gap-2 bg-violet-600 hover:bg-violet-700">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Publier
        </Button>
      </div>

      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${activeTab === tab.id ? 'border-violet-600 text-violet-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'hero' && (
        <div className="space-y-4 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
          <div><Label>Titre</Label><Input value={content.hero.title} onChange={e => updateHero('title', e.target.value)} /></div>
          <div><Label>Sous-titre</Label><Input value={content.hero.subtitle} onChange={e => updateHero('subtitle', e.target.value)} /></div>
          <div><Label>Description</Label><Textarea value={content.hero.body} onChange={e => updateHero('body', e.target.value)} rows={3} /></div>
          <div><Label>Texte du bouton</Label><Input value={content.hero.button_text} onChange={e => updateHero('button_text', e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Couleur de fond</Label><div className="flex gap-2 items-center"><input type="color" value={content.hero.bg_color} onChange={e => updateHero('bg_color', e.target.value)} className="w-12 h-9 rounded border" /><Input value={content.hero.bg_color} onChange={e => updateHero('bg_color', e.target.value)} /></div></div>
            <div><Label>Couleur du texte</Label><div className="flex gap-2 items-center"><input type="color" value={content.hero.text_color} onChange={e => updateHero('text_color', e.target.value)} className="w-12 h-9 rounded border" /><Input value={content.hero.text_color} onChange={e => updateHero('text_color', e.target.value)} /></div></div>
          </div>
          <div className="rounded-xl p-6 text-center" style={{ backgroundColor: content.hero.bg_color, color: content.hero.text_color }}>
            <h3 className="text-2xl font-bold mb-2">{content.hero.title}</h3>
            <p className="font-semibold mb-1">{content.hero.subtitle}</p>
            <p className="text-sm opacity-80 mb-3">{content.hero.body}</p>
            <span className="inline-block bg-white text-violet-700 px-4 py-1.5 rounded-lg text-sm font-semibold">{content.hero.button_text}</span>
          </div>
        </div>
      )}

      {activeTab === 'features' && (
        <div className="space-y-3">
          {content.features.map((f, i) => (
            <div key={i} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Service #{i + 1}</span>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" className="w-8 h-8" onClick={() => moveFeature(i, -1)} disabled={i === 0}><ArrowUp className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" className="w-8 h-8" onClick={() => moveFeature(i, 1)} disabled={i === content.features.length - 1}><ArrowDown className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" className="w-8 h-8 text-red-400" onClick={() => removeFeature(i)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Titre</Label><Input value={f.title} onChange={e => updateFeature(i, 'title', e.target.value)} /></div>
                <div>
                  <Label>Icône</Label>
                  <select className="w-full border rounded-lg px-3 py-2 text-sm bg-white dark:bg-gray-800" value={f.icon} onChange={e => updateFeature(i, 'icon', e.target.value)}>
                    {ICON_OPTIONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
                  </select>
                </div>
              </div>
              <div><Label>Description</Label><Textarea value={f.description} onChange={e => updateFeature(i, 'description', e.target.value)} rows={2} /></div>
            </div>
          ))}
          <Button variant="outline" onClick={addFeature} className="gap-2 w-full"><Plus className="w-4 h-4" /> Ajouter un service</Button>
        </div>
      )}

      {activeTab === 'cta' && (
        <div className="space-y-4 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
          <div><Label>Titre</Label><Input value={content.cta.title} onChange={e => updateCta('title', e.target.value)} /></div>
          <div><Label>Description</Label><Textarea value={content.cta.body} onChange={e => updateCta('body', e.target.value)} rows={2} /></div>
          <div><Label>Texte du bouton</Label><Input value={content.cta.button_text} onChange={e => updateCta('button_text', e.target.value)} /></div>
          <div><Label>Couleur de fond</Label><div className="flex gap-2 items-center"><input type="color" value={content.cta.bg_color} onChange={e => updateCta('bg_color', e.target.value)} className="w-12 h-9 rounded border" /><Input value={content.cta.bg_color} onChange={e => updateCta('bg_color', e.target.value)} /></div></div>
          <div className="rounded-xl p-6 text-center text-white" style={{ backgroundColor: content.cta.bg_color }}>
            <h3 className="text-xl font-bold mb-2">{content.cta.title}</h3>
            <p className="text-sm opacity-80 mb-3">{content.cta.body}</p>
            <span className="inline-block bg-white text-violet-700 px-4 py-1.5 rounded-lg text-sm font-semibold">{content.cta.button_text}</span>
          </div>
        </div>
      )}
    </div>
  );
}