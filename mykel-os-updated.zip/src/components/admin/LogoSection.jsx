import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { AppIcon, reloadCustomLogos } from '@/components/shared/AppIcons';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Save, RotateCcw, Upload, Loader2, Image as ImageIcon } from 'lucide-react';

const ALL_APPS = [
  { id: 'word',     label: 'Mykel Word' },
  { id: 'tabs',     label: 'Mykel Tabs' },
  { id: 'sliders',  label: 'Mykel Sliders' },
  { id: 'draws',    label: 'Mykel Draws' },
  { id: 'snapfix',  label: 'Mykel SnapFix' },
  { id: 'removebg', label: 'Remove Background' },
  { id: '3d',       label: 'Mykel 3D' },
  { id: 'edicode',  label: 'Mykel EdiCode' },
  { id: 'store',    label: 'Mykel Store' },
  { id: 'music',    label: 'Mykel Music' },
  { id: 'ia',       label: 'Mykel IA' },
  { id: 'search',   label: 'Mykel Search' },
  { id: 'chat',     label: 'Mykel Chat' },
];

export default function LogoSection() {
  const [customLogos, setCustomLogos] = useState({});
  const [pendingLogos, setPendingLogos] = useState({}); // { id: url | null }
  const [uploadingId, setUploadingId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const fileRefs = useRef({});

  useEffect(() => {
    loadLogos();
  }, []);

  const loadLogos = async () => {
    try {
      const results = await base44.entities.AppSettings.filter({ key: 'custom_logos' });
      if (results.length > 0 && results[0].value) {
        setCustomLogos(JSON.parse(results[0].value));
      } else {
        setCustomLogos({});
      }
    } catch {
      setCustomLogos({});
    } finally {
      setLoading(false);
    }
  };

  const handleImport = async (e, appId) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingId(appId);
    try {
      const { file_url } = await uploadMedia(file);
      setPendingLogos(prev => ({ ...prev, [appId]: file_url }));
      toast.success(`Logo importé pour ${ALL_APPS.find(a => a.id === appId)?.label}`);
    } catch {
      toast.error('Erreur upload');
    } finally {
      setUploadingId(null);
      e.target.value = '';
    }
  };

  const handleReset = (appId) => {
    setPendingLogos(prev => ({ ...prev, [appId]: null }));
    toast.success(`Logo réinitialisé pour ${ALL_APPS.find(a => a.id === appId)?.label}`);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Merge pending changes into current logos
      const merged = { ...customLogos };
      for (const [id, url] of Object.entries(pendingLogos)) {
        if (url === null) {
          delete merged[id];
        } else {
          merged[id] = url;
        }
      }

      // Save to AppSettings
      const existing = await base44.entities.AppSettings.filter({ key: 'custom_logos' }).catch(() => []);
      if (existing.length > 0) {
        await base44.entities.AppSettings.update(existing[0].id, { key: 'custom_logos', value: JSON.stringify(merged) });
      } else {
        await base44.entities.AppSettings.create({ key: 'custom_logos', value: JSON.stringify(merged) });
      }

      setCustomLogos(merged);
      setPendingLogos({});
      await reloadCustomLogos();
      toast.success('Logos enregistrés avec succès');
    } catch {
      toast.error('Erreur lors de l\'enregistrement');
    } finally {
      setSaving(false);
    }
  };

  const getEffectiveLogo = (appId) => {
    if (appId in pendingLogos) return pendingLogos[appId];
    return customLogos[appId] || null;
  };

  const hasPendingChanges = Object.keys(pendingLogos).length > 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Logos des logiciels et apps</h2>
          <p className="text-sm text-gray-500 mt-1">Importez un logo personnalisé ou réinitialisez vers le logo CSS par défaut.</p>
        </div>
        {hasPendingChanges && (
          <Button onClick={handleSave} disabled={saving} className="gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Enregistrer
          </Button>
        )}
      </div>

      <div className="space-y-3">
        {ALL_APPS.map(app => {
          const logo = getEffectiveLogo(app.id);
          const isPending = app.id in pendingLogos;
          return (
            <div
              key={app.id}
              className={`bg-white dark:bg-gray-900 rounded-xl border p-4 flex items-center gap-4 transition-all ${
                isPending ? 'border-amber-300 bg-amber-50/30' : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              {/* Preview */}
              <div className="flex-shrink-0">
                {logo ? (
                  <img
                    src={logo}
                    alt={app.label}
                    className="object-cover flex-shrink-0"
                    style={{ width: 48, height: 48, borderRadius: '23%' }}
                  />
                ) : (
                  <AppIcon id={app.id} size={48} />
                )}
              </div>

              {/* Label */}
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 dark:text-white">{app.label}</p>
                <p className="text-xs text-gray-500 mt-0.5">
                  {logo ? 'Logo personnalisé' : 'Logo CSS par défaut'}
                  {isPending && ' (modification en attente)'}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <label className="cursor-pointer">
                  <Button asChild size="sm" variant="outline" disabled={uploadingId === app.id} className="gap-1.5">
                    <span>
                      {uploadingId === app.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      Importer
                    </span>
                  </Button>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImport(e, app.id)}
                  />
                </label>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleReset(app.id)}
                  disabled={!logo && !isPending}
                  className="gap-1.5 text-gray-600"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Réinitialiser
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {hasPendingChanges && (
        <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Enregistrer toutes les modifications
        </Button>
      )}
    </div>
  );
}