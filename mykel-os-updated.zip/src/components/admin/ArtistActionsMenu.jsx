import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical, Users, Plus, CheckCircle, XCircle, UserX } from 'lucide-react';

export default function ArtistActionsMenu({ creator, onListeners, onPublish, onCertify, onRevoke }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const action = (fn) => { fn(); setOpen(false); };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(o => !o)}
        className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 transition-colors"
        title="Actions"
      >
        <MoreVertical className="w-4 h-4" />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 w-52 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 z-50 overflow-hidden">
          <button
            onClick={() => action(onListeners)}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-200 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors"
          >
            <Users className="w-4 h-4 text-purple-500" />
            Gérer les auditeurs
          </button>
          <button
            onClick={() => action(onPublish)}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
          >
            <Plus className="w-4 h-4 text-blue-500" />
            Publier un titre
          </button>
          <button
            onClick={() => action(onCertify)}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors"
          >
            {creator.certified
              ? <><XCircle className="w-4 h-4 text-orange-500" /><span className="text-orange-600 dark:text-orange-400">Retirer certification</span></>
              : <><CheckCircle className="w-4 h-4 text-green-500" /><span className="text-green-700 dark:text-green-400">Certifier l'artiste</span></>
            }
          </button>
          <div className="border-t border-gray-100 dark:border-gray-700" />
          <button
            onClick={() => action(onRevoke)}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
          >
            <UserX className="w-4 h-4" />
            Révoquer l'artiste
          </button>
        </div>
      )}
    </div>
  );
}