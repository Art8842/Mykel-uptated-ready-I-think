import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { confirmAction } from '@/lib/confirm';
import { Star, Trash2, Crown, Film, Tv, Loader2, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function TVSection() {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => { loadContent(); }, []);

  const loadContent = async () => {
    try {
      const data = await base44.entities.TVContent.filter({}, '-publish_date', 100);
      setContent(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const toggleFeatured = async (item) => {
    try {
      if (!item.is_featured) {
        // Unfeature all others first
        const featured = content.filter(c => c.is_featured);
        for (const c of featured) {
          await base44.entities.TVContent.update(c.id, { is_featured: false });
        }
      }
      await base44.entities.TVContent.update(item.id, { is_featured: !item.is_featured });
      toast.success(item.is_featured ? 'Retiré de la une' : 'Mis en avant sur la page d\'accueil');
      loadContent();
    } catch { toast.error('Erreur'); }
  };

  const deleteContent = async (item) => {
    if (!await confirmAction({ title: `Supprimer "${item.title}" ?`, message: 'Cela supprimera aussi tous les épisodes et pistes associées.', destructive: true })) return;
    try {
      // Delete episodes
      const episodes = await base44.entities.TVEpisode.filter({ content_id: item.id });
      for (const ep of episodes) await base44.entities.TVEpisode.delete(ep.id);
      // Delete media tracks
      const tracks = await base44.entities.TVMediaTrack.filter({ content_id: item.id });
      for (const t of tracks) await base44.entities.TVMediaTrack.delete(t.id);
      // Delete subtitles
      const subs = await base44.entities.TVSubtitle.filter({ content_id: item.id });
      for (const s of subs) await base44.entities.TVSubtitle.delete(s.id);
      // Delete content
      await base44.entities.TVContent.delete(item.id);
      toast.success('Contenu supprimé');
      loadContent();
    } catch { toast.error('Erreur'); }
  };

  const filtered = content.filter(c =>
    !search || c.title?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Mykel TV — Gestion du contenu</h2>
        <p className="text-sm text-gray-500 mt-1">Mettez en avant un film ou une série sur la page d'accueil, supprimez du contenu.</p>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher..." className="pl-9" />
      </div>

      {/* Featured content info */}
      <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
        <p className="text-sm text-blue-700 dark:text-blue-400 font-medium">
          ⭐ Contenu à la une : {content.find(c => c.is_featured)?.title || 'Aucun'}
        </p>
        <p className="text-xs text-blue-600 dark:text-blue-500 mt-1">Un seul contenu peut être mis en avant à la fois.</p>
      </div>

      {/* Content list */}
      <div className="space-y-3">
        {filtered.map(item => (
          <div key={item.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center gap-4">
            <img src={item.poster_url} alt={item.title} className="w-12 h-16 rounded-lg object-cover flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="font-medium text-gray-900 dark:text-white truncate">{item.title}</p>
                {item.content_type === 'movie'
                  ? <Film className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  : <Tv className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />}
                {item.is_exclusive_plus && (
                  <span className="px-1.5 py-0.5 bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 text-xs rounded-full flex items-center gap-0.5">
                    <Crown className="w-2.5 h-2.5" />+
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{item.genre || 'Sans genre'} · {item.creator_name || 'Inconnu'}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => toggleFeatured(item)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  item.is_featured
                    ? 'bg-yellow-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                <Star className="w-3.5 h-3.5 inline mr-1" />
                {item.is_featured ? 'À la une' : 'Mettre en avant'}
              </button>
              <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:text-red-600" onClick={() => deleteContent(item)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <Film className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p>Aucun contenu TV</p>
          </div>
        )}
      </div>
    </div>
  );
}