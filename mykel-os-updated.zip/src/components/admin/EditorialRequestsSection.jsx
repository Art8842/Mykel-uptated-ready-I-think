import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Check, X, Loader2, Clock, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function EditorialRequestsSection() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.EditorRequest.filter({}, '-created_date', 100);
      setRequests(list);
    } catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const decide = async (req, status) => {
    try {
      await base44.entities.EditorRequest.update(req.id, { status, reviewed_at: new Date().toISOString() });
      toast.success(status === 'approved' ? 'Éditeur approuvé' : 'Demande refusée');
      load();
    } catch { toast.error('Erreur'); }
  };

  const pending = requests.filter(r => r.status === 'pending');
  const decided = requests.filter(r => r.status !== 'pending');

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-1 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-500" /> Demandes éditeurs Mykel Music
        </h2>
        <p className="text-sm text-gray-500">Approuvez les utilisateurs qui pourront créer des playlists éditoriales.</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-purple-500" /></div>
      ) : pending.length === 0 && decided.length === 0 ? (
        <p className="text-gray-400 text-sm text-center py-8">Aucune demande pour le moment.</p>
      ) : (
        <>
          {pending.length > 0 && (
            <div className="space-y-3">
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2"><Clock className="w-4 h-4" /> En attente ({pending.length})</p>
              {pending.map(req => (
                <div key={req.id} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 dark:text-white">{req.user_name}</p>
                      <p className="text-xs text-gray-500">{req.user_email}</p>
                      {req.motivation && <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{req.motivation}</p>}
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button onClick={() => decide(req, 'approved')} className="w-9 h-9 rounded-lg bg-green-500 hover:bg-green-600 text-white flex items-center justify-center">
                        <Check className="w-4 h-4" />
                      </button>
                      <button onClick={() => decide(req, 'rejected')} className="w-9 h-9 rounded-lg bg-red-500 hover:bg-red-600 text-white flex items-center justify-center">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {decided.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Historique</p>
              {decided.map(req => (
                <div key={req.id} className="bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-3 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{req.user_name}</p>
                    <p className="text-xs text-gray-500">{req.user_email}</p>
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${req.status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {req.status === 'approved' ? 'Approuvé' : 'Refusé'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}