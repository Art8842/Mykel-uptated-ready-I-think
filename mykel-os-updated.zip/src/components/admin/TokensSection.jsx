import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, Plus, Minus, Loader2, Coins } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function TokensSection() {
  const [users, setUsers] = useState([]);
  const [tokensMap, setTokensMap] = useState({}); // email -> UserTokens record
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [adjustDialog, setAdjustDialog] = useState(null); // { user, record }
  const [amount, setAmount] = useState('');
  const [mode, setMode] = useState('add'); // 'add' | 'remove' | 'set'
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [userList, tokensList] = await Promise.all([
        base44.entities.User.list(),
        base44.entities.UserTokens.list(),
      ]);
      setUsers(userList);
      const map = {};
      tokensList.forEach(t => { map[t.user_email] = t; });
      setTokensMap(map);
    } catch (e) {
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!adjustDialog || !amount) return;
    const val = parseInt(amount);
    if (isNaN(val) || val < 0) { toast.error('Montant invalide'); return; }
    setSaving(true);
    try {
      const record = adjustDialog.record;
      const currentTokens = record?.tokens || 0;
      let newTokens;
      if (mode === 'add') newTokens = currentTokens + val;
      else if (mode === 'remove') newTokens = Math.max(0, currentTokens - val);
      else newTokens = val;

      if (record) {
        await base44.entities.UserTokens.update(record.id, { tokens: newTokens });
      } else {
        await base44.entities.UserTokens.create({ user_email: adjustDialog.user.email, tokens: newTokens });
      }
      toast.success(`Jetons mis à jour : ${newTokens} jetons pour ${adjustDialog.user.full_name || adjustDialog.user.email}`);
      setAdjustDialog(null);
      setAmount('');
      loadData();
    } catch {
      toast.error('Erreur lors de la mise à jour');
    } finally {
      setSaving(false);
    }
  };

  const filteredUsers = users.filter(u =>
    (u.full_name || '').toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return (
    <div className="flex items-center justify-center h-40">
      <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
    </div>
  );

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Gestion des Jetons</h2>
        <p className="text-sm text-gray-500 mt-1">Ajoutez ou retirez des jetons à n'importe quel utilisateur.</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          placeholder="Rechercher un utilisateur..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* User list */}
      <div className="space-y-2">
        {filteredUsers.map(u => {
          const record = tokensMap[u.email];
          const balance = record?.tokens ?? 0;
          return (
            <div key={u.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                  {(u.full_name || u.email)?.[0]?.toUpperCase()}
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-gray-900 dark:text-white truncate">{u.full_name || u.email}</p>
                  <p className="text-xs text-gray-500 truncate">{u.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-lg px-3 py-1.5">
                  <span className="text-sm">🪙</span>
                  <span className="font-bold text-amber-700 dark:text-amber-400 text-sm">{balance.toLocaleString()}</span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5"
                  onClick={() => { setAdjustDialog({ user: u, record }); setAmount(''); setMode('add'); }}
                >
                  <Coins className="w-3.5 h-3.5" />
                  Modifier
                </Button>
              </div>
            </div>
          );
        })}
        {filteredUsers.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <Coins className="w-10 h-10 mx-auto mb-3 text-gray-300" />
            <p>Aucun utilisateur trouvé</p>
          </div>
        )}
      </div>

      {/* Adjust Dialog */}
      {adjustDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-sm p-6">
            <h3 className="font-bold text-gray-900 dark:text-white text-lg mb-1">Modifier les jetons</h3>
            <p className="text-sm text-gray-500 mb-5">
              {adjustDialog.user.full_name || adjustDialog.user.email}
              {' · '}
              <span className="font-semibold text-amber-600">🪙 {(adjustDialog.record?.tokens ?? 0).toLocaleString()} jetons actuels</span>
            </p>

            {/* Mode */}
            <div className="flex gap-2 mb-4">
              {[
                { id: 'add', label: '+ Ajouter', color: 'bg-green-600 text-white' },
                { id: 'remove', label: '– Retirer', color: 'bg-red-600 text-white' },
                { id: 'set', label: '= Définir', color: 'bg-blue-600 text-white' },
              ].map(m => (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all border ${
                    mode === m.id
                      ? m.color + ' border-transparent'
                      : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <Input
              type="number"
              min="0"
              placeholder="Montant de jetons"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="mb-2"
              onKeyDown={e => e.key === 'Enter' && handleSave()}
            />

            {/* Preview */}
            {amount && !isNaN(parseInt(amount)) && (
              <p className="text-xs text-gray-500 mb-4">
                Résultat : <span className="font-bold text-amber-600">
                  {mode === 'add' && `🪙 ${((adjustDialog.record?.tokens ?? 0) + parseInt(amount)).toLocaleString()}`}
                  {mode === 'remove' && `🪙 ${Math.max(0, (adjustDialog.record?.tokens ?? 0) - parseInt(amount)).toLocaleString()}`}
                  {mode === 'set' && `🪙 ${parseInt(amount).toLocaleString()}`}
                </span> jetons
              </p>
            )}

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setAdjustDialog(null)}>
                Annuler
              </Button>
              <Button
                className="flex-1"
                onClick={handleSave}
                disabled={saving || !amount}
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Confirmer'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}