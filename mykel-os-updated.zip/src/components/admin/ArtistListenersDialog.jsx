import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Users } from 'lucide-react';
import { toast } from 'sonner';

function formatListeners(n) {
  if (!n) return '0';
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'Md';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}

export default function ArtistListenersDialog({ creator, open, onClose, onSaved }) {
  const [autoListeners, setAutoListeners] = useState(creator?.auto_listeners !== false);
  const [manualCount, setManualCount] = useState(creator?.monthly_listeners || 0);
  const [saving, setSaving] = useState(false);

  React.useEffect(() => {
    if (creator) {
      setAutoListeners(creator.auto_listeners !== false);
      setManualCount(creator.monthly_listeners || 0);
    }
  }, [creator]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.entities.MusicCreatorProfile.update(creator.id, {
        auto_listeners: autoListeners,
        monthly_listeners: autoListeners ? creator.monthly_listeners : Number(manualCount),
      });
      toast.success('Paramètres auditeurs sauvegardés');
      onSaved?.();
      onClose();
    } catch {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  if (!creator) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-white dark:bg-gray-900 max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-500" />
            Auditeurs mensuels — {creator.stage_name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Current count display */}
          <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl text-center">
            <p className="text-3xl font-bold text-purple-700 dark:text-purple-300">{formatListeners(creator.monthly_listeners || 0)}</p>
            <p className="text-sm text-purple-500 mt-1">auditeurs mensuels actuels</p>
          </div>

          {/* Auto toggle */}
          <div className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700">
            <input
              type="checkbox"
              id="auto_listeners"
              checked={autoListeners}
              onChange={e => setAutoListeners(e.target.checked)}
              className="w-4 h-4 accent-purple-500"
            />
            <label htmlFor="auto_listeners" className="text-sm text-gray-700 dark:text-gray-300 cursor-pointer flex-1">
              Changement des auditeurs mensuels automatique
            </label>
          </div>

          {/* Manual count input */}
          {!autoListeners && (
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Nombre d'auditeurs mensuels (manuel)
              </Label>
              <p className="text-xs text-gray-400">
                1 000 → 1k · 1 000 000 → 1M · 1 000 000 000 → 1Md
              </p>
              <Input
                type="number"
                min="0"
                value={manualCount}
                onChange={e => setManualCount(e.target.value)}
                placeholder="Ex: 1000"
                className="text-lg"
              />
              <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">
                Aperçu : {formatListeners(Number(manualCount))} auditeurs mensuels
              </p>
            </div>
          )}

          {autoListeners && (
            <p className="text-xs text-gray-500 italic">
              Le compteur s'incrémente automatiquement quand un utilisateur écoute au moins 3 titres de cet artiste dans le mois.
            </p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-purple-600 hover:bg-purple-700 text-white">
            {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            Sauvegarder les changements
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}