import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Loader2, Shield, AlertTriangle, Ban, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

function SanctionBadges({ sanctions }) {
  const active = sanctions.filter(s => s.active && (s.permanent || !s.banned_until || new Date(s.banned_until) > new Date()));
  if (active.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1">
      {active.map(s => (
        <Badge key={s.id} className={s.sanction_type === 'ban' ? 'bg-red-600 text-white text-xs' : 'bg-orange-500 text-white text-xs'}>
          {s.sanction_type === 'ban' ? '🚫 Banni' : '⚠️ Averti'}{s.scope === 'mykel_music' ? ' Music' : ''}
        </Badge>
      ))}
    </div>
  );
}

export default function SanctionSection() {
  const [users, setUsers] = useState([]);
  const [creators, setCreators] = useState([]);
  const [sanctions, setSanctions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [step, setStep] = useState(1);

  // Form state
  const [scope, setScope] = useState('platform');
  const [sanctionType, setSanctionType] = useState('ban');
  const [reason, setReason] = useState('');
  const [permanent, setPermanent] = useState(false);
  const [untilDate, setUntilDate] = useState('');
  const [untilTime, setUntilTime] = useState('');
  const [untilSecond, setUntilSecond] = useState('00');
  const [saving, setSaving] = useState(false);

  const [prevSanctionsForUser, setPrevSanctionsForUser] = useState([]);
  const [prevWarningDialog, setPrevWarningDialog] = useState(false);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [userList, creatorList, sanctionList] = await Promise.all([
        base44.entities.User.list(),
        base44.entities.MusicCreatorProfile.filter({ validated: true }),
        base44.entities.UserSanction.list(),
      ]);
      setUsers(userList);
      setCreators(creatorList);
      setSanctions(sanctionList);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const getUserSanctions = (email) => sanctions.filter(s => s.user_email === email && s.active);
  const getActiveSanctions = (email) => getUserSanctions(email).filter(s =>
    s.permanent || !s.banned_until || new Date(s.banned_until) > new Date()
  );

  const openDialog = (user) => {
    setSelectedUser(user);
    const prev = getActiveSanctions(user.email);
    if (prev.length > 0) {
      setPrevSanctionsForUser(prev);
      setPrevWarningDialog(true);
    } else {
      setPrevSanctionsForUser([]);
      openSanctionForm();
    }
  };

  const openSanctionForm = () => {
    setStep(1);
    setScope('platform');
    setSanctionType('ban');
    setReason('');
    setPermanent(false);
    setUntilDate('');
    setUntilTime('');
    setUntilSecond('00');
    setDialogOpen(true);
    setPrevWarningDialog(false);
  };

  const handleSave = async () => {
    if (!reason.trim()) { toast.error('Entrez une raison'); return; }
    if (!permanent && (!untilDate || !untilTime)) { toast.error('Sélectionnez une date/heure de fin ou bannissement définitif'); return; }
    setSaving(true);
    try {
      const bannedUntil = permanent ? null : `${untilDate}T${untilTime}:${untilSecond || '00'}`;
      await base44.entities.UserSanction.create({
        user_email: selectedUser.email,
        user_name: selectedUser.full_name || selectedUser.email,
        sanction_type: sanctionType,
        scope,
        reason,
        banned_until: bannedUntil,
        permanent: sanctionType === 'ban' ? permanent : false,
        active: true,
        user_acknowledged: false,
      });
      toast.success(sanctionType === 'ban' ? 'Utilisateur banni !' : 'Avertissement envoyé !');
      setDialogOpen(false);
      setSelectedUser(null);
      loadAll();
    } catch { toast.error('Erreur'); }
    finally { setSaving(false); }
  };

  const revokeSanction = async (sanction) => {
    try {
      await base44.entities.UserSanction.update(sanction.id, { active: false });
      toast.success('Sanction levée');
      // Small delay to avoid hitting rate limits
      await new Promise(r => setTimeout(r, 500));
      loadAll();
    } catch (e) {
      if (e?.message?.includes('Rate limit')) {
        toast.error('Trop de requêtes, réessayez dans quelques secondes.');
      } else {
        toast.error('Erreur lors de la révocation');
      }
    }
  };

  const getCreatorForUser = (email) => creators.find(c => c.user_email === email);

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Avertissements, Signalements & Bannissements</h2>
        <p className="text-sm text-gray-500 mt-1">Gérez les sanctions des utilisateurs de la plateforme.</p>
      </div>

      <div className="space-y-3">
        {users.map(user => {
          const activeSanctions = getActiveSanctions(user.email);
          const creator = getCreatorForUser(user.email);
          return (
            <div key={user.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                    {(user.full_name || user.email)?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white text-sm">{user.full_name || user.email}</p>
                    <p className="text-xs text-gray-500">{user.email}</p>
                    {creator && (
                      <span className="text-xs text-purple-600 dark:text-purple-400">🎵 Artiste: {creator.stage_name}</span>
                    )}
                    {activeSanctions.length > 0 && (
                      <div className="mt-1">
                        <SanctionBadges sanctions={activeSanctions} />
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {activeSanctions.map(s => (
                    <Button key={s.id} size="sm" variant="outline" className="text-xs text-gray-500 h-7" onClick={() => revokeSanction(s)}>
                      Lever {s.sanction_type === 'ban' ? 'le ban' : "l'avertissement"}
                    </Button>
                  ))}
                  <Button size="sm" className="bg-orange-500 hover:bg-orange-600 text-white h-8 text-xs gap-1" onClick={() => openDialog(user)}>
                    <AlertTriangle className="w-3 h-3" />
                    Sanctionner
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Previous sanctions warning */}
      <Dialog open={prevWarningDialog} onOpenChange={setPrevWarningDialog}>
        <DialogContent className="bg-white dark:bg-gray-900 max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-orange-500">⚠️ Sanctions existantes</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <p className="text-sm text-gray-700 dark:text-gray-300">Cet utilisateur a déjà été sanctionné :</p>
            {prevSanctionsForUser.map(s => (
              <div key={s.id} className="p-3 rounded-lg bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-700 text-sm">
                <p className="font-medium text-orange-700 dark:text-orange-300">
                  {s.sanction_type === 'ban' ? '🚫 Banni' : '⚠️ Averti'} — {s.scope === 'platform' ? 'Plateforme' : 'Mykel Music'}
                </p>
                <p className="text-orange-600 dark:text-orange-400 mt-1">Raison : {s.reason}</p>
                {s.banned_until && <p className="text-orange-500 text-xs mt-1">Jusqu'au {new Date(s.banned_until).toLocaleString('fr-FR')}</p>}
                {s.permanent && <p className="text-red-500 text-xs mt-1">Définitif</p>}
              </div>
            ))}
          </div>
          <DialogFooter className="flex gap-2">
            <Button variant="outline" onClick={() => setPrevWarningDialog(false)}>Annuler</Button>
            <Button className="bg-orange-500 hover:bg-orange-600 text-white" onClick={openSanctionForm}>
              Ajouter quand même
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sanction wizard */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-white dark:bg-gray-900 max-w-sm">
          <DialogHeader>
            <DialogTitle>
              Sanctionner — {selectedUser?.full_name || selectedUser?.email}
            </DialogTitle>
          </DialogHeader>

          {/* Step 1: scope + type */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Type de sanction</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <button onClick={() => setSanctionType('ban')} className={`p-3 rounded-xl border text-sm font-medium transition-all ${sanctionType === 'ban' ? 'border-red-500 bg-red-50 dark:bg-red-900/20 text-red-600' : 'border-gray-200 dark:border-gray-700'}`}>
                    🚫 Bannissement
                  </button>
                  <button onClick={() => setSanctionType('warning')} className={`p-3 rounded-xl border text-sm font-medium transition-all ${sanctionType === 'warning' ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20 text-orange-600' : 'border-gray-200 dark:border-gray-700'}`}>
                    ⚠️ Avertissement
                  </button>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">Portée</Label>
                <div className="space-y-2 mt-2">
                  <button onClick={() => setScope('platform')} className={`w-full p-3 rounded-xl border text-sm text-left transition-all ${scope === 'platform' ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-700'}`}>
                    🌐 Toute la plateforme Mykel
                  </button>
                  <button onClick={() => setScope('mykel_music')} className={`w-full p-3 rounded-xl border text-sm text-left transition-all ${scope === 'mykel_music' ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20' : 'border-gray-200 dark:border-gray-700'}`}>
                    🎵 Uniquement Mykel Music
                  </button>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
                <Button onClick={() => setStep(2)} className="gap-1">Suivant <ChevronRight className="w-4 h-4" /></Button>
              </DialogFooter>
            </div>
          )}

          {/* Step 2: reason */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Raison de la sanction</Label>
                <Textarea
                  className="mt-2"
                  rows={4}
                  placeholder="Décrivez la raison précise de la sanction..."
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setStep(1)}>Retour</Button>
                <Button onClick={() => setStep(3)} disabled={!reason.trim()} className="gap-1">Suivant <ChevronRight className="w-4 h-4" /></Button>
              </DialogFooter>
            </div>
          )}

          {/* Step 3: duration (only for ban) */}
          {step === 3 && (
            <div className="space-y-4">
              {sanctionType === 'ban' && (
                <>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Durée du bannissement</p>
                  <div className="flex items-center gap-3 p-3 rounded-xl border border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/10">
                    <input type="checkbox" id="permanent" checked={permanent} onChange={e => setPermanent(e.target.checked)} className="w-4 h-4 accent-red-500" />
                    <label htmlFor="permanent" className="text-sm text-red-600 dark:text-red-400 font-medium cursor-pointer">
                      🚫 Bannir définitivement (aucun bouton pour ouvrir Mykel)
                    </label>
                  </div>
                  {!permanent && (
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-500">Jusqu'à (date & heure précise)</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Input type="date" value={untilDate} onChange={e => setUntilDate(e.target.value)} className="text-sm" />
                        <Input type="time" value={untilTime} onChange={e => setUntilTime(e.target.value)} className="text-sm" />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="text-xs text-gray-500 whitespace-nowrap">Secondes :</Label>
                        <Input type="number" min="0" max="59" value={untilSecond} onChange={e => setUntilSecond(e.target.value.padStart(2,'0'))} className="w-20 text-sm" />
                      </div>
                    </div>
                  )}
                </>
              )}
              {sanctionType === 'warning' && (
                <div className="p-4 bg-orange-50 dark:bg-orange-900/10 rounded-xl border border-orange-200 dark:border-orange-700 text-sm text-orange-700 dark:text-orange-300">
                  ⚠️ Un avertissement permet quand même d'utiliser Mykel. L'utilisateur verra un message à sa prochaine connexion.
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setStep(2)}>Retour</Button>
                <Button
                  onClick={handleSave}
                  disabled={saving || (sanctionType === 'ban' && !permanent && (!untilDate || !untilTime))}
                  className={sanctionType === 'ban' ? 'bg-red-600 hover:bg-red-700 text-white' : 'bg-orange-500 hover:bg-orange-600 text-white'}
                >
                  {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  {sanctionType === 'ban' ? '🚫 Bannir' : '⚠️ Avertir'}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}