import { callAI as callAIFree } from '@/lib/freeCore';

export const callAI = callAIFree;

export const callAIText = async (prompt, systemPrompt = '') => {
  const messages = [
    ...(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []),
    { role: 'user', content: prompt },
  ];
  return callAIFree({ messages });
};