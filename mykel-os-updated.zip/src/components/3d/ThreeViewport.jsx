import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js';

function createGeometry(shape) {
  switch (shape) {
    case 'sphere': return new THREE.SphereGeometry(0.5, 32, 32);
    case 'cylinder': return new THREE.CylinderGeometry(0.5, 0.5, 1, 32);
    case 'plane': return new THREE.PlaneGeometry(2, 2);
    case 'torus': return new THREE.TorusGeometry(0.5, 0.2, 16, 100);
    case 'cone': return new THREE.ConeGeometry(0.5, 1, 32);
    case 'capsule': return new THREE.CapsuleGeometry(0.3, 0.6, 8, 16);
    default: return new THREE.BoxGeometry(1, 1, 1);
  }
}

export default function ThreeViewport({ objects, selectedId, onSelect, onObjectUpdate, transformMode = 'translate' }) {
  const mountRef = useRef(null);
  const stateRef = useRef({
    scene: null, renderer: null, camera: null,
    orbit: null, transform: null,
    meshMap: {}, animFrame: null,
    isDragging: false,
    clickStart: { x: 0, y: 0 },
  });

  // Stable callback refs to avoid re-wiring Three.js listeners
  const onSelectRef = useRef(onSelect);
  const onObjectUpdateRef = useRef(onObjectUpdate);
  useEffect(() => { onSelectRef.current = onSelect; }, [onSelect]);
  useEffect(() => { onObjectUpdateRef.current = onObjectUpdate; }, [onObjectUpdate]);

  // Initialize Three.js once
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const s = stateRef.current;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);
    scene.fog = new THREE.Fog(0x1a1a2e, 30, 100);
    s.scene = scene;

    const camera = new THREE.PerspectiveCamera(60, mount.clientWidth / mount.clientHeight, 0.1, 1000);
    camera.position.set(4, 4, 4);
    s.camera = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);
    s.renderer = renderer;

    // Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambient);
    const dirLight = new THREE.DirectionalLight(0xffffff, 1);
    dirLight.position.set(5, 10, 7);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);
    const fillLight = new THREE.DirectionalLight(0x8888ff, 0.3);
    fillLight.position.set(-5, 2, -5);
    scene.add(fillLight);

    // Grid
    const grid = new THREE.GridHelper(30, 30, 0x333355, 0x222244);
    scene.add(grid);

    // Axes (small, at origin)
    const axes = new THREE.AxesHelper(1.5);
    scene.add(axes);

    // OrbitControls
    const orbit = new OrbitControls(camera, renderer.domElement);
    orbit.enableDamping = true;
    orbit.dampingFactor = 0.07;
    orbit.minDistance = 1;
    orbit.maxDistance = 100;
    s.orbit = orbit;

    // TransformControls
    const transform = new TransformControls(camera, renderer.domElement);
    transform.setSize(0.8);
    transform.addEventListener('dragging-changed', (e) => {
      orbit.enabled = !e.value;
      s.isDragging = e.value;
    });
    transform.addEventListener('mouseUp', () => {
      const obj = transform.object;
      if (obj && onObjectUpdateRef.current) {
        onObjectUpdateRef.current(obj.userData.id, {
          position: { x: +obj.position.x.toFixed(3), y: +obj.position.y.toFixed(3), z: +obj.position.z.toFixed(3) },
          rotation: {
            x: +THREE.MathUtils.radToDeg(obj.rotation.x).toFixed(1),
            y: +THREE.MathUtils.radToDeg(obj.rotation.y).toFixed(1),
            z: +THREE.MathUtils.radToDeg(obj.rotation.z).toFixed(1),
          },
          scale: { x: +obj.scale.x.toFixed(3), y: +obj.scale.y.toFixed(3), z: +obj.scale.z.toFixed(3) },
        });
      }
    });
    scene.add(transform);
    s.transform = transform;

    // Click selection
    const raycaster = new THREE.Raycaster();
    renderer.domElement.addEventListener('mousedown', (e) => {
      s.clickStart = { x: e.clientX, y: e.clientY };
    });
    renderer.domElement.addEventListener('mouseup', (e) => {
      const dist = Math.hypot(e.clientX - s.clickStart.x, e.clientY - s.clickStart.y);
      if (dist > 5 || s.isDragging) return;
      const rect = mount.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );
      raycaster.setFromCamera(mouse, camera);
      const meshes = Object.values(s.meshMap);
      const hits = raycaster.intersectObjects(meshes, false);
      if (hits.length > 0) {
        onSelectRef.current(hits[0].object.userData.id);
      } else {
        onSelectRef.current(null);
      }
    });

    // Animate
    const animate = () => {
      s.animFrame = requestAnimationFrame(animate);
      orbit.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const onResize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(s.animFrame);
      window.removeEventListener('resize', onResize);
      transform.dispose();
      orbit.dispose();
      Object.values(s.meshMap).forEach(m => { m.geometry.dispose(); m.material.dispose(); });
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, []);

  // Sync objects → Three.js scene
  useEffect(() => {
    const s = stateRef.current;
    if (!s.scene) return;

    const currentIds = new Set(objects.map(o => o.id));
    // Remove deleted
    Object.keys(s.meshMap).forEach(id => {
      if (!currentIds.has(id)) {
        s.scene.remove(s.meshMap[id]);
        s.meshMap[id].geometry.dispose();
        s.meshMap[id].material.dispose();
        delete s.meshMap[id];
      }
    });

    objects.forEach(obj => {
      if (!s.meshMap[obj.id]) {
        // Create new mesh
        const geo = createGeometry(obj.shape);
        const mat = new THREE.MeshStandardMaterial({ color: obj.color || '#4488ff', roughness: 0.4, metalness: 0.1 });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData.id = obj.id;
        mesh.position.set(obj.position.x, obj.position.y, obj.position.z);
        mesh.rotation.set(
          THREE.MathUtils.degToRad(obj.rotation.x),
          THREE.MathUtils.degToRad(obj.rotation.y),
          THREE.MathUtils.degToRad(obj.rotation.z)
        );
        mesh.scale.set(obj.scale.x, obj.scale.y, obj.scale.z);
        s.scene.add(mesh);
        s.meshMap[obj.id] = mesh;
      } else if (!s.isDragging) {
        // Update existing (only if not dragging - don't fight TransformControls)
        const mesh = s.meshMap[obj.id];
        mesh.position.set(obj.position.x, obj.position.y, obj.position.z);
        mesh.rotation.set(
          THREE.MathUtils.degToRad(obj.rotation.x),
          THREE.MathUtils.degToRad(obj.rotation.y),
          THREE.MathUtils.degToRad(obj.rotation.z)
        );
        mesh.scale.set(obj.scale.x, obj.scale.y, obj.scale.z);
        mesh.material.color.set(obj.color || '#4488ff');
        mesh.material.wireframe = obj.wireframe || false;
      }
    });
  }, [objects]);

  // Sync selected object → TransformControls
  useEffect(() => {
    const s = stateRef.current;
    if (!s.transform) return;
    if (selectedId && s.meshMap[selectedId]) {
      s.transform.attach(s.meshMap[selectedId]);
    } else {
      s.transform.detach();
    }
  }, [selectedId]);

  // Sync transform mode
  useEffect(() => {
    const s = stateRef.current;
    if (s.transform) s.transform.setMode(transformMode);
  }, [transformMode]);

  return <div ref={mountRef} className="w-full h-full" />;
}