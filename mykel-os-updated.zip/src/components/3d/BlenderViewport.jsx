import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

function createGeometry(shape) {
  switch (shape) {
    case 'sphere': return new THREE.SphereGeometry(1, 32, 32);
    case 'cylinder': return new THREE.CylinderGeometry(0.5, 0.5, 2, 32);
    case 'plane': return new THREE.PlaneGeometry(2, 2);
    case 'torus': return new THREE.TorusGeometry(1, 0.4, 16, 100);
    case 'cone': return new THREE.ConeGeometry(0.5, 2, 32);
    case 'capsule': return new THREE.CapsuleGeometry(0.5, 1, 8, 16);
    case 'icosphere': return new THREE.IcosahedronGeometry(1, 2);
    case 'circle': return new THREE.CircleGeometry(1, 32);
    case 'torusknot': return new THREE.TorusKnotGeometry(0.8, 0.25, 100, 16);
    case 'light_point':
    case 'light_sun':
    case 'light_spot': return new THREE.SphereGeometry(0.15, 8, 8);
    case 'camera': return new THREE.ConeGeometry(0.2, 0.4, 4);
    case 'empty': return new THREE.OctahedronGeometry(0.1);
    default: return new THREE.BoxGeometry(1, 1, 1);
  }
}

function makeMaterial(obj, shadingMode) {
  const { shape, color, metalness, roughness, emission, emissionStrength, alpha } = obj;
  if (shape === 'light_point' || shape === 'light_sun' || shape === 'light_spot')
    return new THREE.MeshBasicMaterial({ color: 0xffee44 });
  if (shape === 'camera')
    return new THREE.MeshBasicMaterial({ color: 0x8888ff, wireframe: true });
  if (shape === 'empty')
    return new THREE.MeshBasicMaterial({ color: 0xffffff });

  const mat = new THREE.MeshStandardMaterial({
    color: color || '#b0b0b0',
    metalness: metalness ?? 0,
    roughness: roughness ?? 0.5,
    wireframe: shadingMode === 'wireframe',
    transparent: (alpha ?? 1) < 1,
    opacity: alpha ?? 1,
  });
  if (emission && emissionStrength > 0) {
    mat.emissive = new THREE.Color(emission);
    mat.emissiveIntensity = emissionStrength;
  }
  return mat;
}

export default function BlenderViewport({ objects, selectedId, onSelect, onObjectUpdate, shadingMode, editMode, editSubMode, onKeyAction }) {
  const mountRef = useRef(null);
  const [transformInfo, setTransformInfo] = useState(null);
  const setTI = useRef(setTransformInfo);

  // Mutable state ref (Three.js state)
  const s = useRef({
    scene: null, renderer: null, camera: null,
    meshMap: {}, selectionOutline: null, selectedMesh: null, animFrame: null,
    isMMBDown: false, isShiftDown: false,
    cameraTarget: new THREE.Vector3(0, 0, 0),
    lastMouse: { x: 0, y: 0 }, currentMouse: { x: 0, y: 0 },
    clickStart: { x: 0, y: 0 }, isDragging: false,
    transformState: null,
  }).current;

  const onSelectRef = useRef(onSelect);
  const onObjectUpdateRef = useRef(onObjectUpdate);
  const onKeyActionRef = useRef(onKeyAction);
  useEffect(() => { onSelectRef.current = onSelect; }, [onSelect]);
  useEffect(() => { onObjectUpdateRef.current = onObjectUpdate; }, [onObjectUpdate]);
  useEffect(() => { onKeyActionRef.current = onKeyAction; }, [onKeyAction]);

  // ── Initialize Three.js ──────────────────────────────────────────────────
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x393939);
    s.scene = scene;

    const camera = new THREE.PerspectiveCamera(60, mount.clientWidth / mount.clientHeight, 0.001, 1000);
    camera.position.set(7, 5, 7);
    camera.lookAt(0, 0, 0);
    s.camera = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);
    s.renderer = renderer;

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    const sun = new THREE.DirectionalLight(0xffffff, 1.5);
    sun.position.set(5, 8, 5);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    scene.add(sun);
    const fill = new THREE.DirectionalLight(0x6688aa, 0.4);
    fill.position.set(-4, 2, -4);
    scene.add(fill);

    // Grid + center axes
    scene.add(new THREE.GridHelper(20, 20, 0x4a4a4a, 0x333333));
    const mkLine = (a, b, color) => {
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...a), new THREE.Vector3(...b)]);
      scene.add(new THREE.Line(geo, new THREE.LineBasicMaterial({ color })));
    };
    mkLine([-10, 0, 0], [10, 0, 0], 0x883333);
    mkLine([0, 0, -10], [0, 0, 10], 0x338833);

    // ── Camera helpers ────────────────────────────────────────────────────
    const getSpherical = () => {
      const off = new THREE.Vector3().subVectors(camera.position, s.cameraTarget);
      return new THREE.Spherical().setFromVector3(off);
    };
    const orbit = (dTheta, dPhi) => {
      const sp = getSpherical();
      sp.theta += dTheta;
      sp.phi = THREE.MathUtils.clamp(sp.phi + dPhi, 0.02, Math.PI - 0.02);
      camera.position.copy(s.cameraTarget).add(new THREE.Vector3().setFromSpherical(sp));
      camera.lookAt(s.cameraTarget);
    };
    const pan = (dx, dy) => {
      const f = camera.position.distanceTo(s.cameraTarget) * 0.001;
      const right = new THREE.Vector3().crossVectors(camera.getWorldDirection(new THREE.Vector3()), camera.up).normalize();
      s.cameraTarget.addScaledVector(right, -dx * f).addScaledVector(camera.up, dy * f);
      camera.position.addScaledVector(right, -dx * f).addScaledVector(camera.up, dy * f);
    };
    const zoom = (f) => {
      const off = new THREE.Vector3().subVectors(camera.position, s.cameraTarget);
      const len = THREE.MathUtils.clamp(off.length() * f, 0.05, 500);
      camera.position.copy(s.cameraTarget).add(off.setLength(len));
    };
    const setView = (v) => {
      const d = camera.position.distanceTo(s.cameraTarget);
      const t = s.cameraTarget;
      const p = { front:[t.x,t.y,t.z+d], back:[t.x,t.y,t.z-d], right:[t.x+d,t.y,t.z], left:[t.x-d,t.y,t.z], top:[t.x,t.y+d,t.z], bottom:[t.x,t.y-d,t.z] }[v];
      if (p) { camera.position.set(...p); camera.lookAt(s.cameraTarget); }
    };
    const focusSelected = () => {
      if (!s.selectedMesh) return;
      s.cameraTarget.copy(s.selectedMesh.position);
      camera.lookAt(s.cameraTarget);
    };

    // ── Unproject ─────────────────────────────────────────────────────────
    const unproject = (x, y, depth) => {
      const rect = mount.getBoundingClientRect();
      return new THREE.Vector3(
        ((x - rect.left) / rect.width) * 2 - 1,
        -((y - rect.top) / rect.height) * 2 + 1,
        depth
      ).unproject(camera);
    };

    // ── Transform system ─────────────────────────────────────────────────
    const startTransform = (mode) => {
      if (!s.selectedMesh) return;
      const mesh = s.selectedMesh;
      const objNDC = mesh.position.clone().project(camera);
      s.transformState = {
        mode, axis: null, value: '', negative: false,
        startMouse: { ...s.currentMouse },
        originalPos: mesh.position.clone(),
        originalRot: mesh.rotation.clone(),
        originalQuat: mesh.quaternion.clone(),
        originalScale: mesh.scale.clone(),
        objectId: mesh.userData.id,
        objectDepth: objNDC.z,
      };
      setTI.current({ mode, axis: null, value: '', negative: false });
    };

    const applyTransform = (mx, my) => {
      const ts = s.transformState;
      if (!ts || !s.selectedMesh) return;
      const mesh = s.selectedMesh;

      if (ts.mode === 'translate') {
        const startW = unproject(ts.startMouse.x, ts.startMouse.y, ts.objectDepth);
        const currW = unproject(mx, my, ts.objectDepth);
        const delta = new THREE.Vector3().subVectors(currW, startW);
        mesh.position.copy(ts.originalPos);

        if (ts.value) {
          const val = parseFloat(ts.value) * (ts.negative ? -1 : 1);
          if (!isNaN(val)) {
            if (ts.axis === 'X') mesh.position.x = ts.originalPos.x + val;
            else if (ts.axis === 'Y') mesh.position.y = ts.originalPos.y + val;
            else if (ts.axis === 'Z') mesh.position.z = ts.originalPos.z + val;
            setTI.current({ ...ts }); return;
          }
        }

        if (!ts.axis) mesh.position.add(delta);
        else if (ts.axis === 'X') mesh.position.x = ts.originalPos.x + delta.x;
        else if (ts.axis === 'Y') mesh.position.y = ts.originalPos.y + delta.y;
        else if (ts.axis === 'Z') mesh.position.z = ts.originalPos.z + delta.z;
        else if (ts.axis === 'YZ') { mesh.position.y = ts.originalPos.y + delta.y; mesh.position.z = ts.originalPos.z + delta.z; }
        else if (ts.axis === 'XZ') { mesh.position.x = ts.originalPos.x + delta.x; mesh.position.z = ts.originalPos.z + delta.z; }
        else if (ts.axis === 'XY') { mesh.position.x = ts.originalPos.x + delta.x; mesh.position.y = ts.originalPos.y + delta.y; }

      } else if (ts.mode === 'rotate') {
        const rect = mount.getBoundingClientRect();
        const ndc = ts.originalPos.clone().project(camera);
        const cx = ((ndc.x + 1) / 2) * rect.width + rect.left;
        const cy = ((-ndc.y + 1) / 2) * rect.height + rect.top;
        let angle = Math.atan2(my - cy, mx - cx) - Math.atan2(ts.startMouse.y - cy, ts.startMouse.x - cx);

        if (ts.value) {
          const val = THREE.MathUtils.degToRad(parseFloat(ts.value) * (ts.negative ? -1 : 1));
          if (!isNaN(val)) angle = val;
        }

        mesh.quaternion.copy(ts.originalQuat);
        const axis = ts.axis === 'X' ? new THREE.Vector3(1,0,0) :
                     ts.axis === 'Y' ? new THREE.Vector3(0,1,0) :
                     ts.axis === 'Z' ? new THREE.Vector3(0,0,1) :
                     camera.getWorldDirection(new THREE.Vector3());
        mesh.rotateOnWorldAxis(axis, angle);

      } else if (ts.mode === 'scale') {
        const rect = mount.getBoundingClientRect();
        const ndc = ts.originalPos.clone().project(camera);
        const cx = ((ndc.x + 1) / 2) * rect.width + rect.left;
        const cy = ((-ndc.y + 1) / 2) * rect.height + rect.top;
        const sd = Math.hypot(ts.startMouse.x - cx, ts.startMouse.y - cy) || 1;
        let factor = Math.hypot(mx - cx, my - cy) / sd;

        if (ts.value) {
          const val = parseFloat(ts.value) * (ts.negative ? -1 : 1);
          if (!isNaN(val)) factor = val;
        }

        mesh.scale.copy(ts.originalScale);
        if (!ts.axis) mesh.scale.multiplyScalar(factor);
        else if (ts.axis === 'X') mesh.scale.x = ts.originalScale.x * factor;
        else if (ts.axis === 'Y') mesh.scale.y = ts.originalScale.y * factor;
        else if (ts.axis === 'Z') mesh.scale.z = ts.originalScale.z * factor;
      }

      setTI.current({ ...ts });
    };

    const confirmTransform = () => {
      const ts = s.transformState;
      s.transformState = null;
      setTI.current(null);
      if (!ts || !s.selectedMesh) return;
      const mesh = s.selectedMesh;
      const euler = new THREE.Euler().setFromQuaternion(mesh.quaternion, 'XYZ');
      onObjectUpdateRef.current?.(ts.objectId, {
        position: { x: +mesh.position.x.toFixed(4), y: +mesh.position.y.toFixed(4), z: +mesh.position.z.toFixed(4) },
        rotation: {
          x: +THREE.MathUtils.radToDeg(euler.x).toFixed(3),
          y: +THREE.MathUtils.radToDeg(euler.y).toFixed(3),
          z: +THREE.MathUtils.radToDeg(euler.z).toFixed(3),
        },
        scale: { x: +mesh.scale.x.toFixed(4), y: +mesh.scale.y.toFixed(4), z: +mesh.scale.z.toFixed(4) },
      });
    };

    const cancelTransform = () => {
      const ts = s.transformState;
      s.transformState = null;
      setTI.current(null);
      if (!ts || !s.selectedMesh) return;
      s.selectedMesh.position.copy(ts.originalPos);
      s.selectedMesh.rotation.copy(ts.originalRot);
      s.selectedMesh.scale.copy(ts.originalScale);
    };

    // ── Selection ─────────────────────────────────────────────────────────
    const clickSelect = (e) => {
      const rect = mount.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );
      const rc = new THREE.Raycaster();
      rc.setFromCamera(mouse, camera);
      const meshes = Object.values(s.meshMap).filter(m => m.userData.isObject && m.visible);
      const hits = rc.intersectObjects(meshes, false);
      onSelectRef.current?.(hits.length > 0 ? hits[0].object.userData.id : null);
    };

    // ── Keyboard ─────────────────────────────────────────────────────────
    const onKeyDown = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
      s.isShiftDown = e.shiftKey;

      if (s.transformState) {
        const k = e.key;
        if (k === 'Escape') { e.preventDefault(); cancelTransform(); return; }
        if (k === 'Enter') { e.preventDefault(); confirmTransform(); return; }
        if (k === 'x' || k === 'X') { s.transformState.axis = e.shiftKey ? 'YZ' : 'X'; applyTransform(s.currentMouse.x, s.currentMouse.y); return; }
        if (k === 'y' || k === 'Y') { s.transformState.axis = e.shiftKey ? 'XZ' : 'Y'; applyTransform(s.currentMouse.x, s.currentMouse.y); return; }
        if (k === 'z' || k === 'Z') { s.transformState.axis = e.shiftKey ? 'XY' : 'Z'; applyTransform(s.currentMouse.x, s.currentMouse.y); return; }
        if (k === '-') { s.transformState.negative = !s.transformState.negative; applyTransform(s.currentMouse.x, s.currentMouse.y); return; }
        if (k === 'Backspace') { s.transformState.value = s.transformState.value.slice(0, -1); applyTransform(s.currentMouse.x, s.currentMouse.y); return; }
        if (/^[0-9\.]$/.test(k)) { s.transformState.value += k; applyTransform(s.currentMouse.x, s.currentMouse.y); return; }
        return;
      }

      const k = e.key;
      // Views
      if (k === '1' && !e.ctrlKey && !e.shiftKey) { e.preventDefault(); setView('front'); }
      if (k === '3' && !e.ctrlKey && !e.shiftKey) { e.preventDefault(); setView('right'); }
      if (k === '7' && !e.ctrlKey && !e.shiftKey) { e.preventDefault(); setView('top'); }
      if (k === '1' && e.ctrlKey) { e.preventDefault(); setView('back'); }
      if (k === '3' && e.ctrlKey) { e.preventDefault(); setView('left'); }
      if (k === '7' && e.ctrlKey) { e.preventDefault(); setView('bottom'); }
      if (k === '4') { e.preventDefault(); orbit(-0.2, 0); }
      if (k === '6') { e.preventDefault(); orbit(0.2, 0); }
      if (k === '8') { e.preventDefault(); orbit(0, -0.2); }
      if (k === '2') { e.preventDefault(); orbit(0, 0.2); }
      if (k === '+') { e.preventDefault(); zoom(0.85); }

      // Transform
      if (k === 'g' || k === 'G') { e.preventDefault(); startTransform('translate'); }
      if (k === 'r' || k === 'R') { e.preventDefault(); startTransform('rotate'); }
      if (k === 's' || k === 'S') { e.preventDefault(); startTransform('scale'); }

      // Focus
      if (k === 'f' || k === 'F') { e.preventDefault(); focusSelected(); }

      // Delegate
      if (k === 'x' || k === 'X' || k === 'Delete') { e.preventDefault(); onKeyActionRef.current?.('delete'); }
      if ((k === 'd' || k === 'D') && e.shiftKey) { e.preventDefault(); onKeyActionRef.current?.('duplicate'); }
      if ((k === 'a' || k === 'A') && e.shiftKey) { e.preventDefault(); onKeyActionRef.current?.('addMenu'); }
      if ((k === 'a' || k === 'A') && !e.shiftKey && !e.ctrlKey) { e.preventDefault(); onKeyActionRef.current?.('selectAll'); }
      if ((k === 'z' || k === 'Z') && e.ctrlKey && !e.shiftKey) { e.preventDefault(); onKeyActionRef.current?.('undo'); }
      if (k === 'Z' && e.ctrlKey && e.shiftKey) { e.preventDefault(); onKeyActionRef.current?.('redo'); }
      if (k === 'Tab') { e.preventDefault(); onKeyActionRef.current?.('toggleEditMode'); }
      if (k === 'h' || k === 'H') { onKeyActionRef.current?.('hide'); }
      if (k === 'n' || k === 'N') { e.preventDefault(); onKeyActionRef.current?.('toggleNPanel'); }
    };

    const onKeyUp = (e) => { s.isShiftDown = e.shiftKey; };

    // ── Mouse events ─────────────────────────────────────────────────────
    const onMouseDown = (e) => {
      s.clickStart = { x: e.clientX, y: e.clientY };
      s.isDragging = false;
      if (e.button === 1) { e.preventDefault(); s.isMMBDown = true; }
    };

    const onMouseMove = (e) => {
      s.currentMouse = { x: e.clientX, y: e.clientY };
      const dx = e.clientX - s.lastMouse.x;
      const dy = e.clientY - s.lastMouse.y;
      if (Math.hypot(e.clientX - s.clickStart.x, e.clientY - s.clickStart.y) > 5) s.isDragging = true;

      if (s.transformState) {
        applyTransform(e.clientX, e.clientY);
      } else if (s.isMMBDown) {
        if (s.isShiftDown) pan(dx, dy);
        else orbit(-dx * 0.008, -dy * 0.008);
      }
      s.lastMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = (e) => {
      if (e.button === 1) { s.isMMBDown = false; return; }
      if (e.button === 2) { if (s.transformState) { cancelTransform(); return; } }
      if (e.button === 0) {
        if (s.transformState) { confirmTransform(); return; }
        if (!s.isDragging) clickSelect(e);
      }
    };

    const onWheel = (e) => { e.preventDefault(); zoom(e.deltaY > 0 ? 1.12 : 0.88); };
    const preventCtx = (e) => e.preventDefault();

    renderer.domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    renderer.domElement.addEventListener('wheel', onWheel, { passive: false });
    renderer.domElement.addEventListener('contextmenu', preventCtx);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // ── Render loop ───────────────────────────────────────────────────────
    const animate = () => {
      s.animFrame = requestAnimationFrame(animate);
      if (s.selectionOutline && s.selectedMesh) {
        s.selectionOutline.position.copy(s.selectedMesh.position);
        s.selectionOutline.rotation.copy(s.selectedMesh.rotation);
        const sc = s.selectedMesh.scale;
        s.selectionOutline.scale.set(sc.x * 1.003, sc.y * 1.003, sc.z * 1.003);
      }
      renderer.render(scene, camera);
    };
    animate();

    const ro = new ResizeObserver(() => {
      const w = mount.clientWidth, h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    ro.observe(mount);

    return () => {
      cancelAnimationFrame(s.animFrame);
      ro.disconnect();
      renderer.domElement.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      renderer.domElement.removeEventListener('wheel', onWheel);
      renderer.domElement.removeEventListener('contextmenu', preventCtx);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      Object.values(s.meshMap).forEach(m => { m.geometry?.dispose(); m.material?.dispose(); });
      s.selectionOutline?.geometry?.dispose(); s.selectionOutline?.material?.dispose();
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, []);

  // ── Sync objects → Three.js ───────────────────────────────────────────
  useEffect(() => {
    if (!s.scene) return;
    const ids = new Set(objects.map(o => o.id));

    Object.keys(s.meshMap).forEach(id => {
      if (!ids.has(id)) {
        s.scene.remove(s.meshMap[id]);
        s.meshMap[id].geometry?.dispose();
        s.meshMap[id].material?.dispose();
        delete s.meshMap[id];
      }
    });

    objects.forEach(obj => {
      if (!s.meshMap[obj.id]) {
        const mesh = new THREE.Mesh(createGeometry(obj.shape), makeMaterial(obj, shadingMode));
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData = { id: obj.id, isObject: true };
        s.scene.add(mesh);
        s.meshMap[obj.id] = mesh;
      }

      const mesh = s.meshMap[obj.id];

      if (!s.transformState || s.transformState.objectId !== obj.id) {
        mesh.position.set(obj.position.x, obj.position.y, obj.position.z);
        mesh.rotation.set(
          THREE.MathUtils.degToRad(obj.rotation.x),
          THREE.MathUtils.degToRad(obj.rotation.y),
          THREE.MathUtils.degToRad(obj.rotation.z)
        );
        mesh.scale.set(obj.scale.x, obj.scale.y, obj.scale.z);
      }

      const mat = mesh.material;
      if (mat.color) mat.color.set(obj.color || '#b0b0b0');
      if (mat.metalness !== undefined) mat.metalness = obj.metalness ?? 0;
      if (mat.roughness !== undefined) mat.roughness = obj.roughness ?? 0.5;
      if (mat.emissive && obj.emission) { mat.emissive.set(obj.emission); mat.emissiveIntensity = obj.emissionStrength || 0; }
      mat.wireframe = shadingMode === 'wireframe';
      mat.transparent = (obj.alpha ?? 1) < 1;
      mat.opacity = obj.alpha ?? 1;
      mesh.visible = obj.visible !== false;
    });

    if (s.scene) {
      s.scene.background = new THREE.Color(
        shadingMode === 'wireframe' ? 0x2a2a2a :
        shadingMode === 'solid' ? 0x393939 : 0x1a1a2e
      );
    }
  }, [objects, shadingMode]);

  // ── Sync selection ───────────────────────────────────────────────────
  useEffect(() => {
    if (!s.scene) return;
    if (s.selectionOutline) {
      s.scene.remove(s.selectionOutline);
      s.selectionOutline.geometry?.dispose();
      s.selectionOutline.material?.dispose();
      s.selectionOutline = null;
    }
    s.selectedMesh = selectedId && s.meshMap[selectedId] ? s.meshMap[selectedId] : null;
    if (s.selectedMesh) {
      try {
        const edges = new THREE.EdgesGeometry(s.selectedMesh.geometry, 15);
        const outline = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0xff7f00 }));
        s.scene.add(outline);
        s.selectionOutline = outline;
      } catch (_) {}
    }
  }, [selectedId]);

  const modeLabel = { translate: 'Déplacer', rotate: 'Pivoter', scale: 'Échelle' };
  const axisColor = { X: '#ff4444', Y: '#44cc44', Z: '#4488ff', YZ: '#ff4444', XZ: '#44cc44', XY: '#4488ff' };

  return (
    <div ref={mountRef} className="w-full h-full relative" style={{ outline: 'none' }} tabIndex={-1}>
      {/* Transform overlay (like Blender) */}
      {transformInfo && (
        <div style={{
          position: 'absolute', bottom: '36px', left: '50%', transform: 'translateX(-50%)',
          background: 'rgba(0,0,0,0.8)', color: '#eee', padding: '5px 16px',
          borderRadius: '4px', fontSize: '13px', fontFamily: 'monospace',
          zIndex: 20, display: 'flex', alignItems: 'center', gap: '10px', pointerEvents: 'none',
        }}>
          <span style={{ color: '#aaa' }}>{modeLabel[transformInfo.mode]}</span>
          {transformInfo.axis && <span style={{ color: axisColor[transformInfo.axis] || '#fff', fontWeight: 'bold' }}>{transformInfo.axis}</span>}
          <span style={{ color: '#fff' }}>
            {transformInfo.negative ? '-' : ''}{transformInfo.value || ''}
            {(transformInfo.value !== '' || transformInfo.axis) && <span style={{ opacity: 0.5 }}>|</span>}
          </span>
        </div>
      )}

      {/* Viewport gizmo */}
      <div style={{ position: 'absolute', top: '10px', right: '12px', pointerEvents: 'none', zIndex: 10 }}>
        <svg viewBox="0 0 90 90" width="90" height="90">
          <circle cx="45" cy="45" r="42" fill="rgba(20,20,20,0.55)" stroke="#555" strokeWidth="1" />
          <line x1="45" y1="45" x2="45" y2="10" stroke="#44cc44" strokeWidth="2.5" />
          <circle cx="45" cy="10" r="8" fill="#44cc44" /><text x="45" y="13.5" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">Z</text>
          <line x1="45" y1="45" x2="78" y2="63" stroke="#ff4444" strokeWidth="2.5" />
          <circle cx="78" cy="63" r="8" fill="#ff4444" /><text x="78" y="66" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">X</text>
          <line x1="45" y1="45" x2="12" y2="63" stroke="#4488ff" strokeWidth="2.5" />
          <circle cx="12" cy="63" r="8" fill="#4488ff" /><text x="12" y="66" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">Y</text>
        </svg>
      </div>

      {/* Hints */}
      <div style={{ position: 'absolute', bottom: '6px', left: '8px', fontSize: '10px', color: 'rgba(255,255,255,0.3)', pointerEvents: 'none', lineHeight: '1.7' }}>
        <div>G: Déplacer · R: Pivoter · S: Échelle · X/Y/Z: Contraindre · Shift+X/Y/Z: Plan</div>
        <div>MMB: Orbiter · Shift+MMB: Pan · Molette: Zoom · Num1/3/7: Vues · F: Focus</div>
        <div>Shift+A: Ajouter · X: Supprimer · Shift+D: Dupliquer · Tab: Mode édition · Ctrl+Z: Annuler</div>
      </div>
    </div>
  );
}