import React, { useState } from 'react';
import { Pen, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function NewBoardScreen({ onCreate, onCancel }) {
  const [name, setName] = useState('');
  const [creating, setCreating] = useState(false);

  const submit = async () => {
    if (!name.trim() || creating) return;
    setCreating(true);
    await onCreate(name.trim());
    setCreating(false);
  };

  return (
    <div className="h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 animate-zoom-in">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center">
            <Pen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">Nouveau tableau blanc</h2>
            <p className="text-sm text-gray-500">Donnez un nom à votre tableau</p>
          </div>
        </div>
        <Input value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} placeholder="Mon tableau" className="mb-4" autoFocus />
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onCancel}>Annuler</Button>
          <Button onClick={submit} disabled={!name.trim() || creating} className="flex-1 bg-amber-500 hover:bg-amber-600 text-white">
            {creating && <Loader2 className="w-4 h-4 animate-spin" />} Créer
          </Button>
        </div>
      </div>
    </div>
  );
}