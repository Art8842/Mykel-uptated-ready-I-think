import React from 'react';
import {
  MousePointer2, Hand, Pen, Square, Circle, Minus, ArrowUpRight, Type, StickyNote,
  Image as ImageIcon, Eraser, PaintBucket, ZoomIn, ZoomOut,
} from 'lucide-react';

const TOOLS = [
  { id: 'select', icon: MousePointer2, label: 'Sélectionner / déplacer' },
  { id: 'hand', icon: Hand, label: 'Naviguer' },
  { id: 'pen', icon: Pen, label: 'Stylo' },
  { id: 'rectangle', icon: Square, label: 'Rectangle' },
  { id: 'circle', icon: Circle, label: 'Cercle' },
  { id: 'line', icon: Minus, label: 'Ligne' },
  { id: 'arrow', icon: ArrowUpRight, label: 'Flèche' },
  { id: 'text', icon: Type, label: 'Texte' },
  { id: 'sticky', icon: StickyNote, label: 'Note' },
  { id: 'image', icon: ImageIcon, label: 'Image' },
  { id: 'eraser', icon: Eraser, label: 'Gomme' },
];
const COLORS = ['#1e293b', '#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#6366f1', '#ec4899'];
const WIDTHS = [2, 4, 8];

const btn = (active) => `w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${active ? 'bg-amber-100 text-amber-700' : 'text-gray-500 hover:bg-gray-100'}`;
const Divider = () => <div className="w-px h-6 bg-gray-200 mx-1 flex-shrink-0" />;

export default function WhiteboardTools({ tool, onTool, color, onColor, strokeWidth, onStrokeWidth, filled, onFilled, zoom, onZoom }) {
  const custom = !COLORS.includes(color);
  return (
    <div className="h-12 bg-white border-b border-gray-200 flex items-center gap-1 px-2 overflow-x-auto flex-nowrap flex-shrink-0">
      {TOOLS.map(t => (
        <button key={t.id} type="button" onClick={() => onTool(t.id)} title={t.label} className={btn(tool === t.id)}>
          <t.icon className="w-4 h-4" />
        </button>
      ))}
      <Divider />
      {COLORS.map(c => (
        <button key={c} type="button" onClick={() => onColor(c)} title={c}
          className={`w-6 h-6 mx-0.5 rounded-full flex-shrink-0 ${color === c ? 'ring-2 ring-offset-2 ring-amber-500' : ''}`} style={{ backgroundColor: c }} />
      ))}
      <label title="Couleur personnalisée" className={`relative w-6 h-6 mx-0.5 rounded-full flex-shrink-0 cursor-pointer overflow-hidden ${custom ? 'ring-2 ring-offset-2 ring-amber-500' : ''}`}
        style={{ background: custom ? color : 'conic-gradient(#ef4444, #f59e0b, #10b981, #3b82f6, #a855f7, #ef4444)' }}>
        <input type="color" value={color} onChange={e => onColor(e.target.value)} className="absolute inset-0 opacity-0 cursor-pointer" />
      </label>
      <Divider />
      {WIDTHS.map(w => (
        <button key={w} type="button" onClick={() => onStrokeWidth(w)} title={`Épaisseur ${w}`} className={btn(strokeWidth === w)}>
          <span className="rounded-full bg-gray-700" style={{ width: w + 4, height: w + 4 }} />
        </button>
      ))}
      <button type="button" onClick={() => onFilled(!filled)} title="Remplir les formes" className={btn(filled)}>
        <PaintBucket className="w-4 h-4" />
      </button>
      <Divider />
      <button type="button" onClick={() => onZoom(1 / 1.2)} title="Dézoomer" className={btn(false)}><ZoomOut className="w-4 h-4" /></button>
      <span className="text-xs text-gray-500 w-11 text-center flex-shrink-0">{Math.round(zoom * 100)}%</span>
      <button type="button" onClick={() => onZoom(1.2)} title="Zoomer" className={btn(false)}><ZoomIn className="w-4 h-4" /></button>
    </div>
  );
}