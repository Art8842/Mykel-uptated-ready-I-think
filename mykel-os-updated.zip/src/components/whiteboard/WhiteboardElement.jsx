import React from 'react';
import { getBounds } from '@/components/whiteboard/geometry';

function Shape({ el }) {
  const stroke = el.color || '#1e293b';
  const sw = el.strokeWidth || 2;
  switch (el.type) {
    case 'pen':
      return <path d={el.points.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ')} fill="none" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />;
    case 'line':
    case 'arrow':
      return (
        <g>
          {el.type === 'arrow' && (
            <defs>
              <marker id={`wb-arrow-${el.id}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                <path d="M0,0 L10,5 L0,10 z" fill={stroke} />
              </marker>
            </defs>
          )}
          <line x1={el.x} y1={el.y} x2={el.x2} y2={el.y2} stroke={stroke} strokeWidth={sw} strokeLinecap="round" markerEnd={el.type === 'arrow' ? `url(#wb-arrow-${el.id})` : undefined} />
        </g>
      );
    case 'rectangle':
      return <rect x={el.x} y={el.y} width={el.width} height={el.height} rx={6} fill={el.fillColor || 'transparent'} stroke={stroke} strokeWidth={sw} />;
    case 'circle':
      return <ellipse cx={el.x + el.width / 2} cy={el.y + el.height / 2} rx={el.width / 2} ry={el.height / 2} fill={el.fillColor || 'transparent'} stroke={stroke} strokeWidth={sw} />;
    case 'text': {
      const fs = el.fontSize || 20;
      return (
        <text x={el.x} y={el.y + fs} fill={stroke} fontSize={fs} fontWeight="600" fontFamily="system-ui, sans-serif">
          {String(el.text || '').split('\n').map((line, i) => <tspan key={i} x={el.x} dy={i ? fs * 1.3 : 0}>{line}</tspan>)}
        </text>
      );
    }
    case 'sticky':
      return (
        <g>
          <rect x={el.x} y={el.y} width={el.width} height={el.height} rx={10} fill={el.fillColor || '#fef9c3'} stroke="#eab308" strokeOpacity={0.4} />
          <foreignObject x={el.x} y={el.y} width={el.width} height={el.height}>
            <div style={{ padding: 12, fontSize: 14, lineHeight: 1.35, color: stroke, fontFamily: 'system-ui, sans-serif', whiteSpace: 'pre-wrap', wordBreak: 'break-word', height: '100%', overflow: 'hidden' }}>{el.text}</div>
          </foreignObject>
        </g>
      );
    case 'image':
      return <image href={el.src} x={el.x} y={el.y} width={el.width} height={el.height} preserveAspectRatio="xMidYMid slice" />;
    default:
      return null;
  }
}

export default function WhiteboardElement({ el, selected }) {
  const b = selected ? getBounds(el) : null;
  return (
    <g>
      <Shape el={el} />
      {b && <rect x={b.x - 6} y={b.y - 6} width={b.width + 12} height={b.height + 12} fill="none" stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="6 4" vectorEffect="non-scaling-stroke" />}
    </g>
  );
}