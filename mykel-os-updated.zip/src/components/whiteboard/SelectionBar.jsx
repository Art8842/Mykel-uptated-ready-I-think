import React from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const LABELS = {
  pen: 'Tracé', rectangle: 'Rectangle', circle: 'Cercle', line: 'Ligne', arrow: 'Flèche',
  text: 'Texte', sticky: 'Note', image: 'Image',
};

export default function SelectionBar({ element, onEdit, onDelete }) {
  if (!element) return null;
  const editable = element.type === 'text' || element.type === 'sticky';
  return (
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white rounded-2xl shadow-lg border border-gray-200 flex items-center gap-1 px-2 py-1.5 z-30 animate-zoom-in">
      <span className="text-xs text-gray-500 px-2">{LABELS[element.type] || element.type}</span>
      {editable && (
        <Button variant="ghost" size="sm" className="gap-1.5" onClick={onEdit}>
          <Pencil className="w-4 h-4" /> Modifier
        </Button>
      )}
      <Button variant="ghost" size="sm" className="gap-1.5 text-red-500 hover:bg-red-50 hover:text-red-600" onClick={onDelete}>
        <Trash2 className="w-4 h-4" /> Supprimer
      </Button>
    </div>
  );
}