import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function ShareBoardDialog({ open, onOpenChange, sharedWith = [], onShare }) {
  const [email, setEmail] = useState('');

  const submit = async () => {
    const value = email.trim();
    if (!value) return;
    await onShare(value);
    setEmail('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Partager le tableau</DialogTitle>
        </DialogHeader>
        <div className="flex gap-2">
          <Input type="email" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} placeholder="email@exemple.com" />
          <Button onClick={submit} disabled={!email.trim()} className="bg-amber-500 hover:bg-amber-600 text-white">Partager</Button>
        </div>
        {sharedWith.length > 0 && (
          <div>
            <p className="text-xs text-gray-500 mb-2">Partagé avec :</p>
            {sharedWith.map(e => <div key={e} className="text-sm text-gray-700 py-1">{e}</div>)}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}