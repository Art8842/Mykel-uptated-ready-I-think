let counter = 0;
export const genElId = () => `el${Date.now()}_${counter++}`;

export const DRAW_TOOLS = ['pen', 'rectangle', 'circle', 'line', 'arrow'];

const isLine = (el) => el.type === 'line' || el.type === 'arrow';

export function getBounds(el) {
  if (el.type === 'pen' && el.points?.length) {
    const xs = el.points.map(p => p[0]);
    const ys = el.points.map(p => p[1]);
    const x = Math.min(...xs);
    const y = Math.min(...ys);
    return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y };
  }
  if (isLine(el)) {
    return { x: Math.min(el.x, el.x2), y: Math.min(el.y, el.y2), width: Math.abs(el.x2 - el.x), height: Math.abs(el.y2 - el.y) };
  }
  return { x: el.x, y: el.y, width: el.width || 100, height: el.height || 50 };
}

export function hitTest(elements, p, tol = 6) {
  for (let i = elements.length - 1; i >= 0; i--) {
    const b = getBounds(elements[i]);
    if (p.x >= b.x - tol && p.x <= b.x + b.width + tol && p.y >= b.y - tol && p.y <= b.y + b.height + tol) return elements[i];
  }
  return null;
}

export function translateEl(el, dx, dy) {
  if (el.type === 'pen') return { ...el, points: el.points.map(([x, y]) => [x + dx, y + dy]) };
  if (isLine(el)) return { ...el, x: el.x + dx, y: el.y + dy, x2: el.x2 + dx, y2: el.y2 + dy };
  return { ...el, x: el.x + dx, y: el.y + dy };
}

export function createShape(type, p, { color, strokeWidth, filled }) {
  const base = { id: genElId(), type, color, strokeWidth };
  if (type === 'pen') return { ...base, points: [[p.x, p.y]] };
  if (type === 'line' || type === 'arrow') return { ...base, x: p.x, y: p.y, x2: p.x, y2: p.y };
  return { ...base, x: p.x, y: p.y, width: 0, height: 0, fillColor: filled ? `${color}33` : 'transparent' };
}

export function growShape(el, start, p, minStep = 1.5) {
  if (el.type === 'pen') {
    const last = el.points[el.points.length - 1];
    if (Math.hypot(p.x - last[0], p.y - last[1]) < minStep) return el;
    return { ...el, points: [...el.points, [p.x, p.y]] };
  }
  if (isLine(el)) return { ...el, x2: p.x, y2: p.y };
  return { ...el, x: Math.min(start.x, p.x), y: Math.min(start.y, p.y), width: Math.abs(p.x - start.x), height: Math.abs(p.y - start.y) };
}

export function isDegenerate(el) {
  if (el.type === 'pen') return (el.points?.length || 0) < 2;
  if (isLine(el)) return Math.hypot(el.x2 - el.x, el.y2 - el.y) < 3;
  if (el.type === 'rectangle' || el.type === 'circle') return el.width < 3 && el.height < 3;
  return false;
}

export function textSize(text, fontSize) {
  const lines = String(text).split('\n');
  const longest = Math.max(...lines.map(l => l.length), 1);
  return { width: Math.max(40, longest * fontSize * 0.6), height: lines.length * fontSize * 1.3 };
}