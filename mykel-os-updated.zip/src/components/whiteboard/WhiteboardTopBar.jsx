import React from 'react';
import { ArrowLeft, Pen, Loader2, Undo2, Share2, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function WhiteboardTopBar({ name, saving, canUndo, onBack, onUndo, onShare, onSave }) {
  return (
    <div className="h-14 bg-white border-b border-gray-200 flex items-center gap-2 px-3 flex-shrink-0">
      <Button variant="ghost" size="icon" className="h-9 w-9 flex-shrink-0" onClick={onBack} title="Retour">
        <ArrowLeft className="w-4 h-4" />
      </Button>
      <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center flex-shrink-0">
        <Pen className="w-4 h-4 text-white" />
      </div>
      <span className="font-bold text-sm text-gray-900 truncate min-w-0">{name}</span>
      {saving && <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-500 flex-shrink-0" />}
      <div className="flex-1" />
      <Button variant="ghost" size="icon" className="h-9 w-9 flex-shrink-0" onClick={onUndo} disabled={!canUndo} title="Annuler (Ctrl+Z)">
        <Undo2 className="w-4 h-4" />
      </Button>
      <Button variant="ghost" size="sm" className="gap-1.5 flex-shrink-0 px-2 sm:px-3" onClick={onShare}>
        <Share2 className="w-4 h-4" /><span className="hidden sm:inline">Partager</span>
      </Button>
      <Button size="sm" className="gap-1.5 bg-amber-500 hover:bg-amber-600 text-white flex-shrink-0 px-2 sm:px-3" onClick={onSave}>
        <Save className="w-4 h-4" /><span className="hidden sm:inline">Enregistrer</span>
      </Button>
    </div>
  );
}