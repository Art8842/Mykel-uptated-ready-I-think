import React, { useMemo } from 'react';

export default function PreviewFrame({ files }) {
  const html = useMemo(() => {
    const getName = (f) => f.path || f.name || '';
    const htmlFile = files.find(f => {
      const n = getName(f);
      return n.endsWith('.html') || n.endsWith('.htm');
    });
    const cssFiles = files.filter(f => getName(f).endsWith('.css'));
    const jsFiles = files.filter(f => getName(f).endsWith('.js'));

    const css = cssFiles.map(f => f.code).join('\n');
    const js = jsFiles.map(f => f.code.replace(/<\/script>/gi, '<\\/script>')).join('\n');

    let htmlContent = htmlFile
      ? htmlFile.code
      : '<!DOCTYPE html><html><head></head><body><p style="font-family:sans-serif;padding:20px;color:#666">Aucun fichier HTML trouvé. Ajoutez un fichier .html pour voir l\'aperçu.</p></body></html>';

    if (htmlContent.includes('</head>')) {
      htmlContent = htmlContent.replace('</head>', `<style>${css}</style></head>`);
    } else if (htmlContent.includes('<head>')) {
      htmlContent = htmlContent.replace('<head>', `<head><style>${css}</style>`);
    } else {
      htmlContent = `<style>${css}</style>` + htmlContent;
    }

    if (htmlContent.includes('</body>')) {
      htmlContent = htmlContent.replace('</body>', `<script>${js}<\/script></body>`);
    } else {
      htmlContent = htmlContent + `<script>${js}<\/script>`;
    }

    return htmlContent;
  }, [files]);

  return (
    <iframe
      srcDoc={html}
      className="w-full h-full bg-white border-0"
      sandbox="allow-scripts"
      title="Aperçu"
    />
  );
}