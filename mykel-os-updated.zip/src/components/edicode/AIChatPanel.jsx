import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Loader2, FilePlus, Edit3, Trash2, FolderPlus, X } from 'lucide-react';
import { callAI } from '@/components/utils/aiClient';

function extractJSON(text) {
  if (text && typeof text === 'object') return text;
  try { return JSON.parse(text); } catch {}
  const match = String(text || '').match(/\{[\s\S]*\}/);
  if (match) { try { return JSON.parse(match[0]); } catch {} }
  return null;
}

const ACTION_META = {
  create: { icon: FilePlus, label: 'Création de', color: 'text-green-400' },
  modify: { icon: Edit3, label: 'Modification de', color: 'text-blue-400' },
  delete: { icon: Trash2, label: 'Suppression de', color: 'text-red-400' },
  create_folder: { icon: FolderPlus, label: 'Création du dossier', color: 'text-amber-400' },
};

export default function AIChatPanel({ files, folders, onApplyActions, onClose }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput('');
    const userMsg = { role: 'user', content: text };
    const history = [...messages, userMsg];
    setMessages(history);
    setLoading(true);
    try {
      const fileList = files.map(f => `- ${f.path || f.name}`).join('\n');
      const folderList = (folders || []).map(f => `- ${f.path}/`).join('\n');
      const treeStr = [folderList, fileList].filter(Boolean).join('\n') || '(projet vide)';
      const system = `Tu es un assistant de Vibe Coding dans l'éditeur Mykel EdiCode. Tu aides l'utilisateur à créer et modifier du code source de manière autonome.

Structure actuelle du projet:
${treeStr}

CRITIQUE: Tu dois écrire le code DIRECTEMENT dans l'éditeur via les "actions", jamais dans le message de chat. Le message ne doit contenir qu'une brève explication en français, SANS AUCUN CODE.

Réponds UNIQUEMENT avec un objet JSON valide, sans texte autour ni markdown:
{"message":"explication courte en français de ce que tu fais (SANS CODE)","actions":[{"type":"create","path":"chemin/fichier.ext","content":"contenu complet du fichier"},{"type":"modify","path":"chemin/fichier.ext","content":"nouveau contenu complet"},{"type":"delete","path":"chemin/fichier.ext"},{"type":"create_folder","path":"chemin/dossier"}]}

Règles STRICTES:
- TOUT le code va dans les "actions", JAMAIS dans le "message".
- Le "message" est une phrase courte sans code, par exemple: "J'ai créé index.html avec une page d'accueil et style.css pour le design."
- Pour modifier un fichier existant, donne le contenu COMPLET du fichier (jamais un diff).
- Tu peux créer plusieurs fichiers et dossiers en une seule réponse.
- Utilise des chemins avec dossiers quand c'est pertinent (ex: src/app.js, css/style.css).
- Sois autonome: crée tous les fichiers nécessaires sans demander de confirmation.
- Réponds en français.`;
      const result = await callAI({
        messages: history.map(m => ({ role: m.role, content: m.content })),
        system,
        json_object: true,
      });
      const parsed = extractJSON(result);
      if (parsed && (parsed.message || parsed.actions)) {
        const actions = parsed.actions || [];
        setMessages(prev => [...prev, { role: 'assistant', content: parsed.message || 'Voilà !', actions }]);
        if (actions.length > 0) onApplyActions(actions);
      } else {
        setMessages(prev => [...prev, { role: 'assistant', content: typeof result === 'string' ? result : 'Désolé, je n\'ai pas pu traiter cette demande.' }]);
      }
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Désolé, une erreur est survenue. Réessayez.' }]);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 border-l border-white/10">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10 flex-shrink-0">
        <Sparkles className="w-4 h-4 text-purple-400" />
        <span className="font-semibold text-sm text-white">Assistant IA</span>
        <button onClick={onClose} className="ml-auto text-white/40 hover:text-white/80 transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && !loading && (
          <div className="text-center text-white/40 text-sm py-8">
            <Sparkles className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p className="font-medium">Assistant de Vibe Coding</p>
            <p className="text-xs mt-2 text-white/30">Décrivez ce que vous voulez créer ou modifier. L'IA génère, modifie et organise les fichiers pour vous.</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm ${msg.role === 'user' ? 'bg-purple-600 text-white' : 'bg-gray-800 text-white/90'}`}>
              <p className="whitespace-pre-wrap break-words">{msg.content}</p>
              {msg.actions?.length > 0 && (
                <div className="mt-2 space-y-1 pt-2 border-t border-white/10">
                  {msg.actions.map((a, j) => {
                    const meta = ACTION_META[a.type] || ACTION_META.modify;
                    const Icon = meta.icon;
                    return (
                      <div key={j} className={`flex items-center gap-1.5 text-xs ${meta.color}`}>
                        <Icon className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{meta.label} {a.path}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-gray-800 rounded-2xl px-3.5 py-2.5">
              <Loader2 className="w-4 h-4 text-purple-400 animate-spin" />
            </div>
          </div>
        )}
      </div>
      <div className="p-3 border-t border-white/10 flex-shrink-0">
        <div className="flex gap-2 items-end">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Demandez à l'IA..."
            rows={1}
            className="flex-1 bg-gray-800 border border-white/10 rounded-xl px-3 py-2 text-white text-sm resize-none focus:outline-none focus:border-purple-500 max-h-32"
            disabled={loading}
          />
          <button
            onClick={send}
            disabled={loading || !input.trim()}
            className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex-shrink-0"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}