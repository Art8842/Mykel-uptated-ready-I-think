import React, { useState, useMemo } from 'react';
import { ChevronRight, ChevronDown, Folder, FolderOpen, FilePlus, FolderPlus, Trash2 } from 'lucide-react';
import LanguageIcon from './LanguageIcon';

function buildTree(files, folders) {
  const root = { name: '', path: '', children: {}, files: [] };
  const ensure = (path) => {
    const parts = path.split('/').filter(Boolean);
    let node = root;
    let cur = '';
    for (const part of parts) {
      cur = cur ? `${cur}/${part}` : part;
      if (!node.children[part]) node.children[part] = { name: part, path: cur, children: {}, files: [] };
      node = node.children[part];
    }
    return node;
  };
  (folders || []).forEach(f => ensure(f.path));
  (files || []).forEach(f => {
    const fullPath = f.path || f.name || 'fichier';
    const parts = fullPath.split('/');
    const fileName = parts.pop();
    let node = root;
    if (parts.length > 0) node = ensure(parts.join('/'));
    node.files.push({ ...f, _name: fileName, _path: fullPath });
  });
  return root;
}

function flatten(node, depth, expanded, out) {
  const folderEntries = Object.values(node.children).sort((a, b) => a.name.localeCompare(b.name));
  for (const folder of folderEntries) {
    const isExpanded = expanded.has(folder.path);
    out.push({ type: 'folder', name: folder.name, path: folder.path, depth });
    if (isExpanded) flatten(folder, depth + 1, expanded, out);
  }
  node.files
    .sort((a, b) => a._name.localeCompare(b._name))
    .forEach(f => out.push({ type: 'file', file: f, depth }));
}

export default function FileExplorer({ files, folders, activeFileId, onSelectFile, onAddFile, onAddFolder, onDeleteFile }) {
  const [expanded, setExpanded] = useState(() => new Set());
  const tree = useMemo(() => buildTree(files, folders), [files, folders]);
  const rows = useMemo(() => { const out = []; flatten(tree, 0, expanded, out); return out; }, [tree, expanded]);

  const toggle = (path) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path); else next.add(path);
      return next;
    });
  };

  return (
    <div className="flex flex-col h-full bg-gray-900/50 border-r border-white/5">
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/5 flex-shrink-0">
        <span className="text-xs font-semibold text-white/50 uppercase tracking-wider">Explorateur</span>
        <div className="flex gap-1">
          <button onClick={onAddFolder} className="p-1 rounded hover:bg-white/10 text-white/50 hover:text-white transition-colors" title="Nouveau dossier">
            <FolderPlus className="w-3.5 h-3.5" />
          </button>
          <button onClick={onAddFile} className="p-1 rounded hover:bg-white/10 text-white/50 hover:text-white transition-colors" title="Nouveau fichier">
            <FilePlus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-1">
        {rows.map((row) => {
          if (row.type === 'folder') {
            const isExpanded = expanded.has(row.path);
            return (
              <div
                key={`d-${row.path}`}
                onClick={() => toggle(row.path)}
                className="flex items-center gap-1 px-2 py-1 text-sm text-white/70 hover:bg-white/5 cursor-pointer select-none"
                style={{ paddingLeft: 6 + row.depth * 12 }}
              >
                {isExpanded ? <ChevronDown className="w-3 h-3 flex-shrink-0" /> : <ChevronRight className="w-3 h-3 flex-shrink-0" />}
                {isExpanded ? <FolderOpen className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" /> : <Folder className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />}
                <span className="truncate">{row.name}</span>
              </div>
            );
          }
          const isActive = row.file.id === activeFileId;
          return (
            <div
              key={row.file.id}
              onClick={() => onSelectFile(row.file.id)}
              className={`group flex items-center gap-1.5 pr-2 py-1 text-sm cursor-pointer select-none ${isActive ? 'bg-purple-600/20 text-white' : 'text-white/60 hover:bg-white/5 hover:text-white/90'}`}
              style={{ paddingLeft: 6 + row.depth * 12 + 18 }}
            >
              <LanguageIcon language={row.file.language} name={row.file._name} size={14} />
              <span className="truncate flex-1">{row.file._name}</span>
              <button
                onClick={(e) => { e.stopPropagation(); onDeleteFile(row.file.id); }}
                className="opacity-0 group-hover:opacity-100 text-white/30 hover:text-red-400 transition-opacity"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          );
        })}
        {rows.length === 0 && (
          <div className="text-center text-white/30 text-xs py-4">Aucun fichier</div>
        )}
      </div>
    </div>
  );
}