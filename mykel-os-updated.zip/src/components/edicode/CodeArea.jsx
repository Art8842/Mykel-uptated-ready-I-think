import React, { useRef } from 'react';

export default function CodeArea({ value, onChange }) {
  const textareaRef = useRef(null);
  const lineNumbersRef = useRef(null);

  const handleScroll = () => {
    if (textareaRef.current && lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.target.selectionStart;
      const end = e.target.selectionEnd;
      const newValue = value.substring(0, start) + '  ' + value.substring(end);
      onChange(newValue);
      requestAnimationFrame(() => {
        e.target.selectionStart = e.target.selectionEnd = start + 2;
      });
    }
  };

  const lineCount = value.split('\n').length;
  const lineNumbers = Array.from({ length: lineCount }, (_, i) => i + 1).join('\n');

  return (
    <div className="flex-1 flex overflow-hidden">
      <div
        ref={lineNumbersRef}
        className="hidden sm:block w-12 bg-gray-900/80 border-r border-white/5 overflow-hidden py-3 text-right text-xs text-white/30 font-mono leading-6 select-none"
      >
        <pre className="px-2">{lineNumbers}</pre>
      </div>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        onScroll={handleScroll}
        spellCheck={false}
        autoCapitalize="off"
        autoCorrect="off"
        className="flex-1 bg-gray-950 text-white font-mono leading-6 resize-none outline-none p-3 overflow-auto text-sm"
        style={{ tabSize: 2, fontFamily: "'Fira Code', 'Monaco', 'Menlo', monospace" }}
        placeholder="Commencez à coder..."
      />
    </div>
  );
}