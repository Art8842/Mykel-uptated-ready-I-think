import React from 'react';

const LANG_META = {
  html: { color: '#e34c26', label: '<>', dark: false },
  css: { color: '#1572b6', label: 'CSS', dark: false },
  javascript: { color: '#f7df1e', label: 'JS', dark: true },
  typescript: { color: '#3178c6', label: 'TS', dark: false },
  json: { color: '#545454', label: '{}', dark: false },
  python: { color: '#3776ab', label: 'PY', dark: false },
  java: { color: '#e76f00', label: 'J', dark: false },
  c: { color: '#a8b9cc', label: 'C', dark: true },
  cpp: { color: '#00599c', label: 'C+', dark: false },
  csharp: { color: '#178600', label: 'C#', dark: false },
  php: { color: '#777bb4', label: 'PHP', dark: false },
  ruby: { color: '#cc342d', label: 'RB', dark: false },
  go: { color: '#00add8', label: 'GO', dark: false },
  rust: { color: '#dea584', label: 'RS', dark: true },
  swift: { color: '#f05138', label: 'SW', dark: false },
  kotlin: { color: '#7f52ff', label: 'KT', dark: false },
  markdown: { color: '#545454', label: 'MD', dark: false },
  yaml: { color: '#cb171e', label: 'YML', dark: false },
  xml: { color: '#0060ac', label: '<>', dark: false },
  sql: { color: '#e38c00', label: 'SQL', dark: false },
  bash: { color: '#4eaa25', label: 'SH', dark: false },
  plaintext: { color: '#9a9a9a', label: '··', dark: false },
};

export default function LanguageIcon({ language, name, size = 14 }) {
  const meta = LANG_META[language] || LANG_META.plaintext;
  return (
    <span
      className="inline-flex items-center justify-center rounded font-bold flex-shrink-0 leading-none"
      style={{
        width: size,
        height: size,
        backgroundColor: meta.color,
        color: meta.dark ? '#1a1a1a' : '#ffffff',
        fontSize: Math.max(6, size * 0.4),
      }}
    >
      {meta.label}
    </span>
  );
}