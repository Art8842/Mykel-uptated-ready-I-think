import React from 'react';
import { X, Plus, FileCode } from 'lucide-react';

export default function FileTabs({ files, activeFileId, onSelectFile, onAddFile, onCloseFile }) {
  return (
    <div className="flex items-center bg-gray-900/50 border-b border-white/5 overflow-x-auto flex-nowrap">
      {files.map(file => (
        <div
          key={file.id}
          onClick={() => onSelectFile(file.id)}
          className={`group flex items-center gap-2 px-3 py-2 text-sm cursor-pointer border-r border-white/5 whitespace-nowrap transition-colors ${
            file.id === activeFileId ? 'bg-gray-950 text-white' : 'text-white/50 hover:text-white/80 hover:bg-white/5'
          }`}
        >
          <FileCode className="w-3.5 h-3.5 opacity-60 flex-shrink-0" />
          <span>{file.name}</span>
          {files.length > 1 && (
            <button
              onClick={(e) => { e.stopPropagation(); onCloseFile(file.id); }}
              className="opacity-0 group-hover:opacity-100 text-white/40 hover:text-white/80 transition-opacity"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      ))}
      <button
        onClick={onAddFile}
        className="px-3 py-2 text-white/50 hover:text-white/80 hover:bg-white/5 transition-colors"
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}