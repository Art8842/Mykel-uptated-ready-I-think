import React, { useState, useEffect } from 'react';
import { Search, Grid, List, ChevronRight, Home, Settings, LogOut, MessageSquare, Shield, Users, Code, Building2, Briefcase, User as UserIcon, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { getMykelSession, clearMykelSession } from '@/lib/mykelSession';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import MykelSupport from '@/components/shared/MykelSupport';
import UserSettings from '@/components/settings/UserSettings';
import DeveloperSpace from '@/components/developer/DeveloperSpace';
import { useLanguage } from '@/lib/LanguageContext';
import { isBusinessMode } from '@/lib/businessMode';
import { toast } from 'sonner';

export default function Header({
  searchQuery, onSearchChange, viewMode, onViewModeChange,
  breadcrumbs = [], onBreadcrumbClick, user, isMobile = false,
  sidebarCollapsed = false, onToggleSidebar,
}) {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [searchOpen, setSearchOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [devSpaceOpen, setDevSpaceOpen] = useState(false);
  const [devMode, setDevMode] = useState(() => localStorage.getItem('developer_mode') === 'true');
  const [businessSub, setBusinessSub] = useState(null);
  const [isAdminOfBusiness, setIsAdminOfBusiness] = useState(false);

  useEffect(() => {
    const handler = () => setDevMode(localStorage.getItem('developer_mode') === 'true');
    window.addEventListener('developer-mode-change', handler);
    return () => window.removeEventListener('developer-mode-change', handler);
  }, []);

  useEffect(() => {
    const email = user?.email || getMykelSession()?.email;
    if (!email) return;
    base44.entities.BusinessSubscription.filter({ admin_email: email, active: true })
      .then(subs => {
        if (subs.length > 0) {
          setBusinessSub(subs[0]);
          setIsAdminOfBusiness(true);
        } else {
          base44.entities.BusinessSubscription.list()
            .then(allSubs => {
              const memberSub = allSubs.find(s => s.active && s.member_emails?.includes(email));
              if (memberSub) setBusinessSub(memberSub);
            })
            .catch(() => {});
        }
      })
      .catch(() => {});
  }, [user]);

  const switchAccountMode = () => {
    const currentMode = localStorage.getItem('mykel_account_mode') || 'personal';
    if (currentMode === 'personal' && businessSub) {
      localStorage.setItem('mykel_account_mode', 'business');
      localStorage.setItem('mykel_business_sub_id', businessSub.id);
      toast.success('Mode Business activé');
      navigate('/Dashboard');
      setTimeout(() => window.location.reload(), 100);
    } else {
      localStorage.setItem('mykel_account_mode', 'personal');
      localStorage.removeItem('mykel_business_sub_id');
      toast.success('Mode personnel activé');
      navigate('/Dashboard');
      setTimeout(() => window.location.reload(), 100);
    }
  };

  return (
    <header className="bg-white px-3 md:px-6 py-2.5 select-none">
      <div className="flex items-center gap-2 md:gap-4">
        {!isMobile && onToggleSidebar && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleSidebar}
            className="flex-shrink-0"
            title={sidebarCollapsed ? 'Afficher la barre latérale' : 'Masquer la barre latérale'}
          >
            {sidebarCollapsed ? <PanelLeftOpen className="w-5 h-5" /> : <PanelLeftClose className="w-5 h-5" />}
          </Button>
        )}
        {/* Search - Mobile */}
        {isMobile ? (
          searchOpen ? (
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="text"
                placeholder={t('search_placeholder')}
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                onBlur={() => !searchQuery && setSearchOpen(false)}
                className="pl-9 bg-gray-100 border-0 focus:bg-white focus:ring-2 focus:ring-blue-500 text-sm select-text"
                autoFocus
              />
            </div>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setSearchOpen(true)} className="flex-shrink-0">
              <Search className="w-5 h-5" />
            </Button>
          )
        ) : (
          /* Search - Desktop */
          <div className="flex-1 max-w-2xl relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={t('search_placeholder')}
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10 bg-gray-100 border-0 focus:bg-white focus:ring-2 focus:ring-blue-500 text-sm select-text"
            />
          </div>
        )}

        {/* View Toggle */}
        <div className="flex items-center bg-gray-100 rounded-lg p-1 flex-shrink-0">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('grid')}
            className={viewMode === 'grid' ? 'bg-white shadow-sm' : ''}
          >
            <Grid className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('list')}
            className={viewMode === 'list' ? 'bg-white shadow-sm' : ''}
          >
            <List className="w-4 h-4" />
          </Button>
        </div>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="gap-2 p-1 md:p-2">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-blue-600 text-white text-sm">
                  {user?.full_name?.charAt(0) || user?.email?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-white border-gray-200">
            <div className="px-3 py-2">
              <p className="font-medium text-sm text-gray-900">{user?.full_name || 'Utilisateur'}</p>
              <p className="text-xs text-gray-500">{user?.email}</p>
            </div>
            <DropdownMenuItem onClick={() => setSupportOpen(true)} className="cursor-pointer hover:bg-gray-100">
              <MessageSquare className="w-4 h-4 mr-2" />
              <span className="text-gray-900">Support Mykel</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setSettingsOpen(true)} className="cursor-pointer hover:bg-gray-100">
              <Settings className="w-4 h-4 mr-2" />
              <span className="text-gray-900">{t('settings')}</span>
            </DropdownMenuItem>
            {devMode && (
              <DropdownMenuItem onClick={() => setDevSpaceOpen(true)} className="cursor-pointer hover:bg-gray-100">
                <Code className="w-4 h-4 mr-2" />
                <span className="text-gray-900">Espace développeur</span>
              </DropdownMenuItem>
            )}
            {businessSub && (
              <>
                <div className="h-px bg-gray-100 my-1" />
                {isAdminOfBusiness && (
                  <DropdownMenuItem onClick={() => navigate('/BusinessManage')} className="cursor-pointer hover:bg-gray-100">
                    <Building2 className="w-4 h-4 mr-2" />
                    <span className="text-gray-900">Gérer mon Mykel Business</span>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={switchAccountMode} className="cursor-pointer hover:bg-gray-100">
                  {isBusinessMode() ? <UserIcon className="w-4 h-4 mr-2" /> : <Briefcase className="w-4 h-4 mr-2" />}
                  <span className="text-gray-900">{isBusinessMode() ? 'Revenir au compte personnel' : 'Accéder à mon compte Business'}</span>
                </DropdownMenuItem>
              </>
            )}
            {(user?.role === 'admin' || getMykelSession()?.role === 'admin') && (
              <>
                <div className="h-px bg-gray-100 my-1" />
                <DropdownMenuItem onClick={() => navigate('/AdminPanel')} className="cursor-pointer hover:bg-gray-100">
                  <Shield className="w-4 h-4 mr-2 text-slate-600" />
                  <span className="text-gray-900">Panel Admin</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/Users')} className="cursor-pointer hover:bg-gray-100">
                  <Users className="w-4 h-4 mr-2 text-slate-600" />
                  <span className="text-gray-900">Utilisateurs</span>
                </DropdownMenuItem>
              </>
            )}
            <div className="h-px bg-gray-100 my-1" />
            <DropdownMenuItem
              onClick={() => { clearMykelSession(); base44.auth.logout('/MykelLogin'); }}
              className="cursor-pointer hover:bg-gray-100"
            >
              <LogOut className="w-4 h-4 mr-2" />
              <span className="text-gray-900">Déconnexion</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <MykelSupport open={supportOpen} onClose={() => setSupportOpen(false)} user={user} />
        <UserSettings open={settingsOpen} onClose={() => setSettingsOpen(false)} user={user} />
        <DeveloperSpace open={devSpaceOpen} onClose={() => setDevSpaceOpen(false)} />
      </div>

      {/* Breadcrumbs */}
      {breadcrumbs.length > 0 && (
        <div className="flex items-center gap-1 mt-2 text-xs md:text-sm overflow-x-auto pb-1">
          <button
            onClick={() => onBreadcrumbClick(null)}
            className="flex items-center gap-1 text-gray-600 hover:text-blue-600 transition-colors whitespace-nowrap"
          >
            <Home className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">{t('my_drive')}</span>
          </button>
          {breadcrumbs.map((crumb, index) => (
            <React.Fragment key={crumb.id}>
              <ChevronRight className="w-3 h-3 md:w-4 md:h-4 text-gray-400 flex-shrink-0" />
              <button
                onClick={() => onBreadcrumbClick(crumb)}
                className={`hover:text-blue-600 transition-colors whitespace-nowrap ${
                  index === breadcrumbs.length - 1 ? 'text-gray-900 font-medium' : 'text-gray-600'
                }`}
              >
                {crumb.name}
              </button>
            </React.Fragment>
          ))}
        </div>
      )}
    </header>
  );
}