import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Users, Eye, Edit, MessageSquare, Trash2, Loader2, Folder, UserPlus, Lock } from 'lucide-react';

const PERMISSIONS = [
  { value: 'view', label: 'Visualisation', icon: Eye, color: 'text-gray-600 bg-gray-100' },
  { value: 'edit', label: 'Modification', icon: Edit, color: 'text-green-600 bg-green-100' },
  { value: 'comment', label: 'Commentaires', icon: MessageSquare, color: 'text-blue-600 bg-blue-100' },
];

const PermIcon = ({ perm, className = 'w-3.5 h-3.5' }) => {
  const p = PERMISSIONS.find(x => x.value === perm) || PERMISSIONS[0];
  const Icon = p.icon;
  return <Icon className={className} />;
};

const PermLabel = ({ perm }) => {
  const p = PERMISSIONS.find(x => x.value === perm) || PERMISSIONS[0];
  return p.label;
};

export default function ManageMembersDialog({ open, onOpenChange, file, onShared, userEmail }) {
  const [email, setEmail] = useState('');
  const [permission, setPermission] = useState('view');
  const [loading, setLoading] = useState(false);
  const [members, setMembers] = useState([]);

  // Only the file owner can modify permissions — members get a read-only view
  const isOwner = file && userEmail && !(file.shared_with || []).includes(userEmail);

  useEffect(() => {
    if (file) {
      const sharedWith = file.shared_with || [];
      const permissions = file.shared_permissions || {};
      setMembers(sharedWith.map(e => ({ email: e, permission: permissions[e] || 'view' })));
      }
  }, [file]);

  const handleAdd = async () => {
    if (!email.trim()) return;
    setLoading(true);
    try {
      const currentShared = file.shared_with || [];
      const currentPerms = file.shared_permissions || {};
      const newEmail = email.trim().toLowerCase();

      if (currentShared.includes(newEmail)) {
        toast.error('Cette personne a déjà accès');
        setLoading(false);
        return;
      }

      const updates = {
        shared_with: [...currentShared, newEmail],
        shared_permissions: { ...currentPerms, [newEmail]: permission }
      };
      // Initialize shared_accepted as empty if not yet defined (requires acceptance via notification)
      if (file.shared_accepted === undefined) {
        updates.shared_accepted = [];
      }
      await base44.entities.CloudFile.update(file.id, updates);

      // If folder, share all children recursively
      if (file.type === 'folder') {
        await shareChildrenRecursive(file.id, newEmail, permission);
      }

      setMembers([...members, { email: newEmail, permission }]);
      setEmail('');
      toast.success('Membre ajouté');
      onShared?.();
    } catch (e) {
      toast.error('Erreur lors de l\'ajout');
    } finally {
      setLoading(false);
    }
  };

  const shareChildrenRecursive = async (folderId, email, perm) => {
    const children = await base44.entities.CloudFile.filter({ parent_folder_id: folderId, is_trashed: false });
    for (const child of children) {
      if (!(child.shared_with || []).includes(email)) {
        const childUpdates = {
          shared_with: [...(child.shared_with || []), email],
          shared_permissions: { ...(child.shared_permissions || {}), [email]: perm }
        };
        if (child.shared_accepted === undefined) {
          childUpdates.shared_accepted = [];
        }
        await base44.entities.CloudFile.update(child.id, childUpdates);
      }
      if (child.type === 'folder') {
        await shareChildrenRecursive(child.id, email, perm);
      }
    }
  };

  const handleRemove = async (memberEmail) => {
    setLoading(true);
    try {
      const newShared = (file.shared_with || []).filter(e => e !== memberEmail);
      const newPerms = { ...(file.shared_permissions || {}) };
      delete newPerms[memberEmail];
      await base44.entities.CloudFile.update(file.id, { shared_with: newShared, shared_permissions: newPerms });

      if (file.type === 'folder') {
        await removeChildrenRecursive(file.id, memberEmail);
      }

      setMembers(members.filter(m => m.email !== memberEmail));
      toast.success('Membre retiré');
      onShared?.();
    } catch (e) {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  const removeChildrenRecursive = async (folderId, email) => {
    const children = await base44.entities.CloudFile.filter({ parent_folder_id: folderId, is_trashed: false });
    for (const child of children) {
      if ((child.shared_with || []).includes(email)) {
        const childShared = (child.shared_with || []).filter(e => e !== email);
        const childPerms = { ...(child.shared_permissions || {}) };
        delete childPerms[email];
        await base44.entities.CloudFile.update(child.id, { shared_with: childShared, shared_permissions: childPerms });
      }
      if (child.type === 'folder') {
        await removeChildrenRecursive(child.id, email);
      }
    }
  };

  const handleChangePermission = async (memberEmail, newPerm) => {
    try {
      const newPerms = { ...(file.shared_permissions || {}), [memberEmail]: newPerm };
      await base44.entities.CloudFile.update(file.id, { shared_permissions: newPerms });
      setMembers(members.map(m => m.email === memberEmail ? { ...m, permission: newPerm } : m));

      if (file.type === 'folder') {
        await updateChildrenPermissionRecursive(file.id, memberEmail, newPerm);
      }
      toast.success('Permission modifiée');
    } catch (e) {
      toast.error('Erreur');
    }
  };

  const updateChildrenPermissionRecursive = async (folderId, email, perm) => {
    const children = await base44.entities.CloudFile.filter({ parent_folder_id: folderId, is_trashed: false });
    for (const child of children) {
      if ((child.shared_with || []).includes(email)) {
        await base44.entities.CloudFile.update(child.id, {
          shared_permissions: { ...(child.shared_permissions || {}), [email]: perm }
        });
      }
      if (child.type === 'folder') {
        await updateChildrenPermissionRecursive(child.id, email, perm);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            Gérer les membres — {file?.name}
          </DialogTitle>
        </DialogHeader>

        {file?.type === 'folder' && (
          <div className="flex items-center gap-2 bg-blue-50 dark:bg-blue-950 rounded-lg p-3 text-sm text-blue-700 dark:text-blue-300">
            <Folder className="w-4 h-4 flex-shrink-0" />
            <span>Partager ce dossier partagera aussi tous les fichiers et sous-dossiers qu'il contient.</span>
          </div>
        )}

        {/* Current members */}
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {members.length === 0 && (
            <p className="text-sm text-gray-400 text-center py-4">Aucun membre pour le moment</p>
          )}
          {members.map((m) => (
            <div key={m.email} className="flex items-center gap-2 p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                {m.email[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{m.email}</p>
                {isOwner ? (
                  <select
                    value={m.permission}
                    onChange={(e) => handleChangePermission(m.email, e.target.value)}
                    className="text-xs bg-transparent border-0 text-gray-500 dark:text-gray-400 focus:outline-none cursor-pointer"
                  >
                    {PERMISSIONS.map(p => (
                      <option key={p.value} value={p.value}>{p.label}</option>
                    ))}
                  </select>
                ) : (
                  <span className="text-xs text-gray-400">{PERMISSIONS.find(p => p.value === m.permission)?.label || 'Visualisation'}</span>
                )}
              </div>
              {isOwner && (
                <button
                  onClick={() => handleRemove(m.email)}
                  className="p-1.5 rounded-full text-red-400 hover:bg-red-50 hover:text-red-600 transition-all flex-shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Add new member — owner only */}
        {isOwner ? (
          <div className="border-t border-gray-100 dark:border-gray-800 pt-4 space-y-3">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
              <UserPlus className="w-4 h-4" /> Ajouter un membre
            </p>
            <Input
              type="email"
              placeholder="email@exemple.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
              className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white"
            />
            <div className="flex gap-2">
              {PERMISSIONS.map(p => {
                const Icon = p.icon;
                return (
                  <button
                    key={p.value}
                    onClick={() => setPermission(p.value)}
                    className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-lg border-2 text-xs font-medium transition-all ${
                      permission === p.value
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                        : 'border-gray-200 dark:border-gray-700 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {p.label}
                  </button>
                );
              })}
            </div>
            <Button onClick={handleAdd} disabled={loading || !email.trim()} className="w-full gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
              Ajouter
            </Button>
          </div>
        ) : (
          <div className="border-t border-gray-100 dark:border-gray-800 pt-4">
            <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-sm text-gray-500">
              <Lock className="w-4 h-4 flex-shrink-0" />
              <span>Seul le propriétaire du fichier peut modifier les permissions.</span>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}