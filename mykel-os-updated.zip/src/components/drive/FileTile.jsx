import React from 'react';
import {
  Folder, FileText, Table, Presentation, Palette, Image as ImageIcon,
  FileVideo, FileAudio, Archive, File, MoreVertical, Star, Undo2, Music,
  Eye, Edit, Users, Copy, Download, Trash2, Pin, PinOff,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const FILE_STYLE = {
  folder:       { gradient: 'from-gray-400 to-gray-600',     Icon: Folder },
  document:     { gradient: 'from-blue-500 to-blue-700',     Icon: FileText },
  spreadsheet:  { gradient: 'from-green-500 to-green-700',   Icon: Table },
  presentation: { gradient: 'from-orange-400 to-amber-600',  Icon: Presentation },
  drawing:      { gradient: 'from-purple-500 to-purple-700', Icon: Palette },
  image:        { gradient: 'from-pink-500 to-rose-500',     Icon: ImageIcon },
  video:        { gradient: 'from-red-500 to-rose-600',      Icon: FileVideo },
  audio:        { gradient: 'from-indigo-500 to-indigo-700', Icon: FileAudio },
  archive:      { gradient: 'from-yellow-500 to-amber-600',  Icon: Archive },
  pdf:          { gradient: 'from-red-500 to-red-700',       Icon: FileText },
  other:        { gradient: 'from-gray-400 to-gray-600',     Icon: File },
};

const formatDate = (date) =>
  new Date(date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });

export default function FileTile({
  file, onClick, onToggleStar, onTogglePin, onRename, onShare, onDuplicate, onDownload, onDelete,
  onRestore, onImportToMusic, isTrash = false, selectionMode = false, isSelected = false,
  onSelectFile, draggable = false, dragEvents = {},
}) {
  const style = FILE_STYLE[file.type] || FILE_STYLE.other;
  const { Icon } = style;
  const isImage = file.type === 'image';
  const { dragOver, ...dragHandlers } = dragEvents;
  const isShared = (file.shared_with || []).length > 0;

  return (
    <div className="group" draggable={draggable} {...dragHandlers}>
      <div
        onClick={() => (selectionMode ? onSelectFile?.(file) : onClick(file))}
        className={`relative aspect-square rounded-2xl bg-gradient-to-br ${style.gradient} flex items-center justify-center cursor-pointer overflow-hidden transition-all ${
          isSelected ? 'ring-2 ring-blue-500 ring-offset-2' :
          dragOver ? 'ring-2 ring-green-500 ring-offset-2' :
          'hover:shadow-lg'
        }`}
      >
        {isImage && file.thumbnail_url ? (
          <img src={file.thumbnail_url} alt={file.name} className="w-full h-full object-cover" />
        ) : (
          <Icon className="w-12 h-12 text-white" strokeWidth={1.5} />
        )}

        {selectionMode && (
          <div className="absolute top-2 left-2">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={(e) => { e.stopPropagation(); onSelectFile(file); }}
              className="w-5 h-5 rounded"
            />
          </div>
        )}

        {/* Shared indicator */}
        {!selectionMode && isShared && (
          <div className="absolute top-2 left-2 flex items-center gap-0.5 bg-white/80 rounded-full px-1.5 py-0.5">
            <Users className="w-3 h-3 text-blue-600" />
            <span className="text-[10px] font-medium text-blue-600">{(file.shared_with || []).length}</span>
          </div>
        )}

        {/* Pinned indicator */}
        {!selectionMode && file.is_pinned && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-white/80 rounded-full p-0.5">
            <Pin className="w-3 h-3 text-gray-700 fill-current" />
          </div>
        )}

        {!selectionMode && file.is_starred && (
          <button
            onClick={(e) => { e.stopPropagation(); onToggleStar(file); }}
            className="absolute top-2 right-2 p-1 rounded-full bg-white/80 text-yellow-500"
          >
            <Star className="w-4 h-4 fill-current" />
          </button>
        )}

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              onClick={(e) => e.stopPropagation()}
              className="absolute bottom-2 right-2 p-1.5 rounded-full bg-black/20 text-white hover:bg-black/40 transition-all"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {!isTrash ? (
              <>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onClick(file); }} className="gap-2">
                  <Eye className="w-4 h-4" /> Ouvrir
                </DropdownMenuItem>
                {file.type === 'audio' && onImportToMusic && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onImportToMusic(file); }} className="gap-2">
                    <Music className="w-4 h-4" /> Importer dans Mykel Music
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onRename(file); }} className="gap-2">
                  <Edit className="w-4 h-4" /> Renommer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onShare(file); }} className="gap-2">
                  <Users className="w-4 h-4" /> Gérer les membres
                </DropdownMenuItem>
                {onTogglePin && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onTogglePin(file); }} className="gap-2">
                    {file.is_pinned ? <><PinOff className="w-4 h-4" /> Désépingler</> : <><Pin className="w-4 h-4" /> Épingler</>}
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDuplicate(file); }} className="gap-2">
                  <Copy className="w-4 h-4" /> Dupliquer
                </DropdownMenuItem>
                {file.type !== 'folder' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDownload(file); }} className="gap-2">
                    <Download className="w-4 h-4" /> Télécharger
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(file); }} className="gap-2 text-red-600">
                  <Trash2 className="w-4 h-4" /> Mettre à la corbeille
                </DropdownMenuItem>
              </>
            ) : (
              <>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onRestore(file); }} className="gap-2">
                  <Undo2 className="w-4 h-4" /> Restaurer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(file); }} className="gap-2 text-red-600">
                  <Trash2 className="w-4 h-4" /> Supprimer définitivement
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <p className="mt-2 text-sm font-medium text-gray-900 truncate">{file.name}</p>
      <p className="text-xs text-gray-500 italic">Ouvert le {formatDate(file.last_opened || file.updated_date || file.created_date)}</p>
    </div>
  );
}