import React from 'react';
import {
  Folder, FileText, Table, Presentation, Palette, Image as ImageIcon,
  FileVideo, FileAudio, Archive, File, MoreVertical, Star, Undo2, Music,
  Eye, Edit, Users, Copy, Download, Trash2, Pin, PinOff,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const FILE_STYLE = {
  folder:       { gradient: 'from-gray-400 to-gray-600',     Icon: Folder },
  document:     { gradient: 'from-blue-500 to-blue-700',     Icon: FileText },
  spreadsheet:  { gradient: 'from-green-500 to-green-700',   Icon: Table },
  presentation: { gradient: 'from-orange-400 to-amber-600',  Icon: Presentation },
  drawing:      { gradient: 'from-purple-500 to-purple-700', Icon: Palette },
  image:        { gradient: 'from-pink-500 to-rose-500',     Icon: ImageIcon },
  video:        { gradient: 'from-red-500 to-rose-600',      Icon: FileVideo },
  audio:        { gradient: 'from-indigo-500 to-indigo-700', Icon: FileAudio },
  archive:      { gradient: 'from-yellow-500 to-amber-600',  Icon: Archive },
  pdf:          { gradient: 'from-red-500 to-red-700',       Icon: FileText },
  other:        { gradient: 'from-gray-400 to-gray-600',     Icon: File },
};

const formatDate = (date) =>
  new Date(date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });

export default function FileListRow({
  file, onClick, onToggleStar, onTogglePin, onRename, onShare, onDuplicate, onDownload, onDelete,
  onRestore, onImportToMusic, isTrash = false, selectionMode = false, isSelected = false,
  onSelectFile, draggable = false, dragEvents = {},
}) {
  const style = FILE_STYLE[file.type] || FILE_STYLE.other;
  const { Icon } = style;
  const isImage = file.type === 'image';
  const { dragOver, ...dragHandlers } = dragEvents;
  const isShared = (file.shared_with || []).length > 0;

  return (
    <div className="group" draggable={draggable} {...dragHandlers}>
      <div
        onClick={() => (selectionMode ? onSelectFile?.(file) : onClick(file))}
        className={`flex items-center gap-3 p-2.5 rounded-xl cursor-pointer transition-all ${
          isSelected ? 'bg-blue-50 ring-2 ring-blue-500' :
          dragOver ? 'bg-green-50 ring-2 ring-green-500' :
          'hover:bg-gray-100'
        }`}
      >
        {selectionMode && (
          <input
            type="checkbox"
            checked={isSelected}
            onChange={(e) => { e.stopPropagation(); onSelectFile(file); }}
            className="w-5 h-5 rounded flex-shrink-0"
          />
        )}
        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${style.gradient} flex items-center justify-center flex-shrink-0 overflow-hidden`}>
          {isImage && file.thumbnail_url ? (
            <img src={file.thumbnail_url} alt={file.name} className="w-full h-full object-cover" />
          ) : (
            <Icon className="w-5 h-5 text-white" strokeWidth={1.5} />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            {file.is_pinned && <Pin className="w-3 h-3 text-gray-600 fill-current flex-shrink-0" />}
            <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
          </div>
          <p className="text-xs text-gray-500">{file.type === 'folder' ? 'Dossier' : file.type} · {formatDate(file.last_opened || file.updated_date || file.created_date)}</p>
        </div>
        {!selectionMode && isShared && (
          <div className="flex items-center gap-0.5 bg-blue-50 rounded-full px-1.5 py-0.5 flex-shrink-0">
            <Users className="w-3 h-3 text-blue-600" />
            <span className="text-[10px] font-medium text-blue-600">{(file.shared_with || []).length}</span>
          </div>
        )}
        {!selectionMode && file.is_starred && (
          <Star className="w-4 h-4 text-yellow-500 fill-current flex-shrink-0" />
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              onClick={(e) => e.stopPropagation()}
              className="p-1.5 rounded-full hover:bg-gray-200 transition-all flex-shrink-0"
            >
              <MoreVertical className="w-4 h-4 text-gray-500" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {!isTrash ? (
              <>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onClick(file); }} className="gap-2">
                  <Eye className="w-4 h-4" /> Ouvrir
                </DropdownMenuItem>
                {file.type === 'audio' && onImportToMusic && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onImportToMusic(file); }} className="gap-2">
                    <Music className="w-4 h-4" /> Importer dans Mykel Music
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onRename(file); }} className="gap-2">
                  <Edit className="w-4 h-4" /> Renommer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onShare(file); }} className="gap-2">
                  <Users className="w-4 h-4" /> Gérer les membres
                </DropdownMenuItem>
                {onTogglePin && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onTogglePin(file); }} className="gap-2">
                    {file.is_pinned ? <><PinOff className="w-4 h-4" /> Désépingler</> : <><Pin className="w-4 h-4" /> Épingler</>}
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDuplicate(file); }} className="gap-2">
                  <Copy className="w-4 h-4" /> Dupliquer
                </DropdownMenuItem>
                {file.type !== 'folder' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDownload(file); }} className="gap-2">
                    <Download className="w-4 h-4" /> Télécharger
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(file); }} className="gap-2 text-red-600">
                  <Trash2 className="w-4 h-4" /> Mettre à la corbeille
                </DropdownMenuItem>
              </>
            ) : (
              <>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onRestore(file); }} className="gap-2">
                  <Undo2 className="w-4 h-4" /> Restaurer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(file); }} className="gap-2 text-red-600">
                  <Trash2 className="w-4 h-4" /> Supprimer définitivement
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}