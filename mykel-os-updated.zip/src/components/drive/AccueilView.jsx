import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FolderPlus, Upload, FolderOpen, MoreHorizontal, ChevronRight, Cloud,
  Folder, FileText, Table, Presentation, Palette, Image as ImageIcon, File as FileIcon,
  Video, Music, LayoutGrid,
} from 'lucide-react';
import moment from 'moment';
import { useLanguage } from '@/lib/LanguageContext';
import { AppIcon } from '@/components/shared/AppIcons';

const APPS = [
  { id: 'word',     labelKey: 'mykel_word',     page: '/MykelWord' },
  { id: 'tabs',     labelKey: 'mykel_tabs',     page: '/MykelTabs' },
  { id: 'sliders',  labelKey: 'mykel_sliders',  page: '/MykelSliders' },
  { id: 'draws',    labelKey: 'mykel_draws',    page: '/MykelDraws' },
  { id: 'snapfix',  labelKey: 'mykel_snapfix',  page: '/MykelSnapFix' },
  { id: 'removebg', labelKey: 'remove_bg',      page: '/RemoveBG' },
  { id: '3d',       labelKey: 'mykel_3d',        page: '/Mykel3D' },
  { id: 'edicode',  labelKey: 'mykel_edicode',  page: '/MykelEdiCode' },
  { id: 'meet',     labelKey: 'mykel_meet',     page: '/MykelMeet' },
];

function getFileMeta(file) {
  if (file.type === 'folder')        return { Icon: Folder,        bg: 'bg-blue-50',    color: 'text-blue-600' };
  if (file.type === 'document')      return { Icon: FileText,      bg: 'bg-blue-50',    color: 'text-blue-600' };
  if (file.type === 'spreadsheet')   return { Icon: Table,         bg: 'bg-emerald-50', color: 'text-emerald-600' };
  if (file.type === 'presentation')  return { Icon: Presentation,  bg: 'bg-orange-50',  color: 'text-orange-600' };
  if (file.type === 'drawing')       return { Icon: Palette,       bg: 'bg-purple-50',  color: 'text-purple-600' };
  if (file.type === 'image')         return { Icon: ImageIcon,    bg: 'bg-purple-50',  color: 'text-purple-600' };
  if (file.type === 'pdf')           return { Icon: FileText,      bg: 'bg-red-50',     color: 'text-red-600' };
  if (file.type === 'video')         return { Icon: Video,        bg: 'bg-pink-50',    color: 'text-pink-600' };
  if (file.type === 'audio')         return { Icon: Music,        bg: 'bg-purple-50',  color: 'text-purple-600' };
  return { Icon: FileIcon, bg: 'bg-gray-50', color: 'text-gray-600' };
}

function formatStorage(bytes) {
  if (bytes < 1024) return bytes + ' o';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
  return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' Go';
}

function formatRelativeTime(date) {
  if (!date) return '';
  const m = moment(date);
  const diffMin = moment().diff(m, 'minutes');
  const diffH = moment().diff(m, 'hours');
  const diffD = moment().diff(m, 'days');
  if (diffMin < 1) return "À l'instant";
  if (diffMin < 60) return `Il y a ${diffMin} min`;
  if (diffH < 24) return `Il y a ${diffH} h`;
  if (diffD < 7) return `Il y a ${diffD} j`;
  return m.format('DD/MM/YYYY');
}

const GLASS = 'bg-white/70 backdrop-blur-xl border border-white/60 shadow-[0_4px_24px_rgba(0,0,0,0.06)]';

export default function AccueilView({
  storageUsed, storageMax, recentFiles, user,
  onFileClick, onNewFolder, onUpload, onUploadFolder, onOpenApps, onViewChange,
}) {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const percent = storageMax === -1 ? 0 : Math.min((storageUsed / storageMax) * 100, 100);
  const greetingName = user?.full_name?.split(' ')[0] || '';

  const actions = [
    { label: 'Nouveau dossier',  Icon: FolderPlus,     gradient: 'from-blue-400 to-blue-600',     onClick: onNewFolder },
    { label: 'Importer',         Icon: Upload,          gradient: 'from-emerald-400 to-green-600', onClick: onUpload },
    { label: 'Dossier complet',  Icon: FolderOpen,      gradient: 'from-purple-400 to-purple-600', onClick: onUploadFolder },
    { label: 'Plus',             Icon: MoreHorizontal,  gradient: 'from-cyan-400 to-sky-500',       onClick: onOpenApps },
  ];

  return (
    <div className="relative">
      {/* Subtle background glow */}
      <div className="absolute -top-8 -left-10 w-56 h-56 bg-blue-200/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-40 -right-10 w-40 h-40 bg-purple-200/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative space-y-6">
        {/* Greeting */}
        <div className="animate-fade-up">
          <h1 className="text-2xl font-bold text-[#1A237E]">
            {greetingName ? `Bonjour ${greetingName} !` : 'Bonjour !'}
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">Que voulez-vous faire aujourd'hui ?</p>
        </div>

        {/* Storage card */}
        <div className={`${GLASS} rounded-3xl p-4 flex items-center gap-4 animate-fade-up`} style={{ animationDelay: '0.05s' }}>
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center flex-shrink-0 shadow-md"
            style={{ boxShadow: '0 3px 8px rgba(37,99,235,0.3), inset 0 1px 2px rgba(255,255,255,0.3)' }}
          >
            <Cloud className="w-6 h-6 text-white" strokeWidth={1.8} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900 mb-2">
              {formatStorage(storageUsed)} utilisés sur {storageMax === -1 ? 'illimité' : formatStorage(storageMax)}
            </p>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all" style={{ width: `${percent}%` }} />
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-300 flex-shrink-0" />
        </div>

        {/* Action grid */}
        <div className="grid grid-cols-4 gap-3 animate-fade-up" style={{ animationDelay: '0.1s' }}>
          {actions.map((action, i) => (
            <button
              key={i}
              onClick={action.onClick}
              className="flex flex-col items-center gap-2.5 bg-white/70 backdrop-blur-xl rounded-3xl border border-white/60 shadow-[0_2px_12px_rgba(0,0,0,0.04)] p-3 active:scale-95 transition-all"
            >
              <div
                className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${action.gradient} flex items-center justify-center`}
                style={{ boxShadow: '0 3px 8px rgba(0,0,0,0.12), inset 0 1px 2px rgba(255,255,255,0.35), inset 0 -2px 4px rgba(0,0,0,0.08)' }}
              >
                <action.Icon className="w-6 h-6 text-white" strokeWidth={2} style={{ filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.15))' }} />
              </div>
              <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{action.label}</span>
            </button>
          ))}
        </div>

        {/* Mes fichiers */}
        <div className="animate-fade-up" style={{ animationDelay: '0.15s' }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                <Folder className="w-4 h-4 text-blue-600" />
              </div>
              <h2 className="text-base font-bold text-[#1A237E]">Mes fichiers</h2>
            </div>
            <button onClick={() => onViewChange?.('cloud')} className="text-sm text-blue-600 font-medium flex items-center gap-0.5">
              Voir tout <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          {recentFiles.length === 0 ? (
            <div className={`${GLASS} rounded-3xl flex flex-col items-center justify-center py-12 text-gray-400`}>
              <p className="text-sm">Aucun fichier récent</p>
            </div>
          ) : (
            <div className={`${GLASS} rounded-3xl overflow-hidden`}>
              {recentFiles.slice(0, 5).map((file, index) => {
                const { Icon, bg, color } = getFileMeta(file);
                const isLast = index === Math.min(recentFiles.length, 5) - 1;
                return (
                  <button
                    key={file.id}
                    onClick={() => onFileClick(file)}
                    className={`w-full flex items-center gap-3 p-3.5 active:bg-white/50 transition-colors text-left ${
                      !isLast ? 'border-b border-gray-100/50' : ''
                    }`}
                  >
                    <div className={`w-11 h-11 rounded-2xl ${bg} flex items-center justify-center flex-shrink-0`}>
                      <Icon className={`w-5 h-5 ${color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">{file.name}</p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {formatRelativeTime(file.updated_date || file.last_opened)}
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-300 flex-shrink-0" />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Applications */}
        <div className="animate-fade-up" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                <LayoutGrid className="w-4 h-4 text-blue-600" />
              </div>
              <h2 className="text-base font-bold text-[#1A237E]">{t('applications')}</h2>
            </div>
            <button onClick={() => onViewChange?.('logiciels')} className="text-sm text-blue-600 font-medium flex items-center gap-0.5">
              Voir tout <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {APPS.map((app) => (
              <button
                key={app.id}
                onClick={() => navigate(app.page)}
                className="flex flex-col items-center gap-2 active:scale-95 transition-all"
              >
                <AppIcon id={app.id} size={56} />
                <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{t(app.labelKey)}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}