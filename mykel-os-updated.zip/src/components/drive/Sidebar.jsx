import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Home, Cloud, LayoutGrid, Plus, Upload, FolderPlus,
  FileText, Table, Presentation, Palette, Box,
  ShoppingBag, Music, Sparkles, Globe, MessageCircle,
  UserPlus, ChevronDown,
} from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';
import { AppIcon } from '@/components/shared/AppIcons';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent } from '@/components/ui/sheet';

export default function Sidebar({
  currentView, onViewChange, onNewDocument, onNewFolder, onUpload,
  storageUsed, storageMax, isMobile = false, user = null, folderInputRef = null,
  open = false, onOpenChange = () => {}, collapsed = false,
}) {
  const navigate = useNavigate();
  const { lang, setLanguage, t, currentLang, languages } = useLanguage();
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [inviteDialog, setInviteDialog] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');

  const handleInviteUser = () => {
    setInviteDialog(true);
    if (isMobile) onOpenChange(false);
  };

  const sendInvite = async () => {
    if (!inviteEmail.trim()) return;
    try {
      await base44.users.inviteUser(inviteEmail.trim(), 'user');
      toast.success('Invitation envoyée !');
      setInviteDialog(false);
      setInviteEmail('');
    } catch (e) {
      try {
        await navigator.clipboard.writeText(`${window.location.origin}?invited_by=${user.email}`);
        toast.success('Lien d\'invitation copié dans le presse-papiers');
        setInviteDialog(false);
        setInviteEmail('');
      } catch {
        toast.error('Erreur lors de l\'envoi');
      }
    }
  };

  const formatStorage = (bytes) => {
    if (bytes < 1024) return bytes + ' o';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
    return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' Go';
  };

  const storagePercent = storageMax === -1 ? 0 : (storageUsed / storageMax) * 100;

  const navItems = [
    { id: 'accueil', icon: Home, labelKey: 'home' },
    { id: 'cloud', icon: Cloud, labelKey: 'cloud' },
    { id: 'logiciels', icon: LayoutGrid, labelKey: 'logiciels' },
  ];

  const apps = [
    { id: 'store', labelKey: 'store', page: '/MykelStore' },
    { id: 'music', labelKey: 'mykel_music', page: '/MykelMusic' },
    { id: 'ia', labelKey: 'mykel_ia', page: '/MykelIA' },
    { id: 'search', labelKey: 'mykel_search', page: '/MykelSearch' },
    { id: 'chat', labelKey: 'mykel_chat', page: '/MykelChat' },
    { id: 'tv', labelKey: 'mykel_tv', page: '/MykelTV' },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-gray-100">
      {/* Logo */}
      <div className="px-5 pt-5 pb-3">
        <span className="text-2xl font-bold text-black">Mykel</span>
      </div>

      {/* Ajouter + button */}
      <div className="px-4 pb-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-cyan-100 to-gray-200 text-black font-medium shadow-sm hover:shadow transition-all">
              <Plus className="w-5 h-5" />
              Ajouter +
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            <DropdownMenuItem onClick={() => { onNewFolder(); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <FolderPlus className="w-4 h-4" />
              {t('new_folder')}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { onUpload(); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <Upload className="w-4 h-4" />
              {t('upload')}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { folderInputRef?.current?.click(); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <FolderPlus className="w-4 h-4" />
              {t('upload_folder')}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => { onNewDocument('document'); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <FileText className="w-4 h-4 text-blue-600" />
              {t('new_doc')}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { onNewDocument('spreadsheet'); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <Table className="w-4 h-4 text-green-600" />
              {t('new_sheet')}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { onNewDocument('presentation'); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <Presentation className="w-4 h-4 text-orange-500" />
              {t('new_slide')}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { onNewDocument('drawing'); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <Palette className="w-4 h-4 text-purple-600" />
              {t('new_draw')}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { navigate('/Mykel3D'); if (isMobile) onOpenChange(false); }} className="gap-2 cursor-pointer">
              <Box className="w-4 h-4 text-cyan-600" />
              {t('mykel_3d')}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleInviteUser} className="gap-2 cursor-pointer">
              <UserPlus className="w-4 h-4" />
              {t('invite_user')}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Navigation */}
      <nav className="px-3 space-y-1.5">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => { onViewChange(item.id); if (isMobile) onOpenChange(false); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
              currentView === item.id
                ? 'bg-white border border-gray-800 text-black font-semibold'
                : 'bg-gray-200 text-black hover:bg-gray-300'
            }`}
          >
            <item.icon className="w-5 h-5" />
            {t(item.labelKey)}
          </button>
        ))}
      </nav>

      {/* Applications */}
      <div className="px-3 mt-5">
        <p className="px-3 text-xs font-bold text-black uppercase tracking-wider mb-2">{t('applications')}</p>
        <div className="space-y-1">
          {apps.map((app) => {
            const linkProps = app.external
              ? { to: app.page, target: '_blank', rel: 'noopener noreferrer' }
              : { to: app.page };
            return (
              <Link
                key={app.id}
                {...linkProps}
                onClick={() => isMobile && onOpenChange(false)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-black bg-gray-200 hover:bg-gray-300 transition-all"
              >
                <AppIcon id={app.id} size={20} />
                <span className="flex-1">{t(app.labelKey)}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Language Picker */}
      <div className="px-3 mt-4 relative">
        <button
          onClick={() => setShowLangPicker((o) => !o)}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-black bg-gray-200 hover:bg-gray-300 transition-all"
        >
          <Globe className="w-5 h-5 text-gray-600" />
          <span className="flex-1 text-left">{currentLang?.flag} {currentLang?.label}</span>
          <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${showLangPicker ? 'rotate-180' : ''}`} />
        </button>
        {showLangPicker && (
          <div className="absolute bottom-full left-3 right-3 mb-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden">
            {Object.values(languages).map((l) => (
              <button
                key={l.code}
                onClick={() => { setLanguage(l.code); setShowLangPicker(false); if (isMobile) onOpenChange(false); }}
                className={`w-full flex items-center gap-2 px-3 py-2.5 text-sm transition-colors ${lang === l.code ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700 hover:bg-gray-50'}`}
              >
                <span>{l.flag}</span>{l.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Storage Footer */}
      <div className="mt-auto p-4">
        <p className="text-sm text-black mb-2">{t('stockage_utilise')}</p>
        <div className="h-1.5 bg-gray-300 rounded-full overflow-hidden mb-2">
          <div
            className="h-full bg-green-500 rounded-full transition-all"
            style={{ width: `${Math.min(storagePercent, 100)}%` }}
          />
        </div>
        <p className="text-xs text-black">
          {formatStorage(storageUsed)} / {storageMax === -1 ? t('unlimited') : formatStorage(storageMax)}
        </p>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <>
        <Sheet open={open} onOpenChange={onOpenChange}>
          <SheetContent side="left" className="w-72 p-0">
            <SidebarContent />
          </SheetContent>
        </Sheet>
        <Dialog open={inviteDialog} onOpenChange={setInviteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t('invite_user')}</DialogTitle>
            </DialogHeader>
            <Input
              placeholder={t('email_placeholder')}
              type="email"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendInvite()}
            />
            <DialogFooter>
              <Button variant="outline" onClick={() => setInviteDialog(false)}>{t('cancel')}</Button>
              <Button onClick={sendInvite}>{t('send')}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <>
      <div className={`flex flex-col h-full flex-shrink-0 overflow-hidden transition-[width] duration-300 ease-out ${collapsed ? 'w-0' : 'w-64'}`}>
        <div className="w-64 h-full flex flex-col">
          <SidebarContent />
        </div>
      </div>
      <Dialog open={inviteDialog} onOpenChange={setInviteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('invite_user')}</DialogTitle>
          </DialogHeader>
          <Input
            placeholder={t('email_placeholder')}
            type="email"
            value={inviteEmail}
            onChange={(e) => setInviteEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendInvite()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setInviteDialog(false)}>{t('cancel')}</Button>
            <Button onClick={sendInvite}>{t('send')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}