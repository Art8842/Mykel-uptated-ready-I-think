import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/lib/LanguageContext';
import { AppIcon } from '@/components/shared/AppIcons';
import FileGrid from '@/components/drive/FileGrid';

const APPS = [
  { id: 'word',     labelKey: 'mykel_word',     page: '/MykelWord' },
  { id: 'tabs',     labelKey: 'mykel_tabs',     page: '/MykelTabs' },
  { id: 'sliders',  labelKey: 'mykel_sliders',  page: '/MykelSliders' },
  { id: 'draws',    labelKey: 'mykel_draws',    page: '/MykelDraws' },
  { id: 'snapfix',  labelKey: 'mykel_snapfix',  page: '/MykelSnapFix' },
  { id: 'removebg', labelKey: 'remove_bg',      page: '/RemoveBG' },
  { id: '3d',       labelKey: 'mykel_3d',        page: '/Mykel3D' },
  { id: 'edicode',   labelKey: 'mykel_edicode',   page: '/MykelEdiCode' },
  { id: 'whiteboard', labelKey: 'mykel_whiteboard', page: '/MykelWhiteboard' },
];

export default function LogicielsView({
  officeFiles, viewMode = 'grid', onFileClick, onToggleStar, onTogglePin, onRename, onShare,
  onDuplicate, onDownload, onDelete,
}) {
  const { t } = useLanguage();
  const navigate = useNavigate();

  return (
    <div className="space-y-8">
      {/* App launcher grid */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3 md:grid-cols-8 md:gap-4">
        {APPS.map((app) => (
          <button
            key={app.id}
            onClick={() => navigate(app.page)}
            title={t(app.labelKey)}
            className="flex items-center justify-center p-1.5 rounded-2xl hover:bg-gray-100 active:scale-95 transition-all"
          >
            <AppIcon id={app.id} size={52} />
          </button>
        ))}
      </div>

      {/* Office documents section */}
      <div>
        <h2 className="text-base font-bold text-gray-900 mb-4">{t('dossiers_bureautiques')}</h2>
        {officeFiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-400">
            <p className="text-sm">Aucun document bureautique</p>
          </div>
        ) : (
          <FileGrid
            files={officeFiles}
            viewMode={viewMode}
            onFileClick={onFileClick}
            onToggleStar={onToggleStar}
            onTogglePin={onTogglePin}
            onRename={onRename}
            onShare={onShare}
            onDuplicate={onDuplicate}
            onDownload={onDownload}
            onDelete={onDelete}
          />
        )}
      </div>
    </div>
  );
}