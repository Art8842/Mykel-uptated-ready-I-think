import React from 'react';
import { X, Sparkles, Wand2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

export default function FileViewer({ file, onClose }) {
  const navigate = useNavigate();
  if (!file) return null;

  const openInSnapFix = () => {
    const url = encodeURIComponent(file.file_url);
    const name = encodeURIComponent(file.name);
    navigate(`/MykelSnapFix?url=${url}&name=${name}`);
    onClose();
  };

  const renderContent = () => {
    if (file.type === 'image') {
      return (
        <div className="flex flex-col items-center gap-4 w-full h-full">
          <img 
            src={file.file_url} 
            alt={file.name}
            className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-xl"
          />
          {/* Image action buttons */}
          <div className="flex gap-3 flex-wrap justify-center">
            <Button
              onClick={openInSnapFix}
              className="bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-500 hover:to-pink-500 text-white gap-2 shadow-lg shadow-violet-500/30"
            >
              <Sparkles className="w-4 h-4" />
              Ouvrir dans Mykel SnapFix
            </Button>
            <Button
              onClick={() => {
                // Quick magic eraser: open SnapFix with magic_eraser tool active
                const url = encodeURIComponent(file.file_url);
                const name = encodeURIComponent(file.name);
                navigate(`/MykelSnapFix?url=${url}&name=${name}&tool=magic_eraser`);
                onClose();
              }}
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 gap-2"
            >
              <Wand2 className="w-4 h-4" />
              Gomme magique IA
            </Button>
          </div>
        </div>
      );
    }

    if (file.type === 'video') {
      return (
        <video 
          controls 
          className="max-w-full max-h-full rounded-lg"
          src={file.file_url}
        >
          Votre navigateur ne supporte pas la vidéo.
        </video>
      );
    }

    if (file.type === 'audio') {
      return (
        <div className="flex items-center justify-center h-full">
          <div className="bg-white dark:bg-gray-900 rounded-xl p-8 shadow-lg max-w-md w-full">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{file.name}</h3>
            <audio controls className="w-full" src={file.file_url}>
              Votre navigateur ne supporte pas l'audio.
            </audio>
          </div>
        </div>
      );
    }

    if (file.type === 'pdf') {
      return (
        <iframe 
          src={file.file_url}
          className="w-full h-full"
          title={file.name}
        />
      );
    }

    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <p className="text-white/60 mb-4">Aperçu non disponible pour ce type de fichier</p>
          <Button onClick={() => window.open(file.file_url, '_blank')}>
            Télécharger
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex flex-col">
      <div className="flex items-center justify-between p-4 bg-black/50">
        <h2 className="text-white font-medium truncate max-w-xs">{file.name}</h2>
        <Button 
          variant="ghost" 
          size="icon"
          onClick={onClose}
          className="text-white hover:bg-white/20"
        >
          <X className="w-6 h-6" />
        </Button>
      </div>
      <div className="flex-1 flex items-center justify-center p-4 overflow-auto">
        {renderContent()}
      </div>
    </div>
  );
}