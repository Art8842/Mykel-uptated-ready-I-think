import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Bell, Check, X, Users, FileText, Folder, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function NotificationBell({ user, onAccept }) {
  const [pending, setPending] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(null);
  const [dropdownPos, setDropdownPos] = useState(null);
  const btnRef = useRef(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (user?.email) loadPending();
  }, [user]);

  const loadPending = async () => {
    setLoading(true);
    try {
      const shared = await base44.entities.CloudFile.filter({ shared_with: user.email, is_trashed: false });
      const pendingShares = shared.filter(f =>
        f.shared_accepted !== undefined &&
        Array.isArray(f.shared_accepted) &&
        !f.shared_accepted.includes(user.email)
      );
      setPending(pendingShares);
    } catch {} finally {
      setLoading(false);
    }
  };

  // Fermeture au clic extérieur
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (btnRef.current?.contains(e.target)) return;
      if (dropdownRef.current?.contains(e.target)) return;
      setOpen(false);
    };
    const onScroll = () => setOpen(false);
    document.addEventListener('mousedown', handler);
    window.addEventListener('scroll', onScroll, true);
    return () => {
      document.removeEventListener('mousedown', handler);
      window.removeEventListener('scroll', onScroll, true);
    };
  }, [open]);

  const toggle = () => {
    if (open) { setOpen(false); return; }
    if (btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      const width = Math.min(320, window.innerWidth - 16);
      let left = rect.right - width;
      if (left < 8) left = 8;
      if (left + width > window.innerWidth - 8) left = window.innerWidth - width - 8;
      const top = rect.bottom + 8;
      const maxH = Math.min(420, window.innerHeight - top - 16);
      setDropdownPos({ top, left, width, maxH });
    }
    setOpen(true);
  };

  const handleAccept = async (file) => {
    setActionLoading(file.id);
    try {
      const accepted = [...(file.shared_accepted || []), user.email];
      await base44.entities.CloudFile.update(file.id, { shared_accepted: accepted });
      setPending(pending.filter(f => f.id !== file.id));
      toast.success('Invitation acceptée');
      onAccept?.();
    } catch { toast.error('Erreur'); }
    finally { setActionLoading(null); }
  };

  const handleDecline = async (file) => {
    setActionLoading(file.id);
    try {
      const sharedWith = (file.shared_with || []).filter(e => e !== user.email);
      const newPerms = { ...(file.shared_permissions || {}) };
      delete newPerms[user.email];
      await base44.entities.CloudFile.update(file.id, { shared_with: sharedWith, shared_permissions: newPerms });
      setPending(pending.filter(f => f.id !== file.id));
      toast.success('Invitation refusée');
    } catch { toast.error('Erreur'); }
    finally { setActionLoading(null); }
  };

  return (
    <div className="relative flex-shrink-0">
      <button
        ref={btnRef}
        onClick={toggle}
        className="relative p-2 rounded-full hover:bg-gray-100 transition-all active:scale-95"
      >
        <Bell className="w-5 h-5 text-gray-600" />
        {pending.length > 0 && (
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
            {pending.length}
          </span>
        )}
      </button>

      {open && dropdownPos && (
        <div
          ref={dropdownRef}
          className="fixed bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-800 z-50 overflow-hidden flex flex-col"
          style={{ top: dropdownPos.top, left: dropdownPos.left, width: dropdownPos.width, maxHeight: dropdownPos.maxH }}
        >
          <div className="p-3 border-b border-gray-100 dark:border-gray-800 flex items-center gap-2 flex-shrink-0">
            <Bell className="w-4 h-4 text-gray-500" />
            <span className="font-semibold text-sm text-gray-900 dark:text-white">Invitations collaboratives</span>
            {pending.length > 0 && (
              <span className="ml-auto text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">{pending.length}</span>
            )}
          </div>

          <div className="overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
              </div>
            ) : pending.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-gray-400">
                <Bell className="w-8 h-8 mb-2 opacity-40" />
                <p className="text-sm">Aucune invitation en attente</p>
              </div>
            ) : (
              pending.map(file => (
                <div key={file.id} className="p-3 border-b border-gray-50 dark:border-gray-800 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-start gap-2.5">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${file.type === 'folder' ? 'bg-gray-100' : 'bg-blue-100'}`}>
                      {file.type === 'folder' ? <Folder className="w-4 h-4 text-gray-600" /> : <FileText className="w-4 h-4 text-blue-600" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{file.name}</p>
                      <p className="text-xs text-gray-400 flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        Invitation à collaborer
                      </p>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => handleAccept(file)}
                          disabled={actionLoading === file.id}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-600 hover:bg-green-700 text-white text-xs font-medium transition-all active:scale-95 disabled:opacity-50"
                        >
                          {actionLoading === file.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
                          Accepter
                        </button>
                        <button
                          onClick={() => handleDecline(file)}
                          disabled={actionLoading === file.id}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-medium transition-all active:scale-95 disabled:opacity-50"
                        >
                          <X className="w-3 h-3" />
                          Refuser
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}