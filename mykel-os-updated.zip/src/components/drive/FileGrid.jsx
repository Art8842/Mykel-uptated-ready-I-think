import React from 'react';
import { Folder } from 'lucide-react';
import FileTile from '@/components/drive/FileTile';
import FileListRow from '@/components/drive/FileListRow';

export default function FileGrid({
  files, viewMode = 'grid', onFileClick, onToggleStar, onTogglePin, onDelete, onDownload,
  onRename, onShare, onDuplicate, isTrash = false, selectionMode = false,
  selectedFiles = [], onSelectFile, allFolders = [], onDragMove, onRestore,
  onImportToMusic,
}) {
  const [dragOverFolder, setDragOverFolder] = React.useState(null);

  const handleDragStart = (e, file) => {
    e.dataTransfer.setData('fileId', file.id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e, file) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (file && file.type === 'folder' && dragOverFolder !== file.id) {
      setDragOverFolder(file.id);
    }
  };

  const handleDragLeave = () => setDragOverFolder(null);

  const handleDrop = (e, folder) => {
    e.preventDefault();
    const fileId = e.dataTransfer.getData('fileId');
    if (fileId && folder && folder.type === 'folder') {
      onDragMove(fileId, folder.id);
    }
    setDragOverFolder(null);
  };

  if (files.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-gray-400">
        <Folder className="w-16 h-16 mb-4" />
        <p className="text-lg font-medium">Aucun fichier</p>
        <p className="text-sm">Cliquez sur "Ajouter +" pour commencer</p>
      </div>
    );
  }

  if (viewMode === 'list') {
    return (
      <div className="space-y-1">
        {files.map((file) => (
          <FileListRow
            key={file.id}
            file={file}
            onClick={onFileClick}
            onToggleStar={onToggleStar}
            onTogglePin={onTogglePin}
            onRename={onRename}
            onShare={onShare}
            onDuplicate={onDuplicate}
            onDownload={onDownload}
            onDelete={onDelete}
            onRestore={onRestore}
            onImportToMusic={onImportToMusic}
            isTrash={isTrash}
            selectionMode={selectionMode}
            isSelected={selectedFiles.includes(file.id)}
            onSelectFile={onSelectFile}
            draggable={!selectionMode}
            dragEvents={{
              onDragStart: (e) => handleDragStart(e, file),
              onDragOver: (e) => handleDragOver(e, file),
              onDragLeave: handleDragLeave,
              onDrop: (e) => handleDrop(e, file),
              dragOver: dragOverFolder === file.id,
            }}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      {files.map((file) => (
        <FileTile
          key={file.id}
          file={file}
          onClick={onFileClick}
          onToggleStar={onToggleStar}
          onTogglePin={onTogglePin}
          onRename={onRename}
          onShare={onShare}
          onDuplicate={onDuplicate}
          onDownload={onDownload}
          onDelete={onDelete}
          onRestore={onRestore}
          onImportToMusic={onImportToMusic}
          isTrash={isTrash}
          selectionMode={selectionMode}
          isSelected={selectedFiles.includes(file.id)}
          onSelectFile={onSelectFile}
          draggable={!selectionMode}
          dragEvents={{
            onDragStart: (e) => handleDragStart(e, file),
            onDragOver: (e) => handleDragOver(e, file),
            onDragLeave: handleDragLeave,
            onDrop: (e) => handleDrop(e, file),
            dragOver: dragOverFolder === file.id,
          }}
        />
      ))}
    </div>
  );
}