import React from 'react';
import { HardDrive } from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';

export default function StorageWidget({ used, max }) {
  const { t } = useLanguage();

  const formatStorage = (bytes) => {
    if (bytes < 1024) return bytes + ' o';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
    return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' Go';
  };

  const percent = max === -1 ? 0 : Math.min((used / max) * 100, 100);

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-4 flex items-center gap-4 max-w-md">
      <div className="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
        <HardDrive className="w-6 h-6 text-blue-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-500">{t('stockage_utilise')}</p>
        <p className="text-sm font-semibold text-gray-900 mb-2">
          {formatStorage(used)} / {max === -1 ? t('unlimited') : formatStorage(max)}
        </p>
        <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-green-500 rounded-full transition-all"
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>
    </div>
  );
}