import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { Lock, ShoppingBag } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { getMykelSession } from '@/lib/mykelSession';

export default function AppAccessCheck({ appType, children }) {
  const navigate = useNavigate();
  const [hasAccess, setHasAccess] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const [appName, setAppName] = useState('');

  useEffect(() => {
    checkAccess();
  }, [appType]);

  const checkAccess = async () => {
    try {
      // First check Mykel internal session for role
      const mykelSession = getMykelSession();
      const isAdmin = mykelSession?.role === 'admin';

      if (isAdmin) {
        setHasAccess(true);
        setLoading(false);
        return;
      }

      // Get user email from Mykel session or Base44
      let userEmail = mykelSession?.email;
      if (!userEmail) {
        try {
          const b44User = await base44.auth.me();
          userEmail = b44User?.email;
          if (b44User?.role === 'admin') {
            setHasAccess(true);
            setLoading(false);
            return;
          }
        } catch {}
      }

      if (!userEmail) {
        setHasAccess(false);
        setShowDialog(true);
        setLoading(false);
        return;
      }

      // Check user tokens and owned apps
      const userTokensData = await base44.entities.UserTokens.filter({ user_email: userEmail });
      if (userTokensData.length === 0) {
        setHasAccess(false);
        setShowDialog(true);
        setLoading(false);
        return;
      }

      const userTokens = userTokensData[0];

      // Check if app is in store
      const apps = await base44.entities.StoreApp.filter({ app_type: appType });
      if (apps.length === 0) {
        // App not in store — free access
        setHasAccess(true);
        setLoading(false);
        return;
      }

      const app = apps[0];
      setAppName(app.name);

      if (userTokens.owned_apps?.includes(app.id)) {
        setHasAccess(true);
      } else {
        setHasAccess(false);
        setShowDialog(true);
      }
    } catch (e) {
      console.error(e);
      setHasAccess(true); // On error, allow access
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent" />
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <Dialog open={showDialog} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-6 h-6 text-orange-500" />
              Application non achetée
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-gray-600 mb-4">
              Vous n'avez pas accès à {appName}. Rendez-vous dans le Mykel Store pour l'acheter avec vos jetons.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => navigate('/MykelStore')} className="w-full gap-2">
              <ShoppingBag className="w-4 h-4" />
              Aller au Store
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return children;
}