import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Sparkles, Check, Image, Wand2, X, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { freeGenerateImage } from '@/lib/freeCore';

const WALLPAPER_PACKS = [
  {
    id: 'nature', name: 'Nature & Paysages', price: 50, icon: '🌿',
    description: '20 fonds d\'écran haute résolution de paysages naturels',
    color: 'from-green-400 to-emerald-600',
    preview: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400',
    wallpapers: [
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920',
      'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=1920',
      'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1920',
      'https://images.unsplash.com/photo-1433086966358-54859d0ed716?w=1920',
      'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=1920',
      'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=1920',
      'https://images.unsplash.com/photo-1510784722466-f2aa240d5e48?w=1920',
      'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?w=1920',
      'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?w=1920',
      'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1920',
      'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=1920',
      'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1920',
      'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=1920',
      'https://images.unsplash.com/photo-1505765050516-f72dcac9c60e?w=1920',
      'https://images.unsplash.com/photo-1490682143684-14369e18dce8?w=1920',
      'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=1920',
      'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1920',
      'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1920',
      'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=1920',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920',
    ],
  },
  {
    id: 'space', name: 'Espace & Cosmos', price: 80, icon: '🌌',
    description: '25 fonds d\'écran galaxies, nébuleuses et planètes en 4K',
    color: 'from-indigo-500 to-purple-700',
    preview: 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?w=400',
    wallpapers: [
      'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?w=1920',
      'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1920',
      'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1920',
      'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1920',
      'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1920',
      'https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=1920',
      'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=1920',
      'https://images.unsplash.com/photo-1464802686167-b939a6910659?w=1920',
      'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=1920',
      'https://images.unsplash.com/photo-1563207153-f403bf289096?w=1920',
      'https://images.unsplash.com/photo-1537420327992-d6e192287183?w=1920',
      'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?w=1920',
      'https://images.unsplash.com/photo-1614642264762-d0a3b8bf3700?w=1920',
      'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?w=1920',
      'https://images.unsplash.com/photo-1608178398319-48f814d0750c?w=1920',
      'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=1920',
      'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=1920',
      'https://images.unsplash.com/photo-1502481851512-e9e2529bfbf9?w=1920',
      'https://images.unsplash.com/photo-1581822261290-991b38693d1b?w=1920',
      'https://images.unsplash.com/photo-1517976487492-5750f3195933?w=1920',
      'https://images.unsplash.com/photo-1532767153582-b1a0e5145009?w=1920',
      'https://images.unsplash.com/photo-1609151376730-f246ec0b99e5?w=1920',
      'https://images.unsplash.com/photo-1520034475321-cbe63696469a?w=1920',
      'https://images.unsplash.com/photo-1579487785973-74d2ca7abdd5?w=1920',
      'https://images.unsplash.com/photo-1610296669228-602fa827fc1f?w=1920',
    ],
  },
  {
    id: 'abstract', name: 'Art Abstrait', price: 60, icon: '🎨',
    description: '18 fonds d\'écran designs artistiques et abstraits modernes',
    color: 'from-pink-400 to-rose-600',
    preview: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=400',
    wallpapers: [
      'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=1920',
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920',
      'https://images.unsplash.com/photo-1500462918059-b1a0e5145009?w=1920',
      'https://images.unsplash.com/photo-1524230572899-a752b3835840?w=1920',
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920',
      'https://images.unsplash.com/photo-1550537687-c91072c4792d?w=1920',
      'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1920',
      'https://images.unsplash.com/photo-1518655048521-f130df041f66?w=1920',
      'https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=1920',
      'https://images.unsplash.com/photo-1504197832061-98fedfe7b734?w=1920',
      'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1920',
      'https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1920',
      'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920',
      'https://images.unsplash.com/photo-1507908708918-778587c9e563?w=1920',
      'https://images.unsplash.com/photo-1494472155656-f34e81b17ddc?w=1920',
      'https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=1920',
      'https://images.unsplash.com/photo-1567359781514-3b964e2b04d6?w=1920',
      'https://images.unsplash.com/photo-1557683311-eac922347aa1?w=1920',
    ],
  },
  {
    id: 'city', name: 'Villes & Architecture', price: 70, icon: '🏙️',
    description: '22 fonds d\'écran de métropoles du monde entier',
    color: 'from-slate-500 to-gray-700',
    preview: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400',
    wallpapers: [
      'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1920',
      'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=1920',
      'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=1920',
      'https://images.unsplash.com/photo-1444723121867-7a241cacace9?w=1920',
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920',
      'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?w=1920',
      'https://images.unsplash.com/photo-1534430480872-3498386e7856?w=1920',
      'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=1920',
      'https://images.unsplash.com/photo-1490750967868-88df5691cc28?w=1920',
      'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=1920',
      'https://images.unsplash.com/photo-1532509853700-a257a45de80b?w=1920',
      'https://images.unsplash.com/photo-1496568816309-51d7c20e3b21?w=1920',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1920',
      'https://images.unsplash.com/photo-1471874708880-ea8f82c5bf12?w=1920',
      'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1920',
      'https://images.unsplash.com/photo-1543716091-a840c05249ec?w=1920',
      'https://images.unsplash.com/photo-1555680202-c86f0e12f086?w=1920',
      'https://images.unsplash.com/photo-1541336032412-2048a678540d?w=1920',
      'https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1920',
      'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=1920',
      'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=1920',
      'https://images.unsplash.com/photo-1471017851983-fc28bf1c756e?w=1920',
    ],
  },
  {
    id: 'minimal', name: 'Minimaliste', price: 40, icon: '◻️',
    description: '15 fonds d\'écran épurés pour un bureau zen',
    color: 'from-gray-300 to-gray-500',
    preview: 'https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=400',
    wallpapers: [
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920',
      'https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=1920',
      'https://images.unsplash.com/photo-1557683311-eac922347aa1?w=1920',
      'https://images.unsplash.com/photo-1540206395-68808572332f?w=1920',
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1920',
      'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=1920',
      'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=1920',
      'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?w=1920',
      'https://images.unsplash.com/photo-1490730141103-6cac27aaab94?w=1920',
      'https://images.unsplash.com/photo-1446771778853-e6a3d2ea1d67?w=1920',
      'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=1920',
      'https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=1920',
      'https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3?w=1920',
      'https://images.unsplash.com/photo-1497002961800-ea7dbfe18696?w=1920',
    ],
  },
  {
    id: 'animals', name: 'Animaux', price: 55, icon: '🦁',
    description: '20 fonds d\'écran animaux sauvages en gros plan',
    color: 'from-amber-400 to-orange-600',
    preview: 'https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=400',
    wallpapers: [
      'https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=1920',
      'https://images.unsplash.com/photo-1474511320723-9a56873867b5?w=1920',
      'https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?w=1920',
      'https://images.unsplash.com/photo-1504173010664-32509107de5f?w=1920',
      'https://images.unsplash.com/photo-1564349683136-77e08dba1ef7?w=1920',
      'https://images.unsplash.com/photo-1503066211613-c17ebc9daef0?w=1920',
      'https://images.unsplash.com/photo-1549480017-d76466a4b7e8?w=1920',
      'https://images.unsplash.com/photo-1471017851983-fc28bf1c756e?w=1920',
      'https://images.unsplash.com/photo-1459262838948-3e2de6c1ec80?w=1920',
      'https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?w=1920',
      'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?w=1920',
      'https://images.unsplash.com/photo-1550358864-518f202c02ba?w=1920',
      'https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?w=1920',
      'https://images.unsplash.com/photo-1520443240718-fce21901db79?w=1920',
      'https://images.unsplash.com/photo-1534802046520-4f27db7f3ae5?w=1920',
      'https://images.unsplash.com/photo-1551085254-e96b210db58a?w=1920',
      'https://images.unsplash.com/photo-1494947665470-20322015e3a8?w=1920',
      'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=1920',
      'https://images.unsplash.com/photo-1425082661705-1834bfd09dca?w=1920',
      'https://images.unsplash.com/photo-1567608346757-9cac2f6f2af3?w=1920',
    ],
  },
];

const STYLE_PRESETS = [
  { id: 'photorealist', label: 'Photoréaliste', icon: '📷' },
  { id: 'anime', label: 'Anime / Manga', icon: '✨' },
  { id: 'oil', label: 'Peinture à l\'huile', icon: '🖼️' },
  { id: 'neon', label: 'Néon / Cyberpunk', icon: '🔮' },
  { id: 'watercolor', label: 'Aquarelle', icon: '🎨' },
  { id: 'minimal', label: 'Minimaliste', icon: '◼️' },
];

const STYLE_LABELS = {
  photorealist: 'photorealistic, high detail, 4K wallpaper',
  anime: 'anime style, vibrant colors, manga art, wallpaper',
  oil: 'oil painting style, artistic, textured, wallpaper',
  neon: 'neon lights, cyberpunk, dark background, glowing effects, wallpaper',
  watercolor: 'watercolor painting, soft colors, artistic, wallpaper',
  minimal: 'minimalist, clean, simple shapes, wallpaper',
};

const AI_GENERATION_COST = 10;

export default function WallpaperTab({ user, userTokens, onTokensUpdate }) {
  const [purchasedPacks, setPurchasedPacks] = useState([]);
  const [previewPack, setPreviewPack] = useState(null);
  const [appliedWallpaper, setAppliedWallpaper] = useState(() => localStorage.getItem('mykel_wallpaper') || null);
  const [aiTab, setAiTab] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('photorealist');
  const [generating, setGenerating] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState(null);
  const [generatedWallpapers, setGeneratedWallpapers] = useState(() => {
    try { return JSON.parse(localStorage.getItem('mykel_generated_wallpapers') || '[]'); } catch { return []; }
  });

  useEffect(() => {
    if (user?.email) {
      try {
        const stored = localStorage.getItem(`wallpaper_packs_${user.email}`);
        if (stored) setPurchasedPacks(JSON.parse(stored));
      } catch {}
    }
  }, [user]);

  const handleBuyPack = async (pack) => {
    if (!user || !userTokens) return;
    if (userTokens.tokens < pack.price) {
      toast.error(`Jetons insuffisants. Il vous faut ${pack.price} jetons.`);
      return;
    }
    await base44.entities.UserTokens.update(userTokens.id, { tokens: userTokens.tokens - pack.price });
    const newPurchased = [...purchasedPacks, pack.id];
    setPurchasedPacks(newPurchased);
    localStorage.setItem(`wallpaper_packs_${user.email}`, JSON.stringify(newPurchased));
    toast.success(`Pack "${pack.name}" débloqué ! ${pack.wallpapers.length} fonds d'écran disponibles.`);
    onTokensUpdate();
  };

  const handleApplyWallpaper = (url) => {
    localStorage.setItem('mykel_wallpaper', url);
    setAppliedWallpaper(url);
    window.dispatchEvent(new CustomEvent('wallpaper-change', { detail: { url } }));
    toast.success('Fond d\'écran appliqué !');
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) { toast.error('Entrez une description'); return; }
    if (!userTokens || userTokens.tokens < AI_GENERATION_COST) {
      toast.error(`Il vous faut au moins ${AI_GENERATION_COST} jetons.`);
      return;
    }
    setGenerating(true);
    setGeneratedUrl(null);
    try {
      const fullPrompt = `${prompt}, ${STYLE_LABELS[selectedStyle]}, wide 16:9 desktop wallpaper, ultra high quality`;
      const result = await freeGenerateImage({ prompt: fullPrompt, width: 1920, height: 1080 });
      setGeneratedUrl(result.url);
      await base44.entities.UserTokens.update(userTokens.id, { tokens: Math.max(0, userTokens.tokens - AI_GENERATION_COST) });
      onTokensUpdate();
    } catch {
      toast.error('Erreur lors de la génération');
    } finally {
      setGenerating(false);
    }
  };

  const saveAndApply = (url) => {
    const updated = [url, ...generatedWallpapers].slice(0, 20);
    setGeneratedWallpapers(updated);
    localStorage.setItem('mykel_generated_wallpapers', JSON.stringify(updated));
    handleApplyWallpaper(url);
  };

  return (
    <div>
      {/* Sub-tabs */}
      <div className="flex gap-2 mb-6 bg-gray-100 rounded-xl p-1 w-fit">
        <button
          onClick={() => setAiTab(false)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${!aiTab ? 'bg-white shadow-sm text-gray-900' : 'text-gray-600 hover:text-gray-900'}`}
        >
          <Image className="w-4 h-4" /> Packs
        </button>
        <button
          onClick={() => setAiTab(true)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${aiTab ? 'bg-white shadow-sm text-gray-900' : 'text-gray-600 hover:text-gray-900'}`}
        >
          <Wand2 className="w-4 h-4" /> Générer avec l'IA
        </button>
      </div>

      {/* Current wallpaper banner */}
      {appliedWallpaper && (
        <div className="mb-6 bg-white rounded-2xl border border-violet-200 p-4 flex items-center gap-4 shadow-sm">
          <img src={appliedWallpaper} alt="Fond actuel" className="w-20 h-12 rounded-lg object-cover flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900">Fond d'écran actif</p>
          </div>
          <Button size="sm" variant="outline" className="text-red-500 border-red-200 hover:bg-red-50 flex-shrink-0" onClick={() => {
            localStorage.removeItem('mykel_wallpaper');
            setAppliedWallpaper(null);
            window.dispatchEvent(new CustomEvent('wallpaper-change', { detail: { url: null } }));
            toast.success('Fond d\'écran retiré');
          }}>
            Retirer
          </Button>
        </div>
      )}

      {!aiTab && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {WALLPAPER_PACKS.map(pack => {
            const owned = purchasedPacks.includes(pack.id);
            return (
              <div key={pack.id} className="bg-white rounded-2xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="relative h-40 overflow-hidden">
                  <img src={pack.preview} alt={pack.name} className="w-full h-full object-cover" />
                  <div className={`absolute inset-0 bg-gradient-to-t ${pack.color} opacity-30`} />
                  <div className="absolute top-3 left-3 text-2xl">{pack.icon}</div>
                  <div className="absolute bottom-2 right-2 bg-black/50 text-white text-xs rounded-full px-2 py-0.5 font-medium">
                    {pack.wallpapers.length} fonds
                  </div>
                  {owned && (
                    <div className="absolute top-3 right-3 bg-green-500 text-white rounded-full p-1">
                      <Check className="w-4 h-4" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-900 mb-1">{pack.name}</h3>
                  <p className="text-xs text-gray-500 mb-3">{pack.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400 font-medium">{pack.wallpapers.length} fonds d'écran</span>
                    {owned ? (
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white gap-1.5" onClick={() => setPreviewPack({ pack, index: 0 })}>
                        <Image className="w-3.5 h-3.5" /> Voir & Appliquer
                      </Button>
                    ) : (
                      <Button size="sm" className="gap-1.5" onClick={() => handleBuyPack(pack)} disabled={!userTokens || userTokens.tokens < pack.price}>
                        🪙 {pack.price} jetons
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {aiTab && (
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center">
                <Wand2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900">Générateur IA</h2>
                <p className="text-xs text-gray-500">Coût : {AI_GENERATION_COST} jetons par génération</p>
              </div>
              <div className="ml-auto text-sm font-semibold text-amber-600">🪙 {userTokens?.tokens || 0}</div>
            </div>

            <div className="mb-5">
              <label className="text-sm font-medium text-gray-700 mb-3 block">Style artistique</label>
              <div className="grid grid-cols-3 gap-2">
                {STYLE_PRESETS.map(s => (
                  <button key={s.id} onClick={() => setSelectedStyle(s.id)}
                    className={`flex flex-col items-center gap-1 py-3 px-2 rounded-xl border-2 transition-all text-sm ${selectedStyle === s.id ? 'border-violet-500 bg-violet-50 text-violet-700' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}>
                    <span className="text-xl">{s.icon}</span>
                    <span className="text-xs font-medium">{s.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-5">
              <label className="text-sm font-medium text-gray-700 mb-2 block">Description</label>
              <textarea
                className="w-full rounded-xl border border-gray-200 bg-gray-50 text-gray-900 p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-violet-500"
                rows={3}
                placeholder="Ex: Une forêt enchantée avec des lucioles, ambiance mystique, lumière dorée..."
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
              />
            </div>

            <Button onClick={handleGenerate} disabled={generating || !prompt.trim() || (userTokens?.tokens || 0) < AI_GENERATION_COST}
              className="w-full bg-gradient-to-r from-violet-600 to-purple-700 text-white gap-2">
              {generating ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération...</> : <><Sparkles className="w-4 h-4" /> Générer (🪙 {AI_GENERATION_COST})</>}
            </Button>

            {generatedUrl && (
              <div className="mt-6">
                <div className="rounded-xl overflow-hidden border border-gray-200 mb-3">
                  <img src={generatedUrl} alt="Généré" className="w-full object-cover" />
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1 bg-violet-600 hover:bg-violet-700 text-white gap-2" onClick={() => saveAndApply(generatedUrl)}>
                    <Check className="w-4 h-4" /> Appliquer & Sauvegarder
                  </Button>
                  <Button variant="outline" onClick={() => window.open(generatedUrl, '_blank')}>
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Pack preview modal */}
      {previewPack && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setPreviewPack(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <div>
                <h3 className="font-bold text-gray-900">{previewPack.pack.name}</h3>
                <p className="text-xs text-gray-500">{previewPack.index + 1} / {previewPack.pack.wallpapers.length} fonds</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setPreviewPack(null)}><X className="w-5 h-5" /></Button>
            </div>
            <div className="p-4">
              <div className="rounded-xl overflow-hidden mb-4 bg-gray-100">
                <img src={previewPack.pack.wallpapers[previewPack.index]} alt="Aperçu" className="w-full max-h-64 object-cover" />
              </div>
              <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
                {previewPack.pack.wallpapers.map((url, i) => (
                  <img key={i} src={url} alt={`${i + 1}`}
                    className={`w-16 h-10 object-cover rounded-lg flex-shrink-0 cursor-pointer transition-all ${previewPack.index === i ? 'ring-2 ring-violet-500' : 'opacity-60 hover:opacity-100'}`}
                    onClick={() => setPreviewPack(p => ({ ...p, index: i }))}
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <Button className="flex-1 bg-violet-600 hover:bg-violet-700 text-white gap-2" onClick={() => {
                  handleApplyWallpaper(previewPack.pack.wallpapers[previewPack.index]);
                  setPreviewPack(null);
                }}>
                  <Check className="w-4 h-4" /> Appliquer ce fond d'écran
                </Button>
                <Button variant="outline" onClick={() => window.open(previewPack.pack.wallpapers[previewPack.index], '_blank')}>
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}