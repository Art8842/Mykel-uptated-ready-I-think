import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ChevronRight, Check, Building2, HardDrive, Wand2, Users } from 'lucide-react';
import { toast } from 'sonner';
import { getMykelSession } from '@/lib/mykelSession';

const SUBSCRIPTION_OPTIONS = [
  { type: 'ia_premium', label: 'Mykel IA Premium', price: 25 },
  { type: 'ia_max', label: 'Mykel IA Max', price: 150 },
  { type: 'tv_ads', label: 'Mykel TV (avec pubs)', price: 10 },
  { type: 'tv_premium', label: 'Mykel TV Premium', price: 15 },
  { type: 'tv_plus', label: 'Mykel TV+', price: 20 },
  { type: 'music_premium', label: 'Mykel Music Premium', price: 2 },
];

const SNAPFIX_PRICE = 5;
const STORAGE_PRICE_PER_GB = 1;

const getVolumeDiscount = (n) => {
  if (n >= 51) return 0.25;
  if (n >= 26) return 0.20;
  if (n >= 11) return 0.15;
  if (n >= 6) return 0.10;
  if (n >= 1) return 0.05;
  return 0;
};

export default function BusinessWizard({ open, onClose, user, onCreated }) {
  const [step, setStep] = useState(1);
  const [companyName, setCompanyName] = useState('');
  const [storageGb, setStorageGb] = useState(50);
  const [includesSnapfix, setIncludesSnapfix] = useState(false);
  const [includedSubs, setIncludedSubs] = useState([]);
  const [numAccounts, setNumAccounts] = useState(5);
  const [creating, setCreating] = useState(false);

  const storageCost = storageGb * STORAGE_PRICE_PER_GB;
  const snapfixCost = includesSnapfix ? SNAPFIX_PRICE : 0;
  const subsCost = includedSubs.reduce((sum, type) => {
    const sub = SUBSCRIPTION_OPTIONS.find(s => s.type === type);
    return sum + (sub?.price || 0);
  }, 0);
  const perAccount = storageCost + snapfixCost + subsCost;
  const subtotal = perAccount * numAccounts;
  const discount = getVolumeDiscount(numAccounts);
  const discountAmount = Math.round(subtotal * discount);
  const totalPrice = subtotal - discountAmount;

  const toggleSub = (type) => {
    setIncludedSubs(prev => prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]);
  };

  const handleCreate = async () => {
    setCreating(true);
    try {
      const email = user?.email || getMykelSession()?.email;
      if (!email) { toast.error('Non connecté'); return; }

      const inviteToken = crypto.randomUUID();
      await base44.entities.BusinessSubscription.create({
        company_name: companyName,
        admin_email: email,
        storage_gb: storageGb,
        includes_snapfix: includesSnapfix,
        included_subscriptions: includedSubs,
        num_accounts: numAccounts,
        monthly_price: totalPrice,
        invite_token: inviteToken,
        active: true,
        member_emails: [email],
      });
      toast.success('Abonnement Mykel Business créé !');
      onCreated();
      handleClose();
    } catch (e) {
      console.error(e);
      toast.error('Erreur lors de la création');
    } finally {
      setCreating(false);
    }
  };

  const handleClose = () => {
    setStep(1);
    setCompanyName('');
    setStorageGb(50);
    setIncludesSnapfix(false);
    setIncludedSubs([]);
    setNumAccounts(5);
    onClose();
  };

  const steps = [1, 2, 3, 4, 5, 6];

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-white dark:bg-gray-900 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Mykel Business — Étape {step}/6</DialogTitle>
        </DialogHeader>

        {/* Progress dots */}
        <div className="flex gap-1.5 mb-4">
          {steps.map(s => (
            <div key={s} className={`h-1.5 flex-1 rounded-full ${s <= step ? 'bg-blue-600' : 'bg-gray-200'}`} />
          ))}
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Nom de l'entreprise</h3>
                <p className="text-xs text-gray-500">Comment s'appelle votre entreprise ?</p>
              </div>
            </div>
            <Input
              placeholder="Ex: Tech Corp SA"
              value={companyName}
              onChange={e => setCompanyName(e.target.value)}
              autoFocus
            />
            <DialogFooter>
              <Button variant="outline" onClick={handleClose}>Annuler</Button>
              <Button onClick={() => setStep(2)} disabled={!companyName.trim()} className="gap-2">
                Suivant <ChevronRight className="w-4 h-4" />
              </Button>
            </DialogFooter>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <HardDrive className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Stockage par compte</h3>
                <p className="text-xs text-gray-500">Combien de Go de stockage pour chaque employé ?</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Input type="number" min="0" value={storageGb} onChange={e => setStorageGb(parseInt(e.target.value) || 0)} />
              <span className="text-sm text-gray-500">Go / mois</span>
            </div>
            <p className="text-sm text-gray-500">Coût : {storageCost} jetons/compte/mois</p>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStep(1)}>Retour</Button>
              <Button onClick={() => setStep(3)} className="gap-2">Suivant <ChevronRight className="w-4 h-4" /></Button>
            </DialogFooter>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center">
                <Wand2 className="w-5 h-5 text-cyan-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Mykel SnapFix</h3>
                <p className="text-xs text-gray-500">Inclure Mykel SnapFix pour les employés ?</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700">
              <input type="checkbox" id="snapfix" checked={includesSnapfix} onChange={e => setIncludesSnapfix(e.target.checked)} className="w-4 h-4" />
              <label htmlFor="snapfix" className="text-sm cursor-pointer">
                Inclure SnapFix ({SNAPFIX_PRICE} jetons/compte/mois)
              </label>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStep(2)}>Retour</Button>
              <Button onClick={() => setStep(4)} className="gap-2">Suivant <ChevronRight className="w-4 h-4" /></Button>
            </DialogFooter>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                <Check className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Abonnements inclus</h3>
                <p className="text-xs text-gray-500">Quels abonnements inclure pour les employés ?</p>
              </div>
            </div>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {SUBSCRIPTION_OPTIONS.map(sub => (
                <div key={sub.type} onClick={() => toggleSub(sub.type)}
                  className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${includedSubs.includes(sub.type) ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50'}`}>
                  <div>
                    <p className="font-medium text-sm text-gray-900 dark:text-white">{sub.label}</p>
                    <p className="text-xs text-gray-500">{sub.price} jetons/compte/mois</p>
                  </div>
                  {includedSubs.includes(sub.type) && <Check className="w-4 h-4 text-blue-600" />}
                </div>
              ))}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStep(3)}>Retour</Button>
              <Button onClick={() => setStep(5)} className="gap-2">Suivant <ChevronRight className="w-4 h-4" /></Button>
            </DialogFooter>
          </div>
        )}

        {step === 5 && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                <Users className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Nombre de comptes</h3>
                <p className="text-xs text-gray-500">Combien d'employés auront accès aux avantages ?</p>
              </div>
            </div>
            <Input type="number" min="1" value={numAccounts} onChange={e => setNumAccounts(Math.max(1, parseInt(e.target.value) || 1))} />
            <p className="text-sm text-gray-500">Réduction volume : {Math.round(discount * 100)}%</p>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStep(4)}>Retour</Button>
              <Button onClick={() => setStep(6)} className="gap-2">Suivant <ChevronRight className="w-4 h-4" /></Button>
            </DialogFooter>
          </div>
        )}

        {step === 6 && (
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 dark:text-white">Récapitulatif</h3>
            <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Entreprise</span><span className="font-medium text-gray-900 dark:text-white">{companyName}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Stockage</span><span className="text-gray-900 dark:text-white">{storageGb} Go/compte</span></div>
              <div className="flex justify-between"><span className="text-gray-500">SnapFix</span><span className="text-gray-900 dark:text-white">{includesSnapfix ? 'Oui' : 'Non'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Abonnements</span><span className="text-gray-900 dark:text-white">{includedSubs.length} inclus</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Comptes</span><span className="text-gray-900 dark:text-white">{numAccounts}</span></div>
              <div className="border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                <div className="flex justify-between"><span className="text-gray-500">Coût/compte/mois</span><span className="text-gray-900 dark:text-white">{perAccount} j</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Sous-total</span><span className="text-gray-900 dark:text-white">{subtotal} j</span></div>
                <div className="flex justify-between text-green-600"><span>Réduction ({Math.round(discount * 100)}%)</span><span>−{discountAmount} j</span></div>
                <div className="flex justify-between text-base font-bold mt-1"><span className="text-gray-900 dark:text-white">Total/mois</span><span className="text-blue-600">{totalPrice} jetons</span></div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStep(5)}>Retour</Button>
              <Button onClick={handleCreate} disabled={creating} className="gap-2 bg-blue-600 hover:bg-blue-700">
                {creating ? 'Création...' : <><Check className="w-4 h-4" /> Valider et créer</>}
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}