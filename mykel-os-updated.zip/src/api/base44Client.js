import { createClient } from '@base44/sdk';
import { appParams } from '@/lib/app-params';

const { appId, token, functionsVersion, appBaseUrl } = appParams;

const rawClient = createClient({
  appId,
  token,
  functionsVersion,
  serverUrl: '',
  requiresAuth: false,
  appBaseUrl
});

// ── Garde globale contre l'expiration du token Base44 ──
// L'app garde une session Mykel de 30 jours, mais le token Base44 expire
// indépendamment. Quand il expire, l'utilisateur paraît connecté mais
// chaque écriture en base échoue (« Erreur lors de l'enregistrement »).
// On intercepte le 401 sur n'importe quel appel d'entité et on force une
// reconnexion propre.
let _redirecting = false;
function _onAuthExpired() {
  if (_redirecting) return;
  _redirecting = true;
  try {
    localStorage.removeItem('mykel_session');
    localStorage.removeItem('base44_access_token');
    localStorage.removeItem('token');
  } catch {}
  window.location.href = '/MykelLogin';
}

function _wrap(p) {
  if (!p || typeof p?.then !== 'function') return p;
  return p.catch((err) => {
    const status = err?.status ?? err?.response?.status;
    if (status === 401) _onAuthExpired();
    throw err;
  });
}

function _proxyEntity(entity) {
  if (!entity || typeof entity !== 'object') return entity;
  return new Proxy(entity, {
    get(target, prop) {
      const val = target[prop];
      if (typeof val !== 'function') return val;
      return (...args) => _wrap(val.apply(target, args));
    },
  });
}

export const base44 = new Proxy(rawClient, {
  get(target, prop) {
    if (prop === 'entities' && target.entities && typeof target.entities === 'object') {
      return new Proxy(target.entities, {
        get(entTarget, entName) {
          return _proxyEntity(entTarget[entName]);
        },
      });
    }
    return target[prop];
  },
});