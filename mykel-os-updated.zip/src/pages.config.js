/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AdminAds from './pages/AdminAds';
import RemoveBG from './pages/RemoveBG';
import AdminPanel from './pages/AdminPanel';
import Dashboard from './pages/Dashboard';
import MykelIA from './pages/MykelIA';
import MykelMusic from './pages/MykelMusic';
import Mykel3D from './pages/Mykel3D';
import MykelDraws from './pages/MykelDraws';
import MykelSliders from './pages/MykelSliders';
import MykelStore from './pages/MykelStore';
import MykelTabs from './pages/MykelTabs';
import MykelWord from './pages/MykelWord';
import ReportBug from './pages/ReportBug';
import Users from './pages/Users';
import MykelMusicCreator from './pages/MykelMusicCreator';
import MykelSearch from './pages/MykelSearch';
import MykelChat from './pages/MykelChat';
import MykelTV from './pages/MykelTV';
import PlaylistView from './pages/PlaylistView';
import MykelSnapFix from './pages/MykelSnapFix';
import MykelEdiCode from './pages/MykelEdiCode';
import MykelWhiteboard from './pages/MykelWhiteboard';
import BusinessManage from './pages/BusinessManage';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AdminAds": AdminAds,
    "Dashboard": Dashboard,
    "MykelIA": MykelIA,
    "MykelMusic": MykelMusic,
    "Mykel3D": Mykel3D,
    "MykelDraws": MykelDraws,
    "MykelSliders": MykelSliders,
    "MykelStore": MykelStore,
    "MykelTabs": MykelTabs,
    "MykelWord": MykelWord,
    "ReportBug": ReportBug,
    "Users": Users,
    "RemoveBG": RemoveBG,
    "AdminPanel": AdminPanel,
    "MykelMusicCreator": MykelMusicCreator,
    "MykelSearch": MykelSearch,
    "MykelChat": MykelChat,
    "MykelTV": MykelTV,
    "PlaylistView": PlaylistView,
    "MykelSnapFix": MykelSnapFix,
    "MykelEdiCode": MykelEdiCode,
    "MykelWhiteboard": MykelWhiteboard,
    "BusinessManage": BusinessManage,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};