import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  ArrowLeft, Save, Code2, Sparkles, Loader2, Edit, Eye, FolderTree, X,
} from 'lucide-react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "@/components/ui/sheet";
import { toast } from 'sonner';
import { isAIDisabled } from '@/lib/aiSettings';
import { promptAction } from '@/lib/confirm';
import CodeArea from '@/components/edicode/CodeArea';
import PreviewFrame from '@/components/edicode/PreviewFrame';
import FileExplorer from '@/components/edicode/FileExplorer';
import AIChatPanel from '@/components/edicode/AIChatPanel';
import SaveStatus from '@/components/shared/SaveStatus';
import useAutoSave from '@/hooks/useAutoSave';

const detectLanguage = (name) => {
  const ext = (name || '').split('.').pop().toLowerCase();
  const map = {
    html: 'html', htm: 'html', css: 'css', js: 'javascript', jsx: 'javascript',
    ts: 'typescript', tsx: 'typescript', py: 'python', json: 'json',
    md: 'markdown', txt: 'plaintext', xml: 'xml', yaml: 'yaml', yml: 'yaml',
    sql: 'sql', sh: 'bash', php: 'php', rb: 'ruby', go: 'go', rs: 'rust',
    java: 'java', c: 'c', cpp: 'cpp', cs: 'csharp', swift: 'swift', kt: 'kotlin'
  };
  return map[ext] || 'plaintext';
};

const toPayload = (p) => ({
  name: `EdiCode — ${p.name}`,
  content: { app: 'MykelEdiCode', projectName: p.name, files: p.files, folders: p.folders || [], activeFileId: p.activeFileId },
});

let fileCounter = 0;
const genFileId = () => `f${Date.now()}_${fileCounter++}`;

const DEFAULT_HTML = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mon Projet</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Bonjour Monde</h1>
  <p>Bienvenue dans mon projet EdiCode !</p>
  <script src="script.js"></script>
</body>
</html>`;

export default function MykelEdiCode() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [mode, setMode] = useState('editor');
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [newName, setNewName] = useState('');
  const [showAI, setShowAI] = useState(false);
  const [showFilesMobile, setShowFilesMobile] = useState(false);
  const aiDisabled = isAIDisabled();
  const autoSave = useAutoSave(project?.fileId, { delay: 2000 });
  const saving = autoSave.status === 'saving';

  useEffect(() => {
    if (aiDisabled) setShowAI(false);
  }, [aiDisabled]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const fileId = params.get('fileId');
    if (fileId) {
      loadProject(fileId);
    } else {
      setShowNewDialog(true);
      setLoading(false);
    }
  }, []);

  const loadProject = async (fileId) => {
    try {
      const file = await base44.entities.CloudFile.get(fileId);
      if (file?.content?.app === 'MykelEdiCode') {
        const rawFiles = file.content.files || [];
        const files = rawFiles.map(f => ({
          ...f,
          path: f.path || f.name || 'fichier.txt',
          language: f.language || detectLanguage(f.path || f.name || 'fichier.txt'),
        }));
        const folders = file.content.folders || [];
        const defaultFiles = files.length > 0
          ? files
          : [{ id: genFileId(), path: 'index.html', language: 'html', code: DEFAULT_HTML }];
        const loaded = {
          fileId: file.id,
          name: file.content.projectName || 'Mon projet',
          files: defaultFiles,
          folders,
          activeFileId: file.content.activeFileId || defaultFiles[0].id,
        };
        autoSave.setBaseline(toPayload(loaded));
        setProject(loaded);
        if (!aiDisabled) setShowAI(true);
      } else {
        setShowNewDialog(true);
      }
    } catch {
      toast.error('Erreur lors du chargement du projet');
      setShowNewDialog(true);
    }
    setLoading(false);
  };

  const createProject = async () => {
    if (!newName.trim()) { toast.error('Donnez un nom à votre projet'); return; }
    try {
      const defaultFiles = [{ id: genFileId(), path: 'index.html', language: 'html', code: DEFAULT_HTML }];
      const file = await base44.entities.CloudFile.create({
        name: `EdiCode — ${newName.trim()}`,
        type: 'other',
        content: { app: 'MykelEdiCode', projectName: newName.trim(), files: defaultFiles, folders: [], activeFileId: defaultFiles[0].id },
        is_starred: false, is_trashed: false,
      });
      const created = { fileId: file.id, name: newName.trim(), files: defaultFiles, folders: [], activeFileId: defaultFiles[0].id };
      autoSave.setBaseline(toPayload(created));
      setProject(created);
      setShowNewDialog(false);
      setNewName('');
      navigate(`/MykelEdiCode?fileId=${file.id}`, { replace: true });
      if (!aiDisabled) setShowAI(true);
    } catch {
      toast.error('Erreur lors de la création du projet');
    }
  };

  // Sauvegarde automatique : uniquement quand le projet change
  useEffect(() => {
    if (project) autoSave.queue(toPayload(project));
  }, [project]);

  const saveProject = async () => {
    if (!project) return;
    autoSave.queue(toPayload(project));
    if (await autoSave.saveNow()) toast.success('Projet enregistré');
  };

  const activeFile = project?.files?.find(f => f.id === project.activeFileId) || project?.files?.[0];

  const updateActiveFileCode = (code) => {
    setProject(prev => ({
      ...prev,
      files: prev.files.map(f => f.id === activeFile.id ? { ...f, code } : f),
    }));
  };

  const handleAddFile = async () => {
    const path = await promptAction({ title: 'Nouveau fichier', placeholder: 'ex: index.html, src/app.js', confirmLabel: 'Ajouter' });
    if (!path) return;
    const cleanPath = path.trim().replace(/^\/+/, '');
    if (!cleanPath) return;
    if (project.files.some(f => f.path === cleanPath)) { toast.error('Ce fichier existe déjà'); return; }
    const newFile = { id: genFileId(), path: cleanPath, language: detectLanguage(cleanPath), code: '' };
    setProject(prev => ({ ...prev, files: [...prev.files, newFile], activeFileId: newFile.id }));
  };

  const handleAddFolder = async () => {
    const path = await promptAction({ title: 'Nouveau dossier', placeholder: 'ex: src, src/components', confirmLabel: 'Créer' });
    if (!path) return;
    const cleanPath = path.trim().replace(/^\/+/, '').replace(/\/+$/, '');
    if (!cleanPath) return;
    if ((project.folders || []).some(f => f.path === cleanPath)) { toast.error('Ce dossier existe déjà'); return; }
    setProject(prev => ({ ...prev, folders: [...(prev.folders || []), { id: genFileId(), path: cleanPath }] }));
  };

  const handleDeleteFile = (fileId) => {
    setProject(prev => {
      const newFiles = prev.files.filter(f => f.id !== fileId);
      const newActiveId = prev.activeFileId === fileId ? (newFiles[0]?.id || null) : prev.activeFileId;
      return { ...prev, files: newFiles, activeFileId: newActiveId };
    });
  };

  const applyAIActions = (actions) => {
    setProject(prev => {
      let files = [...prev.files];
      let folders = [...(prev.folders || [])];
      for (const action of actions) {
        const path = (action.path || '').trim().replace(/^\/+/, '');
        if (!path) continue;
        if (action.type === 'create' || action.type === 'modify') {
          const existing = files.find(f => f.path === path);
          if (existing) {
            files = files.map(f => f.path === path ? { ...f, code: action.content || '' } : f);
          } else {
            files = [...files, { id: genFileId(), path, language: detectLanguage(path), code: action.content || '' }];
          }
        } else if (action.type === 'delete') {
          files = files.filter(f => f.path !== path);
          folders = folders.filter(f => f.path !== path);
        } else if (action.type === 'create_folder') {
          if (!folders.some(f => f.path === path)) {
            folders = [...folders, { id: genFileId(), path }];
          }
        }
      }
      const activeFileId = files.find(f => f.id === prev.activeFileId) ? prev.activeFileId : (files[0]?.id || null);
      return { ...prev, files, folders, activeFileId };
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  if (showNewDialog) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
        <div className="bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md border border-white/10 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center">
              <Code2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Nouveau projet EdiCode</h2>
              <p className="text-sm text-white/50">Donnez un nom à votre projet</p>
            </div>
          </div>
          <Input
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && createProject()}
            placeholder="Mon super projet"
            className="bg-gray-800 border-gray-700 text-white mb-4"
            autoFocus
          />
          <div className="flex gap-2">
            <Button variant="ghost" className="flex-1 text-white/70 hover:bg-white/10" onClick={() => navigate('/Dashboard')}>Annuler</Button>
            <Button onClick={createProject} className="flex-1 bg-emerald-600 hover:bg-emerald-500">Créer le projet</Button>
          </div>
        </div>
      </div>
    );
  }

  if (!project) return null;

  return (
    <div className="h-screen bg-gray-950 flex flex-col text-white">
      {/* Top Bar */}
      <div className="h-12 bg-gray-900 border-b border-white/10 flex items-center gap-2 px-3 flex-shrink-0">
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-8 w-8" onClick={() => navigate('/Dashboard')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="w-7 h-7 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
          <Code2 className="w-4 h-4 text-white" />
        </div>
        <span className="font-bold text-sm truncate">{project.name}</span>
        <span className="hidden sm:inline"><SaveStatus status={autoSave.status} lastSaved={autoSave.lastSaved} dark /></span>

        <div className="flex-1" />

        {!aiDisabled && (
          <Button variant="ghost" size="sm" className={`text-xs h-8 gap-1.5 ${showAI ? 'bg-purple-600/20 text-purple-400' : 'text-white/60 hover:bg-white/10'}`} onClick={() => setShowAI(o => !o)}>
            <Sparkles className="w-3.5 h-3.5" /> IA
          </Button>
        )}
        <Button variant="ghost" size="sm" className={`text-xs h-8 gap-1.5 ${mode === 'editor' ? 'bg-emerald-600/20 text-emerald-400' : 'text-white/60 hover:bg-white/10'}`} onClick={() => setMode('editor')}>
          <Edit className="w-3.5 h-3.5" /> Éditeur
        </Button>
        <Button variant="ghost" size="sm" className="text-xs h-8 gap-1.5 text-white/60 hover:bg-white/10" onClick={() => setMode('preview')}>
          <Eye className="w-3.5 h-3.5" /> Aperçu
        </Button>

        <Button variant="ghost" size="sm" className="text-xs h-8 gap-1.5 text-white/60 hover:bg-white/10 sm:hidden" onClick={() => setShowFilesMobile(true)}>
          <FolderTree className="w-3.5 h-3.5" /> Fichiers
        </Button>

        <Button onClick={saveProject} disabled={saving} className="bg-emerald-600 hover:bg-emerald-500 h-8 px-3 text-xs gap-1.5">
          {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
          Sauvegarder
        </Button>
      </div>

      {/* Body */}
      {mode === 'preview' ? (
        <div className="flex-1 bg-white">
          <PreviewFrame files={project.files} />
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* File Explorer */}
          <div className="w-56 flex-shrink-0 hidden sm:block">
            <FileExplorer
              files={project.files}
              folders={project.folders}
              activeFileId={activeFile?.id}
              onSelectFile={(id) => setProject(prev => ({ ...prev, activeFileId: id }))}
              onAddFile={handleAddFile}
              onAddFolder={handleAddFolder}
              onDeleteFile={handleDeleteFile}
            />
          </div>

          {/* Editor */}
          <div className="flex-1 flex flex-col overflow-hidden min-w-0">
            {activeFile ? (
              <>
                <CodeArea value={activeFile.code} onChange={updateActiveFileCode} language={activeFile.language} />
                <div className="h-6 bg-gray-900 border-t border-white/10 flex items-center px-3 text-xs text-white/40 gap-4 flex-shrink-0">
                  <span className="truncate">{activeFile.path}</span><span>•</span>
                  <span>{activeFile.language}</span><span>•</span>
                  <span>{activeFile.code.split('\n').length} lignes</span>
                  <div className="flex-1" />
                  <span className="text-emerald-400/50">EdiCode</span>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-white/30 text-sm">
                Sélectionnez un fichier ou créez-en un nouveau
              </div>
            )}
          </div>

          {/* AI Chat Panel - Desktop */}
          {showAI && !aiDisabled && (
            <div className="w-80 flex-shrink-0 hidden md:block">
              <AIChatPanel
                files={project.files}
                folders={project.folders}
                onApplyActions={applyAIActions}
                onClose={() => setShowAI(false)}
              />
            </div>
          )}
        </div>
      )}

      {/* Mobile File Explorer Sheet */}
      <Sheet open={showFilesMobile} onOpenChange={setShowFilesMobile}>
        <SheetContent side="left" className="w-[280px] p-0 bg-gray-900 border-white/10">
          <SheetHeader className="px-4 py-3 border-b border-white/10">
            <SheetTitle className="text-white text-sm">Fichiers du projet</SheetTitle>
          </SheetHeader>
          <div className="h-[calc(100%-3rem)] overflow-auto">
            <FileExplorer
              files={project?.files || []}
              folders={project?.folders || []}
              activeFileId={activeFile?.id}
              onSelectFile={(id) => { setProject(prev => ({ ...prev, activeFileId: id })); setShowFilesMobile(false); }}
              onAddFile={handleAddFile}
              onAddFolder={handleAddFolder}
              onDeleteFile={handleDeleteFile}
            />
          </div>
        </SheetContent>
      </Sheet>

      {/* Mobile AI Chat Overlay */}
      {showAI && !aiDisabled && (
        <div className="md:hidden fixed inset-0 z-50 bg-gray-950 flex flex-col">
          <div className="h-12 bg-gray-900 border-b border-white/10 flex items-center px-3 gap-2 flex-shrink-0">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-8 w-8" onClick={() => setShowAI(false)}>
              <X className="w-4 h-4" />
            </Button>
            <span className="text-white text-sm font-medium flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" /> Assistant IA
            </span>
          </div>
          <div className="flex-1 overflow-hidden">
            <AIChatPanel
              files={project?.files || []}
              folders={project?.folders || []}
              onApplyActions={applyAIActions}
              onClose={() => setShowAI(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}