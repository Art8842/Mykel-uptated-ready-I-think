import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useMeetRoom } from '@/hooks/useMeetRoom';
import VideoTile from '@/components/meet/VideoTile';
import MeetControls from '@/components/meet/MeetControls';
import MykelLogo from '@/components/auth/MykelLogo';
import { Video, Users, ArrowLeft, Plus, LogIn, Loader2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function MykelMeet() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [view, setView] = useState('home'); // 'home' | 'lobby' | 'meeting'
  const [room, setRoom] = useState('');
  const [joinCode, setJoinCode] = useState('');

  useEffect(() => {
    const code = params.get('code');
    if (code) { setRoom(code.toUpperCase()); setView('lobby'); }
    base44.auth.me().then(u => { setUser(u); setAuthChecked(true); }).catch(() => setAuthChecked(true));
  }, []);

  const createRoom = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    setRoom(code);
    setView('lobby');
  };

  const joinRoom = () => {
    if (!joinCode.trim()) return;
    setRoom(joinCode.trim().toUpperCase());
    setView('lobby');
  };

  if (!authChecked) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center p-6">
        <MykelLogo size={40} />
        <p className="mt-6 text-gray-400">Connectez-vous pour utiliser Mykel Meet</p>
        <button
          onClick={() => window.location.href = '/MykelLogin?returnUrl=/MykelMeet'}
          className="mt-4 px-6 py-2.5 rounded-xl text-white font-medium"
          style={{ background: 'linear-gradient(180deg, #3b82f6, #2563eb)' }}
        >
          Se connecter
        </button>
      </div>
    );
  }

  if (view === 'home') {
    return (
      <div className="min-h-screen bg-gray-950 text-white">
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <button onClick={() => navigate('/Dashboard')} className="flex items-center gap-2 text-white/60 hover:text-white">
            <ArrowLeft className="w-5 h-5" /> Retour
          </button>
          <MykelLogo size={32} />
        </div>
        <div className="max-w-md mx-auto px-6 pt-16">
          <div className="text-center mb-10">
            <div className="w-16 h-16 rounded-2xl mx-auto mb-5 flex items-center justify-center"
              style={{ background: 'linear-gradient(180deg, #3b82f6, #2563eb)' }}>
              <Video className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold">Mykel Meet</h1>
            <p className="text-gray-400 mt-2">Visioconférences sécurisées, directement dans Mykel</p>
          </div>
          <div className="space-y-3">
            <button
              onClick={createRoom}
              className="w-full p-5 rounded-2xl text-left transition-all active:scale-[0.98]"
              style={{ background: 'linear-gradient(180deg, #3b82f6, #2563eb)' }}
            >
              <div className="flex items-center gap-3">
                <Plus className="w-6 h-6" />
                <div>
                  <p className="font-semibold text-lg">Nouvelle réunion</p>
                  <p className="text-sm text-blue-100">Créer un lien à partager</p>
                </div>
              </div>
            </button>
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
              <div className="flex items-center gap-3">
                <LogIn className="w-6 h-6 text-gray-400" />
                <input
                  value={joinCode}
                  onChange={e => setJoinCode(e.target.value)}
                  placeholder="Code de réunion"
                  className="flex-1 bg-transparent text-white placeholder:text-gray-500 outline-none uppercase"
                  onKeyDown={e => e.key === 'Enter' && joinRoom()}
                />
                <button
                  onClick={joinRoom}
                  disabled={!joinCode.trim()}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-sm font-medium disabled:opacity-40"
                >
                  Rejoindre
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'lobby') {
    return <Lobby room={room} user={user} onJoin={() => setView('meeting')} onBack={() => { setView('home'); setRoom(''); }} />;
  }

  return (
    <Meeting room={room} user={user} onLeave={() => { setView('home'); setRoom(''); navigate('/MykelMeet'); }} />
  );
}

function Lobby({ room, user, onJoin, onBack }) {
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
      .then(s => setPreview(s))
      .catch(() => setError('Caméra/micro indisponibles — vous pourrez quand même rejoindre.'));
    return () => { preview?.getTracks().forEach(t => t.stop()); };
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col">
      <div className="flex items-center gap-3 p-4 border-b border-white/10">
        <button onClick={onBack} className="text-white/60 hover:text-white"><ArrowLeft className="w-5 h-5" /></button>
        <span className="font-medium">Salle d'attente</span>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md aspect-video rounded-2xl bg-gray-800 overflow-hidden mb-6">
          {preview ? <video autoPlay playsInline muted ref={r => r && (r.srcObject = preview)} className="w-full h-full object-cover" /> :
            <div className="w-full h-full flex items-center justify-center text-gray-500"><Video className="w-12 h-12" /></div>}
        </div>
        {error && <p className="text-amber-400 text-sm mb-4 flex items-center gap-2"><AlertCircle className="w-4 h-4" />{error}</p>}
        <p className="text-gray-400 mb-1">Code de réunion</p>
        <p className="text-2xl font-bold tracking-widest mb-1">{room}</p>
        <p className="text-gray-500 text-sm mb-8">Partagez ce code pour inviter d'autres participants</p>
        <button
          onClick={() => { preview?.getTracks().forEach(t => t.stop()); onJoin(); }}
          className="px-8 py-3 rounded-xl text-white font-semibold"
          style={{ background: 'linear-gradient(180deg, #3b82f6, #2563eb)' }}
        >
          Rejoindre la réunion
        </button>
      </div>
    </div>
  );
}

function Meeting({ room, user, onLeave }) {
  const { status, participants, localStream, micOn, camOn, error, join, leave, toggleMic, toggleCam, toggleScreenShare } = useMeetRoom({
    room,
    userId: user.id,
    userEmail: user.email,
    displayName: user.full_name || user.email,
    onLeave,
  });

  useEffect(() => { join(); }, []);

  if (error) {
    return (
      <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center p-6">
        <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
        <p className="text-lg font-medium mb-2">{error}</p>
        <button onClick={onLeave} className="px-6 py-2.5 rounded-xl bg-white/10 hover:bg-white/20">Retour</button>
      </div>
    );
  }

  const participantList = Object.entries(participants);
  const totalTiles = participantList.length + 1;

  const gridClass = totalTiles <= 1 ? 'grid-cols-1 grid-rows-1'
    : totalTiles === 2 ? 'grid-cols-2 grid-rows-1'
    : totalTiles <= 4 ? 'grid-cols-2 grid-rows-2'
    : 'grid-cols-3';

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      <div className="flex items-center justify-between p-3 border-b border-white/10">
        <div className="flex items-center gap-2 text-white">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(180deg, #3b82f6, #2563eb)' }}>
            <Video className="w-4 h-4 text-white" />
          </div>
          <span className="font-medium">{room}</span>
        </div>
        <div className="flex items-center gap-1.5 text-white/60 text-sm">
          <Users className="w-4 h-4" /> {totalTiles}
        </div>
      </div>

      <div className={`flex-1 grid ${gridClass} gap-2 p-2`}>
        <VideoTile stream={localStream} name={`${user.full_name || 'Vous'} (vous)`} isLocal micOn={micOn} />
        {participantList.map(([id, p]) => (
          <VideoTile key={id} stream={p.stream} name={p.name} micOn />
        ))}
      </div>

      <div className="flex justify-center pb-4">
        <MeetControls
          micOn={micOn} camOn={camOn}
          onToggleMic={toggleMic} onToggleCam={toggleCam}
          onShare={toggleScreenShare} onLeave={leave}
        />
      </div>
    </div>
  );
}