import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { useMusicPlayer } from '@/components/shared/MusicPlayerContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Play, Shuffle, Music, Pause, MoreVertical, Trash2, Clock } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

export default function PlaylistView() {
  const navigate = useNavigate();
  const { currentTrack, isPlaying, playTrack, togglePlay } = useMusicPlayer();
  const urlParams = new URLSearchParams(window.location.search);
  const playlistId = urlParams.get('id');

  const [playlist, setPlaylist] = useState(null);
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    load();
  }, [playlistId]);

  const load = async () => {
    if (!playlistId) return;
    try {
      const u = await base44.auth.me();
      setUser(u);
      const [pl, allFiles, allTracks] = await Promise.all([
        base44.entities.Playlist.filter({ id: playlistId }),
        base44.entities.MusicFile.list(),
        base44.entities.MusicTrack.list(),
      ]);
      const p = pl[0];
      if (!p) { navigate('/MykelMusic'); return; }
      setPlaylist(p);

      // resolve track IDs to actual track objects
      const ids = p.music_file_ids || [];
      const resolved = ids.map(id => {
        const mf = allFiles.find(f => f.id === id);
        if (mf) return mf;
        const mt = allTracks.find(t => t.id === id);
        if (mt) return { ...mt, name: mt.title, cover_url: mt.album_cover_url };
        return null;
      }).filter(Boolean);
      setTracks(resolved);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePlay = (track, idx) => {
    if (currentTrack?.id === track.id) { togglePlay(); return; }
    playTrack(track, tracks, idx);
  };

  const handlePlayAll = () => {
    if (tracks.length === 0) return;
    playTrack(tracks[0], tracks, 0);
  };

  const handleShuffle = () => {
    if (tracks.length === 0) return;
    const shuffled = [...tracks].sort(() => Math.random() - 0.5);
    playTrack(shuffled[0], shuffled, 0);
  };

  const handleRemoveTrack = async (trackId) => {
    const newIds = (playlist.music_file_ids || []).filter(id => id !== trackId);
    await base44.entities.Playlist.update(playlist.id, { music_file_ids: newIds });
    toast.success('Titre retiré');
    load();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-gray-950 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-purple-400 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!playlist) return null;

  const totalDuration = tracks.reduce((s, t) => s + (t.duration || 0), 0);
  const formatTotal = (s) => {
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    if (h > 0) return `${h}h ${m % 60}min`;
    return `${m}min`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-gray-950 to-gray-900 text-white">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-white/10">
        <Button variant="ghost" size="icon" onClick={() => navigate('/MykelMusic')} className="text-white hover:bg-white/10">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <span className="font-semibold">Playlist</span>
      </div>

      {/* Playlist Hero */}
      <div className="px-6 py-8 flex flex-col items-center text-center gap-4">
        <div className="w-48 h-48 rounded-2xl shadow-2xl overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
          {playlist.cover_url
            ? <img src={playlist.cover_url} className="w-full h-full object-cover" alt="" />
            : <Music className="w-16 h-16 text-white" />
          }
        </div>
        <div>
          <h1 className="text-2xl font-bold">{playlist.name}</h1>
          {playlist.description && <p className="text-white/50 text-sm mt-1">{playlist.description}</p>}
          <p className="text-white/40 text-xs mt-2">
            {tracks.length} titre{tracks.length !== 1 ? 's' : ''}
            {totalDuration > 0 && ` · ${formatTotal(totalDuration)}`}
          </p>
        </div>

        {/* Play buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handlePlayAll}
            disabled={tracks.length === 0}
            className="bg-purple-600 hover:bg-purple-500 text-white gap-2 px-6"
          >
            <Play className="w-4 h-4" />
            Lire
          </Button>
          <Button
            onClick={handleShuffle}
            disabled={tracks.length === 0}
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10 gap-2 px-6"
          >
            <Shuffle className="w-4 h-4" />
            Aléatoire
          </Button>
        </div>
      </div>

      {/* Track list */}
      <div className="px-4 pb-24 space-y-1">
        {tracks.length === 0 && (
          <div className="text-center py-16 text-white/40">
            <Music className="w-12 h-12 mx-auto mb-4" />
            <p>Cette playlist est vide.</p>
          </div>
        )}
        {tracks.map((track, idx) => {
          const isActive = currentTrack?.id === track.id;
          const cover = track.cover_url || track.album_cover_url;
          const artist = track.artist || track.stage_name;
          return (
            <div
              key={track.id}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all ${isActive ? 'bg-purple-600/40 border border-purple-500/50' : 'hover:bg-white/5'}`}
            >
              <span className="text-white/30 text-sm w-5 text-center flex-shrink-0">
                {isActive && isPlaying ? <Pause className="w-3 h-3" /> : idx + 1}
              </span>
              <button className="flex items-center gap-3 flex-1 text-left min-w-0" onClick={() => handlePlay(track, idx)}>
                <div className="w-11 h-11 rounded-lg flex-shrink-0 overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center relative">
                  {cover ? <img src={cover} className="w-full h-full object-cover" alt="" /> : <Music className="w-5 h-5 text-white" />}
                  {isActive && (
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      {isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white" />}
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`font-medium truncate text-sm ${isActive ? 'text-purple-300' : 'text-white'}`}>{track.name || track.title}</p>
                  <p className="text-white/50 text-xs truncate">{artist || 'Artiste inconnu'}</p>
                </div>
                {track.duration && (
                  <span className="text-white/40 text-xs flex-shrink-0 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {Math.floor(track.duration / 60)}:{String(track.duration % 60).padStart(2, '0')}
                  </span>
                )}
              </button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/40 hover:text-white flex-shrink-0">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-gray-900 border-gray-700 text-white">
                  <DropdownMenuItem onClick={() => handleRemoveTrack(track.id)} className="cursor-pointer text-red-400 hover:bg-red-500/20">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Retirer de la playlist
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          );
        })}
      </div>
    </div>
  );
}