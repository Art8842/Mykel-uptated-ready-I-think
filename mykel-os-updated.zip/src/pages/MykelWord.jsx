import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Link, useNavigate } from 'react-router-dom';
import { useScreenSize } from '@/components/utils/useScreenSize';
import WordToolbar from '@/components/word/WordToolbar';
import AppAccessCheck from '@/components/drive/AppAccessCheck';
import { FileText, ChevronLeft, Loader2, Sparkles, MessageSquare } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from 'sonner';
import AIAssistant from '@/components/shared/AIAssistant';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import SaveStatus from '@/components/shared/SaveStatus';
import { callAI } from '@/components/utils/aiClient';
import { getFilePermission } from '@/lib/filePermissions';
import { getMykelSession } from '@/lib/mykelSession';
import useAutoSave from '@/hooks/useAutoSave';
import { createWordPage, readPagesHtml, writePagesHtml, lastPage } from '@/components/word/wordPages';
import CommentsPanel from '@/components/shared/CommentsPanel';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function MykelWord() {
  const navigate = useNavigate();
  const editorRef = useRef(null);
  const htmlRef = useRef(null);        // dernier HTML connu (chargé ou saisi)
  const createdIdRef = useRef(null);   // document qu'on vient de créer (pas besoin de le recharger)
  const urlParams = new URLSearchParams(window.location.search);
  const fileId = urlParams.get('fileId');
  const { isMobile } = useScreenSize();
  
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fileName, setFileName] = useState('Document sans titre');
  const fileNameRef = useRef(fileName);
  const [isEditing, setIsEditing] = useState(false);
  const [shareDialog, setShareDialog] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [writeAIDialog, setWriteAIDialog] = useState(false);
  const [writeAIPrompt, setWriteAIPrompt] = useState('');
  const [writeAILoading, setWriteAILoading] = useState(false);
  const [canEdit, setCanEdit] = useState(true);
  const [showComments, setShowComments] = useState(false);
  const [user, setUser] = useState(null);

  const autoSave = useAutoSave(file?.id, { enabled: canEdit });
  const { queue, setBaseline } = autoSave;

  // Lit le contenu actuel de l'éditeur et le met en file d'enregistrement
  const injectedRef = useRef(false);
  const queueFrom = useCallback((node) => {
    if (!injectedRef.current) return; // jamais avant que le contenu chargé soit affiché
    const html = readPagesHtml(node);
    if (html === null) return;
    htmlRef.current = html;
    queue({ name: fileNameRef.current, content: { html } });
  }, [queue]);

  const queueSave = useCallback(() => queueFrom(editorRef.current), [queueFrom]);

  // Ref de l'éditeur : injecte le contenu dès que l'éditeur apparaît,
  // et capture le dernier contenu juste avant qu'il ne disparaisse.
  const attachEditor = useCallback((node) => {
    if (!node && editorRef.current) queueFrom(editorRef.current);
    editorRef.current = node;
    if (node && htmlRef.current !== null) {
      writePagesHtml(node, htmlRef.current);
      injectedRef.current = true;
      setBaseline({ name: fileNameRef.current, content: { html: readPagesHtml(node) } });
    }
  }, [queueFrom, setBaseline]);
  
  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);
  useEffect(() => {
    if (fileId) {
      if (fileId !== createdIdRef.current) loadFile();
    } else {
      createNewDocument();
    }
  }, [fileId]);

  const loadFile = async () => {
    try {
      const fileData = await base44.entities.CloudFile.filter({ id: fileId });
      if (fileData.length > 0) {
        const f = fileData[0];
        fileNameRef.current = f.name;
        htmlRef.current = f.content?.html || '';
        setFile(f);
        setFileName(f.name);
        // Check permission — only owner or 'edit' members can modify
        const session = getMykelSession();
        const { canEdit: editAllowed, permission } = getFilePermission(f, session?.email);
        setCanEdit(editAllowed);
        if (!editAllowed) {
          toast.info(`Vous êtes en mode ${permission === 'comment' ? 'commentaire' : 'visualisation'}. Vous ne pouvez pas modifier ce document.`);
        }
        if (editorRef.current) attachEditor(editorRef.current);
      }
    } catch (e) {
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  const createNewDocument = async () => {
    try {
      const newFile = await base44.entities.CloudFile.create({
        name: 'Document sans titre',
        type: 'document',
        content: { html: '' },
        is_starred: false,
        is_trashed: false,
      });
      createdIdRef.current = newFile.id;
      fileNameRef.current = 'Document sans titre';
      htmlRef.current = '';
      setFile(newFile);
      setFileName('Document sans titre');
      navigate(`/MykelWord?fileId=${newFile.id}`, { replace: true });
    } catch (e) {
      toast.error('Erreur lors de la création du document');
      navigate('/Dashboard', { replace: true });
    }
    setLoading(false);
  };

  // Renommage → enregistrement
  useEffect(() => {
    fileNameRef.current = fileName;
    queueSave();
  }, [fileName, queueSave]);

  // Filet de sécurité : détecte les changements de mise en forme qui ne
  // déclenchent pas d'événement de saisie (aucune requête si rien n'a changé)
  useEffect(() => {
    const interval = setInterval(queueSave, 3000);
    return () => clearInterval(interval);
  }, [queueSave]);

  const saveDocument = useCallback(async () => {
    if (!canEdit) return;
    queueSave();
    if (await autoSave.saveNow()) toast.success('Document enregistré');
  }, [canEdit, queueSave, autoSave.saveNow]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        saveDocument();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [saveDocument]);

  const handleExport = (format) => {
    if (!editorRef.current) return;
    
    const content = editorRef.current.innerHTML;
    let blob, filename;
    
    if (format === 'html') {
      const fullHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${fileName}</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }
  </style>
</head>
<body>
${content}
</body>
</html>`;
      blob = new Blob([fullHtml], { type: 'text/html' });
      filename = `${fileName}.html`;
    } else if (format === 'txt') {
      const text = editorRef.current.innerText;
      blob = new Blob([text], { type: 'text/plain' });
      filename = `${fileName}.txt`;
    } else {
      toast.info(`Export ${format.toUpperCase()} disponible prochainement`);
      return;
    }
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const insertTextIntoEditor = (text) => {
    const page = lastPage(editorRef.current);
    if (!page) return;
    const plainText = text.replace(/\*\*(.*?)\*\*/g, '$1').replace(/#{1,6} /g, '').trim();
    const p = document.createElement('p');
    p.textContent = plainText;
    page.appendChild(p);
    p.scrollIntoView({ behavior: 'smooth' });
    queueSave();
  };

  const handleWriteAI = async () => {
    if (!writeAIPrompt.trim()) return;
    setWriteAILoading(true);
    try {
      const text = await callAI([
        { role: 'system', content: 'Tu es un assistant de rédaction. Génère uniquement du texte brut, sans markdown, sans titres avec #, sans astérisques. Le texte doit être prêt à être inséré dans un document Word.' },
        { role: 'user', content: writeAIPrompt }
      ]);
      insertTextIntoEditor(text);
      setWriteAIDialog(false);
      setWriteAIPrompt('');
      toast.success('Texte inséré !');
    } catch {
      toast.error('Erreur lors de la génération');
    } finally {
      setWriteAILoading(false);
    }
  };

  const handleShare = async () => {
    if (!shareEmail.trim() || !file) return;
    try {
      const currentShared = file.shared_with || [];
      const updated = await base44.entities.CloudFile.update(file.id, {
        shared_with: [...new Set([...currentShared, shareEmail.trim()])]
      });
      setFile(prev => ({ ...prev, shared_with: updated?.shared_with || [...currentShared, shareEmail.trim()] }));
      setShareDialog(false);
      setShareEmail('');
      toast.success('Document partagé');
    } catch (e) {
      toast.error('Erreur lors du partage');
    }
  };

  // Entrée en bas d'une page pleine → passage à la page suivante
  const handlePageKeyDown = (e) => {
    if (e.key !== 'Enter' || isMobile) return;
    const page = e.target.closest?.('.word-page');
    if (!page) return;
    const maxHeight = 1122; // ~297mm at 96dpi
    if (page.scrollHeight < maxHeight - 40) return;
    e.preventDefault();
    let nextPage = page.nextElementSibling;
    if (!nextPage || !nextPage.classList.contains('word-page')) {
      nextPage = createWordPage();
      page.parentNode.insertBefore(nextPage, page.nextSibling);
    }
    nextPage.focus();
    const range = document.createRange();
    range.setStart(nextPage, 0);
    range.collapse(true);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);
    queueSave();
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <AppAccessCheck appType="document">
      <div className="h-screen flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-4">
        <button onClick={() => navigate('/Dashboard')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div className="min-w-0">
            {isEditing ? (
              <Input
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                onBlur={() => setIsEditing(false)}
                onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
                className="h-7 text-lg font-semibold border-blue-500"
                autoFocus
              />
            ) : (
              <h1 
                className="text-lg font-semibold cursor-pointer hover:text-blue-600 transition-colors truncate"
                onClick={() => setIsEditing(true)}
              >
                {fileName}
              </h1>
            )}
            <SaveStatus status={autoSave.status} lastSaved={autoSave.lastSaved} />
          </div>
        </div>
        <Button
          onClick={() => setShowComments(true)}
          variant="ghost"
          size="sm"
          className="ml-auto gap-2 text-xs md:text-sm flex-shrink-0"
          title="Commentaires"
        >
          <MessageSquare className="w-4 h-4" />
          <span className="hidden md:inline">Commentaires</span>
        </Button>
        {canEdit && (
          <Button
            onClick={() => setWriteAIDialog(true)}
            className="bg-indigo-600 hover:bg-indigo-700 gap-2 text-xs md:text-sm flex-shrink-0"
            size="sm"
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden md:inline">Rédiger avec l'IA</span>
          </Button>
        )}
      </div>

      {/* Toolbar — hidden in view mode */}
      {canEdit && (
        <WordToolbar 
          onSave={saveDocument}
          onExport={handleExport}
          onShare={() => setShareDialog(true)}
          saving={autoSave.status === 'saving'}
        />
      )}

      {/* Editor — paginated */}
      <div
        className="flex-1 overflow-auto p-2 md:p-8 flex flex-col items-center gap-4"
        ref={attachEditor}
        onInput={canEdit ? queueSave : undefined}
        onKeyDown={canEdit ? handlePageKeyDown : undefined}
      >
        <div
          className="word-page bg-white shadow-lg rounded-sm outline-none"
          contentEditable={canEdit}
          suppressContentEditableWarning
          style={{
            width: isMobile ? '100%' : '210mm',
            minHeight: isMobile ? '60vh' : '297mm',
            maxWidth: isMobile ? '100%' : '210mm',
            fontFamily: 'Arial',
            fontSize: isMobile ? '11pt' : '12pt',
            lineHeight: '1.5',
            padding: isMobile ? '1rem' : '2.5cm',
            boxSizing: 'border-box',
            overflowWrap: 'break-word',
            wordBreak: 'break-word',
            userSelect: canEdit ? 'text' : 'none',
            pointerEvents: canEdit ? 'auto' : 'none',
          }}
        />
      </div>

      {/* Write AI Dialog */}
      <Dialog open={writeAIDialog} onOpenChange={setWriteAIDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              Rédiger avec l'IA
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-500">Décris ce que tu veux que l'IA rédige. Le texte sera inséré à la fin du document.</p>
            <Textarea
              placeholder="Ex: Rédige une introduction sur le changement climatique en 2 paragraphes..."
              value={writeAIPrompt}
              onChange={e => setWriteAIPrompt(e.target.value)}
              rows={4}
              onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) handleWriteAI(); }}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setWriteAIDialog(false)}>Annuler</Button>
            <Button onClick={handleWriteAI} disabled={writeAILoading} className="bg-indigo-600 hover:bg-indigo-700 gap-2">
              {writeAILoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Générer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={shareDialog} onOpenChange={setShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Partager "{fileName}"</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Adresse email"
            type="email"
            value={shareEmail}
            onChange={(e) => setShareEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleShare()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleShare}>Partager</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <AIAssistant
        systemContext="Tu es dans Mykel Word (traitement de texte). Tu aides à la rédaction, à la correction, à la mise en forme et à l'amélioration des textes. Réponds de façon concise et pratique."
        onInsertText={insertTextIntoEditor}
        fileId={fileId}
      />
      {showComments && (
        <CommentsPanel fileId={fileId} user={user} onClose={() => setShowComments(false)} />
      )}
      <AnnouncementModal target="app" targetApp="MykelWord" />
    </div>
    </AppAccessCheck>
  );
}