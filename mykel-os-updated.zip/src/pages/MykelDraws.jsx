import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Link, useNavigate } from 'react-router-dom';
import { useScreenSize } from '@/components/utils/useScreenSize';
import DrawToolbar from '@/components/draws/DrawToolbar';
import DrawCanvas from '@/components/draws/DrawCanvas';
import AppAccessCheck from '@/components/drive/AppAccessCheck';
import { useRef } from 'react';
import { Palette, ChevronLeft, Loader2, MessageSquare } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';
import AIAssistant from '@/components/shared/AIAssistant';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import { getFilePermission } from '@/lib/filePermissions';
import { getMykelSession } from '@/lib/mykelSession';
import useAutoSave from '@/hooks/useAutoSave';
import SaveStatus from '@/components/shared/SaveStatus';
import CommentsPanel from '@/components/shared/CommentsPanel';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter 
} from "@/components/ui/dialog";

export default function MykelDraws() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const fileId = urlParams.get('fileId');
  const { isMobile } = useScreenSize();
  
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fileName, setFileName] = useState('Dessin sans titre');
  const [isEditing, setIsEditing] = useState(false);
  const [shareDialog, setShareDialog] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [canEdit, setCanEdit] = useState(true);
  const [showComments, setShowComments] = useState(false);
  const [user, setUser] = useState(null);
  const canEditRef = useRef(true);
  useEffect(() => { canEditRef.current = canEdit; }, [canEdit]);
  const createdIdRef = useRef(null);
  const autoSave = useAutoSave(file?.id, { enabled: canEdit });
  
  // Drawing state
  const [elements, setElements] = useState([]);
  const [currentTool, setCurrentTool] = useState('pencil');
  const [currentColor, setCurrentColor] = useState('#000000');
  const [currentFillColor, setCurrentFillColor] = useState(null);
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [selectedElement, setSelectedElement] = useState(null);
  const [canvasBackground, setCanvasBackground] = useState('#ffffff');
  const [history, setHistory] = useState([[]]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);
  useEffect(() => {
    if (fileId) {
      if (fileId !== createdIdRef.current) loadFile();
    } else {
      createNewDrawing();
    }
  }, [fileId]);

  const loadFile = async () => {
    try {
      const fileData = await base44.entities.CloudFile.filter({ id: fileId });
      if (fileData.length > 0) {
        setFile(fileData[0]);
        setFileName(fileData[0].name);
        const c = fileData[0].content || {};
        autoSave.setBaseline({ name: fileData[0].name, content: { elements: c.elements || [], background: c.background || '#ffffff' } });
        if (fileData[0].content) {
          setElements(fileData[0].content.elements || []);
          setCanvasBackground(fileData[0].content.background || '#ffffff');
          setHistory([fileData[0].content.elements || []]);
        }
        // Check permission — only owner or 'edit' members can modify
        const session = getMykelSession();
        const { canEdit: editAllowed, permission } = getFilePermission(fileData[0], session?.email);
        setCanEdit(editAllowed);
        if (!editAllowed) {
          toast.info(`Vous êtes en mode ${permission === 'comment' ? 'commentaire' : 'visualisation'}. Vous ne pouvez pas modifier ce fichier.`);
        }
      }
    } catch (e) {
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  const createNewDrawing = async () => {
    try {
      const newFile = await base44.entities.CloudFile.create({
        name: 'Dessin sans titre',
        type: 'drawing',
        content: { elements: [], background: '#ffffff' },
        is_starred: false,
        is_trashed: false,
      });
      createdIdRef.current = newFile.id;
      autoSave.setBaseline({ name: 'Dessin sans titre', content: { elements: [], background: '#ffffff' } });
      setFile(newFile);
      setFileName('Dessin sans titre');
      navigate(`/MykelDraws?fileId=${newFile.id}`, { replace: true });
    } catch (e) {
      toast.error('Erreur lors de la création');
      navigate('/Dashboard', { replace: true });
    }
    setLoading(false);
  };

  // Sauvegarde automatique : uniquement quand le contenu change
  useEffect(() => {
    autoSave.queue({ name: fileName, content: { elements, background: canvasBackground } });
  }, [fileName, elements, canvasBackground]);

  const saveDrawing = useCallback(async () => {
    if (!canEditRef.current) return; // Block saves for view/comment members
    if (await autoSave.saveNow()) toast.success('Dessin enregistré');
  }, [autoSave.saveNow]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        saveDrawing();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault();
        handleUndo();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        e.preventDefault();
        handleRedo();
      }
      if (e.key === 'Delete' && selectedElement) {
        handleDeleteElement();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [saveDrawing, historyIndex, history, selectedElement]);

  const saveToHistory = (newElements) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newElements);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const handleAddElement = (element) => {
    const newElements = [...elements, element];
    setElements(newElements);
    saveToHistory(newElements);
  };

  const handleUpdateElement = (elementId, updates) => {
    const newElements = elements.map(el =>
      el.id === elementId ? { ...el, ...updates } : el
    );
    setElements(newElements);
  };

  const handleDeleteElement = () => {
    if (selectedElement) {
      const newElements = elements.filter(el => el.id !== selectedElement);
      setElements(newElements);
      saveToHistory(newElements);
      setSelectedElement(null);
    }
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setElements(history[historyIndex - 1]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setElements(history[historyIndex + 1]);
    }
  };

  const handleClear = () => {
    if (confirm('Êtes-vous sûr de vouloir tout effacer ?')) {
      setElements([]);
      saveToHistory([]);
      setSelectedElement(null);
    }
  };

  const handleExport = (format) => {
    if (format === 'svg') {
      // Create SVG content
      const svgContent = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" style="background-color: ${canvasBackground}">
${elements.map(el => {
  if (el.type === 'path') {
    const pathD = el.points.reduce((acc, point, i) => {
      return acc + (i === 0 ? `M ${point.x} ${point.y}` : ` L ${point.x} ${point.y}`);
    }, '');
    return `<path d="${pathD}" stroke="${el.color}" stroke-width="${el.strokeWidth}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  }
  if (el.type === 'rectangle') {
    return `<rect x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}" stroke="${el.color}" stroke-width="${el.strokeWidth}" fill="${el.fillColor || 'transparent'}"/>`;
  }
  if (el.type === 'circle') {
    return `<ellipse cx="${el.x + el.width/2}" cy="${el.y + el.height/2}" rx="${el.width/2}" ry="${el.height/2}" stroke="${el.color}" stroke-width="${el.strokeWidth}" fill="${el.fillColor || 'transparent'}"/>`;
  }
  if (el.type === 'line') {
    return `<line x1="${el.x1}" y1="${el.y1}" x2="${el.x2}" y2="${el.y2}" stroke="${el.color}" stroke-width="${el.strokeWidth}"/>`;
  }
  if (el.type === 'text') {
    return `<text x="${el.x}" y="${el.y}" fill="${el.color}" font-size="${el.fontSize}">${el.text}</text>`;
  }
  return '';
}).join('\n')}
</svg>`;
      
      const blob = new Blob([svgContent], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}.svg`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      toast.info(`Export ${format.toUpperCase()} disponible prochainement`);
    }
  };

  const handleShare = async () => {
    if (!shareEmail.trim() || !file) return;
    try {
      const currentShared = file.shared_with || [];
      await base44.entities.CloudFile.update(file.id, {
        shared_with: [...currentShared, shareEmail.trim()]
      });
      setShareDialog(false);
      setShareEmail('');
      toast.success('Dessin partagé');
    } catch (e) {
      toast.error('Erreur lors du partage');
    }
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <AppAccessCheck appType="drawing">
      <div className="h-screen flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-4">
        <button onClick={() => navigate('/Dashboard')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
            <Palette className="w-6 h-6 text-white" />
          </div>
          <div>
            {isEditing ? (
              <Input
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                onBlur={() => setIsEditing(false)}
                onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
                className="h-7 text-lg font-semibold border-purple-500"
                autoFocus
              />
            ) : (
              <h1 
                className="text-lg font-semibold cursor-pointer hover:text-purple-600 transition-colors"
                onClick={() => setIsEditing(true)}
              >
                {fileName}
              </h1>
            )}
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <SaveStatus status={autoSave.status} lastSaved={autoSave.lastSaved} />
            </div>
          </div>
          <Button
            onClick={() => setShowComments(true)}
            variant="ghost"
            size="sm"
            className="ml-auto gap-2 text-xs md:text-sm flex-shrink-0"
            title="Commentaires"
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden md:inline">Commentaires</span>
          </Button>
        </div>
      </div>

      {/* Toolbar — hidden in view mode */}
      {canEdit && (
        <DrawToolbar
          currentTool={currentTool}
          onToolChange={setCurrentTool}
          currentColor={currentColor}
          onColorChange={setCurrentColor}
          currentFillColor={currentFillColor}
          onFillColorChange={setCurrentFillColor}
          strokeWidth={strokeWidth}
          onStrokeWidthChange={setStrokeWidth}
          onUndo={handleUndo}
          onRedo={handleRedo}
          onClear={handleClear}
          onSave={saveDrawing}
          onExport={handleExport}
          onShare={() => setShareDialog(true)}
          canUndo={historyIndex > 0}
          canRedo={historyIndex < history.length - 1}
          saving={autoSave.status === 'saving'}
          canvasBackground={canvasBackground}
          onBackgroundChange={setCanvasBackground}
        />
      )}

      {/* Canvas */}
      <DrawCanvas
        elements={elements}
        currentTool={canEdit ? currentTool : 'select'}
        currentColor={currentColor}
        currentStrokeWidth={strokeWidth}
        currentFillColor={currentFillColor}
        onAddElement={canEdit ? handleAddElement : () => {}}
        onUpdateElement={canEdit ? handleUpdateElement : () => {}}
        onSelectElement={canEdit ? setSelectedElement : () => {}}
        selectedElement={canEdit ? selectedElement : null}
        canvasBackground={canvasBackground}
        readOnly={!canEdit}
      />

      {/* Share Dialog */}
      <Dialog open={shareDialog} onOpenChange={setShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Partager "{fileName}"</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Adresse email"
            type="email"
            value={shareEmail}
            onChange={(e) => setShareEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleShare()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleShare}>Partager</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <AIAssistant systemContext="Tu es dans Mykel Draws (dessin vectoriel). Tu peux aider l'utilisateur avec des conseils artistiques, des idées de design, des techniques de dessin et de composition." fileId={fileId} />
      {showComments && (
        <CommentsPanel fileId={fileId} user={user} onClose={() => setShowComments(false)} />
      )}
      <AnnouncementModal target="app" targetApp="MykelDraws" />
    </div>
    </AppAccessCheck>
  );
}