import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { confirmAction } from '@/lib/confirm';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Building2, Users, Trash2, Copy, ArrowLeft, Loader2, Link as LinkIcon } from 'lucide-react';
import { toast } from 'sonner';
import { getMykelSession } from '@/lib/mykelSession';

export default function BusinessManage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [businessSub, setBusinessSub] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInviteLink, setShowInviteLink] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      let userData;
      try { userData = await base44.auth.me(); }
      catch {
        const session = getMykelSession();
        if (!session) { navigate('/MykelLogin'); return; }
        userData = { email: session.email, full_name: session.full_name, role: session.role };
      }
      setUser(userData);

      const subs = await base44.entities.BusinessSubscription.filter({ admin_email: userData.email, active: true });
      if (subs.length > 0) {
        setBusinessSub(subs[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveMember = async (email) => {
    if (email === businessSub.admin_email) { toast.error('Vous ne pouvez pas vous retirer (admin)'); return; }
    if (!await confirmAction(`Retirer ${email} de l'abonnement ?`)) return;
    try {
      const newMembers = businessSub.member_emails.filter(e => e !== email);
      await base44.entities.BusinessSubscription.update(businessSub.id, { member_emails: newMembers });
      setBusinessSub({ ...businessSub, member_emails: newMembers });
      toast.success('Membre retiré');
    } catch (e) { toast.error('Erreur'); }
  };

  const handleCancelBusiness = async () => {
    if (!await confirmAction({ title: 'Arrêter l\'abonnement ?', message: 'Tous les membres perdront accès à l\'espace Business (leur compte personnel reste intact).', destructive: true })) return;
    try {
      await base44.entities.BusinessSubscription.update(businessSub.id, { 
        active: false, 
        member_emails: [businessSub.admin_email]
      });
      toast.success('Abonnement arrêté. Les membres n\'ont plus accès à l\'espace Business.');
      navigate('/Dashboard');
    } catch (e) { toast.error('Erreur'); }
  };

  const copyInviteLink = () => {
    const link = `${window.location.origin}/BusinessInvite?token=${businessSub.invite_token}&company=${encodeURIComponent(businessSub.company_name)}`;
    navigator.clipboard.writeText(link);
    toast.success('Lien copié !');
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  );

  if (!businessSub) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <Building2 className="w-16 h-16 text-gray-300 mb-4" />
      <p className="text-gray-500 mb-4">Vous n'avez pas d'abonnement Mykel Business</p>
      <Button onClick={() => navigate('/MykelStore')}>Créer un abonnement</Button>
    </div>
  );

  const inviteLink = `${window.location.origin}/BusinessInvite?token=${businessSub.invite_token}&company=${encodeURIComponent(businessSub.company_name)}`;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/Dashboard')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <h1 className="font-bold text-lg">Gérer Mykel Business</h1>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* Subscription details */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <h2 className="font-bold text-lg text-gray-900 mb-4">{businessSub.company_name}</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><span className="text-gray-500">Stockage/compte</span><p className="font-medium">{businessSub.storage_gb} Go</p></div>
            <div><span className="text-gray-500">Comptes</span><p className="font-medium">{businessSub.num_accounts}</p></div>
            <div><span className="text-gray-500">SnapFix</span><p className="font-medium">{businessSub.includes_snapfix ? 'Oui' : 'Non'}</p></div>
            <div><span className="text-gray-500">Prix/mois</span><p className="font-medium text-blue-600">{businessSub.monthly_price} jetons</p></div>
          </div>
          {businessSub.included_subscriptions?.length > 0 && (
            <div className="mt-3">
              <span className="text-gray-500 text-sm">Abonnements inclus :</span>
              <div className="flex flex-wrap gap-1.5 mt-1">
                {businessSub.included_subscriptions.map(s => (
                  <span key={s} className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">{s}</span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Members */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-lg text-gray-900 flex items-center gap-2">
              <Users className="w-5 h-5" /> Membres ({businessSub.member_emails?.length || 0}/{businessSub.num_accounts})
            </h2>
            <Button size="sm" onClick={() => setShowInviteLink(!showInviteLink)} className="gap-2">
              <LinkIcon className="w-4 h-4" /> Ajouter
            </Button>
          </div>

          {showInviteLink && (
            <div className="mb-4 bg-blue-50 rounded-xl p-4">
              <p className="text-sm text-gray-600 mb-2">Partagez ce lien avec vos employés :</p>
              <div className="flex items-center gap-2">
                <input readOnly value={inviteLink} className="flex-1 bg-white border rounded-lg px-3 py-2 text-xs text-gray-700" />
                <Button size="sm" onClick={copyInviteLink} className="gap-1.5"><Copy className="w-3.5 h-3.5" /> Copier</Button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {businessSub.member_emails?.map(email => (
              <div key={email} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{email}</p>
                  {email === businessSub.admin_email && <span className="text-xs text-blue-600">Admin</span>}
                </div>
                {email !== businessSub.admin_email && (
                  <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:text-red-600" onClick={() => handleRemoveMember(email)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
            {(!businessSub.member_emails || businessSub.member_emails.length === 0) && (
              <p className="text-gray-400 text-sm text-center py-4">Aucun membre pour le moment</p>
            )}
          </div>
        </div>

        {/* Cancel subscription */}
        <div className="bg-white rounded-2xl border border-red-200 p-6">
          <h2 className="font-bold text-lg text-red-600 mb-2">Zone de danger</h2>
          <p className="text-sm text-gray-500 mb-4">Arrêter l'abonnement supprime l'accès Business pour tous les membres. Leurs comptes personnels restent intacts.</p>
          <Button variant="destructive" onClick={handleCancelBusiness} className="gap-2">
            <Trash2 className="w-4 h-4" /> Arrêter l'abonnement
          </Button>
        </div>
      </div>
    </div>
  );
}