import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { Tv, MoreVertical, Home, Search, Bookmark, ChevronLeft } from 'lucide-react';
import TVHome from '@/components/tv/TVHome';
import TVSearch from '@/components/tv/TVSearch';
import TVLibrary from '@/components/tv/TVLibrary';
import TVContentModal from '@/components/tv/TVContentModal';
import TVPlayer from '@/components/tv/TVPlayer';
import TVSettings from '@/components/tv/TVSettings';
import TVPublishWizard from '@/components/tv/TVPublishWizard';
import { getMykelSession } from '@/lib/mykelSession';

export default function MykelTV() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('home');
  const [selectedContent, setSelectedContent] = useState(null);
  const [playerState, setPlayerState] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [subscriptionType, setSubscriptionType] = useState(null);
  const [isCreator, setIsCreator] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      const session = getMykelSession();
      if (session) setUser({ email: session.email, full_name: session.full_name, role: session.role });
    });
  }, []);

  const checkSubscription = useCallback(async (email) => {
    if (!email) return;

    // Check business mode
    if (localStorage.getItem('mykel_account_mode') === 'business') {
      const subId = localStorage.getItem('mykel_business_sub_id');
      if (subId) {
        try {
          const businessSub = await base44.entities.BusinessSubscription.get(subId);
          if (businessSub && businessSub.active && businessSub.member_emails?.includes(email)) {
            const included = businessSub.included_subscriptions || [];
            if (included.includes('tv_plus')) { setSubscriptionType('plus'); return; }
            if (included.includes('tv_premium')) { setSubscriptionType('premium'); return; }
            if (included.includes('tv_ads')) { setSubscriptionType('ads'); return; }
            setSubscriptionType(null); return;
          }
        } catch {}
      }
    }

    // Personal mode - check own subscriptions
    const subs = await base44.entities.TVSubscription.filter({ user_email: email, active: true });
    if (subs.find(s => s.subscription_type === 'plus')) setSubscriptionType('plus');
    else if (subs.find(s => s.subscription_type === 'premium')) setSubscriptionType('premium');
    else if (subs.find(s => s.subscription_type === 'ads')) setSubscriptionType('ads');
    else setSubscriptionType(null);
  }, []);

  const checkCreator = useCallback(async (email) => {
    if (!email) return;
    const creators = await base44.entities.TVCreatorProfile.filter({ user_email: email, active: true });
    setIsCreator(creators.length > 0);
  }, []);

  useEffect(() => {
    if (user?.email) {
      checkSubscription(user.email);
      checkCreator(user.email);
    }
  }, [user, checkSubscription, checkCreator, refreshKey]);

  const handlePlay = (content, episode = null, startProgress = 0) => {
    setPlayerState({ content, episode, startProgress });
    setSelectedContent(null);
  };

  const handlePlayerClose = () => {
    setPlayerState(null);
    setRefreshKey(k => k + 1);
  };

  const tabs = [
    { id: 'home', label: 'Accueil', icon: Home },
    { id: 'search', label: 'Recherche', icon: Search },
    { id: 'library', label: 'Bibliomovie', icon: Bookmark },
  ];

  return (
    <div className="h-screen flex flex-col bg-gray-950 text-white overflow-hidden">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-gray-900 border-b border-gray-800 flex-shrink-0">
        <div className="flex items-center gap-2">
          <button onClick={() => navigate('/Dashboard')} className="w-9 h-9 rounded-full hover:bg-gray-800 flex items-center justify-center transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="w-9 h-9 bg-gradient-to-br from-red-500 to-rose-700 rounded-lg flex items-center justify-center">
            <Tv className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-bold">Mykel TV</h1>
          {subscriptionType && (
            <span className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium bg-red-600/30 text-red-400 border border-red-600/50">
              {subscriptionType === 'plus' ? 'TV +' : subscriptionType === 'premium' ? 'Premium' : 'Ads'}
            </span>
          )}
        </div>
        <button
          onClick={() => setSettingsOpen(true)}
          className="w-9 h-9 rounded-full hover:bg-gray-800 flex items-center justify-center transition-colors"
        >
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden">
        {activeTab === 'home' && (
          <TVHome key={refreshKey} user={user} subscriptionType={subscriptionType} onContentClick={setSelectedContent} />
        )}
        {activeTab === 'search' && (
          <TVSearch user={user} subscriptionType={subscriptionType} onContentClick={setSelectedContent} />
        )}
        {activeTab === 'library' && (
          <TVLibrary key={refreshKey} user={user} subscriptionType={subscriptionType} onContentClick={setSelectedContent} />
        )}
      </div>

      {/* Bottom navigation */}
      <div className="flex items-center justify-around bg-gray-900 border-t border-gray-800 py-2 flex-shrink-0 pb-safe">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-lg transition-all ${
                activeTab === tab.id ? 'text-red-500' : 'text-gray-500'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Modals */}
      {selectedContent && (
        <TVContentModal
          content={selectedContent}
          user={user}
          subscriptionType={subscriptionType}
          onClose={() => setSelectedContent(null)}
          onPlay={handlePlay}
        />
      )}
      {playerState && (
        <TVPlayer
          content={playerState.content}
          episode={playerState.episode}
          startProgress={playerState.startProgress}
          subscriptionType={subscriptionType}
          user={user}
          onClose={handlePlayerClose}
        />
      )}
      {settingsOpen && (
        <TVSettings
          user={user}
          isCreator={isCreator}
          onClose={() => setSettingsOpen(false)}
          onPublish={() => { setSettingsOpen(false); setPublishOpen(true); }}
          onCreatorToggled={() => checkCreator(user?.email)}
          onGoToStore={() => navigate('/MykelStore')}
        />
      )}
      {publishOpen && (
        <TVPublishWizard
          user={user}
          onClose={() => setPublishOpen(false)}
          onPublished={() => { setPublishOpen(false); setRefreshKey(k => k + 1); }}
        />
      )}
    </div>
  );
}