import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { confirmAction } from '@/lib/confirm';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ChevronLeft, Upload, Trash2, Music, MoreVertical, Volume2, Image, Video, CheckCircle, Loader2, Tv } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const typeIcon = { audio: Volume2, image: Image, video: Video };
const typeLabel = { audio: 'Audio', image: 'Image', video: 'Vidéo' };

export default function AdminAds() {
  const [user, setUser] = useState(null);
  const [ads, setAds] = useState([]);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => { loadUser(); }, []);
  useEffect(() => { if (user) loadAds(); }, [user]);

  const loadUser = async () => {
    const u = await base44.auth.me();
    setUser(u);
  };
  const loadAds = async () => {
    const data = await base44.entities.Advertisement.list();
    setAds(data);
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await uploadMedia(file);
      let file_type = 'other';
      if (file.type.startsWith('audio/')) file_type = 'audio';
      else if (file.type.startsWith('image/')) file_type = 'image';
      else if (file.type.startsWith('video/')) file_type = 'video';

      await base44.entities.Advertisement.create({
        name: file.name,
        file_url,
        file_type,
        is_active_in_music: false,
      });
      loadAds();
      toast.success('Publicité importée');
    } catch (e) {
      toast.error('Erreur lors de l\'import');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const toggleMusicAd = async (ad) => {
    await base44.entities.Advertisement.update(ad.id, { is_active_in_music: !ad.is_active_in_music });
    loadAds();
    toast.success(ad.is_active_in_music ? 'Retirée des pubs Music' : 'Activée dans Mykel Music');
  };

  const toggleTVAd = async (ad) => {
    await base44.entities.Advertisement.update(ad.id, { is_active_in_tv: !ad.is_active_in_tv });
    loadAds();
    toast.success(ad.is_active_in_tv ? 'Retirée des pubs TV' : 'Activée dans Mykel TV');
  };

  const deleteAd = async (ad) => {
    if (!await confirmAction({ title: `Supprimer "${ad.name}" ?`, destructive: true })) return;
    await base44.entities.Advertisement.delete(ad.id);
    loadAds();
    toast.success('Supprimée');
  };

  if (user && user.role !== 'admin') {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-900 text-white">
        <p>Accès réservé aux administrateurs.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-700 px-6 py-4 flex items-center gap-4">
        <Link to={createPageUrl('Dashboard')} className="p-2 hover:bg-gray-800 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5 text-gray-400" />
        </Link>
        <div>
          <h1 className="text-xl font-bold">Gestion Publicités & Premium</h1>
          <p className="text-sm text-gray-400">Administration — Mykel Cloud</p>
        </div>
        <div className="ml-auto">
          <Button
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="bg-blue-600 hover:bg-blue-700 gap-2"
          >
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            Importer une publicité
          </Button>
        </div>
      </div>

      <div className="p-6 max-w-5xl mx-auto">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <StatCard label="Total publicités" value={ads.length} color="blue" />
          <StatCard label="Actives dans Music" value={ads.filter(a => a.is_active_in_music).length} color="green" />
          <StatCard label="Audios" value={ads.filter(a => a.file_type === 'audio').length} color="purple" />
        </div>

        {/* Ads list */}
        <div className="bg-gray-900 rounded-xl border border-gray-700 overflow-hidden">
          <div className="p-4 border-b border-gray-700">
            <h2 className="font-semibold text-lg">Bibliothèque de publicités</h2>
          </div>
          {ads.length === 0 ? (
            <div className="p-12 text-center text-gray-500">
              <Upload className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Aucune publicité importée</p>
              <p className="text-sm mt-1">Cliquez sur "Importer une publicité" pour commencer</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-700">
              {ads.map(ad => {
                const Icon = typeIcon[ad.file_type] || Upload;
                return (
                  <div key={ad.id} className="flex items-center gap-4 p-4 hover:bg-gray-800 transition-colors">
                    <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-gray-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{ad.name}</p>
                      <p className="text-xs text-gray-400">{typeLabel[ad.file_type] || ad.file_type}</p>
                    </div>
                    {ad.is_active_in_music && (
                      <div className="flex items-center gap-1.5 px-2 py-1 bg-green-900/50 border border-green-700 rounded-full text-xs text-green-400">
                        <CheckCircle className="w-3 h-3" />
                        Actif dans Music
                      </div>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700 text-white">
                        {ad.file_type === 'audio' && (
                          <DropdownMenuItem
                            onClick={() => toggleMusicAd(ad)}
                            className="hover:bg-gray-700 cursor-pointer gap-2"
                          >
                            <Music className="w-4 h-4 text-purple-400" />
                            {ad.is_active_in_music ? 'Retirer des pubs Music' : 'Mettre dans les pubs Mykel Music'}
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem
                          onClick={() => toggleTVAd(ad)}
                          className="hover:bg-gray-700 cursor-pointer gap-2"
                        >
                          <Tv className="w-4 h-4 text-red-400" />
                          {ad.is_active_in_tv ? 'Retirer des pubs TV' : 'Mettre dans les pubs Mykel TV'}
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => deleteAd(ad)}
                          className="hover:bg-gray-700 cursor-pointer gap-2 text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                          Supprimer
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <input ref={fileRef} type="file" className="hidden" onChange={handleUpload} accept="audio/*,image/*,video/*" />
    </div>
  );
}

function StatCard({ label, value, color }) {
  const colors = { blue: 'text-blue-400 bg-blue-900/30 border-blue-800', green: 'text-green-400 bg-green-900/30 border-green-800', purple: 'text-purple-400 bg-purple-900/30 border-purple-800' };
  return (
    <div className={`rounded-xl border p-4 ${colors[color]}`}>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-sm opacity-80 mt-1">{label}</p>
    </div>
  );
}