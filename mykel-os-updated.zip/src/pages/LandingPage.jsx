import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Building2, Music, Tv, Sparkles, FileText, Wand2, Cloud, ArrowRight, Check, Zap, Shield, Globe, Star, Users, Play, Lock, Smartphone, Layers } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const DEFAULT_CONTENT = {
  hero: {
    title: 'Mykel',
    subtitle: 'Votre espace numérique tout-en-un',
    body: 'Cloud, Musique, TV, IA, Bureautique... Tous vos services préférés réunis en une seule plateforme élégante et performante.',
    bg_color: '#7c3aed',
    text_color: '#ffffff',
    button_text: "Démarrer gratuitement",
  },
  features: [
    { icon: 'Cloud', title: 'Mykel Cloud', description: 'Stockez vos fichiers en toute sécurité, accessible partout et à tout moment. Partagez en un clic.' },
    { icon: 'Music', title: 'Mykel Music', description: 'Écoutez votre musique préférée et découvrez de nouveaux artistes. Sans publicités, sans limites.' },
    { icon: 'Tv', title: 'Mykel TV', description: 'Films, séries et exclusivités en streaming haute qualité. Du contenu pour toute la famille.' },
    { icon: 'Sparkles', title: 'Mykel IA', description: 'Assistant IA intelligent pour répondre à toutes vos questions et booster votre productivité.' },
    { icon: 'FileText', title: 'Suite Bureautique', description: 'Documents, tableaux, présentations et dessins intégrés. Tout le nécessaire pour travailler.' },
    { icon: 'Wand2', title: 'Mykel SnapFix', description: 'Outils de retouche photo et création visuelle puissants. Donnez vie à vos idées.' },
  ],
  cta: {
    title: 'Prêt à commencer ?',
    body: "Rejoignez des milliers d'utilisateurs qui font confiance à Mykel pour gérer leur vie numérique au quotidien.",
    button_text: 'Créer mon compte gratuit',
    bg_color: '#1e1b4b',
  },
};

const ICON_MAP = { Cloud, Music, Tv, Sparkles, FileText, Wand2, Building2 };

const STATS = [
  { value: '6+', label: 'Services intégrés', color: 'from-violet-600 to-indigo-600' },
  { value: '100%', label: 'Sécurisé & chiffré', color: 'from-emerald-500 to-teal-600' },
  { value: '24/7', label: 'Disponible partout', color: 'from-orange-500 to-amber-600' },
  { value: '0€', label: 'Pour commencer', color: 'from-pink-500 to-rose-600' },
];

const SERVICES_PREVIEW = [
  { icon: Cloud, title: 'Mykel Cloud', color: 'from-blue-500 to-cyan-500', desc: 'Drive sécurisé illimité' },
  { icon: Music, title: 'Mykel Music', color: 'from-purple-500 to-pink-500', desc: 'Streaming sans pubs' },
  { icon: Tv, title: 'Mykel TV', color: 'from-red-500 to-orange-500', desc: 'Films & séries HD' },
  { icon: Sparkles, title: 'Mykel IA', color: 'from-violet-500 to-fuchsia-500', desc: 'Assistant intelligent' },
  { icon: FileText, title: 'Bureautique', color: 'from-green-500 to-emerald-500', desc: 'Docs, tableaux, slides' },
  { icon: Wand2, title: 'SnapFix', color: 'from-amber-500 to-orange-500', desc: 'Retouche photo IA' },
];

const TESTIMONIALS = [
  { name: 'Sarah K.', role: 'Designer', text: 'Mykel a remplacé 5 abonnements différents. Tout est au même endroit, c\'est génial !', avatar: 'from-pink-400 to-rose-500' },
  { name: 'Thomas L.', role: 'Entrepreneur', text: 'La suite bureautique intégrée est un game-changer. Je travaille directement depuis le cloud.', avatar: 'from-blue-400 to-indigo-500' },
  { name: 'Marie D.', role: 'Étudiante', text: 'Mykel Music sans pubs + le cloud pour mes cours = le combo parfait. Et c\'est gratuit !', avatar: 'from-purple-400 to-violet-500' },
];

export default function LandingPage() {
  const navigate = useNavigate();
  const [content, setContent] = useState(DEFAULT_CONTENT);

  useEffect(() => {
    // Try from localStorage first (set by App.jsx from AppSettings), then fetch
    const cached = localStorage.getItem('landing_page_content');
    if (cached) {
      try { setContent(JSON.parse(cached)); } catch {}
    }
    base44.entities.AppSettings.list()
      .then(settings => {
        const landingSetting = settings.find(s => s.key === 'landing_page_content');
        if (landingSetting?.value) {
          try {
            const parsed = JSON.parse(landingSetting.value);
            setContent(parsed);
            localStorage.setItem('landing_page_content', landingSetting.value);
          } catch {}
        }
      })
      .catch(() => {});
  }, []);

  const { hero, features, cta } = content;

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-md shadow-violet-500/20">
              <span className="text-white font-bold text-lg">M</span>
            </div>
            <span className="font-bold text-xl text-gray-900">Mykel</span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate('/MykelLogin')} className="text-gray-700 hover:text-violet-600">Se connecter</Button>
            <Button size="sm" onClick={() => navigate('/MykelLogin?mode=register')} className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 gap-1.5 shadow-md shadow-violet-500/20 transition-all hover:shadow-lg hover:scale-105">
              S'inscrire <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero — multi-color gradient */}
      <section className="relative overflow-hidden" style={{ color: hero.text_color }}>
        {/* Animated multi-color gradient background */}
        <div className="absolute inset-0" style={{
          background: `linear-gradient(135deg, ${hero.bg_color} 0%, #6d28d9 30%, #4f46e5 60%, #7c3aed 100%)`
        }} />
        {/* Floating gradient orbs */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            animate={{ x: [0, 30, 0], y: [0, -20, 0] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-10 left-1/4 w-72 h-72 bg-pink-500/30 rounded-full blur-3xl"
          />
          <motion.div
            animate={{ x: [0, -40, 0], y: [0, 30, 0] }}
            transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute bottom-10 right-1/4 w-80 h-80 bg-cyan-400/20 rounded-full blur-3xl"
          />
          <motion.div
            animate={{ x: [0, 20, 0], y: [0, 20, 0] }}
            transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-1/2 left-1/2 w-64 h-64 bg-amber-400/15 rounded-full blur-3xl"
          />
        </div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-24 sm:py-36 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-sm mb-6 text-sm font-medium border border-white/20">
              <Sparkles className="w-4 h-4 text-amber-300" /> Tout votre numérique, en un seul endroit
            </div>
            <h1 className="text-5xl sm:text-7xl font-extrabold tracking-tight mb-4 drop-shadow-lg">{hero.title}</h1>
            <p className="text-xl sm:text-2xl font-semibold mb-4 opacity-95">{hero.subtitle}</p>
            <p className="text-base sm:text-lg max-w-2xl mx-auto mb-10 opacity-80 leading-relaxed">{hero.body}</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button size="lg" onClick={() => navigate('/MykelLogin?mode=register')} className="bg-white text-violet-700 hover:bg-gray-100 text-base font-semibold px-8 h-12 gap-2 shadow-xl transition-all hover:scale-105">
                {hero.button_text} <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate('/MykelLogin')} className="border-white/30 text-white hover:bg-white/10 text-base font-semibold px-8 h-12 backdrop-blur-sm">
                Se connecter
              </Button>
            </div>
          </motion.div>
        </div>
        {/* Wave separator */}
        <svg className="absolute bottom-0 w-full" viewBox="0 0 1440 80" fill="none" preserveAspectRatio="none" style={{ height: 60 }}>
          <path d="M0 80L60 70C120 60 240 40 360 35C480 30 600 40 720 45C840 50 960 50 1080 45C1200 40 1320 30 1380 25L1440 20V80H0Z" fill="white"/>
        </svg>
      </section>

      {/* Stats bar — colorful */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          {STATS.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <div className={`text-3xl sm:text-4xl font-extrabold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>{stat.value}</div>
              <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Services preview — colorful cards */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-4">Une suite complète, pensée pour vous</h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">Chaque service est conçu avec le même soin et la même attention au détail.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {SERVICES_PREVIEW.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -4 }}
                className="group bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => navigate('/MykelLogin?mode=register')}
              >
                <div className={`w-12 h-12 bg-gradient-to-br ${s.color} rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-sm text-gray-900 mb-1">{s.title}</h3>
                <p className="text-xs text-gray-400">{s.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Features — detailed */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20">
        <div className="text-center mb-14">
          <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-4">Tout ce dont vous avez besoin</h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">Une suite complète de services pensés pour simplifier votre quotidien.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => {
            const Icon = ICON_MAP[f.icon] || Sparkles;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -4 }}
                className="group bg-white rounded-2xl border border-gray-100 p-7 hover:shadow-xl hover:border-violet-200 transition-all duration-300"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-violet-100 to-indigo-100 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-7 h-7 text-violet-600" />
                </div>
                <h3 className="font-bold text-lg text-gray-900 mb-2">{f.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{f.description}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Why Mykel — colorful background */}
      <section className="py-20 bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Pourquoi choisir Mykel ?</h2>
            <p className="text-gray-500 text-lg">La plateforme tout-en-un qui simplifie votre vie numérique.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Shield, title: 'Sécurité avant tout', desc: 'Vos données sont chiffrées et protégées. Nous ne les partageons jamais.', color: 'from-emerald-500 to-teal-600' },
              { icon: Zap, title: 'Ultra rapide', desc: 'Une expérience fluide et instantanée, sur tous vos appareils.', color: 'from-orange-500 to-amber-600' },
              { icon: Globe, title: 'Accessible partout', desc: 'Web, mobile, tablette — retrouvez vos services où que vous soyez.', color: 'from-blue-500 to-cyan-600' },
              { icon: Lock, title: 'Vie privée respectée', desc: 'Pas de revente de données, pas de publicité intrusive.', color: 'from-purple-500 to-violet-600' },
              { icon: Smartphone, title: 'Multi-appareils', desc: 'Synchronisé en temps réel sur tous vos écrans.', color: 'from-pink-500 to-rose-600' },
              { icon: Layers, title: 'Tout-en-un', desc: 'Finis les 10 abonnements différents. Un seul suffit.', color: 'from-indigo-500 to-blue-600' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <div className={`w-12 h-12 bg-gradient-to-br ${item.color} rounded-xl shadow-md flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-1">{item.title}</h3>
                    <p className="text-sm text-gray-500">{item.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Ils utilisent Mykel au quotidien</h2>
          <p className="text-gray-500 text-lg">Des milliers d'utilisateurs nous font déjà confiance.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${t.avatar} flex items-center justify-center text-white font-bold`}>
                  {t.name[0]}
                </div>
                <div>
                  <p className="font-semibold text-gray-900 text-sm">{t.name}</p>
                  <p className="text-xs text-gray-400">{t.role}</p>
                </div>
              </div>
              <div className="flex gap-0.5 mb-2">
                {[1,2,3,4,5].map(s => <Star key={s} className="w-3.5 h-3.5 text-amber-400 fill-current" />)}
              </div>
              <p className="text-sm text-gray-600 leading-relaxed">"{t.text}"</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA — dark gradient with color accents */}
      <section className="py-24 relative overflow-hidden" style={{ backgroundColor: cta.bg_color }}>
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-600/40 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-600/30 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 text-center text-white">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-5xl font-bold mb-4">{cta.title}</h2>
            <p className="text-lg opacity-80 mb-10 max-w-2xl mx-auto">{cta.body}</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button size="lg" onClick={() => navigate('/MykelLogin?mode=register')} className="bg-white text-violet-700 hover:bg-gray-100 text-base font-semibold px-8 h-12 gap-2 shadow-xl transition-all hover:scale-105">
                {cta.button_text} <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate('/MykelLogin')} className="border-white/30 text-white hover:bg-white/10 text-base font-semibold px-8 h-12">
                Se connecter
              </Button>
            </div>
            <div className="flex items-center justify-center gap-6 mt-10 text-sm opacity-60">
              <span className="flex items-center gap-1.5"><Check className="w-4 h-4" /> Gratuit</span>
              <span className="flex items-center gap-1.5"><Check className="w-4 h-4" /> Sans engagement</span>
              <span className="flex items-center gap-1.5"><Check className="w-4 h-4" /> Sans carte bancaire</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-400 py-14">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">M</span>
                </div>
                <span className="font-bold text-white text-lg">Mykel</span>
              </div>
              <p className="text-sm max-w-md">Votre espace numérique personnel. Tout ce dont vous avez besoin, réunis en un seul endroit, accessible partout et à tout moment.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3 text-sm">Produits</h4>
              <ul className="space-y-2 text-sm">
                <li>Mykel Cloud</li>
                <li>Mykel Music</li>
                <li>Mykel TV</li>
                <li>Mykel IA</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3 text-sm">Société</h4>
              <ul className="space-y-2 text-sm">
                <li>À propos</li>
                <li>Nos engagements</li>
                <li>Support</li>
                <li>Contact</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-6 text-center text-xs opacity-50">
            © 2026 Mykel. Tous droits réservés. · Votre espace numérique sécurisé
          </div>
        </div>
      </footer>
    </div>
  );
}