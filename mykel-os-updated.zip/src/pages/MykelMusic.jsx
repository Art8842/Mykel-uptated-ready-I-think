import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import ArtistPage from '@/components/music/ArtistPage';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useMusicPlayer } from '@/components/shared/MusicPlayerContext';
import FullPlayer from '@/components/music/FullPlayer';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ArrowLeft, Search, Music, Loader2, ListMusic, Play, Pause, MoreVertical,
  Clock, Users, Home, Library, X, Plus, Crown, Trash2, Shuffle, Globe, SkipForward, Sparkles
} from 'lucide-react';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import TrackRemovalAlert from '@/components/music/TrackRemovalAlert';
import SanctionGuard from '@/components/shared/SanctionGuard';
import { toast } from 'sonner';
import MusicSettingsModal from '@/components/music/MusicSettingsModal';
import EditorialSection from '@/components/music/EditorialSection';
import EditorialPlaylistView from '@/components/music/EditorialPlaylistView';
import EditorialStudio from '@/components/music/EditorialStudio';
import EditorRequestCard from '@/components/music/EditorRequestCard';
import VerifiedBadge from '@/components/music/VerifiedBadge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLanguage } from '@/lib/LanguageContext';
import { confirmAction } from '@/lib/confirm';

// Countdown timer component for announced-but-not-yet-published tracks
function Countdown({ publishAt }) {
  const [remaining, setRemaining] = useState('');
  useEffect(() => {
    const update = () => {
      const diff = new Date(publishAt) - new Date();
      if (diff <= 0) { setRemaining('Disponible !'); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setRemaining(`${d}j ${h}h ${m}m ${s}s`);
    };
    update();
    const t = setInterval(update, 1000);
    return () => clearInterval(t);
  }, [publishAt]);
  return (
    <div className="flex flex-col items-center justify-center h-full gap-3">
      <Clock className="w-10 h-10 text-purple-400" />
      <p className="text-white font-bold text-2xl font-mono">{remaining}</p>
      <p className="text-white/50 text-sm">avant la sortie</p>
    </div>
  );
}

// Add to Playlist Dialog
function AddToPlaylistDialog({ open, onClose, track, playlists, onAdd }) {
  if (!track) return null;
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-white">Ajouter à une playlist</DialogTitle>
        </DialogHeader>
        <p className="text-white/60 text-sm truncate">"{track.name || track.title}"</p>
        {playlists.length === 0 ? (
          <p className="text-white/40 text-sm text-center py-4">Aucune playlist créée</p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {playlists.map(pl => (
              <button
                key={pl.id}
                onClick={() => onAdd(pl, track)}
                className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/10 transition-all text-left"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {pl.cover_url
                    ? <img src={pl.cover_url} className="w-full h-full object-cover" alt="" />
                    : <ListMusic className="w-5 h-5 text-white" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{pl.name}</p>
                  <p className="text-white/40 text-xs">{(pl.music_file_ids || []).length} titre(s)</p>
                </div>
                <Plus className="w-4 h-4 text-purple-400 flex-shrink-0" />
              </button>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

const TABS = [
  { id: 'home', label: 'Accueil', icon: Home },
  { id: 'search', label: 'Recherche', icon: Search },
  { id: 'library', label: 'Bibliothèque', icon: Library },
];

export default function MykelMusic() {
  const navigate = useNavigate();
  const { currentTrack, isPlaying, playTrack, togglePlay, handleNext } = useMusicPlayer();
  const { t, lang, setLanguage, languages } = useLanguage();
  const [user, setUser] = useState(null);
  const [playlists, setPlaylists] = useState([]);
  const [publicTracks, setPublicTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchHistory, setSearchHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem('mykel_music_search_history') || '[]'); } catch { return []; }
  });
  const [activeTab, setActiveTab] = useState('home');
  const [showPlayer, setShowPlayer] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [countdownTrack, setCountdownTrack] = useState(null);
  const [creatorProfile, setCreatorProfile] = useState(null);
  const [addToPlaylist, setAddToPlaylist] = useState(null);
  const [selectedArtist, setSelectedArtist] = useState(null);
  const [allCreators, setAllCreators] = useState([]);
  const [musicSub, setMusicSub] = useState(null);
  const [musicStoreApp, setMusicStoreApp] = useState(null);
  const [userTokens, setUserTokens] = useState(null);
  const [subscribing, setSubscribing] = useState(false);
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [askBeforePlay, setAskBeforePlay] = useState(() => localStorage.getItem('mykel_ask_before_play') === '1');
  const [pendingTrack, setPendingTrack] = useState(null);
  const [isEditor, setIsEditor] = useState(false);
  const [showEditorJoin, setShowEditorJoin] = useState(false);
  const [showEditorialStudio, setShowEditorialStudio] = useState(false);
  const [openEditorialPlaylist, setOpenEditorialPlaylist] = useState(null);
  // Skip limiter for free users: 3 skips/hour
  const skipCountRef = useRef({ count: 0, resetAt: Date.now() + 3600000 });

  const hasPremium = musicSub?.active === true;

  const getSkipsLeft = () => {
    const s = skipCountRef.current;
    if (Date.now() > s.resetAt) { s.count = 0; s.resetAt = Date.now() + 3600000; }
    return 3 - s.count;
  };

  const consumeSkip = () => {
    const s = skipCountRef.current;
    if (Date.now() > s.resetAt) { s.count = 0; s.resetAt = Date.now() + 3600000; }
    s.count++;
  };

  const ALL_TABS = [
    { id: 'home', label: t('home'), icon: Home },
    { id: 'search', label: t('search'), icon: Search },
    { id: 'library', label: t('library'), icon: Library },
    ...(!hasPremium ? [{ id: 'premium', label: t('premium'), icon: Crown }] : []),
  ];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const u = await base44.auth.me();
      setUser(u);
      const [lists, allTracks, creatorProfiles, subs, storeApps, tokensData] = await Promise.all([
        base44.entities.Playlist.filter({ created_by: u.email }),
        base44.entities.MusicTrack.list(),
        base44.entities.MusicCreatorProfile.filter({ user_email: u.email }),
        base44.entities.MusicSubscription.filter({ user_email: u.email }),
        base44.entities.StoreApp.filter({ app_type: 'music_premium' }),
        base44.entities.UserTokens.filter({ user_email: u.email }),
      ]);
      setPlaylists(lists);
      setMusicSub(subs.length > 0 ? subs[0] : null);
      setMusicStoreApp(storeApps.length > 0 ? storeApps[0] : null);
      setUserTokens(tokensData.length > 0 ? tokensData[0] : null);

      const [activeCreators, removals, editorReqs] = await Promise.all([
        base44.entities.MusicCreatorProfile.filter({ active: true, validated: true }),
        base44.entities.TrackRemoval.list(),
        base44.entities.EditorRequest.filter({ user_email: u.email }),
      ]);
      setAllCreators(activeCreators);
      setIsEditor(u.role === 'admin' || editorReqs.some(r => r.status === 'approved'));
      const removedIds = new Set(removals.filter(r => r.status === 'removed').map(r => r.track_id));
      const activeEmails = new Set(activeCreators.map(c => c.email || c.user_email));
      const now = new Date();
      const visibleTracks = allTracks.filter(t => {
        if (removedIds.has(t.id)) return false;
        if (!activeEmails.has(t.creator_email)) return false;
        const pub = t.publish_at ? new Date(t.publish_at) : null;
        const ann = t.announce_at ? new Date(t.announce_at) : null;
        return (pub && pub <= now) || (ann && ann <= now);
      });
      setPublicTracks(visibleTracks);

      if (creatorProfiles.length > 0 && creatorProfiles[0].active && creatorProfiles[0].validated) {
        setCreatorProfile(creatorProfiles[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const doPlay = async (file) => {
    const now = new Date();
    const pub = file.publish_at ? new Date(file.publish_at) : null;
    if (pub && pub > now) { setCountdownTrack(file); return; }
    if (file.published === false && pub && pub > now) { setCountdownTrack(file); return; }

    // Pre-roll ad for non-premium
    if (!hasPremium) {
      try {
        const ads = await base44.entities.Advertisement.filter({ is_active_in_music: true });
        const audioAds = ads.filter(a => a.file_type === 'audio');
        if (audioAds.length > 0) {
          const ad = audioAds[Math.floor(Math.random() * audioAds.length)];
          const adTrack = { id: `ad_${ad.id}`, name: '🎵 Message publicitaire', file_url: ad.file_url, _isAd: true };
          playTrack(adTrack, [adTrack], 0);
          const audioEl = document.querySelector('audio');
          if (audioEl) {
            const onEnd = () => {
              audioEl.removeEventListener('ended', onEnd);
              playTrack(file, [file], 0);
              setShowPlayer(true);
            };
            audioEl.addEventListener('ended', onEnd);
          }
          setShowPlayer(true);
          return;
        }
      } catch {}
    }
    playTrack(file, [file], 0);
    setShowPlayer(true);
  };

  const handlePlay = async (file) => {
    if (currentTrack?.id === file.id) { togglePlay(); return; }
    if (askBeforePlay) {
      setPendingTrack(file);
      return;
    }
    await doPlay(file);
  };

  const handleSearch = (q) => {
    setSearchQuery(q);
  };

  const commitSearch = (q) => {
    const term = (q ?? searchQuery).trim();
    if (!term) return;
    setSearchQuery(term);
    if (!searchHistory.includes(term)) {
      const newHistory = [term, ...searchHistory].slice(0, 10);
      setSearchHistory(newHistory);
      localStorage.setItem('mykel_music_search_history', JSON.stringify(newHistory));
    }
  };

  const removeFromHistory = (term) => {
    const newHistory = searchHistory.filter(h => h !== term);
    setSearchHistory(newHistory);
    localStorage.setItem('mykel_music_search_history', JSON.stringify(newHistory));
  };

  const handleSubscribePremium = async () => {
    if (!musicStoreApp || !userTokens) return;
    if (userTokens.tokens < musicStoreApp.price) {
      toast.error('Pas assez de jetons !');
      return;
    }
    setSubscribing(true);
    try {
      const today = new Date();
      const next = new Date(today);
      next.setMonth(next.getMonth() + 1);
      await Promise.all([
        base44.entities.UserTokens.update(userTokens.id, { tokens: userTokens.tokens - musicStoreApp.price }),
        base44.entities.MusicSubscription.create({
          user_email: user.email,
          monthly_price: musicStoreApp.price,
          active: true,
          last_payment_date: today.toISOString(),
          next_payment_date: next.toISOString(),
        }),
      ]);
      toast.success('Mykel Music Premium activé ! 🎵');
      await loadData();
    } catch {
      toast.error('Erreur lors de l\'abonnement');
    } finally {
      setSubscribing(false);
    }
  };

  const handleCancelPremium = async () => {
    if (!musicSub) return;
    if (!await confirmAction('Annuler Mykel Music Premium ?')) return;
    await base44.entities.MusicSubscription.update(musicSub.id, { active: false });
    toast.success('Abonnement annulé');
    await loadData();
  };

  const handleAddToPlaylist = async (playlist, track) => {
    const ids = playlist.music_file_ids || [];
    const trackId = track.id;
    if (ids.includes(trackId)) return;
    await base44.entities.Playlist.update(playlist.id, {
      music_file_ids: [...ids, trackId]
    });
    setAddToPlaylist(null);
    await loadData();
  };

  const q = searchQuery.toLowerCase().trim();

  // Search results
  const artistResults = q ? allCreators.filter(c =>
    c.stage_name?.toLowerCase().includes(q) ||
    c.bio?.toLowerCase().includes(q)
  ) : [];

  const trackResults = q ? [
    ...publicTracks
      .filter(t =>
        t.title?.toLowerCase().includes(q) ||
        t.stage_name?.toLowerCase().includes(q) ||
        t.album_name?.toLowerCase().includes(q)
      )
      .map(t => ({ ...t, name: t.title, cover_url: t.album_cover_url, _source: 'public' }))
  ] : [];

  const searchResults = trackResults;

  // Home tab: top 4 playlists + recent public albums
  const topPlaylists = playlists.slice(0, 4);
  const recentAlbums = publicTracks.reduce((acc, t) => {
    if (t.album_name && !acc.find(a => a.album_name === t.album_name)) {
      acc.push(t);
    }
    return acc;
  }, []).slice(0, 6);

  return (
    <SanctionGuard scope="mykel_music">
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-gray-950 to-gray-900 text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-white/10 flex-shrink-0">
        <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl('Dashboard'))} className="text-white hover:bg-white/10">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2 flex-1">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
            <Music className="w-4 h-4 text-white" />
          </div>
          <span className="text-lg font-bold">Mykel Music</span>
        </div>
        {/* Language picker */}
        <div className="relative">
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => setShowLangPicker(o => !o)}>
            <Globe className="w-5 h-5" />
          </Button>
          {showLangPicker && (
            <div className="absolute right-0 top-full mt-1 w-44 bg-gray-900 border border-gray-700 rounded-xl shadow-2xl z-50 overflow-hidden">
              {Object.values(languages).map(l => (
                <button
                  key={l.code}
                  onClick={() => { setLanguage(l.code); setShowLangPicker(false); }}
                  className={`w-full flex items-center gap-2 px-3 py-2.5 text-sm transition-colors ${lang === l.code ? 'bg-purple-600 text-white' : 'text-white/70 hover:bg-white/10'}`}
                >
                  <span className="text-base">{l.flag}</span>{l.label}
                </button>
              ))}
            </div>
          )}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-gray-900 border-gray-700 text-white">
            <DropdownMenuItem onClick={() => setShowSettings(true)} className="cursor-pointer hover:bg-white/10">
              ⚙️ {t('settings')}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => { setAskBeforePlay(v => { const nv = !v; localStorage.setItem('mykel_ask_before_play', nv ? '1' : '0'); return nv; }); }}
              className="cursor-pointer hover:bg-white/10"
            >
              {askBeforePlay ? '✅' : '⬜'} {t('ask_before_play')}
            </DropdownMenuItem>
            {creatorProfile && (
              <DropdownMenuItem onClick={() => navigate(createPageUrl('MykelMusicCreator'))} className="cursor-pointer hover:bg-white/10">
                🎵 {t('creator_mode')}
              </DropdownMenuItem>
            )}
            {isEditor && (
              <DropdownMenuItem onClick={() => setShowEditorialStudio(true)} className="cursor-pointer hover:bg-white/10">
                ✨ Studio éditorial
              </DropdownMenuItem>
            )}
            {!isEditor && (
              <DropdownMenuItem onClick={() => setShowEditorJoin(true)} className="cursor-pointer hover:bg-white/10">
                ✨ Devenir éditeur
              </DropdownMenuItem>
            )}
            {user?.role === 'admin' && (
              <DropdownMenuItem
                onClick={() => navigate(createPageUrl('AdminPanel') + '?section=editorial')}
                className="cursor-pointer hover:bg-white/10"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Demandes éditeurs
              </DropdownMenuItem>
            )}
            {user?.role === 'admin' && (
              <DropdownMenuItem
                onClick={() => navigate(createPageUrl('AdminPanel') + '?section=removals')}
                className="cursor-pointer hover:bg-red-500/20 text-red-400"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                {t('removal')}
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Desktop Tabs */}
      <div className="hidden md:flex gap-1 px-4 pt-4">
        {ALL_TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
              activeTab === tab.id
                ? tab.id === 'premium' ? 'bg-yellow-500 text-white' : 'bg-purple-600 text-white'
                : tab.id === 'premium' ? 'text-yellow-400 hover:bg-yellow-500/20' : 'text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 px-4 pb-6 mt-4 overflow-auto" style={{ paddingBottom: currentTrack ? '10rem' : '6rem' }}>
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
          </div>
        ) : (
          <>
            {/* ── ACCUEIL ── */}
            {activeTab === 'home' && (
              <div className="space-y-8">
                {/* Editorial Playlists */}
                <div className="animate-fade-up"><EditorialSection onOpenPlaylist={setOpenEditorialPlaylist} /></div>

                {/* Top Playlists */}
                <div className="animate-fade-up" style={{ animationDelay: '0.05s' }}>
                  <h2 className="text-white font-bold text-xl mb-4">{t('playlists')}</h2>
                  {topPlaylists.length === 0 ? (
                    <p className="text-white/40 text-sm">{t('no_playlist')}</p>
                  ) : (
                    <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 -mx-1 px-1">
                      {topPlaylists.map(pl => {
                        const tracks = (pl.music_file_ids || []).map(id => publicTracks.find(f => f.id === id)).filter(Boolean);
                        return (
                          <div key={pl.id} className="group relative flex-shrink-0 w-36 sm:w-44 p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all cursor-pointer" onClick={() => navigate(`/PlaylistView?id=${pl.id}`)}>
                              <div className="w-full aspect-square rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center mb-3 overflow-hidden relative shadow-lg">
                                {pl.cover_url
                                  ? <img src={pl.cover_url} className="w-full h-full object-cover" alt="" />
                                  : <ListMusic className="w-8 h-8 text-white" />
                                }
                                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-end justify-end p-2">
                                  <button
                                    onClick={(e) => { e.stopPropagation(); if (tracks[0]) handlePlay(tracks[0]); }}
                                    className="opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 w-11 h-11 bg-green-500 hover:bg-green-400 rounded-full flex items-center justify-center shadow-xl transition-all"
                                  >
                                    <Play className="w-5 h-5 text-black ml-0.5" fill="black" />
                                  </button>
                                </div>
                              </div>
                              <p className="font-semibold text-white text-sm truncate">{pl.name}</p>
                              <p className="text-xs text-white/40 truncate">{tracks.length} titre(s)</p>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Recent Albums from Artists */}
                {recentAlbums.length > 0 && (
                  <div className="animate-fade-up" style={{ animationDelay: '0.1s' }}>
                    <h2 className="text-white font-bold text-xl mb-4">{t('recent_albums')}</h2>
                    <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 -mx-1 px-1">
                      {recentAlbums.map(track => (
                        <button
                          key={track.id}
                          onClick={() => handlePlay(track)}
                          className="group flex-shrink-0 w-36 sm:w-44 p-3 bg-white/5 hover:bg-white/10 rounded-2xl text-left transition-all"
                        >
                          <div className="w-full aspect-square rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center mb-3 overflow-hidden shadow-lg relative">
                            {track.album_cover_url
                              ? <img src={track.album_cover_url} className="w-full h-full object-cover" alt="" />
                              : <Music className="w-8 h-8 text-white" />
                            }
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-end justify-end p-2">
                              <div className="opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 w-11 h-11 bg-green-500 rounded-full flex items-center justify-center shadow-xl transition-all">
                                <Play className="w-5 h-5 text-black ml-0.5" fill="black" />
                              </div>
                            </div>
                          </div>
                          <p className="font-semibold text-white text-sm truncate">{track.album_name}</p>
                          <p className="text-xs text-white/40 truncate">{track.stage_name}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {recentAlbums.length === 0 && topPlaylists.length === 0 && (
                  <div className="text-center py-20 text-white/40">
                    <Music className="w-12 h-12 mx-auto mb-4" />
                    <p>Bienvenue sur Mykel Music !<br />Importez des fichiers depuis votre Drive pour commencer.</p>
                  </div>
                )}
              </div>
            )}

            {/* ── RECHERCHE & DÉCOUVERTE ── */}
            {activeTab === 'search' && selectedArtist && (
              <ArtistPage
                creator={selectedArtist}
                tracks={publicTracks}
                onBack={() => setSelectedArtist(null)}
                currentTrack={currentTrack}
                isPlaying={isPlaying}
                onPlay={handlePlay}
                user={user}
                allCreators={allCreators}
              />
            )}
            {activeTab === 'search' && !selectedArtist && (
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                  <Input
                    value={searchQuery}
                    onChange={e => handleSearch(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') commitSearch(); }}
                    placeholder="Artistes, titres, albums..."
                    className="pl-9 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                    autoFocus
                  />
                </div>

                {/* Search history */}
                {!q && searchHistory.length > 0 && (
                  <div>
                    <p className="text-white/40 text-xs font-medium mb-2">Recherches récentes</p>
                    <div className="space-y-1">
                      {searchHistory.map((term, i) => (
                        <div key={i} className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/5 group">
                          <button
                            className="flex items-center gap-3 flex-1 text-left"
                            onClick={() => commitSearch(term)}
                          >
                            <Search className="w-4 h-4 text-white/30" />
                            <span className="text-white/70 text-sm">{term}</span>
                          </button>
                          <button
                            onClick={() => removeFromHistory(term)}
                            className="opacity-0 group-hover:opacity-100 p-1 rounded-lg hover:bg-white/10 transition-all"
                          >
                            <X className="w-3 h-3 text-white/50" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Search results */}
                {q && (
                  <div className="space-y-6">
                    {/* Artist results */}
                    {artistResults.length > 0 && (
                      <div>
                        <p className="text-white/40 text-xs font-medium mb-3">Artistes</p>
                        <div className="space-y-2">
                          {artistResults.map(creator => (
                            <button
                              key={creator.id}
                              onClick={() => setSelectedArtist(creator)}
                              className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-all text-left"
                            >
                              <div className="w-12 h-12 rounded-full flex-shrink-0 overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600">
                                {creator.avatar_url
                                  ? <img src={creator.avatar_url} className="w-full h-full object-cover" alt="" />
                                  : <div className="w-full h-full flex items-center justify-center text-white font-bold">{creator.stage_name?.[0]?.toUpperCase()}</div>
                                }
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-white font-medium truncate flex items-center gap-1">
                                  {creator.stage_name}
                                  {creator.certified && <VerifiedBadge type="artist" size={14} />}
                                </p>
                                <p className="text-white/50 text-xs">{creator.creator_type === 'music' ? '🎵 Artiste' : creator.creator_type === 'podcast' ? '🎙️ Podcast' : '🎵🎙️ Artiste & Podcast'}</p>
                              </div>
                              <Users className="w-4 h-4 text-white/30 flex-shrink-0" />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    {/* Track results */}
                    <div>
                      <p className="text-white/40 text-xs font-medium mb-3">{searchResults.length} titre(s) pour "{searchQuery}"</p>
                      {searchResults.length === 0 && artistResults.length === 0 ? (
                        <div className="text-center py-12 text-white/40">
                          <Search className="w-10 h-10 mx-auto mb-3" />
                          <p>Aucun résultat trouvé</p>
                        </div>
                      ) : searchResults.length > 0 ? (
                        <TrackList
                          tracks={searchResults}
                          onPlay={handlePlay}
                          currentTrack={currentTrack}
                          isPlaying={isPlaying}
                          playlists={playlists}
                          onAddToPlaylist={setAddToPlaylist}
                          isAdmin={user?.role === 'admin'}
                          onAdminRemove={(track) => navigate(createPageUrl('AdminPanel') + `?section=removals&trackId=${track.id}`)}
                        />
                      ) : null}
                    </div>
                  </div>
                )}

                {/* Discover by artist when no search */}
                {!q && (
                  <div>
                    <h3 className="text-white font-bold text-lg mb-4">Découvrir les artistes</h3>
                    <DiscoverSection
                      tracks={publicTracks}
                      creators={allCreators}
                      onPlay={handlePlay}
                      currentTrack={currentTrack}
                      isPlaying={isPlaying}
                      playlists={playlists}
                      onAddToPlaylist={setAddToPlaylist}
                      isAdmin={user?.role === 'admin'}
                      onAdminRemove={(track) => navigate(createPageUrl('AdminPanel') + `?section=removals&trackId=${track.id}`)}
                      onArtistClick={setSelectedArtist}
                    />
                  </div>
                )}
              </div>
            )}

            {/* ── PREMIUM ── */}
            {activeTab === 'premium' && (
              <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-yellow-500/30">
                  <Crown className="w-10 h-10 text-white" />
                </div>
                <div>
                  <h2 className="text-white font-bold text-2xl mb-2">Mykel Music Premium</h2>
                  <p className="text-white/60 text-sm max-w-xs">Profitez d'une expérience musicale sans pub, avec des fonctionnalités exclusives.</p>
                </div>

                {musicStoreApp ? (
                  <div className="w-full max-w-sm bg-gradient-to-br from-yellow-500/20 to-orange-500/10 border border-yellow-500/30 rounded-2xl p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="text-left">
                        <p className="text-white font-bold text-lg">{musicStoreApp.name}</p>
                        {musicStoreApp.description && <p className="text-white/50 text-sm">{musicStoreApp.description}</p>}
                      </div>
                      <div className="text-right">
                        <p className="text-yellow-400 font-bold text-2xl">{musicStoreApp.price}</p>
                        <p className="text-white/40 text-xs">jetons/mois</p>
                      </div>
                    </div>
                    <ul className="space-y-2 text-sm text-white/70 text-left">
                      <li className="flex items-center gap-2">✅ Écoute sans publicité</li>
                      <li className="flex items-center gap-2">✅ Accès aux contenus exclusifs</li>
                      <li className="flex items-center gap-2">✅ Support prioritaire</li>
                    </ul>
                    {userTokens && (
                      <p className="text-white/40 text-xs text-center">Solde : {userTokens.tokens} jetons</p>
                    )}
                    <Button
                      onClick={handleSubscribePremium}
                      disabled={subscribing || !userTokens || userTokens.tokens < musicStoreApp.price}
                      className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold gap-2 disabled:opacity-40"
                    >
                      {subscribing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Crown className="w-4 h-4" />}
                      S'abonner — {musicStoreApp.price} jetons/mois
                    </Button>
                    {(!userTokens || userTokens.tokens < musicStoreApp.price) && (
                      <p className="text-red-400 text-xs text-center">Jetons insuffisants</p>
                    )}
                  </div>
                ) : (
                  <div className="w-full max-w-sm bg-white/5 border border-white/10 rounded-2xl p-6 text-center">
                    <p className="text-white/40 text-sm">Aucun plan premium disponible pour le moment.</p>
                  </div>
                )}
              </div>
            )}

            {/* ── BIBLIOTHÈQUE ── */}
            {activeTab === 'library' && (
              <div className="space-y-8">
                {/* Playlists */}
                <div>
                  <h2 className="text-white font-bold text-xl mb-4">{t('my_playlists')}</h2>
                  {playlists.length === 0 ? (
                    <p className="text-white/40 text-sm">{t('no_playlist')}</p>
                  ) : (
                    <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 -mx-1 px-1">
                      {playlists.map(pl => {
                        const tracks = (pl.music_file_ids || []).map(id => publicTracks.find(f => f.id === id)).filter(Boolean);
                        return (
                          <div key={pl.id} className="group relative flex-shrink-0 w-40 sm:w-48 p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all cursor-pointer" onClick={() => navigate(`/PlaylistView?id=${pl.id}`)}>
                              <div className="w-full aspect-square rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center mb-3 overflow-hidden relative shadow-lg">
                                {pl.cover_url
                                  ? <img src={pl.cover_url} className="w-full h-full object-cover" alt="" />
                                  : <ListMusic className="w-8 h-8 text-white" />
                                }
                                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-end justify-end p-2 gap-2">
                                  <button onClick={(e) => { e.stopPropagation(); if (tracks[0]) { const shuffled = [...tracks].sort(() => Math.random() - 0.5); handlePlay(shuffled[0]); }}} className="opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 w-9 h-9 bg-white/20 backdrop-blur rounded-full flex items-center justify-center transition-all">
                                    <Shuffle className="w-4 h-4 text-white" />
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); if (tracks[0]) handlePlay(tracks[0]); }} className="opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 w-11 h-11 bg-green-500 hover:bg-green-400 rounded-full flex items-center justify-center shadow-xl transition-all">
                                    <Play className="w-5 h-5 text-black ml-0.5" fill="black" />
                                  </button>
                                </div>
                              </div>
                              <p className="font-semibold text-white truncate">{pl.name}</p>
                              <p className="text-xs text-white/40">{tracks.length} titre(s)</p>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Saved playlists from editorial team */}
                {playlists.filter(p => p.is_editorial_copy).length > 0 && (
                  <div>
                    <h2 className="text-white font-bold text-xl mb-4">Playlists éditoriales sauvegardées</h2>
                    <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 -mx-1 px-1">
                      {playlists.filter(p => p.is_editorial_copy).map(pl => (
                        <div key={pl.id} className="group relative flex-shrink-0 w-40 sm:w-48 p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all cursor-pointer" onClick={() => navigate(`/PlaylistView?id=${pl.id}`)}>
                          <div className="w-full aspect-square rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center mb-3 overflow-hidden shadow-lg">
                            {pl.cover_url
                              ? <img src={pl.cover_url} className="w-full h-full object-cover" alt="" />
                              : <ListMusic className="w-8 h-8 text-white" />}
                          </div>
                          <p className="font-semibold text-white truncate">{pl.name}</p>
                          <p className="text-xs text-white/40">{(pl.music_file_ids || []).length} titre(s)</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Now playing bar */}
      {currentTrack && !showPlayer && (
        <div className="fixed left-0 right-0 bg-purple-900/95 backdrop-blur border-t border-purple-700 px-4 py-3 flex items-center gap-3 cursor-pointer z-30"
          style={{ bottom: '4rem' }}
          onClick={() => setShowPlayer(true)}
        >
          <div className="w-10 h-10 rounded-lg bg-purple-800 flex items-center justify-center flex-shrink-0 overflow-hidden">
            {currentTrack.cover_url
              ? <img src={currentTrack.cover_url} className="w-full h-full object-cover" alt="" />
              : <Music className="w-5 h-5 text-purple-300" />
            }
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium truncate">{currentTrack.name || currentTrack.title}</p>
            <p className="text-white/50 text-xs truncate">{currentTrack.artist || currentTrack.stage_name || 'Artiste inconnu'}</p>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setAddToPlaylist(currentTrack);
            }}
            className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white mr-1"
            title="Ajouter à une playlist"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); togglePlay(); }}
            className="w-9 h-9 rounded-full bg-purple-600 flex items-center justify-center text-white"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
        </div>
      )}

      {/* Mobile Bottom Nav — just below the player */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-gray-950/95 backdrop-blur border-t border-white/10 flex z-40">
        {ALL_TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 flex flex-col items-center py-2 gap-1 transition-all ${
              activeTab === tab.id
                ? tab.id === 'premium' ? 'text-yellow-400' : 'text-purple-400'
                : 'text-white/40 hover:text-white/70'
            }`}
          >
            <tab.icon className="w-5 h-5" />
            <span className="text-xs font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Full Player */}
      {showPlayer && currentTrack && (
        <FullPlayer onClose={() => setShowPlayer(false)} />
      )}

      {/* Countdown modal */}
      {countdownTrack && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center" onClick={() => setCountdownTrack(null)}>
          <div className="bg-gray-900 rounded-2xl p-8 w-80 text-center" onClick={e => e.stopPropagation()}>
            {countdownTrack.album_cover_url && (
              <img src={countdownTrack.album_cover_url} className="w-32 h-32 rounded-xl mx-auto mb-4 object-cover" alt="" />
            )}
            <p className="text-white font-bold text-lg mb-1">{countdownTrack.title}</p>
            <p className="text-white/50 text-sm mb-4">{countdownTrack.stage_name}</p>
            <Countdown publishAt={countdownTrack.publish_at} />
            <Button variant="ghost" className="mt-6 text-white/50" onClick={() => setCountdownTrack(null)}>Fermer</Button>
          </div>
        </div>
      )}

      {/* Add to Playlist Dialog */}
      <AddToPlaylistDialog
        open={!!addToPlaylist}
        onClose={() => setAddToPlaylist(null)}
        track={addToPlaylist}
        playlists={playlists}
        onAdd={handleAddToPlaylist}
      />

      <MusicSettingsModal open={showSettings} onClose={() => { setShowSettings(false); loadData(); }} user={user} />
      <AnnouncementModal target="app" targetApp="MykelMusic" />
      <TrackRemovalAlert userEmail={user?.email} />

      {/* Editorial Studio */}
      {showEditorialStudio && (
        <EditorialStudio
          userEmail={user.email}
          userName={user.full_name}
          publicTracks={publicTracks}
          onBack={() => setShowEditorialStudio(false)}
        />
      )}

      {/* Editorial Playlist View */}
      {openEditorialPlaylist && (
        <EditorialPlaylistView
          playlist={openEditorialPlaylist}
          publicTracks={publicTracks}
          onBack={() => setOpenEditorialPlaylist(null)}
        />
      )}

      {/* Editor Join Dialog */}
      <Dialog open={showEditorJoin} onOpenChange={setShowEditorJoin}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" /> Devenir éditeur
            </DialogTitle>
          </DialogHeader>
          <EditorRequestCard user={user} />
        </DialogContent>
      </Dialog>

      {/* Ask Before Play Dialog */}
      {pendingTrack && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setPendingTrack(null)}>
          <div className="bg-gray-900 border border-white/10 rounded-2xl p-6 w-full max-w-sm text-center space-y-4" onClick={e => e.stopPropagation()}>
            <div className="w-16 h-16 rounded-xl mx-auto overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
              {pendingTrack.cover_url || pendingTrack.album_cover_url
                ? <img src={pendingTrack.cover_url || pendingTrack.album_cover_url} className="w-full h-full object-cover" alt="" />
                : <Music className="w-8 h-8 text-white" />
              }
            </div>
            <div>
              <p className="text-white font-bold truncate">{pendingTrack.name || pendingTrack.title}</p>
              <p className="text-white/50 text-sm">{pendingTrack.artist || pendingTrack.stage_name || 'Artiste inconnu'}</p>
            </div>
            <p className="text-white/60 text-sm">{t('ask_before_play')} ?</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 border-white/20 text-white hover:bg-white/10" onClick={() => setPendingTrack(null)}>
                {t('cancel')}
              </Button>
              <Button className="flex-1 bg-purple-600 hover:bg-purple-500" onClick={() => { const track = pendingTrack; setPendingTrack(null); doPlay(track); }}>
                <Play className="w-4 h-4 mr-1" />Écouter
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Free skip limit indicator */}
      {!hasPremium && currentTrack && (
        <div className="fixed top-14 right-4 z-30 bg-gray-900/90 border border-white/10 rounded-full px-3 py-1 flex items-center gap-1.5 text-xs text-white/60 backdrop-blur">
          <SkipForward className="w-3 h-3" />
          <span>{getSkipsLeft()} skips/h</span>
        </div>
      )}
    </div>
    </SanctionGuard>
  );
}

function TrackList({ tracks, onPlay, currentTrack, isPlaying, playlists = [], onAddToPlaylist, isAdmin = false, onAdminRemove }) {
  const now = new Date();
  if (tracks.length === 0) {
    return (
      <div className="text-center py-20 text-white/40">
        <Music className="w-12 h-12 mx-auto mb-4" />
        <p>Aucun fichier ici.</p>
      </div>
    );
  }
  return (
    <div className="space-y-2">
      {tracks.map(track => {
        const isActive = currentTrack?.id === track.id;
        const pub = track.publish_at ? new Date(track.publish_at) : null;
        const isPending = pub && pub > now;
        const displayName = track.name || track.title;
        const displayArtist = track.artist || track.stage_name;
        const coverUrl = track.cover_url || track.album_cover_url;

        return (
          <div
            key={track.id}
            className={`flex items-center gap-4 p-3 rounded-xl transition-all ${
              isActive ? 'bg-purple-600/40 border border-purple-500/50' : 'hover:bg-white/5'
            }`}
          >
            <button className="flex items-center gap-4 flex-1 text-left min-w-0" onClick={() => onPlay(track)}>
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0 overflow-hidden relative">
                {coverUrl ? (
                  <img src={coverUrl} className="w-full h-full object-cover" alt="" />
                ) : (
                  <Music className="w-6 h-6 text-white" />
                )}
                {isActive && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
                  </div>
                )}
                {isPending && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-purple-300" />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`font-medium truncate flex items-center gap-1.5 ${isActive ? 'text-purple-300' : 'text-white'}`}>
                  <span className="truncate">{displayName}</span>
                  {track.is_ai_generated && <span className="flex-shrink-0 px-1 py-0 rounded text-[10px] font-bold bg-purple-600 text-white leading-4">IA</span>}
                  {track.is_explicit && <span className="flex-shrink-0 px-1 py-0 rounded text-[10px] font-bold bg-gray-600 text-white border border-gray-400 leading-4">E</span>}
                </p>
                <p className="text-sm text-white/50 truncate">{displayArtist || 'Artiste inconnu'}</p>
              </div>
              {isPending && <span className="text-xs text-purple-400 flex-shrink-0">À venir</span>}
              {track.duration && !isPending && (
                <span className="text-xs text-white/40 flex-shrink-0">{Math.floor(track.duration / 60)}:{String(track.duration % 60).padStart(2, '0')}</span>
              )}
            </button>
            {/* 3 dots: add to playlist */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/50 hover:text-white flex-shrink-0">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-gray-900 border-gray-700 text-white">
                <DropdownMenuItem onClick={() => onAddToPlaylist(track)} className="cursor-pointer hover:bg-white/10">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter à une playlist
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem onClick={() => onAdminRemove(track)} className="cursor-pointer hover:bg-red-500/20 text-red-400">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Démarche de suppression
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      })}
    </div>
  );
}

function formatListeners(n) {
  if (!n) return null;
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'Md';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}

function DiscoverSection({ tracks, creators = [], onPlay, currentTrack, isPlaying, playlists, onAddToPlaylist, isAdmin = false, onAdminRemove, onArtistClick }) {
  const now = new Date();
  if (tracks.length === 0) {
    return (
      <div className="text-center py-12 text-white/40">
        <Users className="w-12 h-12 mx-auto mb-4" />
        <p>Aucun contenu de créateur disponible.</p>
      </div>
    );
  }

  const byArtist = tracks.reduce((acc, t) => {
    if (!acc[t.stage_name]) acc[t.stage_name] = [];
    acc[t.stage_name].push(t);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      {Object.entries(byArtist).map(([artist, artistTracks]) => {
        const creatorProfile = creators.find(c => c.stage_name === artist);
        const listeners = creatorProfile?.monthly_listeners;
        return (
          <div key={artist}>
            <div className="flex items-center gap-3 mb-3">
              {creatorProfile?.avatar_url && (
                <img src={creatorProfile.avatar_url} className="w-8 h-8 rounded-full object-cover flex-shrink-0" alt="" />
              )}
              <div>
                <button
                className="text-white font-bold text-lg hover:text-purple-300 transition-colors text-left flex items-center gap-1.5"
                onClick={() => creatorProfile && onArtistClick?.(creatorProfile)}
                >
                {artist}
                {creatorProfile?.certified && <VerifiedBadge type="artist" size={16} />}
                </button>
                {listeners > 0 && (
                  <p className="text-white/40 text-xs flex items-center gap-1">
                    <Users className="w-3 h-3" />{formatListeners(listeners)} auditeurs mensuels
                  </p>
                )}
              </div>
            </div>
            <div className="space-y-2">
              {artistTracks.map(track => {
                const pub = track.publish_at ? new Date(track.publish_at) : null;
                const isPending = pub && pub > now;
                const isActive = currentTrack?.id === track.id;
                const normalizedTrack = { ...track, name: track.title, cover_url: track.album_cover_url };
                return (
                  <div
                    key={track.id}
                    className={`flex items-center gap-4 p-3 rounded-xl transition-all ${
                      isActive ? 'bg-purple-600/40 border border-purple-500/50' : 'hover:bg-white/5'
                    }`}
                  >
                    <button className="flex items-center gap-4 flex-1 text-left min-w-0" onClick={() => onPlay(track)}>
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0 overflow-hidden relative">
                        {track.album_cover_url
                          ? <img src={track.album_cover_url} className="w-full h-full object-cover" alt="" />
                          : <Music className="w-6 h-6 text-white m-auto mt-3" />
                        }
                        {isPending && (
                          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                            <Clock className="w-5 h-5 text-purple-300" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-medium truncate flex items-center gap-1.5">
                          <span className="truncate">{track.title}</span>
                          {track.is_ai_generated && <span className="flex-shrink-0 px-1 py-0 rounded text-[10px] font-bold bg-purple-600 text-white leading-4">IA</span>}
                          {track.is_explicit && <span className="flex-shrink-0 px-1 py-0 rounded text-[10px] font-bold bg-gray-600 text-white border border-gray-400 leading-4">E</span>}
                        </p>
                        <p className="text-white/50 text-xs truncate">{track.album_name || 'Single'}</p>
                      </div>
                      {isPending && <span className="text-xs text-purple-400">À venir</span>}
                    </button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/50 hover:text-white flex-shrink-0">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-gray-900 border-gray-700 text-white">
                        <DropdownMenuItem onClick={() => onAddToPlaylist(normalizedTrack)} className="cursor-pointer hover:bg-white/10">
                          <Plus className="w-4 h-4 mr-2" />
                          Ajouter à une playlist
                        </DropdownMenuItem>
                        {isAdmin && (
                          <DropdownMenuItem onClick={() => onAdminRemove(track)} className="cursor-pointer hover:bg-red-500/20 text-red-400">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Démarche de suppression
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}