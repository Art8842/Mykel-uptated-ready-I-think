import React from 'react';
import { ArrowLeft, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CHAT_URL = 'https://mykel-chat.base44.app';

export default function MykelChat() {
  const navigate = useNavigate();

  return (
    <div className="h-screen flex flex-col bg-gray-950">
      {/* Minimal toolbar — just back + open, NOT a browser chrome */}
      <div className="flex items-center justify-between gap-2 p-3 bg-gray-900 border-b border-gray-800 flex-shrink-0">
        <button
          onClick={() => navigate('/Dashboard')}
          className="w-10 h-10 rounded-full bg-gray-800 text-white flex items-center justify-center hover:bg-gray-700 transition-all"
          title="Retour"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-white text-sm font-medium flex-1 text-center">Mykel Chat</span>
        <button
          onClick={() => window.open(CHAT_URL, '_blank', 'noopener,noreferrer')}
          className="w-10 h-10 rounded-full bg-gray-800 text-white flex items-center justify-center hover:bg-gray-700 transition-all"
          title="Ouvrir dans un nouvel onglet"
        >
          <ExternalLink className="w-4 h-4" />
        </button>
      </div>

      {/* Chat app — fully interactive, integrated */}
      <iframe
        src={CHAT_URL}
        className="flex-1 w-full border-0 bg-white"
        title="Mykel Chat"
        sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
        allow="clipboard-read; clipboard-write"
      />
    </div>
  );
}