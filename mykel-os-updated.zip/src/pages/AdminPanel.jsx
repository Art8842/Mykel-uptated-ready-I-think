import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia, freeInvokeLLM } from '@/lib/freeCore';
import { confirmAction } from '@/lib/confirm';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Settings, Palette, FlaskConical, Megaphone, 
  ShoppingBag, Plus, Trash2, ChevronRight,
  Loader2, Check, X, Edit2, Volume2, Monitor, Send, MessageSquare, Shield, AlertTriangle, Ban, FolderOpen, Users, MoreVertical, LogIn, RefreshCw, Image, Tv, Layout, Sparkles, Gift
} from 'lucide-react';
import LoginStyleEditor from '@/components/admin/LoginStyleEditor';
import TrackRemovalSection from '@/components/music/TrackRemovalSection';
import { getMykelSession } from '@/lib/mykelSession';
import TokensSection from '@/components/admin/TokensSection';
import SanctionSection from '@/components/admin/SanctionSection';
import UserFilesSection from '@/components/admin/UserFilesSection';
import ArtistListenersDialog from '@/components/admin/ArtistListenersDialog';
import ArtistActionsMenu from '@/components/admin/ArtistActionsMenu';
import PublishTrackWizard from '@/components/music/PublishTrackWizard';
import UpdateSection from '@/components/admin/UpdateSection';
import LogoSection from '@/components/admin/LogoSection';
import TVSection from '@/components/admin/TVSection';
import LandingPageEditor from '@/components/admin/LandingPageEditor';
import EditorialRequestsSection from '@/components/admin/EditorialRequestsSection';
import FreeServicesSection from '@/components/admin/FreeServicesSection';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from 'sonner';

const APP_LIST = [
  { key: 'MykelWord', label: 'Mykel Word' },
  { key: 'MykelTabs', label: 'Mykel Tabs' },
  { key: 'MykelSliders', label: 'Mykel Sliders' },
  { key: 'MykelDraws', label: 'Mykel Draws' },
  { key: 'Mykel3D', label: 'Mykel 3D' },
  { key: 'MykelMusic', label: 'Mykel Music' },
  { key: 'MykelIA', label: 'Mykel IA' },
  { key: 'RemoveBG', label: 'Remove Background' },
  { key: 'MykelEdiCode', label: 'Mykel EdiCode' },
  { key: 'MykelSearch', label: 'Mykel Search' },
];

const SECTIONS = [
  { id: 'theme', label: 'Thème & Couleurs', icon: Palette },
  { id: 'login_style', label: 'Style de connexion', icon: LogIn },
  { id: 'landing', label: 'Page d\'accueil', icon: Layout },
  { id: 'logos', label: 'Logos des logiciels', icon: Image },
  { id: 'visibility', label: 'Visibilité Apps', icon: Monitor },
  { id: 'beta', label: 'Mode Bêta', icon: FlaskConical },
  { id: 'announcements', label: 'Annonces', icon: Megaphone },
  { id: 'ads', label: 'Publicités', icon: Volume2 },
  { id: 'store', label: 'Store & Apps', icon: ShoppingBag },
  { id: 'support', label: 'Support', icon: MessageSquare },
  { id: 'artists', label: 'Artistes', icon: Shield },
  { id: 'removals', label: 'Démarches de suppression', icon: AlertTriangle },
  { id: 'sanctions', label: 'Sanctions & Avertissements', icon: Ban },
  { id: 'userfiles', label: 'Fichiers des utilisateurs', icon: FolderOpen },
  { id: 'tokens', label: 'Jetons utilisateurs', icon: Users },
  { id: 'editorial', label: 'Équipe éditoriale', icon: Sparkles },
  { id: 'free', label: 'Services gratuits', icon: Gift },
  { id: 'updates', label: 'Mises à jour', icon: RefreshCw },
  { id: 'tv', label: 'Mykel TV', icon: Tv },
];

export default function AdminPanel() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [activeSection, setActiveSection] = useState('theme');
  const [loading, setLoading] = useState(true);

  // Theme
  const [themeColor, setThemeColor] = useState('#3b82f6');
  const [savingTheme, setSavingTheme] = useState(false);

  // Beta
  const [betaApps, setBetaApps] = useState([]);
  const [betaDialog, setBetaDialog] = useState(false);
  const [selectedBetaApp, setSelectedBetaApp] = useState('');

  // Announcements
  const [announcements, setAnnouncements] = useState([]);
  const [announcementWizard, setAnnouncementWizard] = useState(false);
  const [wizardStep, setWizardStep] = useState(1);
  const [announcementText, setAnnouncementText] = useState('');
  const [announcementTarget, setAnnouncementTarget] = useState('home');
  const [announcementTargetApp, setAnnouncementTargetApp] = useState('');
  const [announcementFrequency, setAnnouncementFrequency] = useState('once');
  const [announcementDismissible, setAnnouncementDismissible] = useState(true);
  const [announcementButtons, setAnnouncementButtons] = useState([]);

  // Ads
  const [ads, setAds] = useState([]);
  const [uploadingAd, setUploadingAd] = useState(false);
  const [adName, setAdName] = useState('');
  const [adFileRef, setAdFileRef] = useState(null);

  // Store Apps
  const [storeApps, setStoreApps] = useState([]);
  const [editApp, setEditApp] = useState(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      // Check Mykel internal session first for admin role
      const mykelSession = getMykelSession();
      let u = null;
      try {
        u = await base44.auth.me();
      } catch {}
      // Use Mykel session as primary source of truth
      const effectiveRole = mykelSession?.role || u?.role;
      if (effectiveRole !== 'admin') { navigate('/'); return; }
      if (u) setUser(u); else setUser(mykelSession);

      const [settings, anns, adsList, appsList, ticketsList, creatorsList] = await Promise.all([
        base44.entities.AppSettings.list(),
        base44.entities.Announcement.list(),
        base44.entities.Advertisement.list(),
        base44.entities.StoreApp.list(),
        base44.entities.SupportTicket.list('-created_at', 50),
        base44.entities.MusicCreatorProfile.filter({ validated: true, active: true }),
      ]);
      setTickets(ticketsList);
      setCreators(creatorsList);

      const colorSetting = settings.find(s => s.key === 'theme_color');
      if (colorSetting) setThemeColor(colorSetting.value);

      const onePriceSetting = settings.find(s => s.key === 'mykel_one_price');
      if (onePriceSetting) setMykelOnePrice(parseInt(onePriceSetting.value) || 315);

      const proxySetting = settings.find(s => s.key === 'ai_proxy_url');
      if (proxySetting?.value) { setAiProxyUrl(proxySetting.value); localStorage.setItem('ai_proxy_url', proxySetting.value); }

      const betaSetting = settings.find(s => s.key === 'beta_apps');
      if (betaSetting) {
        try { setBetaApps(JSON.parse(betaSetting.value)); } catch { setBetaApps([]); }
      }

      setAnnouncements(anns);
      setAds(adsList);
      setStoreApps(appsList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // ── THEME ──
  const saveThemeColor = async () => {
    setSavingTheme(true);
    try {
      const settings = await base44.entities.AppSettings.list();
      const existing = settings.find(s => s.key === 'theme_color');
      if (existing) {
        await base44.entities.AppSettings.update(existing.id, { value: themeColor });
      } else {
        await base44.entities.AppSettings.create({ key: 'theme_color', value: themeColor });
      }
      // Apply immediately — convert hex to HSL for CSS variables
      const applyColor = (hex) => {
        const r = parseInt(hex.slice(1,3),16)/255;
        const g = parseInt(hex.slice(3,5),16)/255;
        const b = parseInt(hex.slice(5,7),16)/255;
        const max = Math.max(r,g,b), min = Math.min(r,g,b);
        let h, s, l = (max+min)/2;
        if (max === min) { h = s = 0; }
        else {
          const d = max - min;
          s = l > 0.5 ? d/(2-max-min) : d/(max+min);
          switch(max) {
            case r: h = ((g-b)/d + (g<b?6:0))/6; break;
            case g: h = ((b-r)/d + 2)/6; break;
            case b: h = ((r-g)/d + 4)/6; break;
          }
        }
        const hsl = `${Math.round(h*360)} ${Math.round(s*100)}% ${Math.round(l*100)}%`;
        document.documentElement.style.setProperty('--primary', hsl);
        localStorage.setItem('theme_color_hex', hex);
        localStorage.setItem('theme_color_hsl', hsl);
      };
      applyColor(themeColor);
      toast.success('Couleur thème sauvegardée');
    } catch { toast.error('Erreur'); }
    finally { setSavingTheme(false); }
  };

  // ── BETA ──
  const saveBetaApps = async (apps) => {
    try {
      const settings = await base44.entities.AppSettings.list();
      const existing = settings.find(s => s.key === 'beta_apps');
      const val = JSON.stringify(apps);
      if (existing) {
        await base44.entities.AppSettings.update(existing.id, { value: val });
      } else {
        await base44.entities.AppSettings.create({ key: 'beta_apps', value: val });
      }
      setBetaApps(apps);
    } catch { toast.error('Erreur'); }
  };

  const addBeta = async () => {
    if (!selectedBetaApp) return;
    if (betaApps.includes(selectedBetaApp)) { toast.error('Déjà en bêta'); return; }
    const newList = [...betaApps, selectedBetaApp];
    await saveBetaApps(newList);
    setBetaDialog(false);
    setSelectedBetaApp('');
    toast.success('App passée en mode bêta');
  };

  const removeBeta = async (key) => {
    const newList = betaApps.filter(a => a !== key);
    await saveBetaApps(newList);
    toast.success('Mode bêta retiré');
  };

  // ── ANNOUNCEMENTS ──
  const resetWizard = () => {
    setAnnouncementText('');
    setAnnouncementTarget('home');
    setAnnouncementTargetApp('');
    setAnnouncementFrequency('once');
    setAnnouncementDismissible(true);
    setAnnouncementButtons([]);
    setWizardStep(1);
  };

  const submitAnnouncement = async () => {
    try {
      await base44.entities.Announcement.create({
        text: announcementText,
        target: announcementTarget,
        target_app: announcementTarget === 'app' ? announcementTargetApp : null,
        frequency: announcementFrequency,
        dismissible: announcementDismissible,
        buttons: announcementButtons,
        active: true
      });
      toast.success('Annonce créée');
      setAnnouncementWizard(false);
      resetWizard();
      loadAll();
    } catch { toast.error('Erreur'); }
  };

  const deleteAnnouncement = async (id) => {
    await base44.entities.Announcement.delete(id);
    toast.success('Annonce supprimée');
    loadAll();
  };

  const toggleAnnouncement = async (ann) => {
    await base44.entities.Announcement.update(ann.id, { active: !ann.active });
    loadAll();
  };

  // ── ADS ──
  const handleAdUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !adName.trim()) { toast.error('Entrez un nom et choisissez un fichier'); return; }
    setUploadingAd(true);
    try {
      const { file_url } = await uploadMedia(file);
      let file_type = 'image';
      if (file.type.startsWith('audio')) file_type = 'audio';
      else if (file.type.startsWith('video')) file_type = 'video';
      await base44.entities.Advertisement.create({ name: adName, file_url, file_type });
      setAdName('');
      toast.success('Publicité ajoutée');
      loadAll();
    } catch { toast.error('Erreur upload'); }
    finally { setUploadingAd(false); }
  };

  const toggleAdActive = async (ad) => {
    await base44.entities.Advertisement.update(ad.id, { is_active_in_music: !ad.is_active_in_music });
    loadAll();
  };

  const deleteAd = async (id) => {
    await base44.entities.Advertisement.delete(id);
    toast.success('Publicité supprimée');
    loadAll();
  };

  // ── SUPPORT ──
  const [tickets, setTickets] = useState([]);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [ticketChatOpen, setTicketChatOpen] = useState(false);
  const [ticketInput, setTicketInput] = useState('');
  const [ticketChatMsgs, setTicketChatMsgs] = useState([]);
  const [ticketChatLoading, setTicketChatLoading] = useState(false);

  // ── ARTISTS ──
  const [creators, setCreators] = useState([]);
  const [listenersDialog, setListenersDialog] = useState(null);
  const [publishForArtist, setPublishForArtist] = useState(null); // creator profile to publish for

  // ── MYKEL ONE PRICE ──
  const [mykelOnePrice, setMykelOnePrice] = useState(315);
  const [savingOnePrice, setSavingOnePrice] = useState(false);
  const [aiProxyUrl, setAiProxyUrl] = useState(() => localStorage.getItem('ai_proxy_url') || '');

  const saveMykelOnePrice = async () => {
    setSavingOnePrice(true);
    try {
      const settings = await base44.entities.AppSettings.list();
      const existing = settings.find(s => s.key === 'mykel_one_price');
      if (existing) await base44.entities.AppSettings.update(existing.id, { value: String(mykelOnePrice) });
      else await base44.entities.AppSettings.create({ key: 'mykel_one_price', value: String(mykelOnePrice) });
      toast.success('Prix Mykel One sauvegardé');
    } catch { toast.error('Erreur'); }
    finally { setSavingOnePrice(false); }
  };

  const saveAiProxyUrl = async () => {
    localStorage.setItem('ai_proxy_url', aiProxyUrl);
    try {
      const settings = await base44.entities.AppSettings.list();
      const existing = settings.find(s => s.key === 'ai_proxy_url');
      if (existing) await base44.entities.AppSettings.update(existing.id, { value: aiProxyUrl });
      else await base44.entities.AppSettings.create({ key: 'ai_proxy_url', value: aiProxyUrl });
    } catch {}
    toast.success('Proxy IA configuré');
  };

  // ── VISIBILITY ──
  const [hiddenApps, setHiddenApps] = useState([]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('admin_hidden_apps');
      if (saved) setHiddenApps(JSON.parse(saved));
    } catch {}
  }, []);

  const toggleAppVisibility = (key) => {
    const newHidden = hiddenApps.includes(key)
      ? hiddenApps.filter(k => k !== key)
      : [...hiddenApps, key];
    setHiddenApps(newHidden);
    localStorage.setItem('admin_hidden_apps', JSON.stringify(newHidden));
    // Also save to AppSettings so other parts of the app can read it
    base44.entities.AppSettings.list().then(settings => {
      const existing = settings.find(s => s.key === 'hidden_apps');
      const val = JSON.stringify(newHidden);
      if (existing) base44.entities.AppSettings.update(existing.id, { value: val });
      else base44.entities.AppSettings.create({ key: 'hidden_apps', value: val });
    });
    toast.success(hiddenApps.includes(key) ? 'App rendue accessible' : 'App masquée');
  };

  // ── STORE APPS ──
  const saveApp = async () => {
    try {
      if (editApp.id) {
        await base44.entities.StoreApp.update(editApp.id, editApp);
      } else {
        await base44.entities.StoreApp.create(editApp);
      }
      setEditApp(null);
      toast.success('Sauvegardé');
      loadAll();
    } catch { toast.error('Erreur'); }
  };

  const deleteApp = async (id) => {
    if (!await confirmAction({ title: 'Supprimer cette app du store ?', destructive: true })) return;
    await base44.entities.StoreApp.delete(id);
    loadAll();
    toast.success('Supprimée');
  };

  // ── SUPPORT — Resolved tickets masking (30 days) ──
  const getResolvedTickets = () => {
    try { return JSON.parse(localStorage.getItem('admin_resolved_tickets') || '{}'); } catch { return {}; }
  };

  const markResolved = (ticketId) => {
    const resolved = getResolvedTickets();
    resolved[ticketId] = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 days
    localStorage.setItem('admin_resolved_tickets', JSON.stringify(resolved));
    setTicketChatOpen(false);
    setTickets(prev => prev.filter(t => t.id !== ticketId));
    toast.success('Ticket masqué pendant 30 jours');
  };

  const visibleTickets = tickets.filter(t => {
    const resolved = getResolvedTickets();
    return !resolved[t.id] || Date.now() > resolved[t.id];
  });

  // ── SUPPORT CHAT ──
  const openTicketChat = async (ticket) => {
    setSelectedTicket(ticket);
    setTicketChatMsgs([{ role: 'ai', content: 'Bonjour, je vais analyser la conversation pour vous donner plus de détails sur ce ticket.' }]);
    setTicketChatOpen(true);
  };

  const sendTicketMessage = async () => {
    if (!ticketInput.trim() || ticketChatLoading) return;
    const msg = ticketInput.trim();
    setTicketInput('');
    const newMsgs = [...ticketChatMsgs, { role: 'admin', content: msg }];
    setTicketChatMsgs(newMsgs);
    setTicketChatLoading(true);
    try {
      const conv = (selectedTicket.conversation || []).map(m => `${m.role}: ${m.content}`).join('\n');
      const response = await freeInvokeLLM({
        prompt: `Tu es un assistant de support admin pour Mykel Music. Voici la conversation originale du ticket :

${conv}

Résumé du ticket : ${selectedTicket.summary}

L'admin demande : ${msg}

Réponds en analysant la conversation et en donnant les détails demandés. Sois précis et utile.`,
      });
      setTicketChatMsgs(prev => [...prev, { role: 'ai', content: response }]);
    } catch {
      setTicketChatMsgs(prev => [...prev, { role: 'ai', content: 'Erreur lors de l\'analyse.' }]);
    } finally {
      setTicketChatLoading(false);
    }
  };

  // ── REMOVALS (preselected track/section from URL) ──
  const urlParams = new URLSearchParams(window.location.search);
  const preselectedTrackId = urlParams.get('trackId') || null;
  const urlSection = urlParams.get('section');

  useEffect(() => {
    if (urlSection) setActiveSection(urlSection);
  }, [urlSection]);

  // ── ARTISTS ──
  const revokeArtist = async (creator) => {
    if (!await confirmAction({ title: `Révoquer les droits de ${creator.stage_name} ?`, message: 'Cette action est irréversible.', destructive: true })) return;
    await base44.entities.MusicCreatorProfile.update(creator.id, { active: false, validated: false });
    toast.success('Artiste retiré de la plateforme');
    loadAll();
  };

  const toggleCertification = async (creator) => {
    const newVal = !creator.certified;
    await base44.entities.MusicCreatorProfile.update(creator.id, { certified: newVal });
    toast.success(newVal ? `✅ ${creator.stage_name} est maintenant certifié` : `Certification retirée`);
    loadAll();
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-gradient-to-br from-slate-700 to-slate-900 rounded-lg flex items-center justify-center">
            <Settings className="w-5 h-5 text-white" />
          </div>
          <h1 className="font-bold text-gray-900 dark:text-white text-lg">Panel Admin</h1>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Desktop Sidebar */}
        <div className="w-56 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 flex-shrink-0 hidden md:flex flex-col">
          <div className="p-3 space-y-1">
            {SECTIONS.map(s => (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeSection === s.id
                    ? 'bg-slate-900 text-white dark:bg-slate-700'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <s.icon className="w-4 h-4" />
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto">
          {/* Mobile: scrollable section tabs */}
          <div className="md:hidden bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-10">
            <div className="flex overflow-x-auto scrollbar-hide px-2 py-2 gap-1.5">
              {SECTIONS.map(s => (
                <button
                  key={s.id}
                  onClick={() => setActiveSection(s.id)}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all whitespace-nowrap ${
                    activeSection === s.id
                      ? 'bg-slate-900 text-white dark:bg-slate-600'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
                  }`}
                >
                  <s.icon className="w-3 h-3" />
                  {s.label}
                </button>
              ))}
            </div>
          </div>
          <div className="p-4 md:p-6">

          {/* ── LOGIN STYLE ── */}
          {activeSection === 'login_style' && <LoginStyleEditor />}

          {/* ── LOGOS ── */}
          {activeSection === 'logos' && <LogoSection />}

          {/* ── THEME ── */}
          {activeSection === 'theme' && (
            <div className="max-w-md space-y-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Thème & Couleurs</h2>
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-6 space-y-4">
                <div>
                  <Label className="text-sm font-medium">Couleur principale des boutons</Label>
                  <p className="text-xs text-gray-500 mt-1 mb-3">Cette couleur sera appliquée aux boutons principaux du logiciel.</p>
                  <div className="flex items-center gap-4">
                    <input
                      type="color"
                      value={themeColor}
                      onChange={e => setThemeColor(e.target.value)}
                      className="w-16 h-16 rounded-xl cursor-pointer border-2 border-gray-200"
                    />
                    <div>
                      <p className="text-sm font-mono text-gray-700 dark:text-gray-300">{themeColor}</p>
                      <div className="w-32 h-8 rounded-lg mt-2 flex items-center justify-center text-white text-sm font-medium" style={{ backgroundColor: themeColor }}>
                        Aperçu bouton
                      </div>
                    </div>
                  </div>
                </div>
                <Button onClick={saveThemeColor} disabled={savingTheme} className="w-full">
                  {savingTheme ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Check className="w-4 h-4 mr-2" />}
                  Enregistrer la couleur
                </Button>
              </div>
            </div>
          )}

          {/* ── VISIBILITY ── */}
          {activeSection === 'visibility' && (
            <div className="max-w-lg space-y-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Visibilité des Apps</h2>
                <p className="text-sm text-gray-500 mt-1">Les apps masquées sont inaccessibles pour les utilisateurs (non-admins).</p>
              </div>
              <div className="space-y-3">
                {APP_LIST.map(app => {
                  const isHidden = hiddenApps.includes(app.key);
                  return (
                    <div key={app.key} className={`bg-white dark:bg-gray-900 rounded-xl border p-4 flex items-center justify-between transition-all ${isHidden ? 'border-red-200 dark:border-red-800 opacity-70' : 'border-gray-200 dark:border-gray-700'}`}>
                      <div className="flex items-center gap-3">
                        <span className="font-medium text-gray-900 dark:text-white">{app.label}</span>
                        {isHidden && <Badge className="bg-red-500 text-white text-xs">Masquée</Badge>}
                        {!isHidden && <Badge className="bg-green-500 text-white text-xs">Accessible</Badge>}
                      </div>
                      <Button
                        size="sm"
                        variant={isHidden ? 'default' : 'outline'}
                        className={isHidden ? 'bg-green-600 hover:bg-green-700 text-white' : 'text-red-500 border-red-200 hover:bg-red-50'}
                        onClick={() => toggleAppVisibility(app.key)}
                      >
                        {isHidden ? '🔓 Rendre accessible' : '🔒 Masquer'}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── BETA ── */}
          {activeSection === 'beta' && (
            <div className="max-w-lg space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Mode Bêta</h2>
                <Button size="sm" onClick={() => setBetaDialog(true)} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Passer une app en bêta
                </Button>
              </div>

              {betaApps.length === 0 ? (
                <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center text-gray-500">
                  <FlaskConical className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                  <p>Aucun logiciel en mode bêta</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-gray-500 font-medium">Logiciels en mode bêta :</p>
                  {betaApps.map(key => {
                    const app = APP_LIST.find(a => a.key === key);
                    return (
                      <div key={key} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-medium text-gray-900 dark:text-white">{app?.label || key}</span>
                          <Badge className="bg-amber-500 text-white text-xs">β Bêta</Badge>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => removeBeta(key)} className="text-red-400 hover:text-red-600 hover:bg-red-50">
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ── ANNOUNCEMENTS ── */}
          {activeSection === 'announcements' && (
            <div className="max-w-2xl space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Annonces</h2>
                <Button size="sm" onClick={() => { resetWizard(); setAnnouncementWizard(true); }} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Créer une annonce
                </Button>
              </div>

              {announcements.length === 0 ? (
                <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center text-gray-500">
                  <Megaphone className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                  <p>Aucune annonce créée</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {announcements.map(ann => {
                    const app = APP_LIST.find(a => a.key === ann.target_app);
                    return (
                      <div key={ann.id} className={`bg-white dark:bg-gray-900 rounded-xl border p-4 ${ann.active ? 'border-gray-200 dark:border-gray-700' : 'border-gray-100 dark:border-gray-800 opacity-60'}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-gray-900 dark:text-white line-clamp-2">{ann.text}</p>
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              <Badge variant="outline" className="text-xs">{ann.target === 'home' ? '🏠 Accueil' : `📱 ${app?.label || ann.target_app}`}</Badge>
                              <Badge variant="outline" className="text-xs">{ann.frequency === 'once' ? '1 fois' : 'À chaque ouverture'}</Badge>
                              {ann.dismissible && <Badge variant="outline" className="text-xs">Ignorable</Badge>}
                              {ann.buttons?.length > 0 && <Badge variant="outline" className="text-xs">{ann.buttons.length} bouton(s)</Badge>}
                              {ann.active ? <Badge className="text-xs bg-green-600">Active</Badge> : <Badge variant="outline" className="text-xs">Inactive</Badge>}
                            </div>
                          </div>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => toggleAnnouncement(ann)}>
                              {ann.active ? <X className="w-3 h-3 text-orange-500" /> : <Check className="w-3 h-3 text-green-500" />}
                            </Button>
                            <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:text-red-600" onClick={() => deleteAnnouncement(ann.id)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ── ADS ── */}
          {activeSection === 'ads' && (
            <div className="max-w-2xl space-y-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Publicités</h2>
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 space-y-3">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Ajouter une publicité</p>
                <div className="flex gap-2">
                  <Input placeholder="Nom de la publicité" value={adName} onChange={e => setAdName(e.target.value)} />
                  <label className="cursor-pointer">
                    <Button asChild className="gap-2" disabled={uploadingAd || !adName.trim()}>
                      <span>
                        {uploadingAd ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                        Choisir fichier
                      </span>
                    </Button>
                    <input type="file" accept="image/*,audio/*,video/*" className="hidden" onChange={handleAdUpload} />
                  </label>
                </div>
              </div>
              <div className="space-y-3">
                {ads.map(ad => (
                  <div key={ad.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="font-medium text-sm text-gray-900 dark:text-white">{ad.name}</p>
                      <p className="text-xs text-gray-500 capitalize">{ad.file_type}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleAdActive(ad)}
                        className={`text-xs px-3 py-1 rounded-full font-medium transition-colors ${
                          ad.is_active_in_music ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                        }`}
                      >
                        {ad.is_active_in_music ? 'Actif sur Music' : 'Inactif'}
                      </button>
                      <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:text-red-600" onClick={() => deleteAd(ad.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                {ads.length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    <Volume2 className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    <p>Aucune publicité</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── SUPPORT ── */}
          {activeSection === 'support' && (
            <div className="max-w-3xl space-y-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Tickets de Support</h2>
              {visibleTickets.length === 0 ? (
                <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center text-gray-500">
                  <MessageSquare className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                  <p>Aucun ticket de support</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {visibleTickets.map(ticket => (
                    <div key={ticket.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 dark:text-white">{ticket.user_name || ticket.user_email}</p>
                          <p className="text-xs text-gray-500 mt-0.5">{ticket.created_at ? new Date(ticket.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Date inconnue'}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 line-clamp-2">{ticket.summary}</p>
                        </div>
                        <Button size="sm" variant="outline" onClick={() => openTicketChat(ticket)} className="flex-shrink-0 gap-1">
                          <MessageSquare className="w-3 h-3" />
                          Détails
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Ticket chat mini */}
              {ticketChatOpen && selectedTicket && (
                <div className="fixed bottom-6 right-6 w-96 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 flex flex-col" style={{ maxHeight: '60vh' }}>
                  <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                    <p className="font-semibold text-sm text-gray-900 dark:text-white">Ticket — {selectedTicket.user_name || selectedTicket.user_email}</p>
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-green-600 border-green-200 hover:bg-green-50 text-xs h-7 px-2"
                        onClick={() => markResolved(selectedTicket.id)}
                      >
                        ✓ Résolu
                      </Button>
                      <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => setTicketChatOpen(false)}>
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-3 space-y-2" style={{ minHeight: '200px', maxHeight: '300px' }}>
                    {ticketChatMsgs.map((m, i) => (
                      <div key={i} className={`flex ${m.role === 'admin' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] px-3 py-2 rounded-xl text-sm ${
                          m.role === 'admin'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
                        }`}>{m.content}</div>
                      </div>
                    ))}
                    {ticketChatLoading && (
                      <div className="flex justify-start">
                        <div className="px-3 py-2 bg-gray-100 dark:bg-gray-800 rounded-xl">
                          <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 p-3 border-t border-gray-200 dark:border-gray-700">
                    <input
                      className="flex-1 bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-1.5 text-sm text-gray-900 dark:text-white"
                      value={ticketInput}
                      onChange={e => setTicketInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && sendTicketMessage()}
                      placeholder="Demander plus de détails..."
                    />
                    <Button size="icon" className="w-8 h-8" onClick={sendTicketMessage} disabled={ticketChatLoading || !ticketInput.trim()}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── ARTISTS ── */}
          {activeSection === 'artists' && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Artistes & Créateurs</h2>
                <p className="text-sm text-gray-500 mt-1">Seuls les artistes actifs sont listés. Révoquer un artiste le retire définitivement de la plateforme.</p>
              </div>
              {creators.length === 0 ? (
                <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center text-gray-500">
                  <Shield className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                  <p>Aucun artiste actif enregistré</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {creators.map(creator => (
                    <div key={creator.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                       {creator.certified && (
                         <span title="Artiste certifié" className="text-green-500 flex-shrink-0">✅</span>
                       )}
                       {creator.avatar_url
                          ? <img src={creator.avatar_url} className="w-10 h-10 rounded-full object-cover" alt="" />
                          : <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white text-sm font-bold">{creator.stage_name?.[0]?.toUpperCase()}</div>
                        }
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{creator.stage_name}</p>
                          <p className="text-xs text-gray-500">{creator.user_email}</p>
                          <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 mt-1 inline-block">
                            {creator.creator_type === 'music' ? '🎵 Musique' : creator.creator_type === 'podcast' ? '🎙️ Podcast' : '🎵🎙️ Les deux'}
                          </span>
                        </div>
                      </div>
                      {/* Desktop: inline buttons */}
                      <div className="hidden sm:flex items-center gap-2">
                       <Button
                         variant="outline"
                         size="sm"
                         className="text-purple-600 border-purple-200 hover:bg-purple-50 gap-1"
                         onClick={() => setListenersDialog(creator)}
                       >
                         <Users className="w-3 h-3" />
                         Auditeurs
                       </Button>
                       <Button
                         variant="outline"
                         size="sm"
                         className="text-blue-600 border-blue-200 hover:bg-blue-50 gap-1"
                         onClick={() => setPublishForArtist(creator)}
                       >
                         <Plus className="w-3 h-3" />
                         Publier
                       </Button>
                       <Button
                         variant="outline"
                         size="sm"
                         className={creator.certified ? 'text-orange-500 border-orange-200 hover:bg-orange-50' : 'text-green-600 border-green-200 hover:bg-green-50'}
                         onClick={() => toggleCertification(creator)}
                       >
                         {creator.certified ? '❌' : '✅'}
                       </Button>
                       <Button
                         variant="outline"
                         size="sm"
                         className="text-red-500 border-red-200 hover:bg-red-50"
                         onClick={() => revokeArtist(creator)}
                       >
                         Révoquer
                       </Button>
                      </div>
                      {/* Mobile: ⋯ menu */}
                      <div className="sm:hidden">
                        <ArtistActionsMenu
                          creator={creator}
                          onListeners={() => setListenersDialog(creator)}
                          onPublish={() => setPublishForArtist(creator)}
                          onCertify={() => toggleCertification(creator)}
                          onRevoke={() => revokeArtist(creator)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── REMOVALS ── */}
          {activeSection === 'removals' && (
            <TrackRemovalSection preselectedTrackId={preselectedTrackId} />
          )}

          {/* ── SANCTIONS ── */}
          {activeSection === 'sanctions' && <SanctionSection />}

          {/* ── USER FILES ── */}
          {activeSection === 'userfiles' && <UserFilesSection />}

          {/* ── TOKENS ── */}
          {activeSection === 'tokens' && <TokensSection />}

          {/* ── UPDATES ── */}
          {activeSection === 'editorial' && <EditorialRequestsSection />}
          {activeSection === 'free' && <FreeServicesSection />}
          {activeSection === 'updates' && <UpdateSection />}

          {/* ── MYKEL TV ── */}
          {activeSection === 'tv' && <TVSection />}

          {/* ── LANDING PAGE ── */}
          {activeSection === 'landing' && <LandingPageEditor />}

          {/* ── STORE ── */}
          {activeSection === 'store' && (
            <div className="max-w-3xl space-y-4 md:space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Store & Applications</h2>
                <Button size="sm" className="gap-2" onClick={() => setEditApp({ name: '', app_type: 'snapfix', price: 0, description: '', is_subscription: false, annual_price: 0, annual_discount_percent: 0 })}>
                  <Plus className="w-4 h-4" />
                  Ajouter
                </Button>
              </div>

              {/* Mykel One price */}
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-5">
                <p className="font-semibold text-gray-900 dark:text-white mb-1">Prix Mykel One</p>
                <p className="text-xs text-gray-500 mb-3">Abonnement ultime (IA Max + Stockage One + bureautique à venir)</p>
                <div className="flex items-center gap-3">
                  <Input type="number" value={mykelOnePrice} onChange={e => setMykelOnePrice(parseInt(e.target.value) || 0)} className="w-40" />
                  <span className="text-sm text-gray-500">jetons / mois</span>
                  <Button size="sm" onClick={saveMykelOnePrice} disabled={savingOnePrice}>
                    {savingOnePrice ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Enregistrer'}
                  </Button>
                </div>
              </div>

              <FreeServicesSection />
              <div className="space-y-3">
                {storeApps.map(app => (
                  <div key={app.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 dark:text-white">{app.name}</p>
                      <p className="text-xs text-gray-500">
                        {app.app_type} — {app.price} jetons{app.is_subscription ? ' / mois' : ''}
                        {app.is_subscription && app.annual_price > 0 && ` · ${app.annual_price} j/an`}
                      </p>
                      {app.is_subscription ? (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 mt-1 inline-block">Abonnement</span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 mt-1 inline-block">Paiement unique</span>
                      )}
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <Button variant="outline" size="sm" onClick={() => setEditApp(app)}>
                        <Edit2 className="w-3 h-3 mr-1" />
                        Modifier
                      </Button>
                      <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:text-red-600" onClick={() => deleteApp(app.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>
        </div>
      </div>

      {/* ── BETA DIALOG ── */}
      <Dialog open={betaDialog} onOpenChange={setBetaDialog}>
        <DialogContent className="bg-white dark:bg-gray-900">
          <DialogHeader>
            <DialogTitle>Passer une app en mode bêta</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {APP_LIST.filter(a => !betaApps.includes(a.key)).map(app => (
              <button
                key={app.key}
                onClick={() => setSelectedBetaApp(app.key)}
                className={`w-full text-left px-4 py-3 rounded-xl border transition-all ${
                  selectedBetaApp === app.key
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/20'
                    : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900 dark:text-white">{app.label}</span>
                  {selectedBetaApp === app.key && <Check className="w-4 h-4 text-amber-500" />}
                </div>
              </button>
            ))}
            {APP_LIST.filter(a => !betaApps.includes(a.key)).length === 0 && (
              <p className="text-center text-gray-500 py-4">Toutes les apps sont déjà en bêta</p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBetaDialog(false)}>Annuler</Button>
            <Button onClick={addBeta} disabled={!selectedBetaApp} className="bg-amber-500 hover:bg-amber-600">
              <FlaskConical className="w-4 h-4 mr-2" />
              Activer bêta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── ANNOUNCEMENT WIZARD ── */}
      <Dialog open={announcementWizard} onOpenChange={setAnnouncementWizard}>
        <DialogContent className="bg-white dark:bg-gray-900 max-w-md">
          <DialogHeader>
            <DialogTitle>
              {wizardStep === 1 && 'Créer une annonce — Texte'}
              {wizardStep === 2 && 'Créer une annonce — Destination'}
              {wizardStep === 3 && 'Créer une annonce — Options'}
            </DialogTitle>
          </DialogHeader>

          {wizardStep === 1 && (
            <div className="space-y-4">
              <div className="flex gap-2 text-xs text-gray-400 mb-2">
                <span className="px-2 py-0.5 bg-gray-900 text-white rounded-full">1</span>
                <span className="px-2 py-0.5 bg-gray-100 rounded-full">2</span>
                <span className="px-2 py-0.5 bg-gray-100 rounded-full">3</span>
              </div>
              <Label>Texte de l'annonce</Label>
              <Textarea
                placeholder="Entrez le message de votre annonce..."
                value={announcementText}
                onChange={e => setAnnouncementText(e.target.value)}
                rows={4}
              />
              <DialogFooter>
                <Button variant="outline" onClick={() => setAnnouncementWizard(false)}>Annuler</Button>
                <Button onClick={() => setWizardStep(2)} disabled={!announcementText.trim()} className="gap-2">
                  Suivant <ChevronRight className="w-4 h-4" />
                </Button>
              </DialogFooter>
            </div>
          )}

          {wizardStep === 2 && (
            <div className="space-y-4">
              <div className="flex gap-2 text-xs text-gray-400 mb-2">
                <span className="px-2 py-0.5 bg-green-600 text-white rounded-full">✓</span>
                <span className="px-2 py-0.5 bg-gray-900 text-white rounded-full">2</span>
                <span className="px-2 py-0.5 bg-gray-100 rounded-full">3</span>
              </div>
              <Label>Où afficher cette annonce ?</Label>
              <div className="space-y-2">
                <button
                  onClick={() => setAnnouncementTarget('home')}
                  className={`w-full text-left px-4 py-3 rounded-xl border transition-all ${
                    announcementTarget === 'home' ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <p className="font-medium text-sm">🏠 Page d'accueil</p>
                  <p className="text-xs text-gray-500">Affichée quand l'utilisateur ouvre le site</p>
                </button>
                <button
                  onClick={() => setAnnouncementTarget('app')}
                  className={`w-full text-left px-4 py-3 rounded-xl border transition-all ${
                    announcementTarget === 'app' ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <p className="font-medium text-sm">📱 Application spécifique</p>
                  <p className="text-xs text-gray-500">Affichée quand l'utilisateur ouvre une app précise</p>
                </button>
              </div>
              {announcementTarget === 'app' && (
                <div>
                  <Label className="text-sm">Quelle application ?</Label>
                  <select
                    className="w-full mt-1 border rounded-lg px-3 py-2 bg-white dark:bg-gray-800 text-sm"
                    value={announcementTargetApp}
                    onChange={e => setAnnouncementTargetApp(e.target.value)}
                  >
                    <option value="">Sélectionner une app</option>
                    {APP_LIST.map(a => <option key={a.key} value={a.key}>{a.label}</option>)}
                  </select>
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setWizardStep(1)}>Retour</Button>
                <Button
                  onClick={() => setWizardStep(3)}
                  disabled={announcementTarget === 'app' && !announcementTargetApp}
                  className="gap-2"
                >
                  Suivant <ChevronRight className="w-4 h-4" />
                </Button>
              </DialogFooter>
            </div>
          )}

          {wizardStep === 3 && (
            <div className="space-y-4">
              <div className="flex gap-2 text-xs text-gray-400 mb-2">
                <span className="px-2 py-0.5 bg-green-600 text-white rounded-full">✓</span>
                <span className="px-2 py-0.5 bg-green-600 text-white rounded-full">✓</span>
                <span className="px-2 py-0.5 bg-gray-900 text-white rounded-full">3</span>
              </div>
              <Label>Fréquence d'affichage</Label>
              <div className="space-y-2">
                <button
                  onClick={() => setAnnouncementFrequency('once')}
                  className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${
                    announcementFrequency === 'once' ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  Une seule fois
                </button>
                <button
                  onClick={() => setAnnouncementFrequency('always')}
                  className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${
                    announcementFrequency === 'always' ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  À chaque ouverture
                </button>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700">
                <input
                  type="checkbox"
                  id="dismissible"
                  checked={announcementDismissible}
                  onChange={e => setAnnouncementDismissible(e.target.checked)}
                  className="w-4 h-4"
                />
                <label htmlFor="dismissible" className="text-sm cursor-pointer">
                  Afficher le bouton "Ne plus afficher cette information"
                </label>
              </div>

              {/* Custom buttons */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Boutons personnalisés (optionnel)</Label>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setAnnouncementButtons(prev => [...prev, { label: '', action: 'close' }])}
                    className="gap-1 h-7 text-xs"
                  >
                    <Plus className="w-3 h-3" /> Ajouter un bouton
                  </Button>
                </div>
                <p className="text-xs text-gray-500">Ajoutez des boutons comme "Accepter" / "Refuser" pour les annonces de politique de confidentialité.</p>
                {announcementButtons.map((btn, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded-lg border border-gray-200 dark:border-gray-700">
                    <Input
                      placeholder="Texte du bouton (ex: Accepter)"
                      value={btn.label}
                      onChange={e => setAnnouncementButtons(prev => prev.map((b, idx) => idx === i ? { ...b, label: e.target.value } : b))}
                      className="h-8 text-sm flex-1"
                    />
                    <select
                      value={btn.action}
                      onChange={e => setAnnouncementButtons(prev => prev.map((b, idx) => idx === i ? { ...b, action: e.target.value, url: e.target.value === 'link' ? (b.url || '') : undefined } : b))}
                      className="h-8 text-xs border rounded-lg px-2 bg-white dark:bg-gray-800"
                    >
                      <option value="close">Fermer</option>
                      <option value="dismiss">Ne plus afficher</option>
                      <option value="accept">Accepter</option>
                      <option value="decline">Refuser</option>
                      <option value="link">Ouvrir un lien</option>
                    </select>
                    {btn.action === 'link' && (
                      <Input
                        placeholder="https://..."
                        value={btn.url || ''}
                        onChange={e => setAnnouncementButtons(prev => prev.map((b, idx) => idx === i ? { ...b, url: e.target.value } : b))}
                        className="h-8 text-xs w-32"
                      />
                    )}
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-red-400 hover:text-red-600 flex-shrink-0"
                      onClick={() => setAnnouncementButtons(prev => prev.filter((_, idx) => idx !== i))}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setWizardStep(2)}>Retour</Button>
                <Button onClick={submitAnnouncement} className="gap-2 bg-green-600 hover:bg-green-700">
                  <Check className="w-4 h-4" />
                  Créer l'annonce
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── ARTIST LISTENERS DIALOG ── */}
      {listenersDialog && (
        <ArtistListenersDialog
          creator={listenersDialog}
          open={!!listenersDialog}
          onClose={() => setListenersDialog(null)}
          onSaved={loadAll}
        />
      )}

      {publishForArtist && (
        <PublishTrackWizard
          open={!!publishForArtist}
          onClose={() => setPublishForArtist(null)}
          creatorProfile={publishForArtist}
          onPublished={() => { toast.success(`Titre publié pour ${publishForArtist.stage_name}`); setPublishForArtist(null); }}
        />
      )}

      {/* ── EDIT APP DIALOG ── */}
      <Dialog open={!!editApp} onOpenChange={() => setEditApp(null)}>
        <DialogContent className="bg-white dark:bg-gray-900 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editApp?.id ? 'Modifier' : 'Nouvelle'} application</DialogTitle>
          </DialogHeader>
          {editApp && (
            <div className="space-y-3">
              <div>
                <Label>Nom</Label>
                <Input value={editApp.name} onChange={e => setEditApp({ ...editApp, name: e.target.value })} />
              </div>
              <div>
                <Label>Type</Label>
                <select className="w-full border rounded-lg px-3 py-2 text-sm bg-white dark:bg-gray-800" value={editApp.app_type} onChange={e => setEditApp({ ...editApp, app_type: e.target.value })}>
                  <option value="document">Document</option>
                  <option value="spreadsheet">Spreadsheet</option>
                  <option value="presentation">Presentation</option>
                  <option value="drawing">Drawing</option>
                  <option value="music_premium">Music Premium</option>
                  <option value="ia_premium">IA Premium</option>
                  <option value="ia_max">IA Max</option>
                  <option value="tv_ads">TV (avec pubs)</option>
                  <option value="tv_premium">TV Premium</option>
                  <option value="tv_plus">TV+</option>
                  <option value="snapfix">SnapFix</option>
                </select>
              </div>
              <div>
                <Label>Prix (jetons){editApp.is_subscription ? ' — mensuel' : ''}</Label>
                <Input type="number" value={editApp.price} onChange={e => setEditApp({ ...editApp, price: parseInt(e.target.value) || 0 })} />
              </div>
              <div>
                <Label>Description</Label>
                <Input value={editApp.description || ''} onChange={e => setEditApp({ ...editApp, description: e.target.value })} />
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700">
                <input
                  type="checkbox"
                  id="is_subscription"
                  checked={editApp.is_subscription || false}
                  onChange={e => setEditApp({ ...editApp, is_subscription: e.target.checked })}
                  className="w-4 h-4"
                />
                <label htmlFor="is_subscription" className="text-sm cursor-pointer">
                  Abonnement récurrent (paiement mensuel/annuel)
                </label>
              </div>
              {editApp.is_subscription && (
                <div className="space-y-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                  <div>
                    <Label>Prix annuel (jetons) — 0 = pas d'option annuelle</Label>
                    <Input type="number" value={editApp.annual_price || 0} onChange={e => setEditApp({ ...editApp, annual_price: parseInt(e.target.value) || 0 })} />
                  </div>
                  {editApp.annual_price > 0 && (
                    <div>
                      <Label>Économie annuelle (%)</Label>
                      <Input type="number" value={editApp.annual_discount_percent || 0} onChange={e => setEditApp({ ...editApp, annual_discount_percent: parseInt(e.target.value) || 0 })} />
                      <p className="text-xs text-gray-500 mt-1">Pourcentage affiché comme économie par rapport au mensuel.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditApp(null)}>Annuler</Button>
            <Button onClick={saveApp}>Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}