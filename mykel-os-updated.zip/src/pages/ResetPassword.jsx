import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import AuthShell from '@/components/auth/AuthShell';
import AuthField from '@/components/auth/AuthField';
import PrimaryButton from '@/components/auth/PrimaryButton';
import AuthAlert from '@/components/auth/AuthAlert';
import { Lock, CheckCircle } from 'lucide-react';
import { parseAuthError } from '@/lib/authErrors';

export default function ResetPassword() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const resetToken = params.get('token') || params.get('reset_token') || '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (password.length < 8) { setError('Le mot de passe doit faire au moins 8 caractères.'); return; }
    if (password !== confirm) { setError('Les mots de passe ne correspondent pas.'); return; }
    setLoading(true);
    try {
      await base44.auth.resetPassword({ resetToken, newPassword: password });
      setDone(true);
    } catch (err) {
      setError(parseAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell>
      {done ? (
        <div className="text-center space-y-4 py-8">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Mot de passe réinitialisé</h2>
          <p className="text-sm text-gray-500">Vous pouvez maintenant vous connecter avec votre nouveau mot de passe.</p>
          <PrimaryButton onClick={() => navigate('/MykelLogin')}>Se connecter</PrimaryButton>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="text-center space-y-1">
            <h1 className="text-2xl font-bold text-gray-900">Nouveau mot de passe</h1>
            <p className="text-sm text-gray-500">Choisissez un nouveau mot de passe pour votre compte.</p>
          </div>
          {error && <AuthAlert>{error}</AuthAlert>}
          <AuthField icon={Lock} label="Nouveau mot de passe" type="password" value={password} onChange={setPassword} placeholder="••••••••" />
          <AuthField icon={Lock} label="Confirmer" type="password" value={confirm} onChange={setConfirm} placeholder="••••••••" />
          <PrimaryButton type="submit" loading={loading}>Réinitialiser</PrimaryButton>
        </form>
      )}
    </AuthShell>
  );
}