import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { confirmAction } from '@/lib/confirm';
import { uploadMedia } from '@/lib/freeCore';
import { computeEffectiveMax } from '@/lib/storageQuota';
import { useNavigate } from 'react-router-dom';
import { useScreenSize } from '@/components/utils/useScreenSize';
import Sidebar from '@/components/drive/Sidebar';
import FileGrid from '@/components/drive/FileGrid';
import Header from '@/components/drive/Header';
import FileViewer from '@/components/drive/FileViewer';
import ManageMembersDialog from '@/components/drive/ManageMembersDialog';
import NotificationBell from '@/components/drive/NotificationBell';
import AccueilView from '@/components/drive/AccueilView';
import LogicielsView from '@/components/drive/LogicielsView';
import BottomTabs from '@/components/mobile/BottomTabs';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Upload, RefreshCw } from 'lucide-react';
import AppsMenu from '@/components/mobile/AppsMenu';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import SanctionGuard from '@/components/shared/SanctionGuard';
import { toast } from 'sonner';
import { useLanguage } from '@/lib/LanguageContext';
import { getMykelSession, clearMykelSession } from '@/lib/mykelSession';
import { isBusinessMode, getBusinessSubId } from '@/lib/businessMode';

export default function Dashboard() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const { isMobile, isTablet, isDesktop } = useScreenSize();
  
  const [user, setUser] = useState(null);
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentView, setCurrentView] = useState('accueil');
  const [cloudSubView, setCloudSubView] = useState('mycloud');
  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [breadcrumbs, setBreadcrumbs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [storageInfo, setStorageInfo] = useState({ used: 0, max: 107374182400 });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => localStorage.getItem('mykel_sidebar_collapsed') === 'true');
  const toggleSidebar = () => {
    const next = !sidebarCollapsed;
    setSidebarCollapsed(next);
    localStorage.setItem('mykel_sidebar_collapsed', String(next));
  };
  
  // Dialogs
  const [newFolderDialog, setNewFolderDialog] = useState(false);
  const [renameDialog, setRenameDialog] = useState({ open: false, file: null });
  const [shareDialog, setShareDialog] = useState({ open: false, file: null });
  const [newName, setNewName] = useState('');
  const [shareEmail, setShareEmail] = useState('');
  const [uploading, setUploading] = useState(false);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [moveDialog, setMoveDialog] = useState(false);
  const [targetFolder, setTargetFolder] = useState(null);
  const [allFolders, setAllFolders] = useState([]);
  const [viewerFile, setViewerFile] = useState(null);
  const [importMusicDialog, setImportMusicDialog] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [appsMenuOpen, setAppsMenuOpen] = useState(false);
  const touchStartY = useRef(0);
  const scrollContainerRef = useRef(null);

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (user) {
      loadFiles();
      loadStorageInfo();
    }
  }, [user, currentView, currentFolderId, cloudSubView]);

  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
    } catch (e) {
      if (e?.status === 401) {
        // Token Base44 expiré — forcer la reconnexion
        clearMykelSession();
        window.location.href = '/MykelLogin';
        return;
      }
      // Erreur réseau — fallback sur la session Mykel
      const mykelSession = getMykelSession();
      if (mykelSession) {
        setUser({ email: mykelSession.email, full_name: mykelSession.full_name, role: mykelSession.role });
      }
    }
  };

  const getCurrentWorkspace = () => isBusinessMode() && getBusinessSubId() ? 'business:' + getBusinessSubId() : 'personal';

  const loadStorageInfo = async () => {
    try {
      if (isBusinessMode() && getBusinessSubId()) {
        const businessSub = await base44.entities.BusinessSubscription.get(getBusinessSubId());
        if (businessSub) {
          const maxStorage = (businessSub.storage_gb || 0) * 1024 * 1024 * 1024;
          const allFiles = await base44.entities.CloudFile.filter({ created_by: user.email });
          const ws = getCurrentWorkspace();
          const used = allFiles.filter(f => (f.workspace || 'personal') === ws).reduce((sum, f) => sum + (f.size || 0), 0);
          setStorageInfo({ used, max: maxStorage });
        }
        return;
      }
      const storageList = await base44.entities.UserStorage.filter({ user_email: user.email });
      if (storageList.length > 0) {
        const activeSubs = await base44.entities.StorageSubscription.filter({ user_email: user.email, active: true });
        setStorageInfo({ used: storageList[0].used_storage || 0, max: computeEffectiveMax(storageList[0].max_storage, activeSubs) });
      } else {
        // Create storage record — unlimited for all users
        await base44.entities.UserStorage.create({
          user_email: user.email,
          used_storage: 0,
          max_storage: -1
        });
        setStorageInfo({ used: 0, max: -1 });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadFolders = async () => {
    try {
      const folders = await base44.entities.CloudFile.filter({
        type: 'folder',
        is_trashed: false,
        created_by: user.email
      });
      setAllFolders(folders);
    } catch (e) {
      console.error(e);
    }
  };

  const loadFiles = async () => {
    setLoading(true);
    try {
      let fileList = [];
      await loadFolders();
      
      if (currentView === 'accueil') {
        const [ownRaw, sharedRaw] = await Promise.all([
          base44.entities.CloudFile.filter({ is_trashed: false, created_by: user.email }, '-updated_date', 50),
          base44.entities.CloudFile.filter({ is_trashed: false, shared_with: user.email }).catch(() => [])
        ]);
        const seen = new Set();
        fileList = [...ownRaw, ...sharedRaw].filter(f => {
          if (seen.has(f.id)) return false;
          seen.add(f.id);
          return !f.imported_to_music;
        });
      } else if (currentView === 'cloud') {
        if (cloudSubView === 'mycloud') {
          if (currentFolderId) {
            const raw = await base44.entities.CloudFile.filter({ 
              parent_folder_id: currentFolderId,
              is_trashed: false,
              created_by: user.email
            });
            fileList = raw.filter(f => !f.imported_to_music);
          } else {
            const [ownFiles, sharedFiles] = await Promise.all([
              base44.entities.CloudFile.filter({ is_trashed: false, created_by: user.email }),
              base44.entities.CloudFile.filter({ is_trashed: false, shared_with: user.email }).catch(() => [])
            ]);
            const seen = new Set();
            fileList = [...ownFiles, ...sharedFiles].filter(f => {
              if (seen.has(f.id)) return false;
              seen.add(f.id);
              return !f.parent_folder_id && !f.imported_to_music;
            });
          }
        } else if (cloudSubView === 'favoris') {
          const raw = await base44.entities.CloudFile.filter({ 
            is_starred: true,
            is_trashed: false,
            created_by: user.email
          });
          fileList = raw.filter(f => !f.imported_to_music);
        } else if (cloudSubView === 'corbeille') {
          fileList = await base44.entities.CloudFile.filter({ 
            is_trashed: true,
            created_by: user.email
          });
        }
      } else if (currentView === 'logiciels') {
        const raw = await base44.entities.CloudFile.filter({ 
          is_trashed: false,
          created_by: user.email
        });
        fileList = raw.filter(f => 
          !f.imported_to_music && 
          ['document', 'spreadsheet', 'presentation', 'drawing'].includes(f.type)
        );
      }
      
      // Filter by workspace (personal vs business) — but always keep shared files
      const ws = getCurrentWorkspace();
      fileList = fileList.filter(f => (f.shared_with && f.shared_with.includes(user.email) && (f.shared_accepted === undefined || f.shared_accepted.includes(user.email))) || (f.workspace || 'personal') === ws);
      
      // Sort: pinned first, then by last opened / updated date (most recent first)
      fileList.sort((a, b) => {
        if (a.is_pinned && !b.is_pinned) return -1;
        if (!a.is_pinned && b.is_pinned) return 1;
        const aDate = a.last_opened || a.updated_date || a.created_date;
        const bDate = b.last_opened || b.updated_date || b.created_date;
        return new Date(bDate || 0).getTime() - new Date(aDate || 0).getTime();
      });
      
      // Limit to 6 most recent on home view
      if (currentView === 'accueil') {
        fileList = fileList.slice(0, 6);
      }
      
      setFiles(fileList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleFileClick = async (file) => {
    // Track last opened time for sorting
    if (file.type !== 'folder') {
      base44.entities.CloudFile.update(file.id, { last_opened: new Date().toISOString() }).catch(() => {});
    }
    if (file.type === 'folder') {
      setBreadcrumbs([...breadcrumbs, file]);
      setCurrentFolderId(file.id);
      setCurrentView('cloud');
      setCloudSubView('mycloud');
    } else if (file.type === 'document') {
      navigate(`/MykelWord?fileId=${file.id}`);
    } else if (file.type === 'spreadsheet') {
      navigate(`/MykelTabs?fileId=${file.id}`);
    } else if (file.type === 'presentation') {
      navigate(`/MykelSliders?fileId=${file.id}`);
    } else if (file.type === 'drawing') {
      navigate(`/MykelDraws?fileId=${file.id}`);
    } else if (file.content?.scene3d_id) {
      // 3D scene — open in Mykel3D
      navigate(`/Mykel3D?sceneId=${file.content.scene3d_id}`);
    } else if (file.content?.app === 'MykelSnapFix' && file.content?.snapfix_url) {
      // SnapFix project
      navigate(`/MykelSnapFix?url=${encodeURIComponent(file.content.snapfix_url)}&name=${encodeURIComponent(file.name)}`);
    } else if (file.content?.app === 'MykelEdiCode') {
      // EdiCode project
      navigate(`/MykelEdiCode?fileId=${file.id}`);
    } else if (['image', 'video', 'audio', 'pdf'].includes(file.type)) {
      setViewerFile(file);
    } else if (file.file_url) {
      window.open(file.file_url, '_blank');
    }
  };

  const handleBreadcrumbClick = (crumb) => {
    if (!crumb) {
      setBreadcrumbs([]);
      setCurrentFolderId(null);
    } else {
      const index = breadcrumbs.findIndex(b => b.id === crumb.id);
      setBreadcrumbs(breadcrumbs.slice(0, index + 1));
      setCurrentFolderId(crumb.id);
    }
  };

  const handleNewFolder = async () => {
    if (!newName.trim()) return;
    try {
      await base44.entities.CloudFile.create({
        name: newName.trim(),
        type: 'folder',
        parent_folder_id: currentFolderId || null,
        is_starred: false,
        is_trashed: false,
        workspace: getCurrentWorkspace()
      });
      setNewFolderDialog(false);
      setNewName('');
      loadFiles();
      toast.success('Dossier créé');
    } catch (e) {
      toast.error('Erreur lors de la création');
    }
  };

  const handleNewDocument = async (type) => {
    try {
      const names = {
        document: 'Document sans titre',
        spreadsheet: 'Feuille de calcul sans titre',
        presentation: 'Présentation sans titre',
        drawing: 'Dessin sans titre'
      };
      const pages = {
        document: '/MykelWord',
        spreadsheet: '/MykelTabs',
        presentation: '/MykelSliders',
        drawing: '/MykelDraws'
      };
      
      const newFile = await base44.entities.CloudFile.create({
        name: names[type],
        type: type,
        parent_folder_id: currentFolderId || null,
        content: type === 'spreadsheet' ? { cells: {}, styles: {} } : 
                 type === 'presentation' ? { slides: [{ id: '1', elements: [], background: '#ffffff' }] } :
                 type === 'drawing' ? { elements: [], background: '#ffffff' } :
                 { html: '', styles: {} },
        is_starred: false,
        is_trashed: false,
        workspace: getCurrentWorkspace()
        });
        
        navigate(pages[type] + `?fileId=${newFile.id}`);
    } catch (e) {
      toast.error('Erreur lors de la création');
    }
  };

  const handleUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    setUploading(true);
    try {
      for (const file of files) {
        const { file_url } = await uploadMedia(file);
        
        let fileType = 'other';
        const ext = file.name.split('.').pop().toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext)) fileType = 'image';
        else if (['mp4', 'webm', 'mov', 'avi'].includes(ext)) fileType = 'video';
        else if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) fileType = 'audio';
        else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) fileType = 'archive';
        else if (ext === 'pdf') fileType = 'pdf';
        
        await base44.entities.CloudFile.create({
          name: file.name,
          type: fileType,
          size: file.size,
          file_url: file_url,
          parent_folder_id: currentFolderId || null,
          is_starred: false,
          is_trashed: false,
          workspace: getCurrentWorkspace()
        });
        
        // Update storage
        await updateStorage(file.size);
      }
      
      loadFiles();
      loadStorageInfo();
      toast.success('Fichier(s) importé(s)');
    } catch (e) {
      toast.error('Erreur lors de l\'import');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleFolderUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    setUploading(true);
    try {
      const folderStructure = {};
      
      // Organize files by folders
      for (const file of files) {
        const path = file.webkitRelativePath || file.name;
        const parts = path.split('/');
        
        if (parts.length > 1) {
          const folderPath = parts.slice(0, -1).join('/');
          if (!folderStructure[folderPath]) {
            folderStructure[folderPath] = [];
          }
          folderStructure[folderPath].push(file);
        }
      }
      
      // Create folders and upload files
      for (const [folderPath, folderFiles] of Object.entries(folderStructure)) {
        const folderParts = folderPath.split('/');
        let parentId = currentFolderId;
        
        // Create nested folders
        for (const folderName of folderParts) {
          const existingFolder = await base44.entities.CloudFile.filter({
            name: folderName,
            type: 'folder',
            parent_folder_id: parentId,
            created_by: user.email
          });
          
          if (existingFolder.length > 0) {
            parentId = existingFolder[0].id;
          } else {
            const newFolder = await base44.entities.CloudFile.create({
              name: folderName,
              type: 'folder',
              parent_folder_id: parentId,
              is_starred: false,
              is_trashed: false,
              workspace: getCurrentWorkspace()
            });
            parentId = newFolder.id;
          }
        }
        
        // Upload files in this folder
        for (const file of folderFiles) {
          const { file_url } = await uploadMedia(file);
          
          let fileType = 'other';
          const ext = file.name.split('.').pop().toLowerCase();
          if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext)) fileType = 'image';
          else if (['mp4', 'webm', 'mov', 'avi'].includes(ext)) fileType = 'video';
          else if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) fileType = 'audio';
          else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) fileType = 'archive';
          else if (ext === 'pdf') fileType = 'pdf';
          
          await base44.entities.CloudFile.create({
            name: file.name,
            type: fileType,
            size: file.size,
            file_url: file_url,
            parent_folder_id: parentId,
            is_starred: false,
            is_trashed: false,
            workspace: getCurrentWorkspace()
          });
          
          await updateStorage(file.size);
        }
      }
      
      loadFiles();
      loadStorageInfo();
      toast.success('Dossier importé');
    } catch (e) {
      toast.error('Erreur lors de l\'import');
    } finally {
      setUploading(false);
      if (folderInputRef.current) folderInputRef.current.value = '';
    }
  };

  const updateStorage = async (addedBytes) => {
    if (isBusinessMode()) return;
    const storageList = await base44.entities.UserStorage.filter({ user_email: user.email });
    if (storageList.length > 0) {
      await base44.entities.UserStorage.update(storageList[0].id, {
        used_storage: (storageList[0].used_storage || 0) + addedBytes
      });
    }
  };

  const handleToggleStar = async (file) => {
    try {
      await base44.entities.CloudFile.update(file.id, { is_starred: !file.is_starred });
      loadFiles();
    } catch (e) {
      toast.error('Erreur');
    }
  };

  const handleTogglePin = async (file) => {
    try {
      await base44.entities.CloudFile.update(file.id, { is_pinned: !file.is_pinned });
      loadFiles();
    } catch (e) {
      toast.error('Erreur');
    }
  };

  const handleDelete = async (file) => {
    try {
      if (isTrashView) {
        await base44.entities.CloudFile.delete(file.id);
        toast.success('Fichier supprimé définitivement');
      } else {
        await base44.entities.CloudFile.update(file.id, { is_trashed: true });
        toast.success('Fichier déplacé vers la corbeille');
      }
      loadFiles();
    } catch (e) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleRename = async () => {
    if (!newName.trim() || !renameDialog.file) return;
    try {
      await base44.entities.CloudFile.update(renameDialog.file.id, { name: newName.trim() });
      setRenameDialog({ open: false, file: null });
      setNewName('');
      loadFiles();
      toast.success('Fichier renommé');
    } catch (e) {
      toast.error('Erreur lors du renommage');
    }
  };

  const [shareConfirmDialog, setShareConfirmDialog] = useState(false);

  const handleShare = async () => {
    if (!shareEmail.trim() || !shareDialog.file) return;
    setShareConfirmDialog(true);
  };

  const confirmShare = async () => {
    try {
      const file = shareDialog.file;
      const currentShared = file.shared_with || [];
      const currentPerms = file.shared_permissions || {};
      const email = shareEmail.trim();
      if (currentShared.includes(email)) {
        toast.info('Cette personne a déjà accès');
        setShareDialog({ open: false, file: null });
        setShareEmail('');
        setShareConfirmDialog(false);
        return;
      }
      await base44.entities.CloudFile.update(file.id, {
        shared_with: [...currentShared, email],
        shared_permissions: { ...currentPerms, [email]: 'view' }
      });
      setShareDialog({ open: false, file: null });
      setShareEmail('');
      setShareConfirmDialog(false);
      toast.success('Invitation envoyée — le destinataire doit accepter');
      loadFiles();
    } catch (e) {
      toast.error('Erreur lors du partage');
    }
  };

  const handleDuplicate = async (file) => {
    try {
      const newFile = { ...file };
      delete newFile.id;
      delete newFile.created_date;
      delete newFile.updated_date;
      newFile.name = `${file.name} (copie)`;
      newFile.workspace = getCurrentWorkspace();
      await base44.entities.CloudFile.create(newFile);
      loadFiles();
      toast.success('Fichier dupliqué');
    } catch (e) {
      toast.error('Erreur lors de la duplication');
    }
  };

  const handleDownload = (file) => {
    if (file.file_url) {
      window.open(file.file_url, '_blank');
    }
  };

  const handleSelectFile = (file) => {
    if (selectedFiles.includes(file.id)) {
      setSelectedFiles(selectedFiles.filter(id => id !== file.id));
    } else {
      setSelectedFiles([...selectedFiles, file.id]);
    }
  };

  const handleBulkDelete = async () => {
    if (isTrashView) {
      const allTrashedFiles = files.map(f => f.id);
      if (allTrashedFiles.length === 0) return;
      if (!await confirmAction({ title: `Supprimer ${allTrashedFiles.length} fichier(s) définitivement ?`, destructive: true })) return;
      
      try {
        for (const fileId of allTrashedFiles) {
          await base44.entities.CloudFile.delete(fileId);
        }
        loadFiles();
        toast.success('Corbeille vidée');
      } catch (e) {
        toast.error('Erreur lors de la suppression');
      }
      return;
    }
    
    if (selectedFiles.length === 0) return;
    if (!await confirmAction({ title: `Supprimer ${selectedFiles.length} fichier(s) ?`, destructive: true })) return;
    
    try {
      for (const fileId of selectedFiles) {
        await base44.entities.CloudFile.update(fileId, { is_trashed: true });
      }
      setSelectedFiles([]);
      setSelectionMode(false);
      loadFiles();
      toast.success(`${selectedFiles.length} fichier(s) supprimé(s)`);
    } catch (e) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleBulkMove = async () => {
    if (!targetFolder || selectedFiles.length === 0) return;

    try {
      for (const fileId of selectedFiles) {
        await base44.entities.CloudFile.update(fileId, {
          parent_folder_id: targetFolder === 'root' ? null : targetFolder
        });
      }
      setSelectedFiles([]);
      setSelectionMode(false);
      setMoveDialog(false);
      setTargetFolder(null);
      loadFiles();
      toast.success(`${selectedFiles.length} fichier(s) déplacé(s)`);
    } catch (e) {
      toast.error('Erreur lors du déplacement');
    }
  };

  const handleDragMove = async (fileId, folderId) => {
    try {
      await base44.entities.CloudFile.update(fileId, {
        parent_folder_id: folderId
      });
      toast.success('Fichier déplacé');
    } catch (e) {
      toast.error('Erreur lors du déplacement');
    }
  };

  const handleRestore = async (file) => {
    try {
      await base44.entities.CloudFile.update(file.id, { is_trashed: false });
      loadFiles();
      toast.success('Fichier restauré');
    } catch (e) {
      toast.error('Erreur lors de la restauration');
    }
  };

  const handleImportToMusic = (file) => {
    setImportMusicDialog(file);
  };

  const confirmImportToMusic = async (type) => {
    if (!importMusicDialog) return;
    try {
      // Create MusicFile
      await base44.entities.MusicFile.create({
        cloud_file_id: importMusicDialog.id,
        name: importMusicDialog.name,
        file_url: importMusicDialog.file_url,
        type: type
      });

      // Mark as imported
      await base44.entities.CloudFile.update(importMusicDialog.id, {
        imported_to_music: true
      });

      setImportMusicDialog(null);
      loadFiles();
      toast.success('Importé dans Mykel Music');
    } catch (e) {
      toast.error('Erreur lors de l\'import');
    }
  };

  const handlePullRefresh = async () => {
    setRefreshing(true);
    await loadFiles();
    await loadStorageInfo();
    setTimeout(() => setRefreshing(false), 500);
  };

  const handleTouchStart = (e) => {
    if (scrollContainerRef.current?.scrollTop === 0) {
      touchStartY.current = e.touches[0].clientY;
    }
  };

  const handleTouchMove = (e) => {
    if (scrollContainerRef.current?.scrollTop === 0 && !refreshing) {
      const touchY = e.touches[0].clientY;
      const distance = touchY - touchStartY.current;
      if (distance > 0 && distance < 100) {
        setPullDistance(distance);
      }
    }
  };

  const handleTouchEnd = () => {
    if (pullDistance > 60) {
      handlePullRefresh();
    }
    setPullDistance(0);
  };

  const filteredFiles = files.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getViewTitle = () => {
    if (currentView === 'accueil') return t('home');
    if (currentView === 'cloud') {
      if (cloudSubView === 'favoris') return t('favorites');
      if (cloudSubView === 'corbeille') return t('trash');
      return breadcrumbs.length > 0 ? breadcrumbs[breadcrumbs.length - 1].name : t('cloud');
    }
    if (currentView === 'logiciels') return t('logiciels');
    return t('cloud');
  };

  const isTrashView = currentView === 'cloud' && cloudSubView === 'corbeille';

  return (
    <SanctionGuard scope="platform">
    <div className="flex h-screen bg-white select-none">
      <Sidebar
        currentView={currentView}
        onViewChange={(view) => {
          setCurrentView(view);
          setCurrentFolderId(null);
          setBreadcrumbs([]);
        }}
        onNewDocument={handleNewDocument}
        onNewFolder={() => setNewFolderDialog(true)}
        onUpload={() => fileInputRef.current?.click()}
        storageUsed={storageInfo.used}
        storageMax={storageInfo.max}
        isMobile={isMobile}
        collapsed={sidebarCollapsed}
        user={user}
        folderInputRef={folderInputRef}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          breadcrumbs={breadcrumbs}
          onBreadcrumbClick={handleBreadcrumbClick}
          sidebarCollapsed={sidebarCollapsed}
          onToggleSidebar={toggleSidebar}
          user={user}
          isMobile={isMobile}
        />
        
        <main 
          ref={scrollContainerRef}
          className="flex-1 overflow-auto p-4 md:p-6 pb-20 md:pb-6"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Pull to refresh indicator */}
          {pullDistance > 0 && (
            <div 
              className="flex justify-center py-2 transition-opacity"
              style={{ opacity: pullDistance / 60 }}
            >
              <RefreshCw className={`w-6 h-6 text-blue-600 ${pullDistance > 60 ? 'animate-spin' : ''}`} />
            </div>
          )}
          
          {refreshing && (
            <div className="flex justify-center py-2">
              <RefreshCw className="w-6 h-6 text-blue-600 animate-spin" />
            </div>
          )}
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
          ) : (
            <>
              {/* Page title + notification bell */}
              <div className="flex items-center justify-between gap-3 mb-4 md:mb-6">
                {currentView !== 'accueil' && <h1 className="text-2xl md:text-3xl font-bold text-black truncate min-w-0">{getViewTitle()}</h1>}
                <NotificationBell user={user} onAccept={loadFiles} />
              </div>

              {currentView === 'accueil' ? (
                <AccueilView
                  storageUsed={storageInfo.used}
                  storageMax={storageInfo.max}
                  recentFiles={filteredFiles}
                  user={user}
                  onFileClick={handleFileClick}
                  onNewFolder={() => setNewFolderDialog(true)}
                  onUpload={() => fileInputRef.current?.click()}
                  onUploadFolder={() => folderInputRef.current?.click()}
                  onOpenApps={() => setAppsMenuOpen(true)}
                  onViewChange={(view) => { setCurrentView(view); setCurrentFolderId(null); setBreadcrumbs([]); }}
                />
              ) : currentView === 'logiciels' ? (
                <LogicielsView
                  officeFiles={filteredFiles}
                  viewMode={viewMode}
                  onFileClick={handleFileClick}
                  onToggleStar={handleToggleStar}
                  onTogglePin={handleTogglePin}
                  onRename={(file) => { setRenameDialog({ open: true, file }); setNewName(file.name); }}
                  onShare={(file) => setShareDialog({ open: true, file })}
                  onDuplicate={handleDuplicate}
                  onDownload={handleDownload}
                  onDelete={handleDelete}
                />
              ) : (
                <>
                  {/* Cloud pill tabs */}
                  <div className="mb-4 flex gap-2">
                    {[
                      { id: 'mycloud', label: t('mon_cloud') },
                      { id: 'favoris', label: t('favorites') },
                      { id: 'corbeille', label: t('trash') },
                    ].map(sub => (
                      <button
                        key={sub.id}
                        onClick={() => { setCloudSubView(sub.id); setCurrentFolderId(null); setBreadcrumbs([]); }}
                        className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                          cloudSubView === sub.id
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-200 text-black hover:bg-gray-300'
                        }`}
                      >
                        {sub.label}
                      </button>
                    ))}
                  </div>

                  {/* Selection buttons */}
                  <div className="mb-4 md:mb-6 flex items-center justify-end gap-2">
                    {isTrashView ? (
                      <>
                        <Button
                          variant={selectionMode ? 'default' : 'outline'}
                          onClick={() => { setSelectionMode(!selectionMode); setSelectedFiles([]); }}
                          className="min-h-[44px]"
                        >
                          {t('select')}
                        </Button>
                        <Button variant="destructive" onClick={handleBulkDelete} className="min-h-[44px]">
                          {t('empty_trash')}
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant={selectionMode ? 'default' : 'outline'}
                          onClick={() => { setSelectionMode(!selectionMode); setSelectedFiles([]); }}
                          className="min-h-[44px]"
                        >
                          {t('select')}
                        </Button>
                        {selectionMode && (
                          <>
                            <Button
                              variant="outline"
                              onClick={() => { const allFileIds = filteredFiles.map(f => f.id); setSelectedFiles(allFileIds); }}
                              className="min-h-[44px]"
                            >
                              {t('select_all')}
                            </Button>
                            {selectedFiles.length > 0 && (
                              <>
                                <Button variant="outline" onClick={() => setMoveDialog(true)} className="min-h-[44px]">
                                  {t('move')} ({selectedFiles.length})
                                </Button>
                                <Button variant="destructive" onClick={handleBulkDelete} className="min-h-[44px]">
                                  {t('delete')} ({selectedFiles.length})
                                </Button>
                              </>
                            )}
                          </>
                        )}
                      </>
                    )}
                  </div>

                  <FileGrid
                    files={filteredFiles}
                    viewMode={viewMode}
                    onFileClick={handleFileClick}
                    onToggleStar={handleToggleStar}
                    onTogglePin={handleTogglePin}
                    onDelete={handleDelete}
                    onDownload={handleDownload}
                    onRename={(file) => { setRenameDialog({ open: true, file }); setNewName(file.name); }}
                    onShare={(file) => setShareDialog({ open: true, file })}
                    onDuplicate={handleDuplicate}
                    isTrash={isTrashView}
                    selectionMode={selectionMode}
                    selectedFiles={selectedFiles}
                    onSelectFile={handleSelectFile}
                    allFolders={allFolders}
                    onDragMove={handleDragMove}
                    onRestore={handleRestore}
                    onImportToMusic={handleImportToMusic}
                  />
                </>
              )}
            </>
          )}
        </main>
      </div>
      
      {/* Hidden file inputs */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleUpload}
        className="hidden"
        multiple
      />
      <input
        type="file"
        ref={folderInputRef}
        onChange={handleFolderUpload}
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
      />
      
      {/* Bottom Navigation for Mobile */}
      {isMobile && (
        <>
          <BottomTabs
            currentView={currentView}
            onViewChange={(view) => {
              setCurrentView(view);
              setCurrentFolderId(null);
              setBreadcrumbs([]);
            }}
            onOpenApps={() => setAppsMenuOpen(true)}
          />
          <AppsMenu
            open={appsMenuOpen}
            onOpenChange={setAppsMenuOpen}
            onNewDocument={handleNewDocument}
            onNewFolder={() => setNewFolderDialog(true)}
            onUpload={() => fileInputRef.current?.click()}
            onUploadFolder={() => folderInputRef.current?.click()}
          />
        </>
      )}

      {/* New Folder Dialog */}
      <Dialog open={newFolderDialog} onOpenChange={setNewFolderDialog}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-gray-900 dark:text-white">{t('new_folder_title')}</DialogTitle>
          </DialogHeader>
          <Input
            placeholder={t('folder_name')}
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleNewFolder()}
            className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white select-text"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewFolderDialog(false)} className="min-h-[44px]">
              {t('cancel')}
            </Button>
            <Button onClick={handleNewFolder} className="min-h-[44px]">{t('create')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Rename Dialog */}
      <Dialog open={renameDialog.open} onOpenChange={(open) => setRenameDialog({ ...renameDialog, open })}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-gray-900 dark:text-white">{t('rename_title')}</DialogTitle>
          </DialogHeader>
          <Input
            placeholder={t('new_name')}
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRename()}
            className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white select-text"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameDialog({ open: false, file: null })} className="min-h-[44px]">
              {t('cancel')}
            </Button>
            <Button onClick={handleRename} className="min-h-[44px]">{t('rename')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Manage Members Dialog */}
      <ManageMembersDialog
        open={shareDialog.open}
        onOpenChange={(open) => setShareDialog({ ...shareDialog, open })}
        file={shareDialog.file}
        onShared={loadFiles}
        userEmail={user?.email}
      />
      
      {/* Move Dialog */}
      <Dialog open={moveDialog} onOpenChange={setMoveDialog}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-gray-900 dark:text-white">{t('move_title_prefix')} {selectedFiles.length}</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            <button
              onClick={() => setTargetFolder('root')}
              className={`w-full text-left p-3 rounded-lg border transition-colors min-h-[44px] ${
                targetFolder === 'root' ? 'border-blue-500 bg-blue-50 dark:bg-blue-950' : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              📁 {t('root_drive')}
            </button>
            {allFolders.map(folder => (
              <button
                key={folder.id}
                onClick={() => setTargetFolder(folder.id)}
                className={`w-full text-left p-3 rounded-lg border transition-colors min-h-[44px] text-gray-900 dark:text-white ${
                  targetFolder === folder.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-950' : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
                }`}
              >
                📁 {folder.name}
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMoveDialog(false)} className="min-h-[44px]">{t('cancel')}</Button>
            <Button onClick={handleBulkMove} disabled={!targetFolder} className="min-h-[44px]">{t('move')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upload overlay */}
      {uploading && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-900 rounded-xl p-8 flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 animate-spin text-blue-600 dark:text-blue-400" />
            <p className="text-lg font-medium text-gray-900 dark:text-white">Import en cours...</p>
          </div>
        </div>
      )}

      {/* File Viewer */}
      {viewerFile && (
        <FileViewer file={viewerFile} onClose={() => setViewerFile(null)} />
      )}

      <AnnouncementModal target="home" />

      {/* Import to Music Dialog */}
      <Dialog open={!!importMusicDialog} onOpenChange={() => setImportMusicDialog(null)}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-gray-900 dark:text-white">{t('import_music_title')}</DialogTitle>
          </DialogHeader>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{t('import_music_body')}</p>
          <DialogFooter className="flex gap-2">
            <Button onClick={() => confirmImportToMusic('music')} className="flex-1 min-h-[44px]">
              {t('music')}
            </Button>
            <Button onClick={() => confirmImportToMusic('podcast')} className="flex-1 min-h-[44px]" variant="outline">
              {t('podcast')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </SanctionGuard>
  );
}