import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import AIAssistant from '@/components/shared/AIAssistant';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import { getFilePermission } from '@/lib/filePermissions';
import { getMykelSession } from '@/lib/mykelSession';
import useAutoSave from '@/hooks/useAutoSave';
import SaveStatus from '@/components/shared/SaveStatus';
import { Link, useNavigate } from 'react-router-dom';
import { useScreenSize } from '@/components/utils/useScreenSize';
import SliderToolbar from '@/components/sliders/SliderToolbar';
import SlideCanvas from '@/components/sliders/SlideCanvas';
import SlideThumbnails from '@/components/sliders/SlideThumbnails';
import AppAccessCheck from '@/components/drive/AppAccessCheck';
import { useRef } from 'react';
import { Presentation, ChevronLeft, Loader2, X, MessageSquare } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';
import { uploadMedia } from '@/lib/freeCore';
import CommentsPanel from '@/components/shared/CommentsPanel';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter 
} from "@/components/ui/dialog";

export default function MykelSliders() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const fileId = urlParams.get('fileId');
  const { isMobile } = useScreenSize();
  
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fileName, setFileName] = useState('Présentation sans titre');
  const [isEditing, setIsEditing] = useState(false);
  const [shareDialog, setShareDialog] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [canEdit, setCanEdit] = useState(true);
  const [showComments, setShowComments] = useState(false);
  const [user, setUser] = useState(null);
  const canEditRef = useRef(true);
  useEffect(() => { canEditRef.current = canEdit; }, [canEdit]);
  const createdIdRef = useRef(null);
  const autoSave = useAutoSave(file?.id, { enabled: canEdit });
  
  // Presentation state
  const [slides, setSlides] = useState([
    { id: '1', elements: [], background: '#ffffff' }
  ]);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [selectedElement, setSelectedElement] = useState(null);
  const [isPresenting, setIsPresenting] = useState(false);
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const imageInputRef = useRef(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  
  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);
  useEffect(() => {
    if (fileId) {
      if (fileId !== createdIdRef.current) loadFile();
    } else {
      createNewPresentation();
    }
  }, [fileId]);

  const loadFile = async () => {
    try {
      const fileData = await base44.entities.CloudFile.filter({ id: fileId });
      if (fileData.length > 0) {
        setFile(fileData[0]);
        setFileName(fileData[0].name);
        autoSave.setBaseline({ name: fileData[0].name, content: { slides: fileData[0].content?.slides || [{ id: '1', elements: [], background: '#ffffff' }] } });
        if (fileData[0].content?.slides) {
          setSlides(fileData[0].content.slides);
        }
        // Check permission — only owner or 'edit' members can modify
        const session = getMykelSession();
        const { canEdit: editAllowed, permission } = getFilePermission(fileData[0], session?.email);
        setCanEdit(editAllowed);
        if (!editAllowed) {
          toast.info(`Vous êtes en mode ${permission === 'comment' ? 'commentaire' : 'visualisation'}. Vous ne pouvez pas modifier ce fichier.`);
        }
      }
    } catch (e) {
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  const createNewPresentation = async () => {
    try {
      const newFile = await base44.entities.CloudFile.create({
        name: 'Présentation sans titre',
        type: 'presentation',
        content: { slides: [{ id: '1', elements: [], background: '#ffffff' }] },
        is_starred: false,
        is_trashed: false,
      });
      createdIdRef.current = newFile.id;
      autoSave.setBaseline({ name: 'Présentation sans titre', content: { slides: [{ id: '1', elements: [], background: '#ffffff' }] } });
      setFile(newFile);
      setFileName('Présentation sans titre');
      navigate(`/MykelSliders?fileId=${newFile.id}`, { replace: true });
    } catch (e) {
      toast.error('Erreur lors de la création');
      navigate('/Dashboard', { replace: true });
    }
    setLoading(false);
  };

  // Sauvegarde automatique : uniquement quand le contenu change
  useEffect(() => {
    autoSave.queue({ name: fileName, content: { slides } });
  }, [fileName, slides]);

  const savePresentation = useCallback(async () => {
    if (!canEditRef.current) return; // Block saves for view/comment members
    if (await autoSave.saveNow()) toast.success('Présentation enregistrée');
  }, [autoSave.saveNow]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        savePresentation();
      }
      if (e.key === 'Escape' && isPresenting) {
        setIsPresenting(false);
      }
      if (isPresenting) {
        if (e.key === 'ArrowRight' || e.key === ' ') {
          if (currentSlideIndex < slides.length - 1) {
            setCurrentSlideIndex(currentSlideIndex + 1);
          }
        } else if (e.key === 'ArrowLeft') {
          if (currentSlideIndex > 0) {
            setCurrentSlideIndex(currentSlideIndex - 1);
          }
        }
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [savePresentation, isPresenting, currentSlideIndex, slides.length]);

  const saveToHistory = () => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(JSON.parse(JSON.stringify(slides)));
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const handleCommand = (command, value) => {
    const currentSlide = slides[currentSlideIndex];
    
    switch (command) {
      case 'undo':
        if (historyIndex > 0) {
          setHistoryIndex(historyIndex - 1);
          setSlides(history[historyIndex - 1]);
        }
        break;
        
      case 'redo':
        if (historyIndex < history.length - 1) {
          setHistoryIndex(historyIndex + 1);
          setSlides(history[historyIndex + 1]);
        }
        break;
        
      case 'addTextBox':
        saveToHistory();
        const newText = {
          id: generateId(),
          type: 'text',
          x: 100,
          y: 100,
          width: 300,
          height: 50,
          content: 'Nouveau texte',
          fontSize: 24,
          fontFamily: 'Arial'
        };
        updateCurrentSlide({
          elements: [...currentSlide.elements, newText]
        });
        setSelectedElement(newText.id);
        break;
        
      case 'addImage':
        imageInputRef.current?.click();
        break;
        
      case 'addShape':
        saveToHistory();
        const newShape = {
          id: generateId(),
          type: value,
          x: 100,
          y: 100,
          width: value === 'line' ? 200 : 150,
          height: value === 'line' ? 4 : 150,
          fillColor: '#3b82f6'
        };
        updateCurrentSlide({
          elements: [...currentSlide.elements, newShape]
        });
        setSelectedElement(newShape.id);
        break;
        
      case 'addSlide':
        saveToHistory();
        const newSlide = {
          id: generateId(),
          elements: [],
          background: '#ffffff'
        };
        setSlides([...slides, newSlide]);
        setCurrentSlideIndex(slides.length);
        break;
        
      case 'duplicateSlide':
        saveToHistory();
        const duplicated = JSON.parse(JSON.stringify(currentSlide));
        duplicated.id = generateId();
        duplicated.elements = duplicated.elements.map(el => ({
          ...el,
          id: generateId()
        }));
        const newSlides = [...slides];
        newSlides.splice(currentSlideIndex + 1, 0, duplicated);
        setSlides(newSlides);
        setCurrentSlideIndex(currentSlideIndex + 1);
        break;
        
      case 'deleteSlide':
        if (slides.length > 1) {
          saveToHistory();
          const filtered = slides.filter((_, i) => i !== currentSlideIndex);
          setSlides(filtered);
          if (currentSlideIndex >= filtered.length) {
            setCurrentSlideIndex(filtered.length - 1);
          }
        }
        break;
        
      case 'slideBackground':
        saveToHistory();
        updateCurrentSlide({ background: value });
        break;
        
      case 'delete':
        if (selectedElement) {
          saveToHistory();
          updateCurrentSlide({
            elements: currentSlide.elements.filter(el => el.id !== selectedElement)
          });
          setSelectedElement(null);
        }
        break;
        
      case 'duplicate':
        if (selectedElement) {
          const element = currentSlide.elements.find(el => el.id === selectedElement);
          if (element) {
            saveToHistory();
            const duplicatedEl = {
              ...element,
              id: generateId(),
              x: element.x + 20,
              y: element.y + 20
            };
            updateCurrentSlide({
              elements: [...currentSlide.elements, duplicatedEl]
            });
            setSelectedElement(duplicatedEl.id);
          }
        }
        break;
        
      case 'bold':
      case 'italic':
      case 'underline':
        if (selectedElement) {
          const element = currentSlide.elements.find(el => el.id === selectedElement);
          if (element && element.type === 'text') {
            handleElementUpdate(selectedElement, { [command]: !element[command] });
          }
        }
        break;
        
      case 'fontFamily':
      case 'fontSize':
      case 'textColor':
      case 'fillColor':
      case 'align':
        if (selectedElement) {
          handleElementUpdate(selectedElement, { [command]: value });
        }
        break;
        
      case 'bringForward':
        if (selectedElement) {
          saveToHistory();
          const idx = currentSlide.elements.findIndex(el => el.id === selectedElement);
          if (idx < currentSlide.elements.length - 1) {
            const newElements = [...currentSlide.elements];
            [newElements[idx], newElements[idx + 1]] = [newElements[idx + 1], newElements[idx]];
            updateCurrentSlide({ elements: newElements });
          }
        }
        break;
        
      case 'sendBackward':
        if (selectedElement) {
          saveToHistory();
          const idx = currentSlide.elements.findIndex(el => el.id === selectedElement);
          if (idx > 0) {
            const newElements = [...currentSlide.elements];
            [newElements[idx], newElements[idx - 1]] = [newElements[idx - 1], newElements[idx]];
            updateCurrentSlide({ elements: newElements });
          }
        }
        break;
    }
  };

  const updateCurrentSlide = (updates) => {
    const newSlides = [...slides];
    newSlides[currentSlideIndex] = { ...newSlides[currentSlideIndex], ...updates };
    setSlides(newSlides);
  };

  const handleElementUpdate = (elementId, updates) => {
    const currentSlide = slides[currentSlideIndex];
    const newElements = currentSlide.elements.map(el =>
      el.id === elementId ? { ...el, ...updates } : el
    );
    updateCurrentSlide({ elements: newElements });
  };

  const handleElementDelete = (elementId) => {
    saveToHistory();
    const currentSlide = slides[currentSlideIndex];
    updateCurrentSlide({
      elements: currentSlide.elements.filter(el => el.id !== elementId)
    });
    setSelectedElement(null);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const { file_url } = await uploadMedia(file);
      const currentSlide = slides[currentSlideIndex];
      const newImage = {
        id: generateId(),
        type: 'image',
        x: 100,
        y: 100,
        width: 300,
        height: 200,
        src: file_url,
      };
      saveToHistory();
      updateCurrentSlide({ elements: [...currentSlide.elements, newImage] });
      setSelectedElement(newImage.id);
      toast.success('Image ajoutée !');
    } catch {
      toast.error('Erreur lors de l\'import de l\'image');
    } finally {
      setUploadingImage(false);
      if (imageInputRef.current) imageInputRef.current.value = '';
    }
  };

  const handleExport = (format) => {
    toast.info(`Export ${format.toUpperCase()} disponible prochainement`);
  };

  const handleShare = async () => {
    if (!shareEmail.trim() || !file) return;
    try {
      const currentShared = file.shared_with || [];
      await base44.entities.CloudFile.update(file.id, {
        shared_with: [...currentShared, shareEmail.trim()]
      });
      setShareDialog(false);
      setShareEmail('');
      toast.success('Présentation partagée');
    } catch (e) {
      toast.error('Erreur lors du partage');
    }
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  // Presentation mode
  if (isPresenting) {
    return (
      <div 
        className="fixed inset-0 z-50 bg-black"
        onClick={() => {
          if (currentSlideIndex < slides.length - 1) {
            setCurrentSlideIndex(currentSlideIndex + 1);
          }
        }}
      >
        <button
          onClick={(e) => { e.stopPropagation(); setIsPresenting(false); }}
          className="absolute top-4 right-4 z-50 p-2 bg-black/50 rounded-full text-white hover:bg-black/70 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
        <div 
          className="w-full h-full transition-opacity duration-500"
          key={currentSlideIndex}
          style={{ animation: 'fadeIn 0.5s ease-in-out' }}
        >
          <SlideCanvas
            slide={slides[currentSlideIndex]}
            isPresenting={true}
            selectedElement={null}
            onElementSelect={() => {}}
            onElementUpdate={() => {}}
            onElementDelete={() => {}}
          />
        </div>
        {/* Navigation dots */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2" onClick={(e) => e.stopPropagation()}>
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlideIndex(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlideIndex ? 'bg-white scale-125' : 'bg-white/50 hover:bg-white/70'
              }`}
            />
          ))}
        </div>
        <style>{`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateX(50px); }
            to { opacity: 1; transform: translateX(0); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <AppAccessCheck appType="presentation">
      <div className="h-screen flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-4">
        <button onClick={() => navigate('/Dashboard')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
            <Presentation className="w-6 h-6 text-white" />
          </div>
          <div>
            {isEditing ? (
              <Input
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                onBlur={() => setIsEditing(false)}
                onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
                className="h-7 text-lg font-semibold border-orange-500"
                autoFocus
              />
            ) : (
              <h1 
                className="text-lg font-semibold cursor-pointer hover:text-orange-600 transition-colors"
                onClick={() => setIsEditing(true)}
              >
                {fileName}
              </h1>
            )}
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <SaveStatus status={autoSave.status} lastSaved={autoSave.lastSaved} />
            </div>
          </div>
          <Button
            onClick={() => setShowComments(true)}
            variant="ghost"
            size="sm"
            className="ml-auto gap-2 text-xs md:text-sm flex-shrink-0"
            title="Commentaires"
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden md:inline">Commentaires</span>
          </Button>
        </div>
      </div>

      {/* Toolbar — hidden in view mode */}
      {canEdit && (
        <SliderToolbar 
          onCommand={handleCommand}
          onSave={savePresentation}
          onExport={handleExport}
          onShare={() => setShareDialog(true)}
          onPresent={() => setIsPresenting(true)}
          saving={autoSave.status === 'saving'}
          selectedElement={selectedElement}
          currentSlide={slides[currentSlideIndex]}
        />
      )}

      {/* Main Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Thumbnails - hide on mobile */}
        {!isMobile && (
          <SlideThumbnails
            slides={slides}
            currentSlideIndex={currentSlideIndex}
            onSlideSelect={setCurrentSlideIndex}
            onAddSlide={() => handleCommand('addSlide')}
            onDuplicateSlide={(index) => {
              setCurrentSlideIndex(index);
              handleCommand('duplicateSlide');
            }}
            onDeleteSlide={(index) => {
              setCurrentSlideIndex(index);
              handleCommand('deleteSlide');
            }}
          />
        )}

        {/* Canvas */}
        <SlideCanvas
          slide={slides[currentSlideIndex]}
          onElementSelect={canEdit ? setSelectedElement : () => {}}
          onElementUpdate={canEdit ? handleElementUpdate : () => {}}
          onElementDelete={canEdit ? handleElementDelete : () => {}}
          selectedElement={canEdit ? selectedElement : null}
          readOnly={!canEdit}
        />
      </div>

      {/* Hidden image input */}
      <input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />

      {/* Share Dialog */}
      <Dialog open={shareDialog} onOpenChange={setShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Partager "{fileName}"</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Adresse email"
            type="email"
            value={shareEmail}
            onChange={(e) => setShareEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleShare()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleShare}>Partager</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {showComments && (
        <CommentsPanel fileId={fileId} user={user} onClose={() => setShowComments(false)} />
      )}
      <AIAssistant systemContext="Tu es dans Mykel Sliders (présentations). Tu aides à créer du contenu pour des diapositives, structurer des présentations, rédiger des textes percutants et donner des conseils de design." fileId={fileId} />
      <AnnouncementModal target="app" targetApp="MykelSliders" />
      </div>
    </AppAccessCheck>
  );
}