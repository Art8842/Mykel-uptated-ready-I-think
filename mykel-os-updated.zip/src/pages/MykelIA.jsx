import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia, freeGenerateImage } from '@/lib/freeCore';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sparkles, Send, User, Trash2, Plus, Menu, X, Paperclip, Loader2, Image as ImageIcon } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import AppAccessCheck from '@/components/drive/AppAccessCheck';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import { toast } from 'sonner';
import { callAIText } from '@/components/utils/aiClient';

const STORAGE_KEY = 'mykel_ia_conversations';

const loadSavedConversations = () => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.length > 0) return parsed;
    }
  } catch {}
  return [{ id: Date.now(), title: 'Nouvelle conversation', messages: [] }];
};

// ── Image Generation Animation ──
function ImageGenAnimation() {
  return (
    <div className="flex flex-col items-center gap-4 py-8 animate-zoom-in">
      <div className="relative w-24 h-24">
        {/* Pulsing rings */}
        <div className="absolute inset-0 rounded-full border-2 border-green-500/30 animate-ping" />
        <div className="absolute inset-2 rounded-full border-2 border-green-500/50 animate-pulse" />
        <div className="absolute inset-4 rounded-full border-2 border-green-400/70 animate-pulse" style={{ animationDelay: '0.2s' }} />
        {/* Center sparkle */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Sparkles className="w-8 h-8 text-green-400 animate-bounce" style={{ animationDuration: '1s' }} />
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="text-green-400 text-sm font-medium">Génération de l'image</span>
        <span className="flex gap-0.5">
          <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0s', animationDuration: '0.6s' }} />
          <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s', animationDuration: '0.6s' }} />
          <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s', animationDuration: '0.6s' }} />
        </span>
      </div>
      {/* Shimmer bar */}
      <div className="w-48 h-1.5 bg-white/10 rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-transparent via-green-400 to-transparent animate-pulse" style={{ width: '100%' }} />
      </div>
    </div>
  );
}

// ── Auto-expanding textarea ──
function AutoTextarea({ value, onChange, onSend, placeholder, disabled }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    const newH = Math.min(el.scrollHeight, 7 * 24); // ~7 lines max
    el.style.height = newH + 'px';
    el.style.overflowY = el.scrollHeight > 7 * 24 ? 'auto' : 'hidden';
  }, [value]);
  return (
    <textarea
      ref={ref}
      value={value}
      onChange={e => onChange(e.target.value)}
      onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend(); } }}
      placeholder={placeholder}
      disabled={disabled}
      rows={1}
      className="flex-1 bg-white/10 border border-white/20 rounded-2xl px-4 py-2.5 text-white placeholder:text-white/40 focus:border-green-500 focus:outline-none resize-none text-sm leading-relaxed"
      style={{ fontSize: '16px', maxHeight: '168px' }}
    />
  );
}

export default function MykelIA() {
  const navigate = useNavigate();
  const [conversations, setConversations] = useState(loadSavedConversations);
  const [activeConvId, setActiveConvId] = useState(() => loadSavedConversations()[0]?.id || null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [generatingImage, setGeneratingImage] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const scrollRef = useRef(null);

  const activeConv = conversations.find(c => c.id === activeConvId) || conversations[0];
  const hasMessages = (activeConv?.messages || []).length > 0;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [activeConv?.messages, loading, generatingImage]);

  const handleFileAttach = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploadingFile(true);
    try {
      const uploaded = await Promise.all(files.map(async (file) => {
        const { file_url } = await uploadMedia(file);
        return { name: file.name, url: file_url };
      }));
      setAttachedFiles(prev => [...prev, ...uploaded]);
    } catch {
      toast.error('Erreur lors de l\'envoi du fichier');
    } finally {
      setUploadingFile(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const isImageRequest = (text) => {
    const lower = text.toLowerCase().trim();
    const imageKeywords = ['génère', 'genere', 'génère-moi', 'générer', 'génère une', 'génère un',
      'crée une image', 'cree une image', 'créer une image',
      'dessine', 'dessiner', 'imagine', 'illustration', 'illustrer',
      'génère une image', 'génère une image de', 'génère moi une image',
      'fais une image', 'fais un dessin', 'fais une illustration',
      'montre une image', 'montre-moi une image',
      'generate image', 'create image', 'generate a', 'draw a', 'draw me',
      'generate an image', 'create an image', 'make an image', 'make a picture',
      'picture of', 'image of', 'image de', 'photo de', 'render',
      'génère une photo', 'crée un visuel', 'fais un visuel',
      'génère le logo', 'génère un logo', 'crée un logo',
      'génère un avatar', 'génère une thumbnail',
      'dall-e', 'dalle', 'midjourney', 'stable diffusion'];
    const hasImageWord = lower.includes('image') || lower.includes('dessin') || lower.includes('photo') ||
      lower.includes('visuel') || lower.includes('logo') || lower.includes('avatar') ||
      lower.includes('illustration') || lower.includes('picture') || lower.includes('drawing');
    const hasActionWord = lower.includes('génère') || lower.includes('genere') || lower.includes('crée') ||
      lower.includes('cree') || lower.includes('fais') || lower.includes('dessine') || lower.includes('imagine') ||
      lower.includes('montre') || lower.includes('générer') || lower.includes('créer') ||
      lower.includes('generate') || lower.includes('create') || lower.includes('draw') || lower.includes('make');
    return imageKeywords.some(k => lower.includes(k)) || (hasImageWord && hasActionWord);
  };

  const sendMessage = async () => {
    if ((!input.trim() && attachedFiles.length === 0) || loading) return;
    const userText = input.trim() || (attachedFiles.length > 0 ? `Analyse ces fichiers : ${attachedFiles.map(f => f.name).join(', ')}` : '');
    const fileUrls = attachedFiles.map(f => f.url);
    const fileNames = attachedFiles.map(f => f.name);
    setInput('');
    setAttachedFiles([]);

    const userMsg = { role: 'user', content: userText, file_urls: fileUrls, file_names: fileNames };
    updateConv(activeConv.id, msgs => [...msgs, userMsg]);
    setLoading(true);

    try {
      if (isImageRequest(userText) && fileUrls.length === 0) {
        setGeneratingImage(true);
        setLoading(false);
        try {
          const imagePrompt = userText.length > 10 ? userText : `Generate an image: ${userText}`;
          const result = await freeGenerateImage({ prompt: imagePrompt });
          const imgUrl = result?.url || result;
          if (!imgUrl) throw new Error("URL manquante");
          setGeneratingImage(false);
          updateConv(activeConv.id, msgs => [...msgs, { role: "assistant", content: `Voici l'image générée pour : "${userText}"`, image_url: imgUrl }]);
        } catch (imgErr) {
          setGeneratingImage(false);
          setLoading(true);
          const history = [...activeConv.messages, userMsg];
          const prompt = `Tu es Mykel IA, un assistant intelligent intégré dans Mykel Cloud. Tu réponds en français.\n\nL'utilisateur a demandé de générer une image avec: "${userText}"\nMalheureusement, la génération d'image a échoué (erreur technique). Explique poliment à l'utilisateur que la génération d'image a temporairement échoué et propose-lui de réessayer ou de reformuler sa demande.\n\nHistorique:\n${history.map(m => `${m.role === 'user' ? 'Utilisateur' : 'Mykel IA'}: ${m.content}`).join('\n')}\n\nRéponds maintenant:`;
          const response = await callAIText(prompt);
          updateConv(activeConv.id, msgs => [...msgs, { role: 'assistant', content: response }]);
        }
      } else {
        const history = [...activeConv.messages, userMsg];
        let updatesContext = "";
        try {
          const updates = await base44.entities.PlatformUpdate.filter({ active: true });
          if (updates.length > 0) {
            const sorted = updates.sort((a, b) => new Date(b.validated_at || 0) - new Date(a.validated_at || 0));
            const updatesText = sorted.map(u =>
              `${u.version ? `v${u.version} — ` : ""}${u.summary}\n${(u.features || []).map(f => `  • ${f}`).join("\n")}`
            ).join("\n\n");
            updatesContext = `\n\n--- Mises à jour de la plateforme Mykel ---\n${updatesText}\n--- Fin des mises à jour ---\n\nSi l'utilisateur demande ce qu'apporte une mise à jour ou ce qui a changé récemment, utilise ces informations pour répondre précisément.`;
          }
        } catch {}
        const prompt = `Tu es Mykel IA, un assistant intelligent intégré dans Mykel Cloud. Tu réponds en français et de manière utile et claire.${updatesContext}\n\nHistorique:\n${history.map(m => `${m.role === 'user' ? 'Utilisateur' : 'Mykel IA'}: ${m.content}`).join('\n')}\n\nRéponds maintenant:`;
        const response = await callAIText(prompt);
        updateConv(activeConv.id, msgs => [...msgs, { role: 'assistant', content: response }]);
      }

      if (activeConv.messages.length === 0) {
        setConversations(prev => prev.map(c =>
          c.id === activeConv.id ? { ...c, title: userText.slice(0, 40) + (userText.length > 40 ? '...' : '') } : c
        ));
      }
    } catch (e) {
      updateConv(activeConv.id, msgs => [...msgs, { role: 'assistant', content: "Désolé, une erreur s'est produite." }]);
    } finally {
      setLoading(false);
      setGeneratingImage(false);
    }
  };

  const updateConv = (id, updater) => {
    setConversations(prev => prev.map(c => c.id === id ? { ...c, messages: updater(c.messages) } : c));
  };

  const newConversation = () => {
    const newConv = { id: Date.now(), title: 'Nouvelle conversation', messages: [] };
    setConversations(prev => [newConv, ...prev]);
    setActiveConvId(newConv.id);
    setSidebarOpen(false);
  };

  const deleteConversation = (id) => {
    setConversations(prev => {
      const next = prev.filter(c => c.id !== id);
      if (next.length === 0) {
        const fresh = { id: Date.now(), title: 'Nouvelle conversation', messages: [] };
        setActiveConvId(fresh.id);
        return [fresh];
      }
      if (activeConvId === id) setActiveConvId(next[0].id);
      return next;
    });
  };

  const selectConv = (id) => {
    setActiveConvId(id);
    setSidebarOpen(false);
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-gray-900">
      <div className="p-4 border-b border-white/10 flex items-center gap-3">
        <div className="flex items-center gap-2 flex-1">
          <div className="w-7 h-7 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-sm text-white">Mykel IA</span>
        </div>
        <button onClick={() => setSidebarOpen(false)} className="text-white/50 hover:text-white md:hidden">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="p-3">
        <Button onClick={newConversation} className="w-full bg-green-600 hover:bg-green-700 text-white gap-2 text-sm">
          <Plus className="w-4 h-4" />
          Nouvelle conversation
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto px-2 space-y-1">
        {conversations.map(conv => (
          <div
            key={conv.id}
            className={`group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-all ${
              activeConvId === conv.id ? 'bg-green-600/20 text-green-300' : 'hover:bg-white/5 text-white/70'
            }`}
            onClick={() => selectConv(conv.id)}
          >
            <span className="flex-1 text-sm truncate">{conv.title}</span>
            <button
              onClick={e => { e.stopPropagation(); deleteConversation(conv.id); }}
              className="opacity-0 group-hover:opacity-100 text-white/40 hover:text-red-400 transition-all flex-shrink-0"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <AppAccessCheck appType="ia_premium">
      <div className="flex h-screen bg-gray-950 text-white overflow-hidden">

        {sidebarOpen && (
          <div className="fixed inset-0 z-40 md:hidden">
            <div className="absolute inset-0 bg-black/60" onClick={() => setSidebarOpen(false)} />
            <div className="absolute left-0 top-0 bottom-0 w-72 z-50">
              <SidebarContent />
            </div>
          </div>
        )}

        <div className="hidden md:flex w-64 flex-col flex-shrink-0">
          <div className="flex items-center gap-2 p-4 border-b border-white/10">
            <Button variant="ghost" size="icon" onClick={() => navigate('/Dashboard')} className="text-white hover:bg-white/10 flex-shrink-0">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </div>
          <SidebarContent />
        </div>

        <div className="flex-1 flex flex-col min-w-0">
          {/* Mobile header */}
          <div className="flex items-center gap-3 p-3 border-b border-white/10 md:hidden flex-shrink-0">
            <Button variant="ghost" size="icon" onClick={() => navigate('/Dashboard')} className="text-white hover:bg-white/10 flex-shrink-0">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <button onClick={() => setSidebarOpen(true)} className="text-white hover:bg-white/10 p-2 rounded-lg">
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 flex-1">
              <div className="w-6 h-6 bg-gradient-to-br from-green-500 to-emerald-600 rounded-md flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-white" />
              </div>
              <span className="font-semibold text-sm truncate">{activeConv?.title || 'Mykel IA'}</span>
            </div>
          </div>

          {/* Messages area OR centered input */}
          {hasMessages ? (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 md:space-y-6">
                {activeConv?.messages.map((msg, i) => (
                  <div key={i} className={`flex gap-2 md:gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-up`}>
                    {msg.role === 'assistant' && (
                      <div className="w-7 h-7 md:w-8 md:h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <Sparkles className="w-3 h-3 md:w-4 md:h-4 text-white" />
                      </div>
                    )}
                    <div className={`max-w-[85%] md:max-w-2xl rounded-2xl px-3 py-2 md:px-4 md:py-3 text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-green-600 text-white'
                        : 'bg-white/10 text-white/90'
                    }`}>
                      {msg.file_names?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-1.5">
                          {msg.file_names.map((name, fi) => (
                            <div key={fi} className="flex items-center gap-1 text-white/80 bg-white/10 rounded-lg px-2 py-1 text-xs">
                              <Paperclip className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate max-w-[120px]">{name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {msg.role === 'assistant' ? (
                        <>
                          <ReactMarkdown className="prose prose-invert prose-sm max-w-none">{msg.content}</ReactMarkdown>
                          {msg.image_url && (
                            <img src={msg.image_url} alt="Image générée" className="mt-2 rounded-xl max-w-full max-h-80 object-contain animate-zoom-in" />
                          )}
                        </>
                      ) : msg.content}
                    </div>
                    {msg.role === 'user' && (
                      <div className="w-7 h-7 md:w-8 md:h-8 bg-white/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <User className="w-3 h-3 md:w-4 md:h-4 text-white/70" />
                      </div>
                    )}
                  </div>
                ))}
                {generatingImage && (
                  <div className="flex justify-start">
                    <div className="bg-white/10 rounded-2xl px-4 py-2">
                      <ImageGenAnimation />
                    </div>
                  </div>
                )}
                {loading && !generatingImage && (
                  <div className="flex gap-3 items-center">
                    <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-white/10 rounded-2xl px-5 py-3">
                      <div className="flex gap-1.5">
                        <span className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                        <span className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }} />
                        <span className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }} />
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Bottom input bar */}
              <div className="p-3 md:p-4 border-t border-white/10 flex-shrink-0">
                <div className="max-w-4xl mx-auto">
                  {attachedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-2">
                      {attachedFiles.map((f, i) => (
                        <div key={i} className="flex items-center gap-2 bg-white/10 rounded-lg px-3 py-1.5 text-sm text-white/80">
                          <Paperclip className="w-3 h-3 text-green-400 flex-shrink-0" />
                          <span className="truncate max-w-[140px]">{f.name}</span>
                          <button onClick={() => setAttachedFiles(prev => prev.filter((_, idx) => idx !== i))} className="text-white/40 hover:text-white">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2 items-end">
                    <input ref={fileInputRef} type="file" onChange={handleFileAttach} className="hidden" multiple />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploadingFile}
                      className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-2xl bg-white/10 hover:bg-white/20 text-white/60 hover:text-white transition-all"
                      title="Joindre un fichier"
                    >
                      {uploadingFile ? <Loader2 className="w-4 h-4 animate-spin" /> : <Paperclip className="w-4 h-4" />}
                    </button>
                    <AutoTextarea
                      value={input}
                      onChange={setInput}
                      onSend={sendMessage}
                      placeholder="Posez une question supplémentaire..."
                      disabled={loading || generatingImage}
                    />
                    <button
                      onClick={sendMessage}
                      disabled={loading || generatingImage || (!input.trim() && attachedFiles.length === 0)}
                      className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-2xl bg-green-600 hover:bg-green-700 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* Centered welcome + input (ChatGPT style) */
            <div className="flex-1 flex flex-col items-center justify-center px-4">
              <div className="w-full max-w-2xl flex flex-col items-center">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-3xl flex items-center justify-center mb-6 shadow-2xl shadow-green-500/20 animate-zoom-in">
                  <Sparkles className="w-8 h-8 md:w-10 md:h-10 text-white" />
                </div>
                <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">Mykel IA</h1>
                <p className="text-white/40 text-sm md:text-base mb-8 text-center">Posez-moi n'importe quelle question, je suis là pour vous aider.</p>

                <div className="w-full">
                  {attachedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-2">
                      {attachedFiles.map((f, i) => (
                        <div key={i} className="flex items-center gap-2 bg-white/10 rounded-lg px-3 py-1.5 text-sm text-white/80">
                          <Paperclip className="w-3 h-3 text-green-400 flex-shrink-0" />
                          <span className="truncate max-w-[140px]">{f.name}</span>
                          <button onClick={() => setAttachedFiles(prev => prev.filter((_, idx) => idx !== i))} className="text-white/40 hover:text-white">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2 items-end">
                    <input ref={fileInputRef} type="file" onChange={handleFileAttach} className="hidden" multiple />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploadingFile}
                      className="flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-2xl bg-white/10 hover:bg-white/20 text-white/60 hover:text-white transition-all"
                      title="Joindre un fichier"
                    >
                      {uploadingFile ? <Loader2 className="w-5 h-5 animate-spin" /> : <Paperclip className="w-5 h-5" />}
                    </button>
                    <AutoTextarea
                      value={input}
                      onChange={setInput}
                      onSend={sendMessage}
                      placeholder="Posez votre question..."
                      disabled={loading || generatingImage}
                    />
                    <button
                      onClick={sendMessage}
                      disabled={loading || generatingImage || (!input.trim() && attachedFiles.length === 0)}
                      className="flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-2xl bg-green-600 hover:bg-green-700 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                    >
                      {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Suggestion chips */}
                <div className="flex flex-wrap gap-2 mt-6 justify-center">
                  {['Explique-moi un concept', 'Génère une image', 'Aide-moi à rédiger', 'Résous un problème'].map(s => (
                    <button
                      key={s}
                      onClick={() => setInput(s)}
                      className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white text-sm transition-all"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <AnnouncementModal target="app" targetApp="MykelIA" />
    </AppAccessCheck>
  );
}