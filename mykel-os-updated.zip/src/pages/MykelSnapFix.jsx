import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { uploadMedia, freeGenerateImage } from '@/lib/freeCore';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import {
  ArrowLeft, Upload, Download, ZoomIn, ZoomOut, RotateCcw, RotateCw,
  Crop, Layers, Wand2, Sun, Contrast, Droplets, Palette, Eraser, Minus,
  Move, Eye, EyeOff, Undo2, Redo2, Sparkles, Image as ImageIcon,
  FlipHorizontal, FlipVertical, Save, Loader2, PenTool, Circle,
  Square, Triangle, Type, Filter, Sliders, ChevronRight, ChevronLeft,
  X, Check, Scissors, Maximize2
} from 'lucide-react';
import { toast } from 'sonner';
import AILoader from '@/components/shared/AILoader';

// ── Helpers ──────────────────────────────────────────────────────────────────
const TOOLS = [
  { id: 'select', label: 'Sélection', icon: Move },
  { id: 'crop', label: 'Recadrer', icon: Crop },
  { id: 'brush', label: 'Pinceau', icon: PenTool },
  { id: 'eraser', label: 'Gomme', icon: Eraser },
  { id: 'text', label: 'Texte', icon: Type },
  { id: 'shapes', label: 'Formes', icon: Square },
  { id: 'magic_eraser', label: 'Gomme IA', icon: Wand2 },
  { id: 'remove_bg', label: 'Suppr. fond', icon: Layers },
];

const FILTERS = [
  { id: 'none', label: 'Original' },
  { id: 'vivid', label: 'Vivid' },
  { id: 'noir', label: 'Noir & Blanc' },
  { id: 'vintage', label: 'Vintage' },
  { id: 'cool', label: 'Cool' },
  { id: 'warm', label: 'Chaud' },
  { id: 'fade', label: 'Fade' },
  { id: 'dramatic', label: 'Drama' },
];

const BLEND_MODES = ['normal','multiply','screen','overlay','darken','lighten','color-dodge','color-burn','hard-light','soft-light'];

const RAINBOW_COLORS = ['#ff0000','#ff7700','#ffff00','#00ff00','#00ffff','#0000ff','#8800ff','#ff00ff'];

// ── Main Component ────────────────────────────────────────────────────────────
export default function MykelSnapFix() {
  const navigate = useNavigate();
  const canvasRef = useRef(null);
  const overlayCanvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const textInputRef = useRef(null);

  // Image state
  const [image, setImage] = useState(null); // HTMLImageElement
  const [imageUrl, setImageUrl] = useState(null);
  const [fileName, setFileName] = useState('image.png');

  // Editor state
  const [activeTool, setActiveTool] = useState('select');
  const [activePanel, setActivePanel] = useState('tools'); // tools | adjust | filters | layers | ai
  const [panelOpen, setPanelOpen] = useState(true);

  // Adjustments
  const [adjustments, setAdjustments] = useState({
    brightness: 0, contrast: 0, saturation: 0, sharpness: 0,
    exposure: 0, highlights: 0, shadows: 0, temperature: 0,
    hue: 0, blur: 0, vignette: 0, grain: 0
  });

  // Transform
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [zoom, setZoom] = useState(1);

  // Filter
  const [activeFilter, setActiveFilter] = useState('none');

  // Layers
  const [layers, setLayers] = useState([]);
  const [activeLayer, setActiveLayer] = useState(0);

  // Brush
  const [brushSize, setBrushSize] = useState(20);
  const [brushColor, setBrushColor] = useState('#ffffff');
  const [brushOpacity, setBrushOpacity] = useState(100);
  const [isDrawing, setIsDrawing] = useState(false);

  // Magic Eraser / selection mask
  const [maskPoints, setMaskPoints] = useState([]);
  const [maskColorIdx, setMaskColorIdx] = useState(0);

  // Text
  const [textContent, setTextContent] = useState('');
  const [fontSize, setFontSize] = useState(32);
  const [fontColor, setFontColor] = useState('#ffffff');

  // History
  const [history, setHistory] = useState([]);
  const [historyIdx, setHistoryIdx] = useState(-1);

  // AI operations
  const [aiProcessing, setAiProcessing] = useState(false);
  const [aiLabel, setAiLabel] = useState('');

  // Crop
  const [cropMode, setCropMode] = useState(false);
  const [cropStart, setCropStart] = useState(null);
  const [cropEnd, setCropEnd] = useState(null);

  // ── Load image ──
  const loadImageFromUrl = useCallback((url, name = 'image.png') => {
    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setImage(img);
      setFileName(name);
      setHistory([url]);
      setHistoryIdx(0);
      setAdjustments({ brightness: 0, contrast: 0, saturation: 0, sharpness: 0, exposure: 0, highlights: 0, shadows: 0, temperature: 0, hue: 0, blur: 0, vignette: 0, grain: 0 });
      setRotation(0); setFlipH(false); setFlipV(false); setZoom(1);
      setActiveFilter('none'); setMaskPoints([]);
      setLayers([{ id: 'base', name: 'Calque de base', visible: true, opacity: 100, blendMode: 'normal', data: null }]);
    };
    img.src = url;
    setImageUrl(url);
  }, []);

  // Check for URL params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const url = params.get('url');
    const name = params.get('name') || 'image.png';
    const tool = params.get('tool');
    if (url) loadImageFromUrl(decodeURIComponent(url), name);
    if (tool && TOOLS.find(t => t.id === tool)) {
      setActiveTool(tool);
      if (tool === 'magic_eraser') setMaskPoints([]);
    }
  }, []);

  // ── Render to canvas ──
  useEffect(() => {
    if (!image || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;

    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    if (flipH) ctx.scale(-1, 1);
    if (flipV) ctx.scale(1, -1);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.drawImage(image, -image.naturalWidth / 2, -image.naturalHeight / 2);
    ctx.restore();

    applyAdjustments(ctx, canvas);
    applyFilter(ctx, canvas);
    applyVignette(ctx, canvas);
    applyGrain(ctx, canvas);
  }, [image, adjustments, rotation, flipH, flipV, activeFilter]);

  const applyAdjustments = (ctx, canvas) => {
    const { brightness, contrast, saturation, temperature, hue } = adjustments;
    const filters = [];
    if (brightness) filters.push(`brightness(${1 + brightness / 100})`);
    if (contrast) filters.push(`contrast(${1 + contrast / 100})`);
    if (saturation) filters.push(`saturate(${1 + saturation / 100})`);
    if (hue) filters.push(`hue-rotate(${hue}deg)`);
    if (adjustments.blur) filters.push(`blur(${adjustments.blur * 0.5}px)`);
    if (temperature > 0) filters.push(`sepia(${temperature / 200})`);

    if (filters.length > 0) {
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      ctx.filter = filters.join(' ');
      ctx.putImageData(imgData, 0, 0);
      const tmp = document.createElement('canvas');
      tmp.width = canvas.width; tmp.height = canvas.height;
      const t2 = tmp.getContext('2d');
      t2.filter = filters.join(' ');
      t2.drawImage(canvas, 0, 0);
      ctx.filter = 'none';
      ctx.drawImage(tmp, 0, 0);
    }
  };

  const applyFilter = (ctx, canvas) => {
    const filterMap = {
      vivid: 'saturate(1.5) contrast(1.1)',
      noir: 'grayscale(1)',
      vintage: 'sepia(0.5) contrast(0.9) brightness(0.95)',
      cool: 'hue-rotate(180deg) saturate(0.8)',
      warm: 'sepia(0.3) saturate(1.2)',
      fade: 'brightness(1.1) contrast(0.85) saturate(0.8)',
      dramatic: 'contrast(1.3) saturate(0.8) brightness(0.9)',
    };
    if (activeFilter === 'none' || !filterMap[activeFilter]) return;
    const tmp = document.createElement('canvas');
    tmp.width = canvas.width; tmp.height = canvas.height;
    const t2 = tmp.getContext('2d');
    t2.filter = filterMap[activeFilter];
    t2.drawImage(canvas, 0, 0);
    ctx.drawImage(tmp, 0, 0);
  };

  const applyVignette = (ctx, canvas) => {
    if (!adjustments.vignette) return;
    const grd = ctx.createRadialGradient(canvas.width/2, canvas.height/2, canvas.width * 0.3, canvas.width/2, canvas.height/2, canvas.width * 0.8);
    grd.addColorStop(0, 'rgba(0,0,0,0)');
    grd.addColorStop(1, `rgba(0,0,0,${adjustments.vignette / 100})`);
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const applyGrain = (ctx, canvas) => {
    if (!adjustments.grain) return;
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = imgData.data;
    const intensity = adjustments.grain * 0.5;
    for (let i = 0; i < d.length; i += 4) {
      const noise = (Math.random() - 0.5) * intensity;
      d[i] += noise; d[i+1] += noise; d[i+2] += noise;
    }
    ctx.putImageData(imgData, 0, 0);
  };

  // ── Upload ──
  const handleUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => loadImageFromUrl(ev.target.result, file.name);
    reader.readAsDataURL(file);
  };

  // ── Save to cloud ──
  const handleSaveToCloud = async () => {
    if (!canvasRef.current) return;
    toast.info('Enregistrement dans le cloud...');
    try {
      const blob = await new Promise(res => canvasRef.current.toBlob(res, 'image/png'));
      const file = new File([blob], fileName.replace(/\.[^.]+$/, '') + '_snapfix.png', { type: 'image/png' });
      const { file_url } = await uploadMedia(file);
      // Check if CloudFile already exists for this session
      const existing = await base44.entities.CloudFile.filter({ name: fileName }).catch(() => []);
      if (existing.length > 0 && existing[0].content?.app === 'MykelSnapFix') {
        await base44.entities.CloudFile.update(existing[0].id, {
          name: fileName,
          content: { app: 'MykelSnapFix', snapfix_url: file_url },
          file_url,
        });
      } else {
        await base44.entities.CloudFile.create({
          name: 'Mykel SnapFix — ' + fileName,
          type: 'image',
          file_url,
          is_starred: false,
          is_trashed: false,
          content: { app: 'MykelSnapFix', snapfix_url: file_url },
        });
      }
      toast.success('Projet enregistré dans le cloud !');
    } catch {
      toast.error('Erreur lors de l\'enregistrement');
    }
  };

  // ── Download ──
  const handleDownload = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = fileName.replace(/\.[^.]+$/, '') + '_snapfix.png';
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
    toast.success('Image téléchargée !');
  };

  // ── History ──
  const pushHistory = () => {
    if (!canvasRef.current) return;
    const snap = canvasRef.current.toDataURL();
    const newHistory = history.slice(0, historyIdx + 1);
    newHistory.push(snap);
    setHistory(newHistory);
    setHistoryIdx(newHistory.length - 1);
  };

  const undo = () => {
    if (historyIdx <= 0) return;
    const idx = historyIdx - 1;
    setHistoryIdx(idx);
    loadImageFromUrl(history[idx]);
  };

  const redo = () => {
    if (historyIdx >= history.length - 1) return;
    const idx = historyIdx + 1;
    setHistoryIdx(idx);
    loadImageFromUrl(history[idx]);
  };

  // ── Magic Eraser (AI) ──
  const getOverlayPos = (e) => {
    const canvas = overlayCanvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const t = e.touches && e.touches[0];
    const cx = t ? t.clientX : e.clientX;
    const cy = t ? t.clientY : e.clientY;
    return { x: (cx - rect.left) * scaleX, y: (cy - rect.top) * scaleY };
  };

  const handleOverlayDown = (e) => {
    if (activeTool !== 'magic_eraser') return;
    if (e.cancelable) e.preventDefault();
    const pos = getOverlayPos(e);
    setMaskPoints([pos]);
  };

  const handleOverlayMove = (e) => {
    if (activeTool !== 'magic_eraser') return;
    if (e.buttons === 0 && !e.touches) return;
    if (e.cancelable) e.preventDefault();
    const pos = getOverlayPos(e);
    setMaskPoints(prev => [...prev, pos]);
  };

  // Native non-passive touch listeners for mobile — preventDefault actually works here
  const activeToolRef = useRef(activeTool);
  useEffect(() => { activeToolRef.current = activeTool; }, [activeTool]);

  useEffect(() => {
    const overlay = overlayCanvasRef.current;
    const main = canvasRef.current;
    if (!overlay && !main) return;

    const onTouchStart = (e) => {
      const tool = activeToolRef.current;
      if (tool === 'magic_eraser') {
        e.preventDefault();
        handleOverlayDown(e);
        if (cropMode) handleOverlayCrop(e);
      } else if (tool === 'brush' || tool === 'eraser') {
        e.preventDefault();
        handleCanvasDown(e);
      }
    };
    const onTouchMove = (e) => {
      const tool = activeToolRef.current;
      if (tool === 'magic_eraser') {
        e.preventDefault();
        handleOverlayMove(e);
        if (cropMode) handleOverlayCrop(e);
      } else if (tool === 'brush' || tool === 'eraser') {
        e.preventDefault();
        handleCanvasMove(e);
      }
    };
    const onTouchEnd = (e) => {
      handleCanvasUp(e);
    };

    if (overlay) {
      overlay.addEventListener('touchstart', onTouchStart, { passive: false });
      overlay.addEventListener('touchmove', onTouchMove, { passive: false });
      overlay.addEventListener('touchend', onTouchEnd, { passive: false });
    }
    if (main) {
      main.addEventListener('touchstart', onTouchStart, { passive: false });
      main.addEventListener('touchmove', onTouchMove, { passive: false });
      main.addEventListener('touchend', onTouchEnd, { passive: false });
    }
    return () => {
      if (overlay) {
        overlay.removeEventListener('touchstart', onTouchStart);
        overlay.removeEventListener('touchmove', onTouchMove);
        overlay.removeEventListener('touchend', onTouchEnd);
      }
      if (main) {
        main.removeEventListener('touchstart', onTouchStart);
        main.removeEventListener('touchmove', onTouchMove);
        main.removeEventListener('touchend', onTouchEnd);
      }
    };
  }, [cropMode]);

  // Draw mask on overlay — smooth continuous glowing stroke (Apple Intelligence style)
  useEffect(() => {
    if (!overlayCanvasRef.current) return;
    const canvas = overlayCanvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (maskPoints.length === 0) return;

    // Build a smooth path through all points using quadratic curves
    ctx.save();

    // Outer glow layer (wide, semi-transparent)
    ctx.beginPath();
    ctx.moveTo(maskPoints[0].x, maskPoints[0].y);
    for (let i = 1; i < maskPoints.length - 1; i++) {
      const midX = (maskPoints[i].x + maskPoints[i + 1].x) / 2;
      const midY = (maskPoints[i].y + maskPoints[i + 1].y) / 2;
      ctx.quadraticCurveTo(maskPoints[i].x, maskPoints[i].y, midX, midY);
    }
    if (maskPoints.length > 1) {
      const last = maskPoints[maskPoints.length - 1];
      ctx.lineTo(last.x, last.y);
    }

    // Glow shadow
    ctx.shadowColor = 'rgba(99, 179, 237, 0.8)';
    ctx.shadowBlur = 20;
    ctx.strokeStyle = 'rgba(147, 197, 253, 0.35)';
    ctx.lineWidth = 36;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();

    // Main stroke layer (solid, clean)
    ctx.shadowBlur = 0;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 14;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();

    // Inner accent (bright core)
    ctx.strokeStyle = 'rgba(219, 234, 254, 0.95)';
    ctx.lineWidth = 6;
    ctx.stroke();

    ctx.restore();
  }, [maskPoints]);

  const applyMagicEraser = async () => {
    if (maskPoints.length === 0) { toast.error('Sélectionnez d\'abord une zone à supprimer'); return; }
    setAiProcessing(true);
    setAiLabel('Suppression IA');
    try {
      const canvas = canvasRef.current;
      const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
      const file = new File([blob], 'img.png', { type: 'image/png' });
      const { file_url } = await uploadMedia(file);

      // Describe the mask area to AI
      const overlayW = overlayCanvasRef.current.width;
      const overlayH = overlayCanvasRef.current.height;
      const avgX = maskPoints.reduce((s, p) => s + p.x, 0) / maskPoints.length;
      const avgY = maskPoints.reduce((s, p) => s + p.y, 0) / maskPoints.length;
      const posDesc = `${avgX < overlayW/3 ? 'gauche' : avgX < 2*overlayW/3 ? 'centre' : 'droite'}, ${avgY < overlayH/3 ? 'haut' : avgY < 2*overlayH/3 ? 'milieu' : 'bas'}`;

      const result = await freeGenerateImage({
        prompt: `Remove the object located at the ${posDesc} of this image. Fill the area naturally with the surrounding background. Keep everything else identical. Inpainting task.`,
        existing_image_urls: [file_url]
      });

      loadImageFromUrl(result.url, fileName);
      setMaskPoints([]);
      toast.success('Objet supprimé avec succès !');
    } catch (e) {
      toast.error('Erreur lors de la suppression IA');
    } finally {
      setAiProcessing(false);
    }
  };

  // ── AI: Remove Background ──
  const handleRemoveBg = async () => {
    if (!canvasRef.current) return;
    setAiProcessing(true);
    setAiLabel('Suppression du fond');
    try {
      const canvas = canvasRef.current;
      const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
      const file = new File([blob], 'img.png', { type: 'image/png' });
      const { file_url } = await uploadMedia(file);
      const result = await freeGenerateImage({
        prompt: 'Remove the background of this image completely. Make the background fully transparent. Keep the subject sharp and well-defined.',
        existing_image_urls: [file_url]
      });
      loadImageFromUrl(result.url, fileName);
      toast.success('Fond supprimé !');
    } catch {
      toast.error('Erreur lors de la suppression du fond');
    } finally {
      setAiProcessing(false);
    }
  };

  // ── AI: Enhance ──
  const handleAiEnhance = async () => {
    if (!canvasRef.current) return;
    setAiProcessing(true);
    setAiLabel('Amélioration IA');
    try {
      const canvas = canvasRef.current;
      const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
      const file = new File([blob], 'img.png', { type: 'image/png' });
      const { file_url } = await uploadMedia(file);
      const result = await freeGenerateImage({
        prompt: 'Enhance this photo: improve sharpness, colors, lighting, and overall quality. Make it look professional and stunning.',
        existing_image_urls: [file_url]
      });
      loadImageFromUrl(result.url, fileName);
      toast.success('Image améliorée !');
    } catch {
      toast.error('Erreur lors de l\'amélioration');
    } finally {
      setAiProcessing(false);
    }
  };

  // ── AI: Generate variation ──
  const handleAiVariation = async (style) => {
    if (!canvasRef.current) return;
    setAiProcessing(true);
    setAiLabel(`Style: ${style}`);
    try {
      const canvas = canvasRef.current;
      const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
      const file = new File([blob], 'img.png', { type: 'image/png' });
      const { file_url } = await uploadMedia(file);
      const prompts = {
        cinematic: 'Transform this photo into a cinematic, film-quality image with dramatic lighting and color grading.',
        anime: 'Transform this photo into a high-quality anime style illustration.',
        watercolor: 'Transform this photo into a beautiful watercolor painting.',
        oil: 'Transform this photo into a classical oil painting.',
        vintage: 'Apply a vintage film photo effect with grain and warm tones.',
        neon: 'Apply a neon cyberpunk aesthetic with vivid glowing colors.',
      };
      const result = await freeGenerateImage({
        prompt: prompts[style] || `Apply ${style} artistic style to this image.`,
        existing_image_urls: [file_url]
      });
      loadImageFromUrl(result.url, fileName);
      toast.success(`Style ${style} appliqué !`);
    } catch {
      toast.error('Erreur lors du traitement IA');
    } finally {
      setAiProcessing(false);
    }
  };

  // ── Brush drawing ──
  const brushStart = useRef(false);
  const lastBrushPos = useRef(null);

  const handleCanvasDown = (e) => {
    if (activeTool !== 'brush' && activeTool !== 'eraser') return;
    if (e.cancelable) e.preventDefault();
    brushStart.current = true;
    const pos = getCanvasPos(e);
    lastBrushPos.current = pos;
  };

  const handleCanvasMove = (e) => {
    if (!brushStart.current) return;
    if (activeTool !== 'brush' && activeTool !== 'eraser') return;
    if (e.cancelable) e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pos = getCanvasPos(e);
    ctx.globalAlpha = brushOpacity / 100;
    ctx.strokeStyle = activeTool === 'eraser' ? '#000000' : brushColor;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.globalCompositeOperation = activeTool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.beginPath();
    ctx.moveTo(lastBrushPos.current.x, lastBrushPos.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    lastBrushPos.current = pos;
  };

  const handleCanvasUp = () => {
    if (brushStart.current) {
      brushStart.current = false;
      pushHistory();
    }
  };

  const getCanvasPos = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const t = e.touches && e.touches[0];
    const cx = t ? t.clientX : e.clientX;
    const cy = t ? t.clientY : e.clientY;
    return { x: (cx - rect.left) * scaleX, y: (cy - rect.top) * scaleY };
  };

  // ── Crop ──
  const handleCropApply = () => {
    if (!cropStart || !cropEnd || !canvasRef.current || !overlayCanvasRef.current) return;
    const canvas = canvasRef.current;
    const overlay = overlayCanvasRef.current;
    const rect = overlay.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = Math.min(cropStart.x, cropEnd.x) * scaleX;
    const y = Math.min(cropStart.y, cropEnd.y) * scaleY;
    const w = Math.abs(cropEnd.x - cropStart.x) * scaleX;
    const h = Math.abs(cropEnd.y - cropStart.y) * scaleY;
    if (w < 10 || h < 10) { toast.error('Zone trop petite'); return; }

    const tmp = document.createElement('canvas');
    tmp.width = w; tmp.height = h;
    tmp.getContext('2d').drawImage(canvas, x, y, w, h, 0, 0, w, h);
    loadImageFromUrl(tmp.toDataURL());
    setCropMode(false); setCropStart(null); setCropEnd(null);
    const ctx = overlay.getContext('2d');
    ctx.clearRect(0, 0, overlay.width, overlay.height);
  };

  const handleOverlayCrop = (e) => {
    if (!cropMode) return;
    if (e.cancelable) e.preventDefault();
    const rect = overlayCanvasRef.current.getBoundingClientRect();
    const t = e.touches && e.touches[0];
    const cx = t ? t.clientX : e.clientX;
    const cy = t ? t.clientY : e.clientY;
    const pos = { x: cx - rect.left, y: cy - rect.top };
    if (!cropStart) { setCropStart(pos); return; }
    setCropEnd(pos);
    // Draw crop box
    const canvas = overlayCanvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 3]);
    ctx.strokeRect(
      Math.min(cropStart.x, pos.x), Math.min(cropStart.y, pos.y),
      Math.abs(pos.x - cropStart.x), Math.abs(pos.y - cropStart.y)
    );
    ctx.setLineDash([]);
    // dim outside
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.fillRect(0, 0, canvas.width, Math.min(cropStart.y, pos.y));
    ctx.fillRect(0, Math.max(cropStart.y, pos.y), canvas.width, canvas.height);
    ctx.fillRect(0, Math.min(cropStart.y, pos.y), Math.min(cropStart.x, pos.x), Math.abs(pos.y - cropStart.y));
    ctx.fillRect(Math.max(cropStart.x, pos.x), Math.min(cropStart.y, pos.y), canvas.width, Math.abs(pos.y - cropStart.y));
  };

  const adjustList = [
    { key: 'brightness', label: 'Luminosité', icon: Sun, min: -100, max: 100 },
    { key: 'contrast', label: 'Contraste', icon: Contrast, min: -100, max: 100 },
    { key: 'saturation', label: 'Saturation', icon: Droplets, min: -100, max: 100 },
    { key: 'exposure', label: 'Exposition', icon: Sun, min: -100, max: 100 },
    { key: 'temperature', label: 'Température', icon: Palette, min: -100, max: 100 },
    { key: 'hue', label: 'Teinte', icon: Palette, min: -180, max: 180 },
    { key: 'highlights', label: 'Hautes lumières', icon: Sun, min: -100, max: 100 },
    { key: 'shadows', label: 'Ombres', icon: Sun, min: -100, max: 100 },
    { key: 'blur', label: 'Flou', icon: Filter, min: 0, max: 100 },
    { key: 'vignette', label: 'Vignettage', icon: Circle, min: 0, max: 100 },
    { key: 'grain', label: 'Grain', icon: Filter, min: 0, max: 100 },
    { key: 'sharpness', label: 'Netteté', icon: Maximize2, min: 0, max: 100 },
  ];

  if (!image && !imageUrl) {
    return (
      <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center gap-6 text-white">
        <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-violet-500/30">
          <Sparkles className="w-10 h-10 text-white" />
        </div>
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Mykel SnapFix</h1>
          <p className="text-white/50 max-w-xs">Éditeur photo professionnel avec IA — aussi puissant que Photoshop, directement dans votre navigateur.</p>
        </div>
        <div className="flex gap-4">
          <Button
            onClick={() => fileInputRef.current?.click()}
            className="bg-violet-600 hover:bg-violet-500 gap-2 text-lg px-6 py-5"
          >
            <Upload className="w-5 h-5" />
            Ouvrir une image
          </Button>
          <Button variant="outline" onClick={() => navigate('/Dashboard')} className="border-white/20 text-white hover:bg-white/10 gap-2 text-lg px-6 py-5">
            <ArrowLeft className="w-5 h-5" />
            Retour
          </Button>
        </div>
        <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleUpload} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col text-white select-none">
      {/* Top Bar */}
      <div className="h-12 bg-gray-900 border-b border-white/10 flex items-center gap-1 sm:gap-2 px-2 sm:px-3 z-20 overflow-x-auto flex-nowrap">
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-8 w-8" onClick={() => navigate('/Dashboard')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="w-6 h-6 bg-gradient-to-br from-violet-500 to-pink-500 rounded flex items-center justify-center">
          <Sparkles className="w-3 h-3 text-white" />
        </div>
        <span className="font-bold text-sm whitespace-nowrap">Mykel SnapFix</span>
        <span className="text-white/30 text-xs ml-1 truncate max-w-[80px] sm:max-w-[120px] flex-shrink-0">{fileName}</span>

        <div className="flex-1 min-w-0" />

        {/* History */}
        <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={undo} disabled={historyIdx <= 0}>
          <Undo2 className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={redo} disabled={historyIdx >= history.length - 1}>
          <Redo2 className="w-4 h-4" />
        </Button>

        {/* Zoom */}
        <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={() => setZoom(z => Math.max(0.1, z - 0.1))}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <span className="text-xs text-white/50 w-10 text-center">{Math.round(zoom * 100)}%</span>
        <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={() => setZoom(z => Math.min(5, z + 0.1))}>
          <ZoomIn className="w-4 h-4" />
        </Button>

        <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={() => fileInputRef.current?.click()}>
          <Upload className="w-4 h-4" />
        </Button>
        <Button onClick={handleSaveToCloud} className="bg-green-600 hover:bg-green-500 h-8 px-3 text-xs gap-1">
          <Save className="w-3 h-3" />
          Sauvegarder
        </Button>
        <Button onClick={handleDownload} className="bg-violet-600 hover:bg-violet-500 h-8 px-3 text-xs gap-1">
          <Download className="w-3 h-3" />
          Exporter
        </Button>
        <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleUpload} />
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Toolbar */}
        <div className="w-12 bg-gray-900 border-r border-white/10 flex flex-col items-center py-2 gap-1 z-10 overflow-y-auto">
          {TOOLS.map(tool => {
            const Icon = tool.icon;
            const active = activeTool === tool.id;
            return (
              <button
                key={tool.id}
                onClick={() => {
                  setActiveTool(tool.id);
                  if (tool.id === 'crop') { setCropMode(true); setCropStart(null); setCropEnd(null); }
                  else { setCropMode(false); }
                  if (tool.id === 'magic_eraser') setMaskPoints([]);
                }}
                title={tool.label}
                className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                  active ? 'bg-violet-600 text-white' : 'text-white/50 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
              </button>
            );
          })}

          <div className="flex-1" />

          {/* Flip / Rotate */}
          <button onClick={() => setFlipH(f => !f)} title="Miroir H" className="w-9 h-9 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white">
            <FlipHorizontal className="w-4 h-4" />
          </button>
          <button onClick={() => setFlipV(f => !f)} title="Miroir V" className="w-9 h-9 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white">
            <FlipVertical className="w-4 h-4" />
          </button>
          <button onClick={() => setRotation(r => r - 90)} title="Rotation -90°" className="w-9 h-9 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white">
            <RotateCcw className="w-4 h-4" />
          </button>
          <button onClick={() => setRotation(r => r + 90)} title="Rotation +90°" className="w-9 h-9 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white">
            <RotateCw className="w-4 h-4" />
          </button>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 bg-gray-800 overflow-auto relative flex items-center justify-center"
          style={{
            backgroundImage: 'repeating-conic-gradient(#666 0% 25%, #555 0% 50%)',
            backgroundSize: '20px 20px',
            touchAction: (activeTool === 'magic_eraser' || activeTool === 'brush' || activeTool === 'eraser') ? 'none' : 'auto',
            overscrollBehavior: 'none',
          }}
        >
          <div style={{ transform: `scale(${zoom})`, transformOrigin: 'center', position: 'relative' }}>
            <canvas
              ref={canvasRef}
              onMouseDown={handleCanvasDown}
              onMouseMove={handleCanvasMove}
              onMouseUp={handleCanvasUp}
              onTouchStart={handleCanvasDown}
              onTouchMove={handleCanvasMove}
              onTouchEnd={handleCanvasUp}
              style={{ display: 'block', maxWidth: '100%', cursor: activeTool === 'brush' || activeTool === 'eraser' ? 'crosshair' : 'default', touchAction: 'none' }}
            />
            <canvas
              ref={overlayCanvasRef}
              width={image?.naturalWidth || canvasRef.current?.width || 800}
              height={image?.naturalHeight || canvasRef.current?.height || 600}
              onMouseDown={(e) => { handleOverlayDown(e); if (cropMode) handleOverlayCrop(e); }}
              onMouseMove={(e) => { handleOverlayMove(e); if (cropMode) handleOverlayCrop(e); }}
              onTouchStart={(e) => { handleOverlayDown(e); if (cropMode) handleOverlayCrop(e); }}
              onTouchMove={(e) => { handleOverlayMove(e); if (cropMode) handleOverlayCrop(e); }}
              style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: activeTool === 'magic_eraser' || cropMode ? 'auto' : 'none', cursor: activeTool === 'magic_eraser' ? 'crosshair' : cropMode ? 'crosshair' : 'default', touchAction: 'none' }}
            />
          </div>

          {/* Magic Eraser Controls */}
          {activeTool === 'magic_eraser' && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 bg-gray-900/90 backdrop-blur rounded-xl p-3 border border-white/10">
              <p className="text-white/60 text-sm self-center">
                {maskPoints.length === 0 ? 'Dessinez sur l\'objet à supprimer' : `${maskPoints.length} points sélectionnés`}
              </p>
              {maskPoints.length > 0 && (
                <>
                  <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setMaskPoints([])}>
                    <X className="w-3 h-3 mr-1" />Effacer
                  </Button>
                  <Button size="sm" className="bg-violet-600 hover:bg-violet-500 gap-1" onClick={applyMagicEraser}>
                    <Wand2 className="w-3 h-3" />Supprimer
                  </Button>
                </>
              )}
            </div>
          )}

          {/* Crop Controls */}
          {cropMode && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 bg-gray-900/90 backdrop-blur rounded-xl p-3 border border-white/10">
              <p className="text-white/60 text-sm self-center">Cliquez pour définir la zone de recadrage</p>
              {cropEnd && (
                <Button size="sm" className="bg-green-600 hover:bg-green-500 gap-1" onClick={handleCropApply}>
                  <Check className="w-3 h-3" />Recadrer
                </Button>
              )}
              <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => { setCropMode(false); setCropStart(null); setCropEnd(null); setActiveTool('select'); const ctx = overlayCanvasRef.current?.getContext('2d'); if(ctx) ctx.clearRect(0,0,9999,9999); }}>
                Annuler
              </Button>
            </div>
          )}

          {/* AI Loading Overlay */}
          {aiProcessing && (
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center gap-4 z-20">
              <AILoader label={aiLabel} />
            </div>
          )}
        </div>

        {/* Right Panel — desktop sidebar */}
        <div className={`hidden md:flex bg-gray-900 border-l border-white/10 flex-col transition-all z-10 ${panelOpen ? 'w-72' : 'w-10'}`}>
          <button
            onClick={() => setPanelOpen(o => !o)}
            className="h-10 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/5 transition-colors border-b border-white/10"
          >
            {panelOpen ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>

          {panelOpen && (
            <>
              {/* Panel Tabs */}
              <div className="flex border-b border-white/10">
                {[
                  { id: 'tools', label: 'Outils', icon: Sliders },
                  { id: 'adjust', label: 'Réglages', icon: Sun },
                  { id: 'filters', label: 'Filtres', icon: Filter },
                  { id: 'ai', label: 'IA', icon: Sparkles },
                ].map(p => {
                  const Icon = p.icon;
                  return (
                    <button key={p.id} onClick={() => setActivePanel(p.id)}
                      className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[10px] transition-all ${activePanel === p.id ? 'text-violet-400 border-b-2 border-violet-400' : 'text-white/40 hover:text-white'}`}>
                      <Icon className="w-3.5 h-3.5" />
                      {p.label}
                    </button>
                  );
                })}
              </div>

              <div className="flex-1 overflow-y-auto p-3 space-y-3">
                {/* Tools Panel */}
                {activePanel === 'tools' && (
                  <div className="space-y-4">
                    {(activeTool === 'brush' || activeTool === 'eraser') && (
                      <>
                        <div>
                          <label className="text-white/60 text-xs block mb-2">Taille du pinceau: {brushSize}px</label>
                          <Slider value={[brushSize]} min={1} max={200} onValueChange={v => setBrushSize(v[0])} />
                        </div>
                        <div>
                          <label className="text-white/60 text-xs block mb-2">Opacité: {brushOpacity}%</label>
                          <Slider value={[brushOpacity]} min={1} max={100} onValueChange={v => setBrushOpacity(v[0])} />
                        </div>
                        {activeTool === 'brush' && (
                          <div>
                            <label className="text-white/60 text-xs block mb-2">Couleur</label>
                            <div className="grid grid-cols-8 gap-1 mb-2">
                              {['#ffffff','#000000','#ff0000','#00ff00','#0000ff','#ffff00','#ff00ff','#00ffff',
                                '#ff8800','#8800ff','#00ff88','#ff0088','#888888','#ff4444','#44ff44','#4444ff'].map(c => (
                                <button key={c} onClick={() => setBrushColor(c)}
                                  style={{ background: c }}
                                  className={`w-6 h-6 rounded border-2 transition-all ${brushColor === c ? 'border-white scale-110' : 'border-transparent'}`}
                                />
                              ))}
                            </div>
                            <input type="color" value={brushColor} onChange={e => setBrushColor(e.target.value)} className="w-full h-8 rounded cursor-pointer" />
                          </div>
                        )}
                      </>
                    )}
                    {activeTool === 'text' && (
                      <div className="space-y-3">
                        <div>
                          <label className="text-white/60 text-xs block mb-1">Texte</label>
                          <input
                            ref={textInputRef}
                            type="text"
                            value={textContent}
                            onChange={e => setTextContent(e.target.value)}
                            className="w-full bg-white/10 rounded px-2 py-1 text-sm text-white border border-white/20"
                            placeholder="Votre texte..."
                          />
                        </div>
                        <div>
                          <label className="text-white/60 text-xs block mb-1">Taille: {fontSize}px</label>
                          <Slider value={[fontSize]} min={8} max={200} onValueChange={v => setFontSize(v[0])} />
                        </div>
                        <div>
                          <label className="text-white/60 text-xs block mb-1">Couleur</label>
                          <input type="color" value={fontColor} onChange={e => setFontColor(e.target.value)} className="w-full h-8 rounded" />
                        </div>
                        <Button className="w-full bg-violet-600 hover:bg-violet-500 text-sm" onClick={() => {
                          if (!textContent || !canvasRef.current) return;
                          const ctx = canvasRef.current.getContext('2d');
                          ctx.font = `bold ${fontSize}px sans-serif`;
                          ctx.fillStyle = fontColor;
                          ctx.fillText(textContent, canvasRef.current.width / 2 - ctx.measureText(textContent).width / 2, canvasRef.current.height / 2);
                          pushHistory();
                          toast.success('Texte ajouté');
                        }}>
                          Ajouter le texte
                        </Button>
                      </div>
                    )}
                    {activeTool === 'select' && (
                      <div className="space-y-2">
                        <p className="text-white/40 text-xs">Transformations</p>
                        <div className="grid grid-cols-2 gap-2">
                          <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setRotation(r => r - 90)}>↺ -90°</Button>
                          <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setRotation(r => r + 90)}>↻ +90°</Button>
                          <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setFlipH(f => !f)}>⇄ Miroir H</Button>
                          <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setFlipV(f => !f)}>⇅ Miroir V</Button>
                        </div>
                        <div>
                          <label className="text-white/60 text-xs block mb-1">Rotation libre: {rotation}°</label>
                          <Slider value={[rotation]} min={-180} max={180} onValueChange={v => setRotation(v[0])} />
                        </div>
                      </div>
                    )}
                    {activeTool === 'magic_eraser' && (
                      <div className="space-y-2">
                        <div className="bg-violet-900/30 rounded-lg p-3 border border-violet-500/30">
                          <p className="text-violet-300 text-xs font-medium mb-1">🪄 Gomme Magique IA</p>
                          <p className="text-white/50 text-xs">Dessinez sur l'objet à supprimer avec votre souris. L'IA supprimera l'objet et reconstruira le fond naturellement.</p>
                        </div>
                        <div className="flex items-center gap-2 bg-white/5 rounded-lg p-2 border border-white/10">
                          <div className="w-6 h-1 rounded-full bg-gradient-to-r from-blue-300 via-white to-blue-300 shadow-[0_0_8px_rgba(147,197,253,0.8)]" />
                          <span className="text-white/40 text-xs">Style du tracé de sélection</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Adjustments Panel */}
                {activePanel === 'adjust' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-white/60 text-xs font-medium">Réglages fins</p>
                      <Button size="sm" variant="ghost" className="text-white/40 hover:text-white text-xs h-6"
                        onClick={() => setAdjustments({ brightness: 0, contrast: 0, saturation: 0, sharpness: 0, exposure: 0, highlights: 0, shadows: 0, temperature: 0, hue: 0, blur: 0, vignette: 0, grain: 0 })}>
                        Réinitialiser
                      </Button>
                    </div>
                    {adjustList.map(adj => {
                      const Icon = adj.icon;
                      return (
                        <div key={adj.key}>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-white/60 text-xs flex items-center gap-1">
                              <Icon className="w-3 h-3" />{adj.label}
                            </label>
                            <span className="text-white/40 text-xs">{adjustments[adj.key]}</span>
                          </div>
                          <Slider
                            value={[adjustments[adj.key]]}
                            min={adj.min}
                            max={adj.max}
                            onValueChange={v => setAdjustments(a => ({ ...a, [adj.key]: v[0] }))}
                          />
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Filters Panel */}
                {activePanel === 'filters' && (
                  <div className="space-y-2">
                    <p className="text-white/60 text-xs font-medium mb-2">Filtres photo</p>
                    <div className="grid grid-cols-2 gap-2">
                      {FILTERS.map(f => (
                        <button
                          key={f.id}
                          onClick={() => setActiveFilter(f.id)}
                          className={`p-2 rounded-lg border text-xs font-medium transition-all ${activeFilter === f.id ? 'border-violet-500 bg-violet-600/30 text-violet-300' : 'border-white/10 hover:border-white/30 text-white/60 hover:text-white'}`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* AI Panel */}
                {activePanel === 'ai' && (
                  <div className="space-y-3">
                    <p className="text-white/60 text-xs font-medium">Outils IA</p>

                    <button onClick={handleAiEnhance} disabled={aiProcessing}
                      className="w-full p-3 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white text-sm font-medium flex items-center gap-2 disabled:opacity-50">
                      <Sparkles className="w-4 h-4" />
                      Amélioration automatique
                    </button>

                    <button onClick={handleRemoveBg} disabled={aiProcessing}
                      className="w-full p-3 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white text-sm font-medium flex items-center gap-2 disabled:opacity-50">
                      <Layers className="w-4 h-4" />
                      Supprimer le fond
                    </button>

                    <div className="pt-2">
                      <p className="text-white/40 text-xs mb-2">Styles artistiques IA</p>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: 'cinematic', label: '🎬 Cinématique' },
                          { id: 'anime', label: '🎌 Anime' },
                          { id: 'watercolor', label: '🎨 Aquarelle' },
                          { id: 'oil', label: '🖼️ Huile' },
                          { id: 'vintage', label: '📷 Vintage' },
                          { id: 'neon', label: '💜 Néon' },
                        ].map(s => (
                          <button key={s.id} onClick={() => handleAiVariation(s.id)} disabled={aiProcessing}
                            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white/70 hover:text-white transition-all disabled:opacity-40">
                            {s.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {aiProcessing && (
                      <div className="flex items-center gap-2 p-3 bg-violet-900/30 rounded-xl border border-violet-500/30">
                        <Loader2 className="w-4 h-4 animate-spin text-violet-400" />
                        <span className="text-violet-300 text-sm">{aiLabel} en cours...</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Mobile floating panel toggle */}
        <button
          onClick={() => setPanelOpen(o => !o)}
          className="md:hidden fixed bottom-4 right-4 z-30 w-12 h-12 rounded-full bg-violet-600 text-white shadow-lg flex items-center justify-center"
        >
          {panelOpen ? <ChevronRight className="w-5 h-5" /> : <Sliders className="w-5 h-5" />}
        </button>

        {/* Right Panel — mobile bottom sheet */}
        {panelOpen && (
          <div className="md:hidden fixed bottom-0 left-0 right-0 max-h-[50vh] bg-gray-900 border-t border-white/10 flex flex-col z-30 rounded-t-2xl">
            <div className="flex border-b border-white/10">
              {[
                { id: 'tools', label: 'Outils', icon: Sliders },
                { id: 'adjust', label: 'Réglages', icon: Sun },
                { id: 'filters', label: 'Filtres', icon: Filter },
                { id: 'ai', label: 'IA', icon: Sparkles },
              ].map(p => {
                const Icon = p.icon;
                return (
                  <button key={p.id} onClick={() => setActivePanel(p.id)}
                    className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[10px] transition-all ${activePanel === p.id ? 'text-violet-400 border-b-2 border-violet-400' : 'text-white/40 hover:text-white'}`}>
                    <Icon className="w-3.5 h-3.5" />
                    {p.label}
                  </button>
                );
              })}
            </div>
            <div className="overflow-y-auto p-3 space-y-3 flex-1">
              {activePanel === 'tools' && (
                <div className="space-y-4">
                  {(activeTool === 'brush' || activeTool === 'eraser') && (
                    <>
                      <div>
                        <label className="text-white/60 text-xs block mb-2">Taille: {brushSize}px</label>
                        <Slider value={[brushSize]} min={1} max={200} onValueChange={v => setBrushSize(v[0])} />
                      </div>
                      <div>
                        <label className="text-white/60 text-xs block mb-2">Opacité: {brushOpacity}%</label>
                        <Slider value={[brushOpacity]} min={1} max={100} onValueChange={v => setBrushOpacity(v[0])} />
                      </div>
                      {activeTool === 'brush' && (
                        <div>
                          <label className="text-white/60 text-xs block mb-2">Couleur</label>
                          <div className="grid grid-cols-8 gap-1 mb-2">
                            {['#ffffff','#000000','#ff0000','#00ff00','#0000ff','#ffff00','#ff00ff','#00ffff',
                              '#ff8800','#8800ff','#00ff88','#ff0088','#888888','#ff4444','#44ff44','#4444ff'].map(c => (
                              <button key={c} onClick={() => setBrushColor(c)}
                                style={{ background: c }}
                                className={`w-6 h-6 rounded border-2 transition-all ${brushColor === c ? 'border-white scale-110' : 'border-transparent'}`}
                              />
                            ))}
                          </div>
                          <input type="color" value={brushColor} onChange={e => setBrushColor(e.target.value)} className="w-full h-8 rounded cursor-pointer" />
                        </div>
                      )}
                    </>
                  )}
                  {activeTool === 'magic_eraser' && (
                    <div className="bg-violet-900/30 rounded-lg p-3 border border-violet-500/30">
                      <p className="text-violet-300 text-xs font-medium mb-1">🪄 Gomme Magique IA</p>
                      <p className="text-white/50 text-xs">Dessinez sur l'objet à supprimer avec votre doigt. L'IA supprimera l'objet et reconstruira le fond.</p>
                    </div>
                  )}
                  {activeTool === 'select' && (
                    <div className="grid grid-cols-2 gap-2">
                      <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setRotation(r => r - 90)}>↺ -90°</Button>
                      <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setRotation(r => r + 90)}>↻ +90°</Button>
                      <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setFlipH(f => !f)}>⇄ Miroir H</Button>
                      <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => setFlipV(f => !f)}>⇅ Miroir V</Button>
                    </div>
                  )}
                </div>
              )}
              {activePanel === 'adjust' && (
                <div className="space-y-3">
                  {adjustList.map(adj => {
                    return (
                      <div key={adj.key}>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-white/60 text-xs">{adj.label}</label>
                          <span className="text-white/40 text-xs">{adjustments[adj.key]}</span>
                        </div>
                        <Slider value={[adjustments[adj.key]]} min={adj.min} max={adj.max} onValueChange={v => setAdjustments(a => ({ ...a, [adj.key]: v[0] }))} />
                      </div>
                    );
                  })}
                </div>
              )}
              {activePanel === 'filters' && (
                <div className="grid grid-cols-2 gap-2">
                  {FILTERS.map(f => (
                    <button key={f.id} onClick={() => setActiveFilter(f.id)}
                      className={`p-2 rounded-lg border text-xs font-medium transition-all ${activeFilter === f.id ? 'border-violet-500 bg-violet-600/30 text-violet-300' : 'border-white/10 text-white/60'}`}>
                      {f.label}
                    </button>
                  ))}
                </div>
              )}
              {activePanel === 'ai' && (
                <div className="space-y-2">
                  <button onClick={handleAiEnhance} disabled={aiProcessing} className="w-full p-3 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white text-sm font-medium flex items-center gap-2 disabled:opacity-50">
                    <Sparkles className="w-4 h-4" /> Amélioration auto
                  </button>
                  <button onClick={handleRemoveBg} disabled={aiProcessing} className="w-full p-3 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 text-white text-sm font-medium flex items-center gap-2 disabled:opacity-50">
                    <Layers className="w-4 h-4" /> Suppr. fond
                  </button>
                  <div className="grid grid-cols-2 gap-2">
                    {[{id:'cinematic',l:'🎬 Ciné'},{id:'anime',l:'🎌 Anime'},{id:'watercolor',l:'🎨 Aquarelle'},{id:'oil',l:'🖼️ Huile'},{id:'vintage',l:'📷 Vintage'},{id:'neon',l:'💜 Néon'}].map(s => (
                      <button key={s.id} onClick={() => handleAiVariation(s.id)} disabled={aiProcessing} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white/70 disabled:opacity-40">{s.l}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}