import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Link, useNavigate } from 'react-router-dom';
import { useScreenSize } from '@/components/utils/useScreenSize';
import TabsToolbar from '@/components/tabs/TabsToolbar';
import Spreadsheet from '@/components/tabs/Spreadsheet';
import AppAccessCheck from '@/components/drive/AppAccessCheck';
import { useRef } from 'react';
import { Table, ChevronLeft, Loader2, Plus, MessageSquare } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';
import AIAssistant from '@/components/shared/AIAssistant';
import AnnouncementModal from '@/components/shared/AnnouncementModal';
import { getFilePermission } from '@/lib/filePermissions';
import { getMykelSession } from '@/lib/mykelSession';
import useAutoSave from '@/hooks/useAutoSave';
import SaveStatus from '@/components/shared/SaveStatus';
import CommentsPanel from '@/components/shared/CommentsPanel';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter 
} from "@/components/ui/dialog";

export default function MykelTabs() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const fileId = urlParams.get('fileId');
  const { isMobile } = useScreenSize();
  
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fileName, setFileName] = useState('Feuille de calcul sans titre');
  const [isEditing, setIsEditing] = useState(false);
  const [shareDialog, setShareDialog] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [canEdit, setCanEdit] = useState(true);
  const [showComments, setShowComments] = useState(false);
  const [user, setUser] = useState(null);
  const canEditRef = useRef(true);
  useEffect(() => { canEditRef.current = canEdit; }, [canEdit]);
  const createdIdRef = useRef(null);
  const autoSave = useAutoSave(file?.id, { enabled: canEdit });
  
  // Spreadsheet state
  const [cells, setCells] = useState({});
  const [styles, setStyles] = useState({});
  const [selectedCell, setSelectedCell] = useState('A1');
  const [formula, setFormula] = useState('');
  const [sheets, setSheets] = useState([{ id: '1', name: 'Feuille 1' }]);
  const [activeSheet, setActiveSheet] = useState('1');
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  
  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);
  useEffect(() => {
    if (fileId) {
      if (fileId !== createdIdRef.current) loadFile();
    } else {
      createNewSpreadsheet();
    }
  }, [fileId]);

  useEffect(() => {
    if (selectedCell && cells[selectedCell]) {
      setFormula(cells[selectedCell].formula || cells[selectedCell].value || '');
    } else {
      setFormula('');
    }
  }, [selectedCell, cells]);

  const loadFile = async () => {
    try {
      const fileData = await base44.entities.CloudFile.filter({ id: fileId });
      if (fileData.length > 0) {
        setFile(fileData[0]);
        setFileName(fileData[0].name);
        const c = fileData[0].content || {};
        autoSave.setBaseline({ name: fileData[0].name, content: { cells: c.cells || {}, styles: c.styles || {}, sheets: c.sheets || [{ id: '1', name: 'Feuille 1' }] } });
        if (fileData[0].content) {
          setCells(fileData[0].content.cells || {});
          setStyles(fileData[0].content.styles || {});
          setSheets(fileData[0].content.sheets || [{ id: '1', name: 'Feuille 1' }]);
        }
        // Check permission — only owner or 'edit' members can modify
        const session = getMykelSession();
        const { canEdit: editAllowed, permission } = getFilePermission(fileData[0], session?.email);
        setCanEdit(editAllowed);
        if (!editAllowed) {
          toast.info(`Vous êtes en mode ${permission === 'comment' ? 'commentaire' : 'visualisation'}. Vous ne pouvez pas modifier ce fichier.`);
        }
      }
    } catch (e) {
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  const createNewSpreadsheet = async () => {
    try {
      const newFile = await base44.entities.CloudFile.create({
        name: 'Feuille de calcul sans titre',
        type: 'spreadsheet',
        content: { cells: {}, styles: {}, sheets: [{ id: '1', name: 'Feuille 1' }] },
        is_starred: false,
        is_trashed: false,
      });
      createdIdRef.current = newFile.id;
      autoSave.setBaseline({ name: 'Feuille de calcul sans titre', content: { cells: {}, styles: {}, sheets: [{ id: '1', name: 'Feuille 1' }] } });
      setFile(newFile);
      setFileName('Feuille de calcul sans titre');
      navigate(`/MykelTabs?fileId=${newFile.id}`, { replace: true });
    } catch (e) {
      toast.error('Erreur lors de la création');
      navigate('/Dashboard', { replace: true });
    }
    setLoading(false);
  };

  // Sauvegarde automatique : uniquement quand le contenu change
  useEffect(() => {
    autoSave.queue({ name: fileName, content: { cells, styles, sheets } });
  }, [fileName, cells, styles, sheets]);

  const saveSpreadsheet = useCallback(async () => {
    if (!canEditRef.current) return; // Block saves for view/comment members
    if (await autoSave.saveNow()) toast.success('Feuille enregistrée');
  }, [autoSave.saveNow]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        saveSpreadsheet();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [saveSpreadsheet]);

  const handleCellChange = (cellId, value, formula) => {
    // Save history for undo
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push({ cells: { ...cells }, styles: { ...styles } });
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    setCells(prev => ({
      ...prev,
      [cellId]: { value, formula }
    }));
  };

  const handleCommand = (command, value) => {
    switch (command) {
      case 'undo':
        if (historyIndex > 0) {
          setHistoryIndex(historyIndex - 1);
          setCells(history[historyIndex - 1].cells);
          setStyles(history[historyIndex - 1].styles);
        }
        break;
      case 'redo':
        if (historyIndex < history.length - 1) {
          setHistoryIndex(historyIndex + 1);
          setCells(history[historyIndex + 1].cells);
          setStyles(history[historyIndex + 1].styles);
        }
        break;
      case 'bold':
      case 'italic':
      case 'underline':
      case 'strikethrough':
        setStyles(prev => ({
          ...prev,
          [selectedCell]: {
            ...prev[selectedCell],
            [command]: !prev[selectedCell]?.[command]
          }
        }));
        break;
      case 'fontFamily':
      case 'fontSize':
      case 'textColor':
      case 'fillColor':
      case 'align':
        setStyles(prev => ({
          ...prev,
          [selectedCell]: {
            ...prev[selectedCell],
            [command]: value
          }
        }));
        break;
      case 'format':
        // Apply number format
        if (selectedCell && cells[selectedCell]) {
          let formattedValue = cells[selectedCell].value;
          const numValue = parseFloat(formattedValue);
          
          if (!isNaN(numValue)) {
            switch (value) {
              case 'currency':
                formattedValue = numValue.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
                break;
              case 'percent':
                formattedValue = (numValue * 100).toFixed(2) + '%';
                break;
              case 'number':
                formattedValue = numValue.toLocaleString('fr-FR');
                break;
            }
            setCells(prev => ({
              ...prev,
              [selectedCell]: { ...prev[selectedCell], value: formattedValue }
            }));
          }
        }
        break;
    }
  };

  const handleFormulaChange = (value) => {
    setFormula(value);
  };

  const handleFormulaSubmit = () => {
    if (selectedCell) {
      const isFormula = formula.startsWith('=');
      handleCellChange(selectedCell, isFormula ? evaluateFormula(formula, cells) : formula, isFormula ? formula : null);
    }
  };

  const evaluateFormula = (formula, cells) => {
    if (!formula.startsWith('=')) return formula;
    // This is simplified - the full evaluation happens in Spreadsheet component
    return formula;
  };

  const handleExport = (format) => {
    if (format === 'csv') {
      let csv = '';
      for (let row = 0; row < 100; row++) {
        const rowData = [];
        for (let col = 0; col < 26; col++) {
          const cellId = `${String.fromCharCode(65 + col)}${row + 1}`;
          rowData.push(cells[cellId]?.value || '');
        }
        // Only include rows with data
        if (rowData.some(v => v !== '')) {
          csv += rowData.map(v => `"${v}"`).join(',') + '\n';
        }
      }
      
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      toast.info(`Export ${format.toUpperCase()} disponible prochainement`);
    }
  };

  const handleShare = async () => {
    if (!shareEmail.trim() || !file) return;
    try {
      const currentShared = file.shared_with || [];
      await base44.entities.CloudFile.update(file.id, {
        shared_with: [...currentShared, shareEmail.trim()]
      });
      setShareDialog(false);
      setShareEmail('');
      toast.success('Feuille partagée');
    } catch (e) {
      toast.error('Erreur lors du partage');
    }
  };

  const addSheet = () => {
    const newId = String(sheets.length + 1);
    setSheets([...sheets, { id: newId, name: `Feuille ${newId}` }]);
    setActiveSheet(newId);
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  return (
    <AppAccessCheck appType="spreadsheet">
      <div className="h-screen flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-4">
        <button onClick={() => navigate('/Dashboard')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
            <Table className="w-6 h-6 text-white" />
          </div>
          <div>
            {isEditing ? (
              <Input
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                onBlur={() => setIsEditing(false)}
                onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
                className="h-7 text-lg font-semibold border-green-500"
                autoFocus
              />
            ) : (
              <h1 
                className="text-lg font-semibold cursor-pointer hover:text-green-600 transition-colors"
                onClick={() => setIsEditing(true)}
              >
                {fileName}
              </h1>
            )}
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <SaveStatus status={autoSave.status} lastSaved={autoSave.lastSaved} />
            </div>
          </div>
          <Button
            onClick={() => setShowComments(true)}
            variant="ghost"
            size="sm"
            className="ml-auto gap-2 text-xs md:text-sm flex-shrink-0"
            title="Commentaires"
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden md:inline">Commentaires</span>
          </Button>
        </div>
      </div>

      {/* Toolbar — hidden in view mode */}
      {canEdit && (
        <TabsToolbar 
          onCommand={handleCommand}
          onSave={saveSpreadsheet}
          onExport={handleExport}
          onShare={() => setShareDialog(true)}
          saving={autoSave.status === 'saving'}
          selectedCell={selectedCell}
          formula={formula}
          onFormulaChange={(v) => {
            setFormula(v);
            if (selectedCell) {
              const isFormula = v.startsWith('=');
              handleCellChange(selectedCell, v, isFormula ? v : null);
            }
          }}
        />
      )}

      {/* Spreadsheet */}
      <Spreadsheet
        cells={cells}
        styles={styles}
        onCellChange={canEdit ? handleCellChange : () => {}}
        onCellSelect={setSelectedCell}
        selectedCell={selectedCell}
        readOnly={!canEdit}
      />

      {/* Sheet Tabs */}
      <div className="bg-gray-200 border-t border-gray-300 px-2 py-1 flex items-center gap-1">
        {sheets.map(sheet => (
          <button
            key={sheet.id}
            onClick={() => setActiveSheet(sheet.id)}
            className={`px-4 py-1.5 text-sm rounded-t-lg transition-colors ${
              activeSheet === sheet.id
                ? 'bg-white text-gray-900 font-medium'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-50'
            }`}
          >
            {sheet.name}
          </button>
        ))}
        <button
          onClick={addSheet}
          className="p-1.5 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded transition-colors"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Share Dialog */}
      <Dialog open={shareDialog} onOpenChange={setShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Partager "{fileName}"</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Adresse email"
            type="email"
            value={shareEmail}
            onChange={(e) => setShareEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleShare()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleShare}>Partager</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <AIAssistant systemContext="Tu es dans Mykel Tabs (tableur). Tu peux aider avec les formules, l'organisation des données, les calculs, et tout ce qui concerne les feuilles de calcul." fileId={fileId} />
      {showComments && (
        <CommentsPanel fileId={fileId} user={user} onClose={() => setShowComments(false)} />
      )}
      <AnnouncementModal target="app" targetApp="MykelTabs" />
    </div>
    </AppAccessCheck>
  );
}