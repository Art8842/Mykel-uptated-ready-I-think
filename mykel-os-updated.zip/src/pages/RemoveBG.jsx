import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Upload, Download, ImageIcon, X, Cloud, RefreshCw, Film, Loader2 } from 'lucide-react';
import AILoader from '@/components/shared/AILoader';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from 'sonner';
import AnnouncementModal from '@/components/shared/AnnouncementModal';

export default function RemoveBG() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [originalFile, setOriginalFile] = useState(null); // File object
  const [originalUrl, setOriginalUrl] = useState(null);
  const [resultBlob, setResultBlob] = useState(null);
  const [resultUrl, setResultUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [cloudFiles, setCloudFiles] = useState([]);
  const [showCloudPicker, setShowCloudPicker] = useState(false);
  const [loadingCloud, setLoadingCloud] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [sourceCloudFile, setSourceCloudFile] = useState(null);
  const [isVideo, setIsVideo] = useState(false);

  const processBlob = async (blob, name, videoMode = false) => {
    const url = URL.createObjectURL(blob);
    setOriginalUrl(url);
    setIsVideo(videoMode);
    setResultBlob(null);
    setResultUrl(null);
    setLoading(true);
    try {
      const formData = new FormData();
      if (videoMode) {
        formData.append('video_file', blob, name || 'video.mp4');
      } else {
        formData.append('image_file', blob, name || 'image.jpg');
        formData.append('size', 'auto');
      }
      const endpoint = videoMode
        ? 'https://api.remove.bg/v1.0/removebg/video'
        : 'https://api.remove.bg/v1.0/removebg';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'X-Api-Key': 'sVAZVvTEkopspHHsTj6whB5q' },
        body: formData,
      });
      if (!response.ok) {
        const err = await response.json();
        throw new Error(err?.errors?.[0]?.title || 'Erreur API');
      }
      const result = await response.blob();
      setResultBlob(result);
      setResultUrl(URL.createObjectURL(result));
      toast.success(`Arrière-plan ${videoMode ? 'vidéo' : ''} supprimé !`);
    } catch (e) {
      toast.error(`Erreur : ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleGalleryFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isVid = file.type.startsWith('video/');
    if (!file.type.startsWith('image/') && !isVid) { toast.error('Veuillez sélectionner une image ou vidéo'); return; }
    setOriginalFile(file);
    setSourceCloudFile(null);
    processBlob(file, file.name, isVid);
  };

  const openCloudPicker = async () => {
    setLoadingCloud(true);
    setShowCloudPicker(true);
    try {
      const u = await base44.auth.me();
      const [images, videos] = await Promise.all([
        base44.entities.CloudFile.filter({ type: 'image', is_trashed: false, created_by: u.email }),
        base44.entities.CloudFile.filter({ type: 'video', is_trashed: false, created_by: u.email }),
      ]);
      setCloudFiles([...images, ...videos]);
    } catch {
      toast.error('Erreur chargement cloud');
    } finally {
      setLoadingCloud(false);
    }
  };

  const handleCloudFileSelect = async (cf) => {
    setShowCloudPicker(false);
    setSourceCloudFile(cf);
    setResultBlob(null);
    setResultUrl(null);
    try {
      const res = await fetch(cf.file_url);
      const blob = await res.blob();
      processBlob(blob, cf.name, cf.type === 'video');
    } catch {
      toast.error('Erreur lors du chargement du fichier cloud');
    }
  };

  const handleDownload = () => {
    if (!resultBlob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(resultBlob);
    a.download = isVideo ? 'video-sans-fond.mp4' : 'image-sans-fond.png';
    a.click();
    toast.success(isVideo ? 'Vidéo téléchargée' : 'Image téléchargée');
  };

  const handleSaveToCloud = async (mode) => {
    // mode: 'replace' | 'new'
    setSaving(true);
    try {
      const file = new File([resultBlob], 'image-sans-fond.png', { type: 'image/png' });
      const { file_url } = await uploadMedia(file);
      const u = await base44.auth.me();

      if (mode === 'replace' && sourceCloudFile) {
        await base44.entities.CloudFile.update(sourceCloudFile.id, { file_url });
        toast.success(`${isVideo ? 'Vidéo' : 'Image'} remplacée dans le cloud`);
      } else {
        const ext = isVideo ? '.mp4' : '.png';
        const name = sourceCloudFile ? `${sourceCloudFile.name.replace(/\.[^.]+$/, '')}-sans-fond${ext}` : `fichier-sans-fond${ext}`;
        await base44.entities.CloudFile.create({
          name,
          type: isVideo ? 'video' : 'image',
          file_url,
          size: resultBlob.size,
          is_starred: false,
          is_trashed: false
        });
        toast.success(`Nouveau fichier ajouté dans le cloud`);
      }
      setShowSaveDialog(false);
    } catch {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  const reset = () => {
    setOriginalUrl(null);
    setResultBlob(null);
    setResultUrl(null);
    setOriginalFile(null);
    setSourceCloudFile(null);
    setIsVideo(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl('Dashboard'))}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2 flex-1">
          <div className="w-9 h-9 bg-gradient-to-br from-pink-500 to-rose-600 rounded-lg flex items-center justify-center">
            <ImageIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-gray-900 dark:text-white">Remove Background</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Supprimer l'arrière-plan d'une image ou vidéo</p>
          </div>
        </div>
        {originalUrl && (
          <Button variant="outline" size="sm" onClick={reset} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Nouvelle image
          </Button>
        )}
      </div>

      <div className="flex-1 max-w-4xl mx-auto w-full px-4 py-8">
        {/* Upload area */}
        {!originalUrl && (
          <div className="flex flex-col items-center gap-6 py-12">
            <div className="w-20 h-20 bg-gradient-to-br from-pink-100 to-rose-100 dark:from-pink-950 dark:to-rose-950 rounded-2xl flex items-center justify-center">
              <ImageIcon className="w-10 h-10 text-pink-500" />
            </div>
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Déposer une image ou vidéo</h2>
              <p className="text-gray-500 dark:text-gray-400">Choisissez une image ou une vidéo depuis votre galerie ou Mykel Cloud</p>
            </div>
            <div className="flex gap-4 flex-wrap justify-center">
              <Button
                size="lg"
                className="gap-2 bg-pink-600 hover:bg-pink-700 text-white"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-5 h-5" />
                Depuis ma galerie
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2"
                onClick={openCloudPicker}
              >
                <Cloud className="w-5 h-5" />
                Depuis Mykel Cloud
              </Button>
            </div>
            <p className="text-xs text-gray-400">Formats supportés : images (JPG, PNG, WebP) et vidéos (MP4, MOV, WebM)</p>
            <input ref={fileInputRef} type="file" accept="image/*,video/*" onChange={handleGalleryFile} className="hidden" />
          </div>
        )}

        {/* Result area */}
        {originalUrl && (
          <div className="space-y-6">
            {/* Action buttons */}
            {resultBlob && (
              <div className="flex gap-2 flex-wrap justify-end">
                <Button variant="outline" className="gap-2" onClick={handleDownload}>
                  <Download className="w-4 h-4" />
                  Télécharger (galerie)
                </Button>
                <Button className="gap-2 bg-pink-600 hover:bg-pink-700" onClick={() => setShowSaveDialog(true)}>
                  <Cloud className="w-4 h-4" />
                  Enregistrer dans le cloud
                </Button>
              </div>
            )}

            {/* Side by side */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div className="px-4 py-2 border-b border-gray-100 dark:border-gray-800">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Original</p>
                </div>
                <div className="p-4 flex items-center justify-center min-h-64">
                  {isVideo
                    ? <video src={originalUrl} controls className="max-h-80 max-w-full rounded-lg" />
                    : <img src={originalUrl} alt="Original" className="max-h-80 max-w-full object-contain rounded-lg" />}
                </div>
              </div>

              <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div className="px-4 py-2 border-b border-gray-100 dark:border-gray-800">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sans arrière-plan</p>
                </div>
                <div className="p-4 flex items-center justify-center min-h-64" style={isVideo ? {} : {
                  backgroundImage: 'repeating-conic-gradient(#e5e7eb 0% 25%, white 0% 50%)',
                  backgroundSize: '20px 20px'
                }}>
                  {loading ? (
                    <div className="flex flex-col items-center gap-4 py-4">
                      <AILoader size="lg" text="Suppression du fond par IA..." color="pink" />
                    </div>
                  ) : resultUrl ? (
                    isVideo
                      ? <video src={resultUrl} controls className="max-h-80 max-w-full rounded-lg" />
                      : <img src={resultUrl} alt="Sans fond" className="max-h-80 max-w-full object-contain rounded-lg" />
                  ) : (
                    <p className="text-gray-400 text-sm">Le résultat apparaîtra ici</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Cloud picker dialog */}
      <Dialog open={showCloudPicker} onOpenChange={setShowCloudPicker}>
        <DialogContent className="max-w-lg bg-white dark:bg-gray-900">
          <DialogHeader>
            <DialogTitle>Choisir depuis Mykel Cloud</DialogTitle>
          </DialogHeader>
          {loadingCloud ? (
            <div className="flex justify-center py-10">
              <Loader2 className="w-8 h-8 animate-spin text-pink-500" />
            </div>
          ) : cloudFiles.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Aucune image dans votre cloud</p>
          ) : (
            <div className="grid grid-cols-3 gap-3 max-h-80 overflow-y-auto">
              {cloudFiles.map(cf => (
                <button
                  key={cf.id}
                  onClick={() => handleCloudFileSelect(cf)}
                  className="aspect-square rounded-lg overflow-hidden border-2 border-transparent hover:border-pink-500 transition-all relative"
                >
                  {cf.type === 'video'
                    ? <div className="w-full h-full bg-gray-800 flex flex-col items-center justify-center gap-1">
                        <Film className="w-6 h-6 text-white" />
                        <span className="text-white text-xs truncate px-1 max-w-full">{cf.name}</span>
                      </div>
                    : <img src={cf.file_url} alt={cf.name} className="w-full h-full object-cover" />}
                </button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Save to cloud dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="max-w-sm bg-white dark:bg-gray-900">
          <DialogHeader>
            <DialogTitle>Enregistrer dans Mykel Cloud</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-2">
            {sourceCloudFile && (
              <Button
                className="w-full gap-2 bg-orange-500 hover:bg-orange-600"
                onClick={() => handleSaveToCloud('replace')}
                disabled={saving}
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                Remplacer l'image originale
              </Button>
            )}
            <Button
              className="w-full gap-2 bg-pink-600 hover:bg-pink-700"
              onClick={() => handleSaveToCloud('new')}
              disabled={saving}
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Cloud className="w-4 h-4" />}
              Ajouter comme nouvelle image
            </Button>
            <Button variant="outline" className="w-full" onClick={handleDownload} disabled={saving}>
              <Download className="w-4 h-4 mr-2" />
              Télécharger dans la galerie
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      <AnnouncementModal target="app" targetApp="RemoveBG" />
    </div>
  );
}