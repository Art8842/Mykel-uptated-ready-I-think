import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Building2, Check, UserPlus, LogIn, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { getMykelSession } from '@/lib/mykelSession';

export default function BusinessInvite() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const companyFromUrl = searchParams.get('company') || 'l\'entreprise';
  const [businessSub, setBusinessSub] = useState(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [step, setStep] = useState('invite');
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    loadInvite();
  }, []);

  const loadInvite = async () => {
    if (!token) { setLoading(false); return; }

    // Check if user is already logged in (Mykel session)
    const session = getMykelSession();
    if (session) {
      setUser({ email: session.email, full_name: session.full_name });
      // Fetch the business sub — use list() + find for reliability (filter on string fields can fail)
      try {
        const allSubs = await base44.entities.BusinessSubscription.list();
        const sub = allSubs.find(s => s.invite_token === token && s.active);
        if (sub) {
          setBusinessSub(sub);
          setStep('confirm');
        } else {
          toast.error('Lien d\'invitation invalide ou expiré');
        }
      } catch (e) {
        console.error('Business invite load error:', e);
        toast.error('Erreur lors du chargement de l\'invitation');
      }
    }
    // Not logged in — show the invite page with URL company name (no auth needed)
    setLoading(false);
  };

  const companyName = businessSub?.company_name || companyFromUrl;

  const buildReturnUrl = () => {
    return `/BusinessInvite?token=${token}&company=${encodeURIComponent(companyFromUrl)}`;
  };

  const handleAccept = async () => {
    setJoining(true);
    try {
      const email = user?.email || getMykelSession()?.email;
      if (!email) { toast.error('Non connecté'); setStep('invite'); return; }

      // Fetch fresh business sub — use list() + find for reliability
      const allSubs = await base44.entities.BusinessSubscription.list();
      const sub = allSubs.find(s => s.invite_token === token && s.active);
      if (!sub) { toast.error('Lien d\'invitation invalide'); return; }

      if (sub.member_emails?.includes(email)) {
        toast.success('Vous faites déjà partie de cet abonnement !');
      } else {
        if (sub.member_emails?.length >= sub.num_accounts) {
          toast.error('Le nombre maximum de comptes est atteint');
          return;
        }
        const newMembers = [...(sub.member_emails || []), email];
        await base44.entities.BusinessSubscription.update(sub.id, { member_emails: newMembers });
        toast.success('Vous avez rejoint l\'abonnement Mykel Business !');
      }

      localStorage.setItem('mykel_account_mode', 'business');
      localStorage.setItem('mykel_business_sub_id', sub.id);
      window.location.href = '/Dashboard';
    } catch (e) {
      console.error(e);
      toast.error('Erreur lors de l\'association');
    } finally {
      setJoining(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  );

  if (!token) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <Building2 className="w-16 h-16 text-gray-300 mb-4" />
      <p className="text-gray-500">Lien d'invitation invalide</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl max-w-md w-full p-8">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Building2 className="w-8 h-8 text-white" />
          </div>
        </div>

        {step === 'invite' && (
          <>
            <h1 className="text-xl font-bold text-center text-gray-900 mb-2">
              {companyName} vous invite
            </h1>
            <p className="text-center text-gray-600 mb-8">
              à rejoindre l'abonnement Mykel for Business et profiter des avantages offerts par votre entreprise.
            </p>
            <div className="space-y-3">
              <Button onClick={() => navigate(`/MykelLogin?returnUrl=${encodeURIComponent(buildReturnUrl())}`)} className="w-full h-12 gap-2">
                <LogIn className="w-5 h-5" /> J'ai déjà un compte Mykel
              </Button>
              <Button variant="outline" onClick={() => navigate(`/MykelLogin?returnUrl=${encodeURIComponent(buildReturnUrl())}&mode=register`)} className="w-full h-12 gap-2">
                <UserPlus className="w-5 h-5" /> Je souhaite créer un nouveau compte
              </Button>
            </div>
          </>
        )}

        {step === 'confirm' && (
          <>
            <h1 className="text-xl font-bold text-center text-gray-900 mb-2">
              {companyName} vous invite
            </h1>
            <p className="text-center text-gray-600 mb-6">
              Êtes-vous sûr d'associer votre compte <strong>{user?.email}</strong> à l'abonnement Mykel for Business de {companyName} ?
            </p>
            <p className="text-sm text-gray-500 text-center mb-6">
              Vous pourrez basculer entre votre compte personnel et votre compte Business à tout moment.
            </p>
            <div className="space-y-3">
              <Button onClick={handleAccept} disabled={joining} className="w-full h-12 gap-2 bg-blue-600 hover:bg-blue-700">
                {joining ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Check className="w-5 h-5" /> Oui, associer mon compte</>}
              </Button>
              <Button variant="outline" onClick={() => { window.location.href = '/Dashboard'; }} className="w-full h-12">Plus tard</Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}