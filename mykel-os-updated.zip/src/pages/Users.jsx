import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { ChevronLeft, Search, Loader2, Save, Coins, Plus, Minus, Smartphone, Globe, Shield, User as UserIcon } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from 'sonner';
import { getMykelSession, setMykelSession } from '@/lib/mykelSession';
import { computeEffectiveMax } from '@/lib/storageQuota';

export default function Users() {
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [mykelAccounts, setMykelAccounts] = useState([]);
  const [userStorages, setUserStorages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [updatingRole, setUpdatingRole] = useState({});
  const [editDialog, setEditDialog] = useState({ open: false, user: null, storage: null });
  const [newStorage, setNewStorage] = useState('');
  const [isUnlimited, setIsUnlimited] = useState(false);
  const [tokenDialog, setTokenDialog] = useState({ open: false, user: null, userTokens: null });
  const [tokenAmount, setTokenAmount] = useState(0);
  const [userTokensList, setUserTokensList] = useState([]);
  const [activeStorageSubs, setActiveStorageSubs] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await base44.auth.me().catch(() => null);
      setUser(currentUser);

      const mykelSession = getMykelSession();
      const isAdmin = currentUser?.role === 'admin' || mykelSession?.role === 'admin';

      if (!isAdmin) {
        toast.error('Accès non autorisé');
        return;
      }

      const [allUsers, allStorages, allTokens, allMykelAccounts, storageSubs] = await Promise.all([
        base44.entities.User.list(),
        base44.entities.UserStorage.list(),
        base44.entities.UserTokens.list(),
        base44.entities.MykelAccount.list().catch(() => []),
        base44.entities.StorageSubscription.filter({ active: true }).catch(() => []),
      ]);

      setActiveStorageSubs(storageSubs);
      setUsers(allUsers);
      setUserStorages(allStorages);
      setUserTokensList(allTokens);
      setMykelAccounts(allMykelAccounts);
    } catch (e) {
      toast.error('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const formatStorage = (value) => {
    const bytes = Number(value) || 0;
    if (bytes < 1024) return bytes + ' o';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
    return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' Go';
  };

  const getUserVersion = (email) => {
    const hasMykelAccount = mykelAccounts.some(a => a.email?.toLowerCase() === email?.toLowerCase());
    return hasMykelAccount ? 'new' : 'old';
  };

  const handleRoleChange = async (targetUser, newRole) => {
    setUpdatingRole(prev => ({ ...prev, [targetUser.id]: true }));
    try {
      await base44.entities.User.update(targetUser.id, { role: newRole });

      const mykelAcc = mykelAccounts.find(a => a.email?.toLowerCase() === targetUser.email?.toLowerCase());
      if (mykelAcc) {
        await base44.entities.MykelAccount.update(mykelAcc.id, { role: newRole }).catch(() => {});
      }

      const currentSession = getMykelSession();
      if (currentSession && currentSession.email?.toLowerCase() === targetUser.email?.toLowerCase()) {
        setMykelSession({ ...currentSession, role: newRole });
      }

      toast.success(`Rôle de ${targetUser.full_name || targetUser.email} changé en ${newRole === 'admin' ? 'Administrateur' : 'Utilisateur'}`);
      await loadData();
    } catch (error) {
      toast.error('Erreur lors de la mise à jour du rôle');
    } finally {
      setUpdatingRole(prev => ({ ...prev, [targetUser.id]: false }));
    }
  };

  const handleEditStorage = (u, storage) => {
    setEditDialog({ open: true, user: u, storage });
    if (storage) {
      setIsUnlimited(storage.max_storage === -1);
      const gb = (Number(storage.max_storage) || 0) / (1024 * 1024 * 1024);
      setNewStorage(storage.max_storage === -1 || !gb ? '100' : String(Math.round(gb * 100) / 100));
    } else {
      setIsUnlimited(false);
      setNewStorage('100');
    }
  };

  const handleOpenTokenDialog = (u, tokensRecord) => {
    setTokenDialog({ open: true, user: u, userTokens: tokensRecord });
    setTokenAmount(0);
  };

  const handleSaveTokens = async () => {
    if (!tokenDialog.user) return;
    try {
      if (tokenDialog.userTokens) {
        const newTotal = Math.max(0, (tokenDialog.userTokens.tokens || 0) + tokenAmount);
        await base44.entities.UserTokens.update(tokenDialog.userTokens.id, { tokens: newTotal });
      } else {
        await base44.entities.UserTokens.create({
          user_email: tokenDialog.user.email,
          tokens: Math.max(0, tokenAmount),
          owned_apps: []
        });
      }
      toast.success('Jetons mis à jour');
      setTokenDialog({ open: false, user: null, userTokens: null });
      loadData();
    } catch (e) {
      toast.error('Erreur lors de la mise à jour des jetons');
    }
  };

  const handleSaveStorage = async () => {
    if (!editDialog.user) return;
    const gb = parseFloat(newStorage);
    if (!isUnlimited && (!Number.isFinite(gb) || gb <= 0)) {
      toast.error('Entrez une valeur de stockage valide (en Go)');
      return;
    }
    try {
      const maxStorage = isUnlimited ? -1 : Math.round(gb * 1024 * 1024 * 1024);
      if (editDialog.storage) {
        await base44.entities.UserStorage.update(editDialog.storage.id, { max_storage: maxStorage });
      } else {
        await base44.entities.UserStorage.create({
          user_email: editDialog.user.email,
          used_storage: 0,
          max_storage: maxStorage
        });
      }
      toast.success('Stockage mis à jour');
      setEditDialog({ open: false, user: null, storage: null });
      loadData();
    } catch (e) {
      toast.error('Erreur lors de la mise à jour du stockage');
    }
  };

  const filteredUsers = users.filter(u =>
    u.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const mykelSession = getMykelSession();
  const isAdmin = user?.role === 'admin' || mykelSession?.role === 'admin';

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="h-screen flex items-center justify-center">
        <p className="text-red-500 font-semibold">Accès réservé aux administrateurs</p>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
        <div className="flex items-center gap-4">
          <Link to="/AdminPanel" className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Gestion des utilisateurs & des Rôles</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-6xl mx-auto">
          {/* Search */}
          <div className="mb-6 relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Rechercher un utilisateur par nom ou email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Legend */}
          <div className="mb-4 flex items-center gap-4 text-xs text-gray-500">
            <div className="flex items-center gap-1.5">
              <Badge className="bg-violet-100 text-violet-700 border-violet-200 text-xs gap-1 font-medium">
                <Smartphone className="w-3 h-3" /> Nouvelle version
              </Badge>
              <span>— Compte Mykel interne</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Badge className="bg-gray-100 text-gray-600 border-gray-200 text-xs gap-1 font-medium">
                <Globe className="w-3 h-3" /> Ancienne version
              </Badge>
              <span>— Connexion Base44 / AppWrite</span>
            </div>
          </div>

          {/* Users Table */}
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow border border-gray-100 dark:border-gray-800">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Utilisateur</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead>Rôle (Sélection)</TableHead>
                  <TableHead>Stockage utilisé</TableHead>
                  <TableHead>Stockage max</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((u) => {
                  const storage = userStorages.find(s => s.user_email === u.email);
                  const version = getUserVersion(u.email);
                  const userRole = u.role || 'user';

                  return (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium text-gray-900 dark:text-white">{u.full_name || 'Sans nom'}</TableCell>
                      <TableCell className="text-gray-600 dark:text-gray-400">{u.email}</TableCell>
                      <TableCell>
                        {version === 'new' ? (
                          <Badge className="bg-violet-100 text-violet-700 border border-violet-200 text-xs gap-1 font-medium">
                            <Smartphone className="w-3 h-3" /> Nouvelle version
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-600 border border-gray-200 text-xs gap-1 font-medium">
                            <Globe className="w-3 h-3" /> Ancienne version
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="w-36">
                          <Select
                            disabled={updatingRole[u.id]}
                            value={userRole}
                            onValueChange={(newRole) => handleRoleChange(u, newRole)}
                          >
                            <SelectTrigger className={`h-8 text-xs font-semibold ${
                              userRole === 'admin' 
                                ? 'bg-purple-50 text-purple-700 border-purple-200' 
                                : 'bg-gray-50 text-gray-700 border-gray-200'
                            }`}>
                              <SelectValue placeholder="Sélectionner le rôle" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="user">
                                <div className="flex items-center gap-1.5">
                                  <UserIcon className="w-3.5 h-3.5 text-gray-500" />
                                  <span>User (Par défaut)</span>
                                </div>
                              </SelectItem>
                              <SelectItem value="admin">
                                <div className="flex items-center gap-1.5 font-medium text-purple-600">
                                  <Shield className="w-3.5 h-3.5" />
                                  <span>Admin</span>
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-600 dark:text-gray-400">
                        {storage ? formatStorage(storage.used_storage) : '0 o'}
                      </TableCell>
                      <TableCell className="text-gray-600 dark:text-gray-400">
                        {(() => {
                          const subs = activeStorageSubs.filter(s => s.user_email === u.email);
                          const effective = computeEffectiveMax(storage?.max_storage, subs);
                          return (
                            <>
                              {effective === -1 ? 'Illimité' : formatStorage(effective)}
                              {subs.length > 0 && storage?.max_storage !== -1 && (
                                <span className="block text-[11px] text-gray-400">base {formatStorage(storage?.max_storage ?? 107374182400)} + abonnements</span>
                              )}
                            </>
                          );
                        })()}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2 flex-wrap">
                          <Button variant="outline" size="sm" onClick={() => handleEditStorage(u, storage)}>
                            Stockage
                          </Button>
                          <Button
                            variant="outline" size="sm"
                            className="gap-1 text-amber-600 border-amber-300 hover:bg-amber-50"
                            onClick={() => handleOpenTokenDialog(u, userTokensList.find(t => t.user_email === u.email))}
                          >
                            <Coins className="w-3 h-3" />
                            {userTokensList.find(t => t.user_email === u.email)?.tokens ?? 0} jetons
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Dialog modification Jetons */}
      <Dialog open={tokenDialog.open} onOpenChange={(open) => setTokenDialog({ ...tokenDialog, open })}>
        <DialogContent className="bg-white dark:bg-gray-900">
          <DialogHeader>
            <DialogTitle>Modifier les jetons — {tokenDialog.user?.full_name || tokenDialog.user?.email}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 rounded-lg p-3 text-center">
              <p className="text-sm text-amber-700">Solde actuel</p>
              <p className="text-3xl font-bold text-amber-600">{tokenDialog.userTokens?.tokens ?? 0} <span className="text-lg">jetons</span></p>
            </div>
            <div>
              <label className="text-sm text-gray-600 mb-2 block">Ajuster (positif = ajouter, négatif = retirer)</label>
              <div className="flex items-center gap-3">
                <Button variant="outline" size="icon" onClick={() => setTokenAmount(v => v - 1)}><Minus className="w-4 h-4" /></Button>
                <Input type="number" value={tokenAmount} onChange={e => setTokenAmount(parseInt(e.target.value) || 0)} className="text-center text-xl font-bold" />
                <Button variant="outline" size="icon" onClick={() => setTokenAmount(v => v + 1)}><Plus className="w-4 h-4" /></Button>
              </div>
              <p className="text-sm text-gray-500 mt-2">Nouveau solde : <strong>{Math.max(0, (tokenDialog.userTokens?.tokens ?? 0) + tokenAmount)} jetons</strong></p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTokenDialog({ open: false, user: null, userTokens: null })}>Annuler</Button>
            <Button onClick={handleSaveTokens}>
              <Save className="w-4 h-4 mr-2" />
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog modification Stockage */}
      <Dialog open={editDialog.open} onOpenChange={(open) => setEditDialog({ ...editDialog, open })}>
        <DialogContent className="bg-white dark:bg-gray-900">
          <DialogHeader>
            <DialogTitle>Modifier le stockage de {editDialog.user?.full_name || editDialog.user?.email}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <input type="checkbox" id="unlimited" checked={isUnlimited} onChange={(e) => setIsUnlimited(e.target.checked)} className="w-4 h-4" />
              <label htmlFor="unlimited" className="text-sm">Stockage illimité</label>
            </div>
            {!isUnlimited && (
              <div>
                <label className="text-sm text-gray-600 mb-2 block">Stockage de base (Go)</label>
                <Input type="number" value={newStorage} onChange={(e) => setNewStorage(e.target.value)} placeholder="100" min="1" />
                <p className="text-xs text-gray-400 mt-1.5">Les abonnements de stockage achetés s'ajoutent automatiquement à cette valeur.</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialog({ open: false, user: null, storage: null })}>Annuler</Button>
            <Button onClick={handleSaveStorage}>
              <Save className="w-4 h-4 mr-2" />
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
