import React, { useState, useEffect, useCallback, Suspense, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import {
  ChevronLeft, Box, Loader2, Plus, Trash2, Copy, Undo2, Redo2,
  Eye, EyeOff, Lock, Unlock, Sun, Camera, Circle, Save, ChevronRight,
  ChevronDown, Move3D, RotateCcw, Maximize2, Grid3X3, Layers, Settings2,
  Minus, X, Globe, Triangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';

const BlenderViewport = React.lazy(() => import('@/components/3d/BlenderViewport'));

const genId = () => Math.random().toString(36).substr(2, 9);

const SHAPES = {
  mesh: [
    { id: 'box', label: 'Cube', icon: '⬜' },
    { id: 'sphere', label: 'Sphère UV', icon: '⚪' },
    { id: 'icosphere', label: 'Icosphère', icon: '🔷' },
    { id: 'cylinder', label: 'Cylindre', icon: '⭕' },
    { id: 'cone', label: 'Cône', icon: '▲' },
    { id: 'torus', label: 'Tore', icon: '🍩' },
    { id: 'torusknot', label: 'Nœud de tore', icon: '∞' },
    { id: 'plane', label: 'Plan', icon: '▬' },
    { id: 'circle', label: 'Cercle', icon: '⭕' },
    { id: 'capsule', label: 'Capsule', icon: '💊' },
  ],
  lights: [
    { id: 'light_point', label: 'Point', icon: '💡' },
    { id: 'light_sun', label: 'Soleil', icon: '☀️' },
    { id: 'light_spot', label: 'Spot', icon: '🔦' },
  ],
  other: [
    { id: 'camera', label: 'Caméra', icon: '📷' },
    { id: 'empty', label: 'Vide', icon: '✚' },
  ],
};

const SHADING_MODES = [
  { id: 'solid', label: 'Solide', icon: '⬜' },
  { id: 'wireframe', label: 'Filaire', icon: '⬡' },
  { id: 'material', label: 'Matériau', icon: '🎨' },
];

const TRANSFORM_MODES = [
  { id: 'translate', label: 'Déplacer', icon: Move3D, key: 'G' },
  { id: 'rotate', label: 'Pivoter', icon: RotateCcw, key: 'R' },
  { id: 'scale', label: 'Échelle', icon: Maximize2, key: 'S' },
];

const defaultObj = (shape) => ({
  id: genId(),
  shape,
  name: SHAPES.mesh.concat(SHAPES.lights, SHAPES.other).find(s => s.id === shape)?.label || shape,
  position: { x: 0, y: (shape.startsWith('light') ? 3 : shape === 'camera' ? 2 : 0), z: 0 },
  rotation: { x: 0, y: 0, z: 0 },
  scale: { x: 1, y: 1, z: 1 },
  color: shape.startsWith('light') ? '#fffbe6' : shape === 'camera' ? '#8888ff' : '#b0b0b0',
  metalness: 0,
  roughness: 0.5,
  emission: '#000000',
  emissionStrength: 0,
  alpha: 1,
  visible: true,
  locked: false,
});

export default function Mykel3D() {
  const urlParams = new URLSearchParams(window.location.search);
  const sceneId = urlParams.get('sceneId');

  const [scene, setScene] = useState(null);
  const [sceneName, setSceneName] = useState('Scène sans titre');
  const [editingName, setEditingName] = useState(false);
  const [objects, setObjects] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [shadingMode, setShadingMode] = useState('solid');
  const [transformMode, setTransformMode] = useState('translate');
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);
  const [history, setHistory] = useState([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [nPanelOpen, setNPanelOpen] = useState(true);
  const [addMenuOpen, setAddMenuOpen] = useState(false);
  const [addMenuPos, setAddMenuPos] = useState({ x: 200, y: 200 });
  const [editMode, setEditMode] = useState(false);
  const [propCollapse, setPropCollapse] = useState({ transform: false, material: false, display: false });
  const [outlinerCollapse, setOutlinerCollapse] = useState(false);
  const [mobileOutliner, setMobileOutliner] = useState(false);
  const [mobileNPanel, setMobileNPanel] = useState(false);

  const sceneRef = useRef(null);
  const objectsRef = useRef([]);
  const sceneNameRef = useRef('Scène sans titre');

  useEffect(() => { objectsRef.current = objects; }, [objects]);
  useEffect(() => { sceneNameRef.current = sceneName; }, [sceneName]);

  useEffect(() => {
    if (sceneId) loadScene();
    else createNewScene();
  }, []);

  const loadScene = async () => {
    try {
      const data = await base44.entities.Scene3D.filter({ id: sceneId });
      if (data.length > 0) {
        sceneRef.current = data[0];
        setScene(data[0]);
        setSceneName(data[0].name);
        const objs = data[0].objects || [];
        setObjects(objs);
        pushHistory(objs, true);
      } else toast.error('Scène introuvable');
    } catch { toast.error('Erreur de chargement'); }
  };

  const createNewScene = async () => {
    const initObjs = [defaultObj('box')];
    try {
      const newScene = await base44.entities.Scene3D.create({ name: 'Scène sans titre', objects: initObjs });
      sceneRef.current = newScene;
      setScene(newScene);
      setObjects(initObjs);
      pushHistory(initObjs, true);
      // Also create a CloudFile entry so it appears in the drive
      try {
        await base44.entities.CloudFile.create({
          name: 'Mykel 3D — Scène sans titre',
          type: 'other',
          is_starred: false,
          is_trashed: false,
          content: { scene3d_id: newScene.id, app: 'Mykel3D' },
        });
      } catch {}
      window.history.replaceState({}, '', window.location.pathname + `?sceneId=${newScene.id}`);
    } catch { toast.error('Erreur création scène'); }
  };

  const save = useCallback(async () => {
    const sc = sceneRef.current;
    if (!sc) return;
    setSaving(true);
    try {
      await base44.entities.Scene3D.update(sc.id, {
        name: sceneNameRef.current,
        objects: objectsRef.current,
      });
      // Also sync CloudFile name
      try {
        const cloudFiles = await base44.entities.CloudFile.filter({ content: { scene3d_id: sc.id } });
        if (cloudFiles.length > 0) {
          await base44.entities.CloudFile.update(cloudFiles[0].id, { name: sceneNameRef.current });
        }
      } catch {}
      setLastSaved(new Date());
    } catch { toast.error('Erreur de sauvegarde'); }
    finally { setSaving(false); }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => { if (sceneRef.current) save(); }, 1500);
    return () => clearTimeout(t);
  }, [objects, sceneName]);

  const pushHistory = (objs, reset = false) => {
    setHistory(prev => {
      const h = reset ? [] : prev.slice(0, historyIdx + 1);
      const next = [...h, JSON.parse(JSON.stringify(objs))];
      setHistoryIdx(next.length - 1);
      return next;
    });
  };

  const setObjs = (objs) => { setObjects(objs); pushHistory(objs); };

  const undo = () => {
    setHistoryIdx(prev => {
      const idx = Math.max(0, prev - 1);
      setHistory(h => { setObjects(JSON.parse(JSON.stringify(h[idx] || []))); return h; });
      return idx;
    });
  };
  const redo = () => {
    setHistoryIdx(prev => {
      setHistory(h => {
        const idx = Math.min(h.length - 1, prev + 1);
        setObjects(JSON.parse(JSON.stringify(h[idx] || [])));
        return h;
      });
      return prev;
    });
  };

  const addObject = (shape) => {
    const o = defaultObj(shape);
    o.position.x = (Math.random() - 0.5) * 4;
    o.position.z = (Math.random() - 0.5) * 4;
    const next = [...objectsRef.current, o];
    setObjs(next);
    setSelectedId(o.id);
    setAddMenuOpen(false);
  };

  const deleteSelected = useCallback(() => {
    if (!selectedId) return;
    const next = objectsRef.current.filter(o => o.id !== selectedId);
    setObjs(next);
    setSelectedId(null);
  }, [selectedId]);

  const duplicateSelected = useCallback(() => {
    const obj = objectsRef.current.find(o => o.id === selectedId);
    if (!obj) return;
    const dup = { ...JSON.parse(JSON.stringify(obj)), id: genId(), name: obj.name + ' (copie)' };
    dup.position.x += 1; dup.position.z += 1;
    const next = [...objectsRef.current, dup];
    setObjs(next);
    setSelectedId(dup.id);
  }, [selectedId]);

  const toggleHide = useCallback(() => {
    const obj = objectsRef.current.find(o => o.id === selectedId);
    if (!obj) return;
    updateProp('visible', !obj.visible);
  }, [selectedId]);

  const handleObjectUpdate = useCallback((id, updates) => {
    setObjects(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
    setTimeout(() => { pushHistory(objectsRef.current); }, 0);
  }, []);

  const updateProp = (key, val) => {
    if (!selectedId) return;
    setObjects(prev => prev.map(o => o.id === selectedId ? { ...o, [key]: val } : o));
  };
  const updateSubProp = (key, axis, val) => {
    const obj = objects.find(o => o.id === selectedId);
    if (!obj) return;
    updateProp(key, { ...obj[key], [axis]: val });
  };

  const handleKeyAction = useCallback((action) => {
    if (action === 'delete') deleteSelected();
    else if (action === 'duplicate') duplicateSelected();
    else if (action === 'undo') undo();
    else if (action === 'redo') redo();
    else if (action === 'addMenu') setAddMenuOpen(true);
    else if (action === 'hide') toggleHide();
    else if (action === 'toggleNPanel') setNPanelOpen(p => !p);
    else if (action === 'toggleEditMode') setEditMode(p => !p);
    else if (action === 'selectAll') {
      if (objects.length > 0) setSelectedId(objects[0].id);
    }
  }, [deleteSelected, duplicateSelected, toggleHide, objects]);

  const selectedObj = objects.find(o => o.id === selectedId);

  const PVec3 = ({ label, objKey, step = 0.01 }) => {
    const obj = selectedObj;
    if (!obj) return null;
    const axisColors = { x: '#ff5555', y: '#55cc55', z: '#5588ff' };
    return (
      <div className="mb-3">
        <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">{label}</div>
        {['x', 'y', 'z'].map(ax => (
          <div key={ax} className="flex items-center gap-1.5 mb-1">
            <span className="text-xs font-bold w-3" style={{ color: axisColors[ax] }}>{ax.toUpperCase()}</span>
            <input
              type="number"
              step={step}
              value={Number(obj[objKey][ax]).toFixed(4)}
              onChange={e => updateSubProp(objKey, ax, parseFloat(e.target.value) || 0)}
              className="flex-1 h-6 text-xs rounded px-2 font-mono"
              style={{ background: '#2a2a2a', border: '1px solid #444', color: '#eee' }}
            />
          </div>
        ))}
      </div>
    );
  };

  const Section = ({ label, k, children }) => (
    <div className="border-b border-gray-700">
      <button
        className="w-full flex items-center justify-between px-3 py-2 text-xs font-semibold uppercase tracking-wider hover:bg-gray-800"
        style={{ color: '#ccc' }}
        onClick={() => setPropCollapse(prev => ({ ...prev, [k]: !prev[k] }))}
      >
        {label}
        {propCollapse[k] ? <ChevronRight className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>
      {!propCollapse[k] && <div className="px-3 py-2">{children}</div>}
    </div>
  );

  return (
    <div className="h-screen flex flex-col select-none overflow-hidden" style={{ background: '#1a1a1a', color: '#ddd' }}>
      {/* ── Top bar ───────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1.5 flex-shrink-0 border-b overflow-x-auto flex-nowrap" style={{ background: '#2a2a2a', borderColor: '#3a3a3a', minHeight: '42px' }}>
        <Link to="/" className="p-1.5 rounded hover:bg-gray-700 flex-shrink-0">
          <ChevronLeft className="w-4 h-4 text-gray-400" />
        </Link>
        <button onClick={() => setMobileOutliner(true)} className="md:hidden p-1.5 rounded hover:bg-gray-700 flex-shrink-0" title="Scène">
          <Box className="w-4 h-4 text-gray-400" />
        </button>

        <div className="w-7 h-7 rounded flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(135deg,#e68a00,#ff6600)' }}>
          <Box className="w-4 h-4 text-white" />
        </div>

        {editingName ? (
          <input value={sceneName} onChange={e => setSceneName(e.target.value)}
            onBlur={() => setEditingName(false)} onKeyDown={e => e.key === 'Enter' && setEditingName(false)}
            className="text-sm font-semibold bg-gray-800 border border-blue-500 rounded px-2 h-7 text-white w-48" autoFocus />
        ) : (
          <span className="text-sm font-semibold cursor-pointer hover:text-orange-400" onClick={() => setEditingName(true)}>
            {sceneName}
          </span>
        )}

        <span className="text-xs text-gray-600 ml-1">
          {saving ? '⌛ Sauvegarde...' : lastSaved ? `✓ ${lastSaved.toLocaleTimeString('fr-FR')}` : ''}
        </span>

        {/* Separator */}
        <div className="w-px h-6 bg-gray-600 mx-1" />

        {/* Undo / Redo */}
        <button onClick={undo} disabled={historyIdx <= 0}
          className="p-1.5 rounded hover:bg-gray-700 disabled:opacity-30" title="Annuler (Ctrl+Z)">
          <Undo2 className="w-4 h-4" />
        </button>
        <button onClick={redo} disabled={historyIdx >= history.length - 1}
          className="p-1.5 rounded hover:bg-gray-700 disabled:opacity-30" title="Rétablir (Ctrl+Shift+Z)">
          <Redo2 className="w-4 h-4" />
        </button>

        <div className="w-px h-6 bg-gray-600 mx-1" />

        {/* Transform modes */}
        {TRANSFORM_MODES.map(tm => (
          <button key={tm.id}
            onClick={() => setTransformMode(tm.id)}
            title={`${tm.label} (${tm.key})`}
            className="p-1.5 rounded flex items-center gap-1 text-xs"
            style={{ background: transformMode === tm.id ? '#e68a00' : 'transparent', color: transformMode === tm.id ? '#fff' : '#999' }}>
            <tm.icon className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">{tm.label}</span>
          </button>
        ))}

        <div className="w-px h-6 bg-gray-600 mx-1" />

        {/* Shading modes */}
        {SHADING_MODES.map(sm => (
          <button key={sm.id}
            onClick={() => setShadingMode(sm.id)}
            title={sm.label}
            className="px-2 py-1 rounded text-xs"
            style={{ background: shadingMode === sm.id ? '#555' : 'transparent', color: shadingMode === sm.id ? '#fff' : '#888' }}>
            {sm.icon} {sm.label}
          </button>
        ))}

        <div className="w-px h-6 bg-gray-600 mx-1" />

        {/* Edit mode */}
        <button
          onClick={() => setEditMode(p => !p)}
          title="Tab: Basculer mode édition"
          className="px-2 py-1 rounded text-xs font-semibold"
          style={{ background: editMode ? '#0055cc' : '#333', color: editMode ? '#fff' : '#888' }}>
          {editMode ? '◉ Mode Édition' : '◎ Mode Objet'}
        </button>

        <div className="flex-1" />

        {/* Add object button */}
        <button
          onClick={() => setAddMenuOpen(p => !p)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded text-sm font-medium"
          style={{ background: '#e68a00', color: '#fff' }}
          title="Ajouter (Shift+A)"
        >
          <Plus className="w-4 h-4" /> Ajouter
        </button>

        <button onClick={save} className="flex items-center gap-1 px-2 py-1.5 rounded text-xs hover:bg-gray-700" title="Sauvegarder">
          <Save className="w-3.5 h-3.5 text-gray-400" />
        </button>
      </div>

      {/* ── Main area ─────────────────────────────────────────────────────── */}
      <div className="flex-1 flex overflow-hidden">
        {/* Outliner (left) — desktop */}
        <div className="hidden md:flex w-52 flex-shrink-0 border-r flex-col" style={{ background: '#252525', borderColor: '#3a3a3a' }}>
          <div className="flex items-center justify-between px-3 py-1.5 border-b" style={{ borderColor: '#3a3a3a' }}>
            <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Scène</span>
            <button onClick={() => setOutlinerCollapse(p => !p)}>
              {outlinerCollapse ? <ChevronRight className="w-3 h-3 text-gray-500" /> : <ChevronDown className="w-3 h-3 text-gray-500" />}
            </button>
          </div>
          {!outlinerCollapse && (
            <div className="flex-1 overflow-y-auto">
              {objects.length === 0 && (
                <div className="text-xs text-gray-600 p-3">Scène vide</div>
              )}
              {objects.map(obj => (
                <div key={obj.id}
                  onClick={() => setSelectedId(obj.id === selectedId ? null : obj.id)}
                  className="flex items-center gap-1.5 px-2 py-1 cursor-pointer text-xs group"
                  style={{
                    background: selectedId === obj.id ? '#e68a0033' : 'transparent',
                    borderLeft: selectedId === obj.id ? '2px solid #e68a00' : '2px solid transparent',
                    opacity: obj.visible === false ? 0.4 : 1,
                  }}
                >
                  <span className="text-gray-500 w-4 flex-shrink-0">
                    {obj.shape.startsWith('light') ? '💡' : obj.shape === 'camera' ? '📷' : obj.shape === 'empty' ? '✚' : '⬜'}
                  </span>
                  <span className="flex-1 truncate" style={{ color: selectedId === obj.id ? '#e68a00' : '#ccc' }}>{obj.name}</span>
                  <button className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-gray-700"
                    onClick={e => { e.stopPropagation(); setObjects(prev => prev.map(o => o.id === obj.id ? { ...o, visible: !o.visible } : o)); }}>
                    {obj.visible !== false ? <Eye className="w-3 h-3 text-gray-400" /> : <EyeOff className="w-3 h-3 text-gray-600" />}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Mobile outliner overlay */}
        {mobileOutliner && (
          <div className="md:hidden fixed inset-0 z-50 flex">
            <div className="w-64 max-w-[80vw] flex flex-col border-r" style={{ background: '#252525', borderColor: '#3a3a3a' }}>
              <div className="flex items-center justify-between px-3 py-1.5 border-b" style={{ borderColor: '#3a3a3a' }}>
                <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Scène</span>
                <button onClick={() => setMobileOutliner(false)} className="text-gray-500 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                {objects.length === 0 && <div className="text-xs text-gray-600 p-3">Scène vide</div>}
                {objects.map(obj => (
                  <div key={obj.id}
                    onClick={() => { setSelectedId(obj.id === selectedId ? null : obj.id); setMobileOutliner(false); }}
                    className="flex items-center gap-1.5 px-2 py-1 cursor-pointer text-xs"
                    style={{ background: selectedId === obj.id ? '#e68a0033' : 'transparent', borderLeft: selectedId === obj.id ? '2px solid #e68a00' : '2px solid transparent', opacity: obj.visible === false ? 0.4 : 1 }}>
                    <span className="text-gray-500 w-4">{obj.shape.startsWith('light') ? '💡' : obj.shape === 'camera' ? '📷' : obj.shape === 'empty' ? '✚' : '⬜'}</span>
                    <span className="flex-1 truncate" style={{ color: selectedId === obj.id ? '#e68a00' : '#ccc' }}>{obj.name}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex-1 bg-black/50" onClick={() => setMobileOutliner(false)} />
          </div>
        )}

        {/* 3D Viewport */}
        <div className="flex-1 relative" style={{ background: '#393939' }}>
          {/* Edit mode indicator */}
          {editMode && (
            <div className="absolute top-2 left-2 z-10 px-2 py-1 rounded text-xs font-bold" style={{ background: '#0055cc', color: '#fff' }}>
              MODE ÉDITION
            </div>
          )}

          <Suspense fallback={
            <div className="w-full h-full flex items-center justify-center" style={{ background: '#393939' }}>
              <Loader2 className="w-8 h-8 animate-spin text-orange-400" />
            </div>
          }>
            <BlenderViewport
              objects={objects}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onObjectUpdate={handleObjectUpdate}
              shadingMode={shadingMode}
              editMode={editMode}
              onKeyAction={handleKeyAction}
            />
          </Suspense>

          {/* Add menu (Shift+A) */}
          {addMenuOpen && (
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-30 rounded shadow-2xl min-w-[220px]" style={{ background: '#2a2a2a', border: '1px solid #555' }}>
              <div className="px-3 py-2 text-xs font-semibold uppercase text-gray-400 border-b" style={{ borderColor: '#444' }}>Ajouter</div>
              <div className="py-1">
                <div className="px-3 py-1 text-xs text-gray-500 uppercase tracking-wider">Maillage</div>
                {SHAPES.mesh.map(s => (
                  <button key={s.id} onClick={() => addObject(s.id)}
                    className="w-full text-left px-4 py-1.5 text-sm hover:bg-blue-600 hover:text-white flex items-center gap-2" style={{ color: '#ccc' }}>
                    <span>{s.icon}</span>{s.label}
                  </button>
                ))}
                <div className="border-t my-1" style={{ borderColor: '#444' }} />
                <div className="px-3 py-1 text-xs text-gray-500 uppercase tracking-wider">Lumière</div>
                {SHAPES.lights.map(s => (
                  <button key={s.id} onClick={() => addObject(s.id)}
                    className="w-full text-left px-4 py-1.5 text-sm hover:bg-blue-600 hover:text-white flex items-center gap-2" style={{ color: '#ccc' }}>
                    <span>{s.icon}</span>{s.label}
                  </button>
                ))}
                <div className="border-t my-1" style={{ borderColor: '#444' }} />
                {SHAPES.other.map(s => (
                  <button key={s.id} onClick={() => addObject(s.id)}
                    className="w-full text-left px-4 py-1.5 text-sm hover:bg-blue-600 hover:text-white flex items-center gap-2" style={{ color: '#ccc' }}>
                    <span>{s.icon}</span>{s.label}
                  </button>
                ))}
              </div>
              <button onClick={() => setAddMenuOpen(false)}
                className="w-full text-center py-1.5 text-xs text-gray-500 hover:bg-gray-700 border-t" style={{ borderColor: '#444' }}>
                Fermer (Esc)
              </button>
            </div>
          )}
        </div>

        {/* N-Panel (right properties) — sidebar on desktop, bottom sheet on mobile */}
        {nPanelOpen && (
          <div className="w-full md:w-64 md:flex-shrink-0 border-l border-t md:border-t-0 flex flex-col overflow-y-auto max-h-[55vh] md:max-h-none fixed inset-x-0 bottom-0 z-40 md:static md:z-auto" style={{ background: '#252525', borderColor: '#3a3a3a' }}>
            <div className="flex items-center justify-between px-3 py-1.5 border-b" style={{ borderColor: '#3a3a3a' }}>
              <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Propriétés (N)</span>
              <button onClick={() => setNPanelOpen(false)} className="text-gray-500 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {selectedObj ? (
              <div className="flex-1">
                {/* Object name */}
                <div className="px-3 py-2 border-b" style={{ borderColor: '#3a3a3a' }}>
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider">Nom</div>
                  <input
                    value={selectedObj.name}
                    onChange={e => updateProp('name', e.target.value)}
                    className="w-full h-7 text-xs rounded px-2"
                    style={{ background: '#2a2a2a', border: '1px solid #555', color: '#eee' }}
                  />
                </div>

                {/* Transform */}
                <Section label="Transformation" k="transform">
                  <PVec3 label="Position" objKey="position" />
                  <PVec3 label="Rotation (°)" objKey="rotation" step={0.1} />
                  <PVec3 label="Échelle" objKey="scale" step={0.001} />
                  <button
                    onClick={() => updateProp('position', { x: 0, y: 0, z: 0 }) || updateProp('rotation', { x: 0, y: 0, z: 0 }) || updateProp('scale', { x: 1, y: 1, z: 1 })}
                    className="w-full text-xs py-1 rounded hover:bg-gray-700 text-gray-400 border mt-1"
                    style={{ borderColor: '#444' }}>
                    Réinitialiser tout
                  </button>
                </Section>

                {/* Material */}
                {!selectedObj.shape?.startsWith('light') && selectedObj.shape !== 'camera' && selectedObj.shape !== 'empty' && (
                  <Section label="Matériau" k="material">
                    <div className="mb-2">
                      <div className="text-xs text-gray-400 mb-1">Couleur de base</div>
                      <div className="flex items-center gap-2">
                        <input type="color" value={selectedObj.color || '#b0b0b0'}
                          onChange={e => updateProp('color', e.target.value)}
                          className="w-8 h-8 rounded cursor-pointer border-0 bg-transparent flex-shrink-0" />
                        <input value={selectedObj.color || '#b0b0b0'}
                          onChange={e => updateProp('color', e.target.value)}
                          className="flex-1 h-7 text-xs rounded px-2 font-mono"
                          style={{ background: '#2a2a2a', border: '1px solid #555', color: '#eee' }} />
                      </div>
                    </div>

                    <PropSlider label="Métal" value={selectedObj.metalness ?? 0} onChange={v => updateProp('metalness', v)} min={0} max={1} step={0.01} />
                    <PropSlider label="Rugosité" value={selectedObj.roughness ?? 0.5} onChange={v => updateProp('roughness', v)} min={0} max={1} step={0.01} />
                    <PropSlider label="Alpha" value={selectedObj.alpha ?? 1} onChange={v => updateProp('alpha', v)} min={0} max={1} step={0.01} />

                    <div className="mt-2 mb-1">
                      <div className="text-xs text-gray-400 mb-1">Émission</div>
                      <div className="flex items-center gap-2">
                        <input type="color" value={selectedObj.emission || '#000000'}
                          onChange={e => updateProp('emission', e.target.value)}
                          className="w-8 h-7 rounded cursor-pointer border-0 bg-transparent flex-shrink-0" />
                        <input value={selectedObj.emission || '#000000'}
                          onChange={e => updateProp('emission', e.target.value)}
                          className="flex-1 h-7 text-xs rounded px-2 font-mono"
                          style={{ background: '#2a2a2a', border: '1px solid #555', color: '#eee' }} />
                      </div>
                    </div>
                    <PropSlider label="Force émission" value={selectedObj.emissionStrength ?? 0} onChange={v => updateProp('emissionStrength', v)} min={0} max={10} step={0.1} />
                  </Section>
                )}

                {/* Display */}
                <Section label="Affichage" k="display">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-gray-400">Visible</span>
                    <button
                      onClick={() => updateProp('visible', !selectedObj.visible)}
                      className="p-1 rounded hover:bg-gray-700">
                      {selectedObj.visible !== false ? <Eye className="w-4 h-4 text-gray-300" /> : <EyeOff className="w-4 h-4 text-gray-600" />}
                    </button>
                  </div>
                </Section>

                {/* Actions */}
                <div className="px-3 py-3 space-y-2">
                  <button onClick={duplicateSelected}
                    className="w-full flex items-center justify-center gap-2 py-1.5 rounded text-xs hover:bg-gray-700"
                    style={{ background: '#333', color: '#ccc', border: '1px solid #555' }}>
                    <Copy className="w-3.5 h-3.5" /> Dupliquer (Shift+D)
                  </button>
                  <button onClick={deleteSelected}
                    className="w-full flex items-center justify-center gap-2 py-1.5 rounded text-xs"
                    style={{ background: '#5c1a1a', color: '#ff8888', border: '1px solid #7a2a2a' }}>
                    <Trash2 className="w-3.5 h-3.5" /> Supprimer (X)
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
                <Box className="w-10 h-10 text-gray-700 mb-3" />
                <p className="text-xs text-gray-500">Sélectionnez un objet<br/>pour voir ses propriétés</p>
                <p className="text-xs text-gray-600 mt-2">Clic gauche sur un objet<br/>ou dans l'outliner</p>
              </div>
            )}
          </div>
        )}

        {/* N-Panel toggle (when hidden) */}
        {!nPanelOpen && (
          <button
            onClick={() => setNPanelOpen(true)}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 px-1 py-4 rounded-l text-xs hover:bg-gray-700"
            style={{ background: '#2a2a2a', border: '1px solid #444', color: '#888' }}>
            N
          </button>
        )}
      </div>
    </div>
  );
}

function PropSlider({ label, value, onChange, min, max, step }) {
  return (
    <div className="mb-2">
      <div className="flex items-center justify-between mb-0.5">
        <span className="text-xs text-gray-400">{label}</span>
        <span className="text-xs font-mono text-gray-300">{Number(value).toFixed(2)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="w-full h-1.5 rounded cursor-pointer accent-orange-500" />
    </div>
  );
}