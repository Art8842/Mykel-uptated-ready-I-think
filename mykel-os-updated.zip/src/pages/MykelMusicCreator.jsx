import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { uploadMedia } from '@/lib/freeCore';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Music, Loader2, Plus, Clock, CheckCircle, Image as ImageIcon, Trash2 } from 'lucide-react';
import PublishTrackWizard from '@/components/music/PublishTrackWizard';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export default function MykelMusicCreator() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [creatorProfile, setCreatorProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('profile');
  const [tracks, setTracks] = useState([]);
  const [albums, setAlbums] = useState([]);
  const [showPublishWizard, setShowPublishWizard] = useState(false);
  const [editingProfile, setEditingProfile] = useState(false);
  const [stageName, setStageName] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [bannerUrl, setBannerUrl] = useState('');
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [deleteTrackDialog, setDeleteTrackDialog] = useState(null);
  const [deleteAlbumDialog, setDeleteAlbumDialog] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const avatarRef = useRef(null);
  const bannerRef = useRef(null);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    try {
      const u = await base44.auth.me();
      setUser(u);
      const profiles = await base44.entities.MusicCreatorProfile.filter({ user_email: u.email, active: true, validated: true });
      if (profiles.length === 0) {
        navigate(createPageUrl('MykelMusic'));
        return;
      }
      const p = profiles[0];
      setCreatorProfile(p);
      setStageName(p.stage_name || '');
      setBio(p.bio || '');
      setAvatarUrl(p.avatar_url || '');
      setBannerUrl(p.banner_url || '');

      const [myTracks, myAlbums] = await Promise.all([
        base44.entities.MusicTrack.filter({ creator_email: u.email }),
        base44.entities.MusicAlbum.filter({ creator_email: u.email }),
      ]);
      setTracks(myTracks);
      setAlbums(myAlbums);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarUpload = async (file) => {
    setUploadingAvatar(true);
    try {
      const { file_url } = await uploadMedia(file);
      setAvatarUrl(file_url);
    } catch { toast.error('Erreur upload image'); }
    finally { setUploadingAvatar(false); }
  };

  const handleBannerUpload = async (file) => {
    setUploadingBanner(true);
    try {
      const { file_url } = await uploadMedia(file);
      setBannerUrl(file_url);
    } catch { toast.error('Erreur upload bannière'); }
    finally { setUploadingBanner(false); }
  };

  const saveProfile = async () => {
    try {
      await base44.entities.MusicCreatorProfile.update(creatorProfile.id, {
        stage_name: stageName,
        bio,
        avatar_url: avatarUrl,
        banner_url: bannerUrl,
      });
      setCreatorProfile({ ...creatorProfile, stage_name: stageName, bio, avatar_url: avatarUrl, banner_url: bannerUrl });
      setEditingProfile(false);
      toast.success('Profil mis à jour');
    } catch { toast.error('Erreur sauvegarde'); }
  };

  const handleDeleteTrack = async () => {
    if (!deleteTrackDialog) return;
    setDeleting(true);
    try {
      await base44.entities.MusicTrack.delete(deleteTrackDialog.id);
      toast.success('Chanson supprimée');
      setDeleteTrackDialog(null);
      loadAll();
    } catch { toast.error('Erreur suppression'); }
    finally { setDeleting(false); }
  };

  const handleDeleteAlbum = async () => {
    if (!deleteAlbumDialog) return;
    setDeleting(true);
    try {
      // Delete all tracks from this album first
      const albumTracks = tracks.filter(t => t.album_id === deleteAlbumDialog.id);
      for (const t of albumTracks) {
        await base44.entities.MusicTrack.delete(t.id);
      }
      await base44.entities.MusicAlbum.delete(deleteAlbumDialog.id);
      toast.success('Album supprimé');
      setDeleteAlbumDialog(null);
      loadAll();
    } catch { toast.error('Erreur suppression'); }
    finally { setDeleting(false); }
  };

  if (loading) return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-gray-950 to-gray-900 flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
    </div>
  );

  const now = new Date();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-gray-950 to-gray-900 text-white">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-white/10">
        <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl('MykelMusic'))} className="text-white hover:bg-white/10">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2 flex-1">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
            <Music className="w-4 h-4 text-white" />
          </div>
          <span className="text-lg font-bold">Mykel Music — Créateur</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-4">
        {[
          { id: 'profile', label: "Ma page d'artiste" },
          { id: 'tracks', label: 'Mes publications' },
          { id: 'albums', label: 'Mes albums' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              activeTab === tab.id ? 'bg-purple-600 text-white' : 'text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="px-4 pb-20">

        {/* Profile Tab */}
        {activeTab === 'profile' && creatorProfile && (
          <div className="max-w-md mx-auto space-y-6">
            {/* Banner + Avatar */}
            <div className="relative w-full rounded-2xl overflow-hidden">
              <div
                className="w-full h-32 bg-gradient-to-br from-purple-900 via-gray-800 to-pink-900 overflow-hidden cursor-pointer relative group"
                onClick={() => bannerRef.current?.click()}
              >
                {bannerUrl
                  ? <img src={bannerUrl} className="w-full h-full object-cover" alt="" />
                  : <div className="w-full h-full flex items-center justify-center text-white/30 text-sm">Cliquez pour ajouter une bannière</div>}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  {uploadingBanner ? <Loader2 className="w-6 h-6 animate-spin text-white" /> : <ImageIcon className="w-6 h-6 text-white" />}
                </div>
              </div>
              <input ref={bannerRef} type="file" accept="image/*" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) handleBannerUpload(f); }} />
              {/* Avatar half on banner */}
              <div className="absolute -bottom-10 left-4">
                <div
                  className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden cursor-pointer relative group border-4 border-gray-950 shadow-xl"
                  onClick={() => avatarRef.current?.click()}
                >
                  {avatarUrl
                    ? <img src={avatarUrl} className="w-full h-full object-cover" alt="" />
                    : <Music className="w-10 h-10 text-white m-auto mt-5" />}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-full">
                    {uploadingAvatar ? <Loader2 className="w-5 h-5 animate-spin text-white" /> : <ImageIcon className="w-5 h-5 text-white" />}
                  </div>
                </div>
              </div>
              <input ref={avatarRef} type="file" accept="image/*" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) handleAvatarUpload(f); }} />
            </div>
            <p className="text-white/50 text-xs pt-10">Cliquez sur la bannière et l'avatar pour les modifier</p>

            {editingProfile ? (
              <div className="space-y-4">
                <div>
                  <Label className="text-white/80">Nom d'affiche</Label>
                  <Input value={stageName} onChange={e => setStageName(e.target.value)}
                    className="mt-1 bg-gray-800 border-gray-600 text-white" />
                </div>
                <div>
                  <Label className="text-white/80">Biographie</Label>
                  <textarea value={bio} onChange={e => setBio(e.target.value)} rows={4}
                    className="w-full mt-1 bg-gray-800 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm resize-none" />
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" className="flex-1 text-white/60" onClick={() => setEditingProfile(false)}>Annuler</Button>
                  <Button className="flex-1 bg-purple-600 hover:bg-purple-700" onClick={saveProfile}>Sauvegarder</Button>
                </div>
              </div>
            ) : (
              <div className="text-center space-y-3">
                <h2 className="text-2xl font-bold text-white">{creatorProfile.stage_name}</h2>
                {creatorProfile.bio && <p className="text-white/60 text-sm">{creatorProfile.bio}</p>}
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-900/40 rounded-full text-xs text-purple-300">
                  {creatorProfile.creator_type === 'music' ? '🎵 Musicien' : creatorProfile.creator_type === 'podcast' ? '🎙️ Podcasteur' : '🎵🎙️ Musicien & Podcasteur'}
                </div>
                <div>
                  <Button className="bg-white/10 hover:bg-white/20 text-white" onClick={() => setEditingProfile(true)}>
                    Modifier le profil
                  </Button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-purple-400">{tracks.length}</p>
                <p className="text-white/50 text-xs mt-1">Publication{tracks.length !== 1 ? 's' : ''}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-purple-400">{albums.length}</p>
                <p className="text-white/50 text-xs mt-1">Album{albums.length !== 1 ? 's' : ''}</p>
              </div>
            </div>
          </div>
        )}

        {/* Tracks Tab */}
        {activeTab === 'tracks' && (
          <div className="space-y-4">
            <Button
              className="w-full bg-purple-600 hover:bg-purple-700 gap-2"
              onClick={() => setShowPublishWizard(true)}
            >
              <Plus className="w-5 h-5" />
              Nouvelle publication
            </Button>

            {tracks.length === 0 ? (
              <div className="text-center py-20 text-white/40">
                <Music className="w-12 h-12 mx-auto mb-4" />
                <p>Aucune publication.<br />Créez votre première publication !</p>
              </div>
            ) : (
              <div className="space-y-3">
                {tracks.map(track => {
                  const pub = track.publish_at ? new Date(track.publish_at) : null;
                  const isPublished = pub && pub <= now;
                  const isAnnounced = track.announced && !isPublished;

                  return (
                    <div key={track.id} className="bg-white/5 rounded-xl p-4 flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden flex-shrink-0">
                        {track.album_cover_url
                          ? <img src={track.album_cover_url} className="w-full h-full object-cover" alt="" />
                          : <Music className="w-6 h-6 text-white m-auto mt-3" />
                        }
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-medium truncate">{track.title}</p>
                        <p className="text-white/50 text-xs truncate">{track.album_name || 'Single'}</p>
                        <p className="text-white/30 text-xs">
                          {isPublished ? '✅ Publié' : isAnnounced ? '📣 Annoncé' : '⏳ Programmé'}
                          {pub && ` — ${pub.toLocaleDateString('fr-FR')} ${pub.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`}
                        </p>
                      </div>
                      {isPublished
                        ? <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                        : <Clock className="w-5 h-5 text-purple-400 flex-shrink-0" />
                      }
                      <button
                        onClick={() => setDeleteTrackDialog(track)}
                        className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-all flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Albums Tab */}
        {activeTab === 'albums' && (
          <div className="space-y-4">
            {albums.length === 0 ? (
              <div className="text-center py-20 text-white/40">
                <Music className="w-12 h-12 mx-auto mb-4" />
                <p>Aucun album.<br />Publiez des morceaux regroupés en album.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {albums.map(album => {
                  const albumTracks = tracks.filter(t => t.album_id === album.id);
                  return (
                    <div key={album.id} className="bg-white/5 rounded-xl p-4 flex items-center gap-4">
                      <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 overflow-hidden flex-shrink-0">
                        {album.cover_url
                          ? <img src={album.cover_url} className="w-full h-full object-cover" alt="" />
                          : <Music className="w-6 h-6 text-white m-auto mt-4" />
                        }
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-medium truncate">{album.name}</p>
                        <p className="text-white/50 text-xs">{albumTracks.length} morceau(x)</p>
                        {album.release_date && (
                          <p className="text-white/30 text-xs">Sorti le {new Date(album.release_date).toLocaleDateString('fr-FR')}</p>
                        )}
                      </div>
                      <button
                        onClick={() => setDeleteAlbumDialog(album)}
                        className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-all flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Delete Track Confirm */}
      <Dialog open={!!deleteTrackDialog} onOpenChange={() => setDeleteTrackDialog(null)}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white">Supprimer la chanson ?</DialogTitle>
          </DialogHeader>
          <p className="text-white/60 text-sm">"{deleteTrackDialog?.title}" sera supprimée définitivement.</p>
          <DialogFooter>
            <Button variant="ghost" className="text-white/60" onClick={() => setDeleteTrackDialog(null)}>Annuler</Button>
            <Button onClick={handleDeleteTrack} disabled={deleting} className="bg-red-600 hover:bg-red-700">
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Supprimer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Album Confirm */}
      <Dialog open={!!deleteAlbumDialog} onOpenChange={() => setDeleteAlbumDialog(null)}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white">Supprimer l'album ?</DialogTitle>
          </DialogHeader>
          <p className="text-white/60 text-sm">"{deleteAlbumDialog?.name}" et tous ses morceaux seront supprimés définitivement.</p>
          <DialogFooter>
            <Button variant="ghost" className="text-white/60" onClick={() => setDeleteAlbumDialog(null)}>Annuler</Button>
            <Button onClick={handleDeleteAlbum} disabled={deleting} className="bg-red-600 hover:bg-red-700">
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Supprimer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <PublishTrackWizard
        open={showPublishWizard}
        onClose={() => setShowPublishWizard(false)}
        creatorProfile={creatorProfile}
        onPublished={loadAll}
      />
    </div>
  );
}