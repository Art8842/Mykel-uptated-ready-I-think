import React from 'react';
import NavigateurMykel from '@/components/shared/NavigateurMykel';

export default function MykelSearch() {
  return (
    <div className="h-screen overflow-hidden">
      <NavigateurMykel showSearchBar={true} showQuickLinks={true} />
    </div>
  );
}