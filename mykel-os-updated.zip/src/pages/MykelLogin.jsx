import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import AuthShell from '@/components/auth/AuthShell';
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import ForgotForm from '@/components/auth/ForgotForm';

// Re-export pour la compatibilité avec les imports existants
export { getMykelSession, setMykelSession, clearMykelSession } from '@/lib/mykelSession';

export default function MykelLogin() {
  const [params] = useSearchParams();
  const initialMode = params.get('mode') === 'register' ? 'register' : 'login';
  const [mode, setMode] = useState(initialMode); // 'login' | 'register' | 'forgot'

  return (
    <AuthShell>
      {mode === 'login' && (
        <LoginForm onSwitch={() => setMode('register')} onForgot={() => setMode('forgot')} />
      )}
      {mode === 'register' && (
        <RegisterForm onSwitch={() => setMode('login')} />
      )}
      {mode === 'forgot' && (
        <ForgotForm onBack={() => setMode('login')} />
      )}
    </AuthShell>
  );
}