import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { MousePointer2, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { getMykelSession } from '@/lib/mykelSession';
import { promptAction } from '@/lib/confirm';
import { uploadMedia } from '@/lib/freeCore';
import WhiteboardTopBar from '@/components/whiteboard/WhiteboardTopBar';
import WhiteboardTools from '@/components/whiteboard/WhiteboardTools';
import WhiteboardElement from '@/components/whiteboard/WhiteboardElement';
import SelectionBar from '@/components/whiteboard/SelectionBar';
import NewBoardScreen from '@/components/whiteboard/NewBoardScreen';
import ShareBoardDialog from '@/components/whiteboard/ShareBoardDialog';
import useBoardCursors from '@/hooks/useBoardCursors';
import {
  genElId, hitTest, translateEl, createShape, growShape, isDegenerate, textSize, DRAW_TOOLS,
} from '@/components/whiteboard/geometry';

const clampZoom = (z) => Math.max(0.2, Math.min(4, z));
const CURSORS = { hand: 'grab', select: 'default', eraser: 'cell' };

export default function MykelWhiteboard() {
  const navigate = useNavigate();
  const session = getMykelSession();
  const myEmail = session?.email || 'anonymous';
  const myName = session?.full_name || session?.email || 'Anonyme';

  const [loading, setLoading] = useState(true);
  const [board, setBoard] = useState(null);
  const [elements, setElements] = useState([]);
  const [tool, setTool] = useState('pen');
  const [color, setColor] = useState('#1e293b');
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [filled, setFilled] = useState(false);
  const [view, setView] = useState({ x: 0, y: 0, zoom: 1 });
  const [selectedId, setSelectedId] = useState(null);
  const [showShare, setShowShare] = useState(false);
  const [saving, setSaving] = useState(false);
  const [canUndo, setCanUndo] = useState(false);
  const [uploading, setUploading] = useState(false);

  const svgRef = useRef(null);
  const fileInputRef = useRef(null);
  const elementsRef = useRef([]);
  const dirtyRef = useRef(false);
  const undoRef = useRef([]);
  const actionRef = useRef(null);
  const { cursors, sendCursor } = useBoardCursors(board?.id, myEmail, myName);

  // Source de vérité synchrone : la ref est toujours à jour, l'état sert au rendu
  const updateElements = useCallback((updater) => {
    const next = typeof updater === 'function' ? updater(elementsRef.current) : updater;
    elementsRef.current = next;
    dirtyRef.current = true;
    setElements(next);
  }, []);

  const snapshot = () => {
    undoRef.current.push(elementsRef.current);
    if (undoRef.current.length > 50) undoRef.current.shift();
    setCanUndo(true);
  };

  const undo = () => {
    const prev = undoRef.current.pop();
    if (prev) { updateElements(prev); setSelectedId(null); }
    setCanUndo(undoRef.current.length > 0);
  };

  useEffect(() => {
    const boardId = new URLSearchParams(window.location.search).get('boardId');
    if (!boardId) { setLoading(false); return; }
    base44.entities.Whiteboard.get(boardId)
      .then(b => { setBoard(b); elementsRef.current = b.elements || []; setElements(b.elements || []); })
      .catch(() => toast.error('Tableau introuvable'))
      .finally(() => setLoading(false));
  }, []);

  const saveBoard = useCallback(async (silent) => {
    if (!board) return;
    dirtyRef.current = false;
    setSaving(true);
    try {
      await base44.entities.Whiteboard.update(board.id, { elements: elementsRef.current });
      if (!silent) toast.success('Tableau enregistré');
    } catch {
      dirtyRef.current = true;
      if (!silent) toast.error("Erreur lors de l'enregistrement");
    } finally {
      setSaving(false);
    }
  }, [board]);

  useEffect(() => {
    if (!board) return undefined;
    const timer = setInterval(() => { if (dirtyRef.current && !actionRef.current) saveBoard(true); }, 5000);
    return () => clearInterval(timer);
  }, [board, saveBoard]);

  const zoomAt = useCallback((factor, mx, my) => {
    setView(v => {
      const zoom = clampZoom(v.zoom * factor);
      return { zoom, x: mx - (mx - v.x) * (zoom / v.zoom), y: my - (my - v.y) * (zoom / v.zoom) };
    });
  }, []);

  const zoomBy = (factor) => {
    const r = svgRef.current?.getBoundingClientRect();
    if (r) zoomAt(factor, r.width / 2, r.height / 2);
  };

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return undefined;
    const onWheel = (e) => {
      e.preventDefault();
      const r = svg.getBoundingClientRect();
      zoomAt(e.deltaY > 0 ? 1 / 1.1 : 1.1, e.clientX - r.left, e.clientY - r.top);
    };
    svg.addEventListener('wheel', onWheel, { passive: false });
    return () => svg.removeEventListener('wheel', onWheel);
  }, [board?.id, zoomAt]);

  const toCanvas = (e) => {
    const r = svgRef.current.getBoundingClientRect();
    return { x: (e.clientX - r.left - view.x) / view.zoom, y: (e.clientY - r.top - view.y) / view.zoom };
  };

  const eraseAt = (p) => {
    const hit = hitTest(elementsRef.current, p, 6 / view.zoom);
    if (!hit) return;
    if (actionRef.current && !actionRef.current.snap) { snapshot(); actionRef.current.snap = true; }
    updateElements(prev => prev.filter(el => el.id !== hit.id));
  };

  const addText = async (p) => {
    const text = (await promptAction({ title: 'Ajouter du texte', placeholder: 'Votre texte…', confirmLabel: 'Ajouter' }))?.trim();
    if (!text) return;
    const fontSize = 12 + strokeWidth * 2;
    snapshot();
    const el = { id: genElId(), type: 'text', x: p.x, y: p.y, text, color, fontSize, ...textSize(text, fontSize) };
    updateElements(prev => [...prev, el]);
    setSelectedId(el.id);
    setTool('select');
  };

  const editElement = async (el) => {
    if (!el || (el.type !== 'text' && el.type !== 'sticky')) return;
    const text = await promptAction({ title: el.type === 'sticky' ? 'Modifier la note' : 'Modifier le texte', defaultValue: el.text || '', confirmLabel: 'Enregistrer' });
    if (text === null || text === undefined) return;
    snapshot();
    updateElements(prev => prev.map(x => {
      if (x.id !== el.id) return x;
      return x.type === 'text' ? { ...x, text, ...textSize(text, x.fontSize || 20) } : { ...x, text };
    }));
  };

  const onPointerDown = (e) => {
    if (e.button === 2) return;
    svgRef.current.setPointerCapture?.(e.pointerId);
    const p = toCanvas(e);
    const startPan = { mode: 'pan', sx: e.clientX - view.x, sy: e.clientY - view.y };
    if (e.button === 1 || tool === 'hand') { actionRef.current = startPan; return; }
    if (tool === 'select') {
      const hit = hitTest(elementsRef.current, p, 6 / view.zoom);
      setSelectedId(hit?.id || null);
      actionRef.current = hit ? { mode: 'move', id: hit.id, start: p, orig: hit, moved: false } : startPan;
      return;
    }
    if (tool === 'eraser') { actionRef.current = { mode: 'erase' }; eraseAt(p); return; }
    if (tool === 'text') { addText(p); return; }
    if (tool === 'sticky') {
      snapshot();
      const el = { id: genElId(), type: 'sticky', x: p.x, y: p.y, width: 180, height: 140, text: 'Nouvelle note', color: '#1e293b', fillColor: '#fef9c3' };
      updateElements(prev => [...prev, el]);
      setSelectedId(el.id);
      setTool('select');
      return;
    }
    if (DRAW_TOOLS.includes(tool)) {
      snapshot();
      const el = createShape(tool, p, { color, strokeWidth, filled });
      updateElements(prev => [...prev, el]);
      setSelectedId(null);
      actionRef.current = { mode: 'draw', id: el.id, start: p };
    }
  };

  const onPointerMove = (e) => {
    const p = toCanvas(e);
    sendCursor(p.x, p.y);
    const a = actionRef.current;
    if (!a) return;
    if (a.mode === 'pan') { setView(v => ({ ...v, x: e.clientX - a.sx, y: e.clientY - a.sy })); return; }
    if (a.mode === 'erase') { eraseAt(p); return; }
    if (a.mode === 'move') {
      const dx = p.x - a.start.x;
      const dy = p.y - a.start.y;
      if (!a.moved) {
        if (Math.hypot(dx, dy) * view.zoom < 2) return;
        snapshot();
        a.moved = true;
      }
      updateElements(prev => prev.map(el => (el.id === a.id ? translateEl(a.orig, dx, dy) : el)));
      return;
    }
    if (a.mode === 'draw') {
      updateElements(prev => prev.map(el => (el.id === a.id ? growShape(el, a.start, p, 1.5 / view.zoom) : el)));
    }
  };

  const onPointerUp = () => {
    const a = actionRef.current;
    actionRef.current = null;
    if (a?.mode !== 'draw') return;
    const el = elementsRef.current.find(x => x.id === a.id);
    if (el && isDegenerate(el)) {
      updateElements(prev => prev.filter(x => x.id !== a.id));
      undoRef.current.pop();
      setCanUndo(undoRef.current.length > 0);
    }
  };

  const onDoubleClick = (e) => {
    const hit = hitTest(elementsRef.current, toCanvas(e), 6 / view.zoom);
    if (hit && (hit.type === 'text' || hit.type === 'sticky')) { setSelectedId(hit.id); editElement(hit); }
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    snapshot();
    updateElements(prev => prev.filter(x => x.id !== selectedId));
    setSelectedId(null);
  };

  const patchSelected = (makePatch) => {
    const el = elementsRef.current.find(x => x.id === selectedId);
    const changes = el && makePatch(el);
    if (!changes) return;
    snapshot();
    updateElements(prev => prev.map(x => (x.id === el.id ? { ...x, ...changes } : x)));
  };

  const changeColor = (c) => {
    setColor(c);
    patchSelected(el => {
      if (el.type === 'image') return null;
      const hasFill = (el.type === 'rectangle' || el.type === 'circle') && el.fillColor && el.fillColor !== 'transparent';
      return hasFill ? { color: c, fillColor: `${c}33` } : { color: c };
    });
  };

  const changeStroke = (w) => {
    setStrokeWidth(w);
    patchSelected(el => (DRAW_TOOLS.includes(el.type) ? { strokeWidth: w } : null));
  };

  const toggleFill = (f) => {
    setFilled(f);
    patchSelected(el => (el.type === 'rectangle' || el.type === 'circle' ? { fillColor: f ? `${el.color}33` : 'transparent' } : null));
  };

  const selectTool = (id) => {
    if (id === 'image') { fileInputRef.current?.click(); return; }
    setTool(id);
    if (id !== 'select') setSelectedId(null);
  };

  const handleImageFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setUploading(true);
    try {
      const dims = await new Promise((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new window.Image();
        img.onload = () => { resolve({ w: img.naturalWidth, h: img.naturalHeight }); URL.revokeObjectURL(url); };
        img.onerror = () => resolve({ w: 4, h: 3 });
        img.src = url;
      });
      const { file_url } = await uploadMedia(file);
      const r = svgRef.current.getBoundingClientRect();
      const w = 260;
      const h = Math.round((w * dims.h) / Math.max(1, dims.w));
      const cx = (r.width / 2 - view.x) / view.zoom;
      const cy = (r.height / 2 - view.y) / view.zoom;
      snapshot();
      const el = { id: genElId(), type: 'image', x: cx - w / 2, y: cy - h / 2, width: w, height: h, src: file_url };
      updateElements(prev => [...prev, el]);
      setSelectedId(el.id);
      setTool('select');
      toast.success('Image ajoutée');
    } catch {
      toast.error("Erreur lors de l'import de l'image");
    } finally {
      setUploading(false);
    }
  };

  useEffect(() => {
    const onKey = (e) => {
      const tag = document.activeElement?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); return; }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedId) { e.preventDefault(); deleteSelected(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const createBoard = async (name) => {
    try {
      const b = await base44.entities.Whiteboard.create({ name, elements: [], owner_email: myEmail, shared_with: [], background: '#f8fafc' });
      elementsRef.current = [];
      setElements([]);
      setBoard(b);
      navigate(`/MykelWhiteboard?boardId=${b.id}`, { replace: true });
    } catch {
      toast.error('Erreur lors de la création');
    }
  };

  const shareBoard = async (email) => {
    const list = [...new Set([...(board.shared_with || []), email])];
    try {
      await base44.entities.Whiteboard.update(board.id, { shared_with: list });
      setBoard(b => ({ ...b, shared_with: list }));
      toast.success('Tableau partagé');
    } catch {
      toast.error('Erreur lors du partage');
    }
  };

  const handleBack = async () => {
    if (dirtyRef.current) await saveBoard(true);
    navigate('/Dashboard');
  };

  if (loading) {
    return <div className="h-screen bg-gray-50 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-amber-500" /></div>;
  }

  if (!board) return <NewBoardScreen onCreate={createBoard} onCancel={() => navigate('/Dashboard')} />;

  const selectedEl = elements.find(x => x.id === selectedId) || null;
  const cursorList = Object.entries(cursors);

  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      <WhiteboardTopBar name={board.name} saving={saving || uploading} canUndo={canUndo} onBack={handleBack} onUndo={undo} onShare={() => setShowShare(true)} onSave={() => saveBoard(false)} />
      <WhiteboardTools tool={tool} onTool={selectTool} color={color} onColor={changeColor} strokeWidth={strokeWidth} onStrokeWidth={changeStroke} filled={filled} onFilled={toggleFill} zoom={view.zoom} onZoom={zoomBy} />

      <div className="flex-1 relative overflow-hidden" style={{ background: board.background || '#f8fafc' }}>
        <div className="absolute inset-0 pointer-events-none opacity-60" style={{
          backgroundImage: 'radial-gradient(circle, #cbd5e1 1px, transparent 1px)',
          backgroundSize: `${20 * view.zoom}px ${20 * view.zoom}px`,
          backgroundPosition: `${view.x}px ${view.y}px`,
        }} />
        <svg
          ref={svgRef}
          className="absolute inset-0 w-full h-full select-none"
          style={{ touchAction: 'none', cursor: CURSORS[tool] || 'crosshair' }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          onDoubleClick={onDoubleClick}
        >
          <g transform={`translate(${view.x} ${view.y}) scale(${view.zoom})`} pointerEvents="none">
            {elements.map(el => <WhiteboardElement key={el.id} el={el} selected={el.id === selectedId} />)}
          </g>
        </svg>

        {cursorList.map(([id, c]) => (
          <div key={id} className="absolute pointer-events-none z-20" style={{ left: view.x + c.x * view.zoom, top: view.y + c.y * view.zoom }}>
            <MousePointer2 className="w-5 h-5 text-amber-600 fill-amber-500" />
            {cursorList.length >= 2 && <span className="ml-3 px-1.5 py-0.5 bg-amber-500 text-white text-xs rounded whitespace-nowrap">{c.name}</span>}
          </div>
        ))}

        <SelectionBar element={selectedEl} onEdit={() => editElement(selectedEl)} onDelete={deleteSelected} />
      </div>

      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageFile} />
      <ShareBoardDialog open={showShare} onOpenChange={setShowShare} sharedWith={board.shared_with || []} onShare={shareBoard} />
    </div>
  );
}