import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { confirmAction } from '@/lib/confirm';
import WallpaperTab from '@/components/store/WallpaperTab';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  FileText, Table, Presentation, Palette, Coins, HardDrive,
  ChevronLeft, Loader2, Gift, Users, Bug, Music, Sparkles,
  Zap, Crown, Star, Check, Gem, Package, Image, Wand2, X, Download, Tv, Building2, AlertCircle
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from 'sonner';
import { getMykelSession } from '@/lib/mykelSession';
import BusinessWizard from '@/components/store/BusinessWizard';

const APP_COLORS = {
  document:    { bg: 'bg-blue-500',    border: 'border-blue-200',   text: 'text-blue-600',   btn: 'bg-blue-500 hover:bg-blue-600' },
  spreadsheet: { bg: 'bg-green-500',   border: 'border-green-200',  text: 'text-green-600',  btn: 'bg-green-500 hover:bg-green-600' },
  presentation:{ bg: 'bg-orange-500',  border: 'border-orange-200', text: 'text-orange-600', btn: 'bg-orange-500 hover:bg-orange-600' },
  drawing:     { bg: 'bg-purple-500',  border: 'border-purple-200', text: 'text-purple-600', btn: 'bg-purple-500 hover:bg-purple-600' },
  snapfix:     { bg: 'bg-cyan-500',    border: 'border-cyan-200',   text: 'text-cyan-600',   btn: 'bg-cyan-500 hover:bg-cyan-600' },
};

const APP_ICONS = {
  document: FileText, spreadsheet: Table, presentation: Presentation, drawing: Palette, snapfix: Wand2,
};

// IA plan hierarchy: index = rank (higher = superior)
const IA_PLANS = [
  {
    key: 'ia_premium',
    rank: 0,
    label: 'Premium',
    icon: Star,
    iconBg: 'bg-gradient-to-br from-blue-400 to-cyan-400',
    btnColor: 'bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600',
    activeBorder: 'border-blue-400',
    badge: null,
    features: ['+5 questions par mois', '1 image IA par jour', 'Accès prioritaire'],
  },
  {
    key: 'ia_pro',
    rank: 1,
    label: 'Pro',
    icon: Zap,
    iconBg: 'bg-gradient-to-br from-violet-500 to-purple-500',
    btnColor: 'bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700',
    activeBorder: 'border-violet-500',
    badge: 'Populaire',
    badgeColor: 'bg-violet-500',
    features: ['+15 questions par mois', '5 images IA par jour', 'Accès prioritaire'],
  },
  {
    key: 'ia_max',
    rank: 2,
    label: 'Max',
    icon: Crown,
    iconBg: 'bg-gradient-to-br from-orange-400 to-yellow-400',
    btnColor: 'bg-gradient-to-r from-orange-400 to-yellow-400 hover:from-orange-500 hover:to-yellow-500',
    activeBorder: 'border-orange-400',
    badge: 'Meilleure offre',
    badgeColor: 'bg-orange-500',
    features: ['+30 questions par mois', '10 images IA par jour', 'Actions IA sur fichiers', 'Tri automatique IA'],
  },
];

function formatStorage(bytes) {
  if (!bytes) return '';
  const gb = bytes / (1024 ** 3);
  if (gb >= 1000) return `${(gb / 1024).toFixed(1)} To`;
  return `${Math.round(gb)} Go`;
}

export default function MykelStore() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userTokens, setUserTokens] = useState(null);
  const [apps, setApps] = useState([]);
  const [promos, setPromos] = useState([]);
  const [storagePackages, setStoragePackages] = useState([]);
  const [tokenRewards, setTokenRewards] = useState([]);
  const [storageSubscriptions, setStorageSubscriptions] = useState([]);
  const [musicSubscriptions, setMusicSubscriptions] = useState([]);
  const [tvSubscriptions, setTvSubscriptions] = useState([]);
  const [selectedApp, setSelectedApp] = useState(null);
  const [buyDialog, setBuyDialog] = useState(false);
  const [mykelOneApp, setMykelOneApp] = useState(null);
  const [mykelOnePrice, setMykelOnePrice] = useState(315);
  // Confirmation dialog
  const [confirmDialog, setConfirmDialog] = useState(null); // { type, label, action }
  const [billingAnnual, setBillingAnnual] = useState(false);
  const [confirmProcessing, setConfirmProcessing] = useState(false);
  const [businessWizardOpen, setBusinessWizardOpen] = useState(false);
  const [tvPlanDialogOpen, setTvPlanDialogOpen] = useState(false);
  const [betaDialogOpen, setBetaDialogOpen] = useState(false);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      let userData;
      try {
        userData = await base44.auth.me();
      } catch {
        const session = getMykelSession();
        if (!session) throw new Error('Non connecté');
        userData = { email: session.email, full_name: session.full_name, role: session.role };
      }
      setUser(userData);

      let userTokensData = await base44.entities.UserTokens.filter({ user_email: userData.email });
      if (userTokensData.length === 0) {
        userTokensData = [await base44.entities.UserTokens.create({
          user_email: userData.email, tokens: 0, owned_apps: [], daily_login_streak: 0
        })];
      }
      setUserTokens(userTokensData[0]);

      const safe = (p) => p.catch(() => []);
      const [appsData, promosData, packagesData, rewardsData, subsData, musicSubsData, tvSubsData, settingsList] = await Promise.all([
        safe(base44.entities.StoreApp.list()),
        safe(base44.entities.StorePromo.list()),
        safe(base44.entities.StoragePackage.list()),
        safe(base44.entities.TokenRewards.list()),
        safe(base44.entities.StorageSubscription.filter({ user_email: userData.email })),
        safe(base44.entities.MusicSubscription.filter({ user_email: userData.email })),
        safe(base44.entities.TVSubscription.filter({ user_email: userData.email })),
        safe(base44.entities.AppSettings.list()),
      ]);

      setApps(appsData);
      setPromos(promosData);
      setStoragePackages(packagesData);
      setTokenRewards(rewardsData);
      setStorageSubscriptions(subsData);
      setMusicSubscriptions(musicSubsData);
      setTvSubscriptions(tvSubsData);

      const onePriceSetting = settingsList.find(s => s.key === 'mykel_one_price');
      if (onePriceSetting) setMykelOnePrice(parseInt(onePriceSetting.value) || 315);

      const oneApp = appsData.find(a => a.app_type === 'ia_max');
      setMykelOneApp(oneApp);

      // Non-blocking checks (don't slow down page load)
      runBackgroundChecks(userTokensData[0], rewardsData, subsData, musicSubsData, tvSubsData).catch(() => {});
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Les contrôles partagent un même portefeuille pour que les débits ne s'écrasent pas entre eux
  const runBackgroundChecks = async (tokensData, rewards, storageSubs, musicSubs, tvSubs) => {
    const wallet = { id: tokensData.id, tokens: tokensData.tokens || 0 };
    await checkDailyLogin(tokensData, rewards, wallet);
    await checkSubscriptionPayments(storageSubs, 'StorageSubscription', wallet, 'Abonnement stockage annulé (solde insuffisant)');
    await checkSubscriptionPayments(musicSubs, 'MusicSubscription', wallet, 'Abonnement Music Premium annulé (solde insuffisant)');
    await checkSubscriptionPayments(tvSubs, 'TVSubscription', wallet, 'Abonnement TV annulé (solde insuffisant)');
    if (wallet.tokens !== (tokensData.tokens || 0)) {
      setUserTokens(prev => (prev ? { ...prev, tokens: wallet.tokens } : prev));
    }
  };

  const checkDailyLogin = async (tokensData, rewards, wallet) => {
    const today = new Date().toISOString().split('T')[0];
    const lastLogin = tokensData.last_login_date?.split('T')[0];
    if (lastLogin === today) return;
    let newStreak = 1;
    if (lastLogin) {
      const diff = Math.floor((new Date(today) - new Date(lastLogin)) / (1000 * 60 * 60 * 24));
      if (diff === 1) newStreak = (tokensData.daily_login_streak || 0) + 1;
    }
    if (newStreak >= 7) {
      const reward = rewards.find(r => r.action_type === 'daily_streak');
      const bonus = reward?.reward_amount || 10;
      wallet.tokens += bonus;
      newStreak = 0;
      toast.success(`🎉 Vous avez gagné ${bonus} jetons pour 7 jours de connexion !`);
    }
    await base44.entities.UserTokens.update(wallet.id, {
      last_login_date: new Date().toISOString(),
      daily_login_streak: newStreak,
      tokens: wallet.tokens,
    });
  };

  const checkSubscriptionPayments = async (subs, entityName, wallet, failMessage) => {
    const now = new Date();
    const seen = new Set();
    for (const sub of subs) {
      if (!sub.active) continue;
      const key = sub.package_id || sub.subscription_type || 'default';
      if (seen.has(key)) continue; // doublon d'un même abonnement : facturé une seule fois
      seen.add(key);
      if (!sub.next_payment_date || now < new Date(sub.next_payment_date)) continue;
      const price = sub.monthly_price || 0;
      if (wallet.tokens >= price) {
        wallet.tokens -= price;
        await base44.entities.UserTokens.update(wallet.id, { tokens: wallet.tokens });
        const next = new Date(sub.next_payment_date);
        next.setMonth(next.getMonth() + 1);
        await base44.entities[entityName].update(sub.id, { last_payment_date: now.toISOString(), next_payment_date: next.toISOString() });
      } else {
        await base44.entities[entityName].update(sub.id, { active: false });
        toast.error(failMessage);
      }
    }
  };

  const getAppPromo = (appId) => {
    const promo = promos.find(p => p.app_id === appId);
    return (promo && new Date(promo.end_date) > new Date()) ? promo : null;
  };

  // Get the highest IA rank currently owned
  const getHighestIARank = () => {
    let highest = -1;
    for (const plan of IA_PLANS) {
      const app = getIAPlanApp(plan);
      if (app && userTokens?.owned_apps?.includes(app.id)) {
        if (plan.rank > highest) highest = plan.rank;
      }
    }
    return highest;
  };

  const getIAPlanApp = (plan) => {
    if (plan.key === 'ia_pro') return apps.find(a => a.app_type === 'ia_premium' && a.name?.toLowerCase().includes('pro'));
    return apps.find(a => a.app_type === plan.key);
  };

  const hasMykelOne = () => {
    // Mykel One = owns ia_max AND has an active storage subscription
    const iaMaxApp = apps.find(a => a.app_type === 'ia_max');
    return iaMaxApp && userTokens?.owned_apps?.includes(iaMaxApp.id) && storageSubscriptions.some(s => s.active);
  };

  const handleBuyApp = async (app) => {
    if (!userTokens) { toast.error('Compte de jetons introuvable'); return; }
    const promo = getAppPromo(app.id);
    const finalPrice = promo ? (Number(promo.discounted_price) || 0) : (Number(app.price) || 0);
    if ((userTokens.tokens || 0) < finalPrice) { toast.error('Pas assez de jetons !'); return; }
    await base44.entities.UserTokens.update(userTokens.id, {
      tokens: userTokens.tokens - finalPrice,
      owned_apps: [...(userTokens.owned_apps || []), app.id]
    });
    toast.success(`${app.name} acheté !`);
    setBuyDialog(false);
    loadData();
  };

  const handleBuyBureautique = async (app) => {
    if (!userTokens) { toast.error('Compte de jetons introuvable'); return; }
    // Bureautique pack: unlock all doc/spreadsheet/presentation/drawing apps for free
    const promo = getAppPromo(app.id);
    const finalPrice = promo ? (Number(promo.discounted_price) || 0) : (Number(app.price) || 0);
    if ((userTokens.tokens || 0) < finalPrice) { toast.error('Pas assez de jetons !'); return; }
    const officeApps = apps.filter(a => ['document', 'spreadsheet', 'presentation', 'drawing'].includes(a.app_type));
    const newOwned = [...new Set([...(userTokens.owned_apps || []), app.id, ...officeApps.map(a => a.id)])];
    await base44.entities.UserTokens.update(userTokens.id, {
      tokens: userTokens.tokens - finalPrice,
      owned_apps: newOwned
    });
    toast.success('Pack Mykel Bureautique activé ! Tous les logiciels sont débloqués 🎉');
    setBuyDialog(false);
    loadData();
  };

  const handleSubscribeIA = async (app, isAnnual = false) => {
    if (!app) return;
    if (!userTokens) { toast.error('Compte de jetons introuvable'); return; }
    const price = isAnnual && app.annual_price ? (Number(app.annual_price) || 0) : (Number(app.price) || 0);
    if ((userTokens.tokens || 0) < price) { toast.error('Pas assez de jetons !'); return; }
    if (userTokens?.owned_apps?.includes(app.id)) { toast.error('Déjà abonné !'); return; }
    await base44.entities.UserTokens.update(userTokens.id, {
      tokens: userTokens.tokens - price,
      owned_apps: [...(userTokens.owned_apps || []), app.id]
    });
    toast.success(`${app.name} activé !`);
    loadData();
  };

  const handleCancelIA = async (app) => {
    if (!await confirmAction({ title: `Annuler ${app.name} ?`, destructive: true })) return;
    await base44.entities.UserTokens.update(userTokens.id, {
      owned_apps: userTokens.owned_apps.filter(id => id !== app.id)
    });
    toast.success('Abonnement annulé');
    loadData();
  };

  const handleSubscribeMykelOne = async (isAnnual = false) => {
    if (!userTokens) { toast.error('Compte de jetons introuvable'); return; }
    const basePrice = Number(mykelOnePrice) || 315;
    const price = isAnnual ? Math.round(basePrice * 12 * 0.8) : basePrice;
    if ((userTokens.tokens || 0) < price) { toast.error('Pas assez de jetons !'); return; }
    const iaMaxApp = apps.find(a => a.app_type === 'ia_max');
    const newOwned = [...new Set([...(userTokens.owned_apps || []), ...(iaMaxApp ? [iaMaxApp.id] : [])])];
    await base44.entities.UserTokens.update(userTokens.id, {
      tokens: userTokens.tokens - price,
      owned_apps: newOwned
    });
    const today = new Date(); const next = new Date(today);
    if (isAnnual) next.setFullYear(next.getFullYear() + 1); else next.setMonth(next.getMonth() + 1);
    await base44.entities.StorageSubscription.create({
      user_email: user.email, package_id: 'mykel_one', monthly_price: mykelOnePrice,
      storage_amount: -1, last_payment_date: today.toISOString(), next_payment_date: next.toISOString(), active: true
    });
    toast.success('Mykel One activé ! Bienvenue dans l\'expérience complète ✨');
    loadData();
  };

  const handleCancelMykelOne = async () => {
    if (!await confirmAction({ title: 'Annuler Mykel One ?', destructive: true })) return;
    const iaMaxApp = apps.find(a => a.app_type === 'ia_max');
    if (iaMaxApp) {
      await base44.entities.UserTokens.update(userTokens.id, {
        owned_apps: userTokens.owned_apps.filter(id => id !== iaMaxApp.id)
      });
    }
    const oneSub = storageSubscriptions.find(s => s.package_id === 'mykel_one' && s.active);
    if (oneSub) await base44.entities.StorageSubscription.update(oneSub.id, { active: false });
    toast.success('Mykel One annulé');
    loadData();
  };

  const handleSubscribeTV = async (app, isAnnual = false) => {
    if (!userTokens) { toast.error('Compte de jetons introuvable'); return; }
    const price = isAnnual && app.annual_price ? (Number(app.annual_price) || 0) : (Number(app.price) || 0);
    if ((userTokens.tokens || 0) < price) { toast.error('Pas assez de jetons !'); return; }
    const subType = app.app_type === 'tv_ads' ? 'ads' : app.app_type === 'tv_premium' ? 'premium' : 'plus';
    if (tvSubscriptions.find(s => s.active && s.subscription_type === subType)) { toast.error('Déjà abonné !'); return; }
    const today = new Date(); const next = new Date(today);
    if (isAnnual) next.setFullYear(next.getFullYear() + 1); else next.setMonth(next.getMonth() + 1);
    await base44.entities.UserTokens.update(userTokens.id, { tokens: userTokens.tokens - price });
    await base44.entities.TVSubscription.create({
      user_email: user.email, subscription_type: subType, monthly_price: app.price,
      active: true, last_payment_date: today.toISOString(), next_payment_date: next.toISOString(),
    });
    toast.success(`${app.name} activé !`);
    loadData();
  };

  const handleCancelTV = async (sub) => {
    if (!await confirmAction({ title: 'Annuler cet abonnement TV ?', destructive: true })) return;
    await base44.entities.TVSubscription.update(sub.id, { active: false });
    toast.success('Abonnement TV annulé');
    loadData();
  };

  const handleSubscribeStorage = async (pkg, isAnnual = false) => {
    if (!userTokens) { toast.error('Compte de jetons introuvable'); return; }
    const monthlyPrice = Number(pkg.monthly_price) || 0;
    const price = isAnnual ? Math.round(monthlyPrice * 12 * 0.8) : monthlyPrice;
    if ((userTokens.tokens || 0) < price) { toast.error('Pas assez de jetons !'); return; }
    const existing = storageSubscriptions.find(s => s.package_id === pkg.id && s.active);
    if (existing) { toast.error('Déjà abonné à ce pack !'); return; }

    const today = new Date(); const next = new Date(today);
    if (isAnnual) next.setFullYear(next.getFullYear() + 1); else next.setMonth(next.getMonth() + 1);

    // Le quota effectif = quota de base + abonnements actifs (calculé à l'affichage)
    await base44.entities.UserTokens.update(userTokens.id, { tokens: userTokens.tokens - price });
    await base44.entities.StorageSubscription.create({ user_email: user.email, package_id: pkg.id, monthly_price: pkg.monthly_price, storage_amount: pkg.storage_amount || 0, last_payment_date: today.toISOString(), next_payment_date: next.toISOString(), active: true });

    toast.success(`Abonnement souscrit ! +${formatStorage(pkg.storage_amount)} de stockage`);
    loadData();
  };

  const handleCancelSubscription = async (sub) => {
    if (!await confirmAction({ title: 'Annuler cet abonnement ?', destructive: true })) return;
    await base44.entities.StorageSubscription.update(sub.id, { active: false });
    toast.success('Abonnement annulé');
    loadData();
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  );

  const highestIARank = getHighestIARank();
  const mykelOneActive = hasMykelOne();
  const oneSub = storageSubscriptions.find(s => s.package_id === 'mykel_one' && s.active);

  // Apps to show: exclude music_premium, ia_premium, ia_max from regular apps tab
  const regularApps = apps.filter(a => !['ia_premium', 'ia_max', 'music_premium', 'tv_ads', 'tv_premium', 'tv_plus'].includes(a.app_type));
  const musicApp = apps.find(a => a.app_type === 'music_premium');
  const tvApps = apps.filter(a => ['tv_ads', 'tv_premium', 'tv_plus'].includes(a.app_type));

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Dashboard')}>
              <Button variant="ghost" size="icon"><ChevronLeft className="w-5 h-5" /></Button>
            </Link>
            <h1 className="text-2xl font-bold">Mykel Store</h1>
          </div>
          <Badge variant="outline" className="text-base px-4 py-2 gap-2">
            <Coins className="w-4 h-4 text-yellow-500" />
            {userTokens?.tokens || 0} jetons
          </Badge>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <Tabs defaultValue="ia">
          <TabsList className="mb-8 flex-wrap">
            <TabsTrigger value="ia">Mykel IA</TabsTrigger>
            <TabsTrigger value="apps">Applications</TabsTrigger>
            <TabsTrigger value="storage">Stockage</TabsTrigger>
            <TabsTrigger value="wallpapers">Fonds d'écran</TabsTrigger>
            <TabsTrigger value="earn">Jetons</TabsTrigger>
          </TabsList>

          {/* ── IA TAB ── */}
          <TabsContent value="ia">

            {/* Billing toggle — monthly/annual (global for all subscriptions) */}
            <div className="flex items-center justify-center mb-8">
              <div className="inline-flex items-center bg-gray-100 rounded-full p-1">
                <button
                  onClick={() => setBillingAnnual(false)}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${!billingAnnual ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}
                >
                  Mensuel
                </button>
                <button
                  onClick={() => setBillingAnnual(true)}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-1.5 ${billingAnnual ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}
                >
                  Annuel
                  <span className="text-xs text-green-600 font-bold">−20%</span>
                </button>
              </div>
            </div>

            {/* MYKEL ONE — shown first */}
            <div className="mb-10">
              <div className="flex items-center gap-2 mb-4">
                <span className="bg-gradient-to-r from-pink-500 to-violet-500 text-white text-xs font-bold px-3 py-1 rounded-full">⭐ Recommandé</span>
              </div>
              <div className="relative rounded-3xl overflow-hidden shadow-xl border-2 border-transparent p-[2px]"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899, #f59e0b, #10b981)' }}>
                <div className="bg-white rounded-3xl p-8">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899, #f59e0b)' }}>
                          <Gem className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <h2 className="text-2xl font-black text-gray-900">Mykel One</h2>
                          <p className="text-sm text-gray-500">L'expérience Mykel complète</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4">
                        {[
                          'Mykel IA Max inclus',
                          'Stockage One illimité',
                          'Logiciels bureautiques (à venir)',
                          '+30 questions IA par mois',
                          '10 images IA par jour',
                          'Actions IA sur fichiers',
                        ].map((f, i) => (
                          <div key={i} className="flex items-center gap-2 text-sm text-gray-700">
                            <Check className="w-4 h-4 text-violet-500 flex-shrink-0" />
                            {f}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex-shrink-0 text-center md:text-right">
                      <div className="mb-3">
                        <span className="text-4xl font-black text-gray-900">{billingAnnual ? Math.round(mykelOnePrice * 12 * 0.8) : mykelOnePrice}</span>
                        <span className="text-gray-500 ml-1">jetons / {billingAnnual ? 'an' : 'mois'}</span>
                        {billingAnnual && (
                          <div className="text-xs text-green-600 font-medium mt-1">Économisez {Math.round(mykelOnePrice * 12 * 0.2)} jetons/an</div>
                        )}
                      </div>
                      {mykelOneActive ? (
                        <div>
                          <div className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-white mb-2"
                            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899)' }}>
                            <Check className="w-5 h-5" /> Mykel One Actif
                          </div>
                          {oneSub && <p className="text-xs text-gray-400">Renouvellement : {new Date(oneSub.next_payment_date).toLocaleDateString('fr-FR')}</p>}
                          <button onClick={handleCancelMykelOne} className="mt-2 text-xs text-red-400 hover:text-red-600 underline">Annuler</button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmDialog({ type: 'subscribe', label: 'Mykel One', price: billingAnnual ? Math.round(mykelOnePrice * 12 * 0.8) : mykelOnePrice, period: billingAnnual ? 'an' : 'mois', action: () => handleSubscribeMykelOne(billingAnnual) })}
                          disabled={userTokens.tokens < (billingAnnual ? Math.round(mykelOnePrice * 12 * 0.8) : mykelOnePrice)}
                          className="px-8 py-3 rounded-2xl font-bold text-white disabled:opacity-40 transition-all hover:scale-105"
                          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899, #f59e0b)' }}
                        >
                          S'abonner à Mykel One
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* IA Plans */}
            <h2 className="text-xl font-bold text-gray-800 mb-6">Abonnements Mykel IA</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              {IA_PLANS.map((plan) => {
                const app = getIAPlanApp(plan);
                const owned = app && userTokens?.owned_apps?.includes(app.id);
                const higherOwned = highestIARank > plan.rank;
                const Icon = plan.icon;

                return (
                  <div key={plan.key} className={`relative bg-white rounded-2xl border-2 p-6 shadow-sm transition-all ${
                    owned ? plan.activeBorder : higherOwned ? 'border-gray-100 opacity-60' : 'border-gray-200 hover:shadow-md'
                  }`}>
                    {plan.badge && !higherOwned && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <span className={`${plan.badgeColor} text-white text-xs font-semibold px-3 py-1 rounded-full`}>{plan.badge}</span>
                      </div>
                    )}
                    {owned && (
                      <div className="absolute -top-3 right-4">
                        <span className="bg-green-500 text-white text-xs font-semibold px-3 py-1 rounded-full">Actif</span>
                      </div>
                    )}
                    <div className={`w-12 h-12 rounded-2xl ${plan.iconBg} flex items-center justify-center mb-4`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{plan.label}</h3>
                    <ul className="space-y-1 mb-4">
                      {plan.features.map((f, i) => (
                        <li key={i} className="text-sm text-gray-500">{f}</li>
                      ))}
                    </ul>
                    {app ? (
                      <>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-gray-900">{billingAnnual && app.annual_price ? app.annual_price : app.price}</span>
                          <span className="text-gray-500 ml-1 text-sm">jetons / {billingAnnual ? 'an' : 'mois'}</span>
                          {billingAnnual && app.annual_price && app.annual_price < app.price * 12 && (
                            <div className="text-xs text-green-600 font-medium mt-1">Économisez {app.price * 12 - app.annual_price} jetons/an</div>
                          )}
                        </div>
                        {higherOwned ? (
                          <button disabled className="w-full py-2.5 rounded-xl text-sm font-semibold bg-gray-100 text-gray-400 cursor-not-allowed">
                            Abonnement supérieur déjà souscrit
                          </button>
                        ) : owned ? (
                          <button onClick={() => handleCancelIA(app)}
                            className={`w-full py-2.5 rounded-xl font-semibold text-sm ${plan.btnColor} text-white flex items-center justify-center gap-2`}>
                            <Check className="w-4 h-4" /> Actif — Annuler
                          </button>
                        ) : (
                          <button onClick={() => setConfirmDialog({ type: 'subscribe', label: `Mykel IA ${plan.label}`, price: billingAnnual && app.annual_price ? app.annual_price : app.price, period: billingAnnual ? 'an' : 'mois', action: () => handleSubscribeIA(app, billingAnnual) })} disabled={userTokens.tokens < (billingAnnual && app.annual_price ? app.annual_price : app.price)}
                            className={`w-full py-2.5 rounded-xl font-semibold text-sm ${plan.btnColor} text-white disabled:opacity-40`}>
                            S'abonner
                          </button>
                        )}
                      </>
                    ) : (
                      <p className="text-sm text-gray-400 italic">Bientôt disponible</p>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Music Premium */}
            {musicApp && (
              <div>
                <h2 className="text-xl font-bold text-gray-800 mb-4">Autres abonnements</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <MusicCard app={musicApp} musicSubscriptions={musicSubscriptions} userTokens={userTokens} billingAnnual={billingAnnual}
                    onSubscribeClick={(app) => {
                      const price = billingAnnual && app.annual_price ? app.annual_price : app.price;
                      const period = billingAnnual ? 'an' : 'mois';
                      setConfirmDialog({ type: 'subscribe', label: 'Mykel Music Premium', price, period, action: async () => {
                        if (userTokens.tokens < price) { toast.error('Pas assez de jetons !'); return; }
                        if (musicSubscriptions.find(s => s.active)) { toast.error('Déjà abonné !'); return; }
                        const today = new Date(); const next = new Date(today);
                        if (billingAnnual) next.setFullYear(next.getFullYear() + 1); else next.setMonth(next.getMonth() + 1);
                        await base44.entities.UserTokens.update(userTokens.id, { tokens: userTokens.tokens - price });
                        await base44.entities.MusicSubscription.create({ user_email: user.email, monthly_price: app.price, active: true, last_payment_date: today.toISOString(), next_payment_date: next.toISOString() });
                        toast.success('Mykel Music Premium activé ! 🎵');
                        loadData();
                      }});
                    }}
                    onCancel={async (sub) => {
                      if (!await confirmAction({ title: 'Annuler Mykel Music Premium ?', destructive: true })) return;
                      await base44.entities.MusicSubscription.update(sub.id, { active: false });
                      toast.success('Abonnement Music Premium annulé');
                      loadData();
                    }}
                  />
                </div>
              </div>
            )}

            {/* TV Subscriptions — single hero card */}
            {tvApps.length > 0 && (
              <div className="mt-8">
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                    <Tv className="w-5 h-5 text-red-500" /> Mykel TV
                  </h2>
                </div>
                <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-gray-900 via-red-950 to-gray-900 p-6 md:p-10 text-white shadow-xl">
                  <div className="absolute -top-20 -right-20 w-64 h-64 bg-red-500/30 rounded-full blur-3xl" />
                  <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-rose-500/20 rounded-full blur-3xl" />
                  <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center gap-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-rose-600 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                      <Tv className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl md:text-3xl font-black mb-2">Mykel TV</h3>
                      <p className="text-gray-300 text-sm md:text-base max-w-md">Profitez d'avantages exclusifs et regardez vos films et séries préférés, partout, à tout moment.</p>
                    </div>
                    <button
                      onClick={() => setTvPlanDialogOpen(true)}
                      className="px-6 py-3 rounded-xl bg-white text-gray-900 font-bold text-sm hover:bg-gray-100 transition-all whitespace-nowrap shadow-lg w-full md:w-auto text-center"
                    >
                      Choisir une formule d'abonnement
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Mykel for Work / Business */}
            <div className="mt-8">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" /> Mykel for Work
              </h2>
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border-2 border-blue-200 p-6">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-4">
                  <Building2 className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-bold text-gray-900">Mykel Business</h3>
                  <button
                    onClick={() => setBetaDialogOpen(true)}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-bold border border-amber-300 hover:bg-amber-200 transition-colors"
                  >
                    <AlertCircle className="w-3 h-3" /> Bêta
                  </button>
                </div>
                <p className="text-sm text-gray-600 mb-4">Offrez des abonnements avantageux à vos employés. Prix sur mesure selon vos besoins, avec des réductions volume.</p>
                <button
                  onClick={() => setBusinessWizardOpen(true)}
                  className="px-6 py-2.5 rounded-xl text-white font-semibold bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700"
                >
                  Créer un abonnement
                </button>
              </div>
            </div>
          </TabsContent>

          {/* ── APPS TAB ── */}
          <TabsContent value="apps">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Applications disponibles</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
              {regularApps.map(app => {
                const isBureautique = app.name?.toLowerCase().includes('bureautique');
                const colors = APP_COLORS[app.app_type] || APP_COLORS.document;
                const Icon = APP_ICONS[app.app_type] || FileText;
                const promo = getAppPromo(app.id);
                const owned = userTokens?.owned_apps?.includes(app.id);
                const finalPrice = promo ? promo.discounted_price : app.price;

                // Check if this single app is included in a bureautique pack already owned
                const bureautiqueTypes = ['document', 'spreadsheet', 'presentation', 'drawing'];
                const bureautiquePack = apps.find(a => a.name?.toLowerCase().includes('bureautique'));
                const includedInPack = bureautiquePack && userTokens?.owned_apps?.includes(bureautiquePack.id) && bureautiqueTypes.includes(app.app_type);

                return (
                  <div key={app.id} className={`bg-white rounded-2xl border-2 ${colors.border} p-5 shadow-sm hover:shadow-md transition-all relative`}>
                    {isBureautique && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full">Pack complet</span>
                      </div>
                    )}
                    <div className={`w-12 h-12 ${isBureautique ? 'bg-gradient-to-br from-blue-500 to-indigo-600' : colors.bg} rounded-2xl flex items-center justify-center mb-4`}>
                      {isBureautique ? <Package className="w-6 h-6 text-white" /> : <Icon className="w-6 h-6 text-white" />}
                    </div>
                    <h3 className="font-bold text-gray-900 text-lg mb-1">{app.name}</h3>
                    <p className="text-gray-500 text-sm mb-4">{app.description}</p>
                    {isBureautique && (
                      <p className="text-xs text-blue-600 font-medium mb-3">✓ Inclut Word, Tabs, Sliders, Draws</p>
                    )}
                    {(owned || includedInPack) ? (
                      <span className={`inline-flex items-center gap-1 text-sm font-semibold ${colors.text}`}>
                        <Check className="w-4 h-4" /> {includedInPack && !owned ? 'Inclus dans le pack' : 'Possédé'}
                      </span>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div>
                          {promo ? (
                            <div className="flex items-center gap-2">
                              <span className="line-through text-gray-400 text-sm">{app.price} j</span>
                              <span className={`font-bold text-lg ${colors.text}`}>{promo.discounted_price} jetons</span>
                            </div>
                          ) : (
                            <span className={`font-bold text-lg ${colors.text}`}>{app.price} jetons</span>
                          )}
                        </div>
                        <button
                          onClick={() => setConfirmDialog({ type: 'buy', label: app.name, price: finalPrice, action: () => isBureautique ? handleBuyBureautique(app) : handleBuyApp(app) })}
                          disabled={userTokens.tokens < finalPrice}
                          className={`px-4 py-2 rounded-xl text-white text-sm font-semibold ${isBureautique ? 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700' : colors.btn} disabled:opacity-40`}
                        >
                          Acheter
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </TabsContent>

          {/* ── STORAGE TAB ── */}
          <TabsContent value="storage">
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Mes abonnements actifs</h2>
              {storageSubscriptions.filter(s => s.active).length > 0 ? (
                <div className="space-y-3">
                  {storageSubscriptions.filter(s => s.active).map(sub => {
                    const pkg = storagePackages.find(p => p.id === sub.package_id);
                    const isOne = sub.package_id === 'mykel_one';
                    return (
                      <div key={sub.id} className="bg-white rounded-xl border p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 ${isOne ? '' : 'bg-blue-100'} rounded-xl flex items-center justify-center`}
                            style={isOne ? { background: 'linear-gradient(135deg, #6366f1, #ec4899)' } : {}}>
                            {isOne ? <Gem className="w-5 h-5 text-white" /> : <HardDrive className="w-5 h-5 text-blue-600" />}
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{isOne ? 'Mykel One — Stockage' : pkg?.name}</p>
                            <p className="text-sm text-gray-500">{sub.monthly_price} jetons/mois · Renouvellement : {new Date(sub.next_payment_date).toLocaleDateString('fr-FR')}</p>
                          </div>
                        </div>
                        <Button variant="destructive" size="sm" onClick={() => isOne ? handleCancelMykelOne() : handleCancelSubscription(sub)}>Annuler</Button>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-gray-400 text-sm">Aucun abonnement actif</p>
              )}
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Packs disponibles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {storagePackages.map(pkg => {
                const isSubscribed = storageSubscriptions.some(s => s.package_id === pkg.id && s.active);
                const storageLabel = formatStorage(pkg.storage_amount);
                return (
                  <div key={pkg.id} className="bg-white rounded-2xl border-2 border-blue-100 p-5 shadow-sm hover:shadow-md transition-all">
                    <div className="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center mb-4">
                      <HardDrive className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold text-gray-900 text-lg mb-1">{pkg.name}</h3>
                    {storageLabel && (
                      <p className="text-sm text-blue-600 font-medium mb-2">📦 {storageLabel} de stockage</p>
                    )}
                    <div className="mb-4">
                      <p className="text-2xl font-bold text-blue-600">{billingAnnual ? Math.round(pkg.monthly_price * 12 * 0.8) : pkg.monthly_price}<span className="text-sm font-normal text-gray-500 ml-1">jetons / {billingAnnual ? 'an' : 'mois'}</span></p>
                      {billingAnnual && (
                        <p className="text-xs text-green-600 font-medium mt-1">Économisez {Math.round(pkg.monthly_price * 12 * 0.2)} jetons/an</p>
                      )}
                    </div>
                    {isSubscribed ? (
                      <span className="text-green-600 font-semibold flex items-center gap-1"><Check className="w-4 h-4" /> Abonné</span>
                    ) : (
                      <button onClick={() => setConfirmDialog({ type: 'subscribe', label: pkg.name, price: billingAnnual ? Math.round(pkg.monthly_price * 12 * 0.8) : pkg.monthly_price, period: billingAnnual ? 'an' : 'mois', action: () => handleSubscribeStorage(pkg, billingAnnual) })} disabled={userTokens.tokens < (billingAnnual ? Math.round(pkg.monthly_price * 12 * 0.8) : pkg.monthly_price)}
                        className="w-full py-2.5 rounded-xl text-white font-semibold bg-blue-500 hover:bg-blue-600 disabled:opacity-40">
                        S'abonner
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </TabsContent>

          {/* ── WALLPAPERS TAB ── */}
          <TabsContent value="wallpapers">
            <WallpaperTab user={user} userTokens={userTokens} onTokensUpdate={loadData} />
          </TabsContent>

          {/* ── EARN TAB ── */}
          <TabsContent value="earn">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Gagner des jetons</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <EarnCard icon={Gift} color="bg-yellow-500" title="Connexion quotidienne"
                desc={`Connectez-vous 7 jours d'affilée pour gagner ${tokenRewards.find(r => r.action_type === 'daily_streak')?.reward_amount || 10} jetons !`}
                extra={<p className="text-sm text-yellow-700 font-medium mt-2">Streak : {userTokens?.daily_login_streak || 0} / 7 jours</p>} />
              <EarnCard icon={Users} color="bg-green-500" title="Inviter des utilisateurs"
                desc={`Invitez des amis et gagnez ${tokenRewards.find(r => r.action_type === 'invite_user')?.reward_amount || 5} jetons par invitation !`} />
              <EarnCard icon={Bug} color="bg-red-500" title="Signaler un bug"
                desc={`Signalez un bug non découvert pour gagner ${tokenRewards.find(r => r.action_type === 'bug_report')?.reward_amount || 5} jetons !`}
                extra={<Link to={createPageUrl('ReportBug')}><Button size="sm" className="mt-3 bg-red-500 hover:bg-red-600">Signaler</Button></Link>} />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Confirm dialog */}
      <Dialog open={!!confirmDialog} onOpenChange={() => setConfirmDialog(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{confirmDialog?.type === 'subscribe' ? 'Souscrire à un abonnement' : 'Acheter une application'}</DialogTitle>
          </DialogHeader>
          <p className="text-gray-700">
            Êtes-vous sûr de vouloir {confirmDialog?.type === 'subscribe' ? 'souscrire à' : 'acheter'} <strong>{confirmDialog?.label}</strong> ?
          </p>
          <p className="font-bold text-lg text-gray-900">{confirmDialog?.price} jetons{confirmDialog?.type === 'subscribe' ? ` / ${confirmDialog?.period || 'mois'}` : ''}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmDialog(null)}>Annuler</Button>
            <Button onClick={async () => {
              setConfirmProcessing(true);
              try { await confirmDialog?.action(); } catch (e) { toast.error('Erreur lors de l\'opération'); console.error(e); }
              setConfirmProcessing(false);
              setConfirmDialog(null);
            }} disabled={confirmProcessing}>
              {confirmProcessing && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {confirmDialog?.type === 'subscribe' ? 'Souscrire' : 'Acheter'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {businessWizardOpen && (
        <BusinessWizard
          open={businessWizardOpen}
          onClose={() => setBusinessWizardOpen(false)}
          user={user}
          onCreated={() => loadData()}
        />
      )}

      {/* TV Plan Selection Dialog */}
      <Dialog open={tvPlanDialogOpen} onOpenChange={setTvPlanDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Tv className="w-5 h-5 text-red-500" /> Choisissez votre formule Mykel TV
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
            {tvApps.map(app => {
              const subType = app.app_type === 'tv_ads' ? 'ads' : app.app_type === 'tv_premium' ? 'premium' : 'plus';
              const activeSub = tvSubscriptions.find(s => s.active && s.subscription_type === subType);
              const displayPrice = billingAnnual && app.annual_price ? app.annual_price : app.price;
              const periodLabel = billingAnnual ? 'an' : 'mois';
              const tvTiers = { ads: 0, premium: 1, plus: 2 };
              const anyActiveSub = tvSubscriptions.find(s => s.active);
              const isHigherTier = anyActiveSub && tvTiers[anyActiveSub.subscription_type] > tvTiers[subType];
              return (
                <div key={app.id} className={`bg-white rounded-2xl border-2 p-5 ${activeSub ? 'border-red-400' : 'border-gray-200'}`}>
                  <h3 className="font-bold text-gray-900 mb-1">{app.name}</h3>
                  <p className="text-xs text-gray-500 mb-3">{app.description}</p>
                  {activeSub ? (
                    <div>
                      <span className="text-green-600 font-semibold text-sm flex items-center gap-1 mb-2"><Check className="w-4 h-4" /> Actif</span>
                      <Button variant="destructive" size="sm" onClick={() => { setTvPlanDialogOpen(false); handleCancelTV(activeSub); }}>Annuler</Button>
                    </div>
                  ) : isHigherTier ? (
                    <div className="text-xs text-gray-400 text-center py-2">Abonnement supérieur souscrit</div>
                  ) : (
                    <>
                      <div className="mb-3">
                        <span className="text-2xl font-bold text-gray-900">{displayPrice}</span>
                        <span className="text-gray-500 ml-1 text-xs">jetons / {periodLabel}</span>
                        {billingAnnual && app.annual_discount_percent > 0 && (
                          <span className="ml-2 text-xs bg-green-100 text-green-700 font-bold px-2 py-0.5 rounded-full">−{app.annual_discount_percent}%</span>
                        )}
                      </div>
                      <button
                        onClick={() => { setConfirmDialog({ type: 'subscribe', label: app.name, price: displayPrice, period: periodLabel, action: () => handleSubscribeTV(app, billingAnnual) }); setTvPlanDialogOpen(false); }}
                        disabled={userTokens.tokens < displayPrice}
                        className="w-full py-2 rounded-xl text-white font-semibold text-sm bg-gradient-to-r from-red-500 to-rose-600 disabled:opacity-40"
                      >
                        S'abonner
                      </button>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Beta Warning Dialog */}
      <Dialog open={betaDialogOpen} onOpenChange={setBetaDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-500" /> Mode Bêta
            </DialogTitle>
          </DialogHeader>
          <div className="pt-4 space-y-3">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <p className="text-sm text-amber-800">
                ⚠️ Le mode Mykel Business est actuellement en phase Bêta. Certaines fonctionnalités peuvent ne pas être encore totalement fonctionnelles ou stables.
              </p>
              <p className="text-sm text-amber-800 mt-2">
                Merci de rester vigilant avant de payer des jetons pour un abonnement Business. Nous vous recommandons de tester d'abord les fonctionnalités avant de vous engager.
              </p>
            </div>
            <Button className="w-full" onClick={() => setBetaDialogOpen(false)}>
              J'ai compris
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MusicCard({ app, musicSubscriptions, userTokens, onSubscribeClick, onCancel, billingAnnual }) {
  const activeSub = musicSubscriptions.find(s => s.active);
  const displayPrice = billingAnnual && app.annual_price ? app.annual_price : app.price;
  const periodLabel = billingAnnual ? 'an' : 'mois';
  return (
    <div className={`bg-white rounded-2xl border-2 p-6 shadow-sm ${activeSub ? 'border-pink-400' : 'border-pink-100'}`}>
      <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center mb-4">
        <Music className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-bold text-gray-900 mb-1">Music Premium</h3>
      <p className="text-sm text-gray-500 mb-4">{app.description || 'Musique sans publicité, qualité optimale'}</p>
      {activeSub ? (
        <div>
          <span className="text-green-600 font-semibold flex items-center gap-1 mb-2"><Check className="w-4 h-4" /> Premium actif</span>
          <p className="text-xs text-gray-400 mb-3">Prochain paiement : {new Date(activeSub.next_payment_date).toLocaleDateString('fr-FR')}</p>
          <Button variant="destructive" size="sm" onClick={() => onCancel(activeSub)}>Annuler</Button>
        </div>
      ) : (
        <>
          <div className="mb-4">
            <span className="text-3xl font-bold text-gray-900">{displayPrice}</span>
            <span className="text-gray-500 ml-1 text-sm">jetons / {periodLabel}</span>
            {billingAnnual && app.annual_price && app.annual_price < app.price * 12 && (
              <div className="text-xs text-green-600 font-medium mt-1">Économisez {app.price * 12 - app.annual_price} jetons/an</div>
            )}
          </div>
          <button onClick={() => onSubscribeClick(app)} disabled={userTokens.tokens < displayPrice}
            className="w-full py-2.5 rounded-xl text-white font-semibold bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 disabled:opacity-40">
            S'abonner
          </button>
        </>
      )}
    </div>
  );
}

function EarnCard({ icon: Icon, color, title, desc, extra }) {
  return (
    <div className="bg-white rounded-2xl border p-5 shadow-sm hover:shadow-md transition-all">
      <div className={`w-12 h-12 ${color} rounded-2xl flex items-center justify-center mb-4`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-500 text-sm">{desc}</p>
      {extra}
    </div>
  );
}