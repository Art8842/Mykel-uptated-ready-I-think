import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MusicPlayerProvider, useMusicPlayer } from './components/shared/MusicPlayerContext';
import FloatingMusicPlayer from './components/shared/FloatingMusicPlayer';
import { usePresenceTracker } from './hooks/usePresenceTracker';
import { base44 } from './api/base44Client';
import useLiquidGlass from './hooks/useLiquidGlass';

const MUSIC_PAGE = 'MykelMusic';

function LayoutInner({ children, currentPageName }) {
  const showFloatingPlayer = currentPageName !== MUSIC_PAGE;
  const { isPlaying, currentTrack } = useMusicPlayer();
  const [user, setUser] = useState(null);
  const [wallpaper, setWallpaper] = useState(() => localStorage.getItem('mykel_wallpaper') || null);
  const [wallpaperOpacity, setWallpaperOpacity] = useState(() => {
    const saved = localStorage.getItem('mykel_wallpaper_opacity');
    return saved ? parseFloat(saved) : 0.85;
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (e.detail.url !== undefined) setWallpaper(e.detail.url);
      if (e.detail.opacity !== undefined) setWallpaperOpacity(e.detail.opacity);
    };
    window.addEventListener('wallpaper-change', handler);
    return () => window.removeEventListener('wallpaper-change', handler);
  }, []);

  useLiquidGlass();

  const activityLabel = isPlaying && currentTrack
    ? `🎵 À l'écoute de Musique`
    : currentPageName ? `Sur ${currentPageName}` : 'En ligne';

  usePresenceTracker(user, currentPageName, activityLabel);

  return (
    <div
      className="min-h-screen bg-gray-50 dark:bg-gray-950 relative"
      style={{
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {/* Wallpaper layer */}
      {wallpaper && (
        <div
          className="fixed inset-0 z-0 pointer-events-none"
          style={{
            backgroundImage: `url('${wallpaper}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            opacity: wallpaperOpacity,
          }}
        />
      )}
      {/* Content layer */}
      <div className="relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPageName}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
        {showFloatingPlayer && <FloatingMusicPlayer />}
      </div>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <MusicPlayerProvider>
      <LayoutInner currentPageName={currentPageName}>
        {children}
      </LayoutInner>
    </MusicPlayerProvider>
  );
}