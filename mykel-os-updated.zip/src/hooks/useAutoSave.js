import { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { saveCloudFile, isTransientError, saveErrorMessage } from '@/lib/cloudSave';
import { useLanguage } from '@/lib/LanguageContext';

const MAX_WAIT = 8000;

// Sauvegarde automatique : n'écrit que si le contenu a changé, regroupe les
// modifications, réessaie en cas d'échec et enregistre en quittant la page.
// status: idle | dirty | saving | saved | error
export default function useAutoSave(fileId, { enabled = true, delay = 1500 } = {}) {
  const { lang } = useLanguage();
  const [status, setStatus] = useState('idle');
  const [lastSaved, setLastSaved] = useState(null);
  const idRef = useRef(fileId);
  const enabledRef = useRef(enabled);
  const langRef = useRef(lang);
  const readyRef = useRef(false);
  const latestRef = useRef(null);
  const savedJsonRef = useRef(null);
  const timerRef = useRef(null);
  const dirtySinceRef = useRef(0);
  const errorShownRef = useRef(false);
  idRef.current = fileId;
  enabledRef.current = enabled;
  langRef.current = lang;

  const flush = useCallback(async (force = false) => {
    clearTimeout(timerRef.current);
    dirtySinceRef.current = 0;
    const id = idRef.current;
    const payload = latestRef.current;
    if (!id || !payload || !enabledRef.current || !readyRef.current) return true;
    const json = JSON.stringify(payload);
    if (!force && json === savedJsonRef.current) return true;
    setStatus('saving');
    try {
      await saveCloudFile(id, payload);
      savedJsonRef.current = json;
      errorShownRef.current = false;
      setLastSaved(new Date());
      setStatus(JSON.stringify(latestRef.current) === json ? 'saved' : 'dirty');
      return true;
    } catch (e) {
      setStatus('error');
      if (!errorShownRef.current) {
        errorShownRef.current = true;
        toast.error(saveErrorMessage(e, langRef.current));
      }
      if (isTransientError(e)) timerRef.current = setTimeout(() => flush(), 15000);
      return false;
    }
  }, []);

  const queue = useCallback((payload) => {
    latestRef.current = payload;
    if (!readyRef.current || !enabledRef.current) return;
    if (JSON.stringify(payload) === savedJsonRef.current) return;
    setStatus('dirty');
    if (!dirtySinceRef.current) dirtySinceRef.current = Date.now();
    const wait = Date.now() - dirtySinceRef.current >= MAX_WAIT ? 0 : delay;
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => flush(), wait);
  }, [delay, flush]);

  const setBaseline = useCallback((payload) => {
    latestRef.current = payload;
    savedJsonRef.current = JSON.stringify(payload);
    readyRef.current = true;
    setStatus('saved');
  }, []);

  const saveNow = useCallback(() => flush(true), [flush]);

  useEffect(() => {
    const onHide = () => { if (document.visibilityState === 'hidden') flush(); };
    const onPageHide = () => flush();
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', onPageHide);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', onPageHide);
      flush();
    };
  }, [flush]);

  return { status, lastSaved, queue, setBaseline, saveNow };
}