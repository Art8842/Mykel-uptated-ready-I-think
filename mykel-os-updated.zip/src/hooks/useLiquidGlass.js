import { useEffect } from 'react';

const LIQUID_GLASS_CSS = `
/* ============================================================
   MYKEL LIQUID GLASS — Subtle frosted glass, iOS-inspired
   ============================================================ */

@keyframes lg-shimmer {
  0%   { transform: translateX(-120%) skewX(-12deg); opacity: 0; }
  30%  { opacity: 1; }
  100% { transform: translateX(220%) skewX(-12deg); opacity: 0; }
}

/* ── BUTTONS — tinted glass, preserve size & layout ─────── */
.liquid-glass-enabled button:not(.no-glass):not([disabled]) {
  position: relative !important;
  overflow: hidden !important;
  backdrop-filter: blur(12px) saturate(150%) !important;
  -webkit-backdrop-filter: blur(12px) saturate(150%) !important;
  box-shadow:
    0 1px 4px rgba(0,0,0,0.10),
    inset 0 1px 0 rgba(255,255,255,0.30),
    inset 0 -1px 0 rgba(0,0,0,0.05) !important;
  border-radius: var(--radius, 8px) !important;
  transition: box-shadow 0.2s ease, transform 0.15s ease !important;
}

/* Keep background color as-is — only add shimmer on hover */
.liquid-glass-enabled button:not(.no-glass):not([disabled])::before {
  content: '' !important;
  position: absolute !important;
  top: 0 !important; left: 0 !important;
  width: 50% !important; height: 100% !important;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.20), transparent) !important;
  opacity: 0 !important;
  pointer-events: none !important;
  z-index: 1 !important;
}
.liquid-glass-enabled button:not(.no-glass):not([disabled]):hover::before {
  opacity: 1 !important;
  animation: lg-shimmer 0.55s ease forwards !important;
}

.liquid-glass-enabled button:not(.no-glass):not([disabled]):hover {
  box-shadow:
    0 3px 10px rgba(0,0,0,0.13),
    inset 0 1px 0 rgba(255,255,255,0.38),
    inset 0 -1px 0 rgba(0,0,0,0.04) !important;
  transform: translateY(-1px) !important;
}

.liquid-glass-enabled button:not(.no-glass):not([disabled]):active {
  transform: translateY(0px) scale(0.99) !important;
  box-shadow:
    0 1px 3px rgba(0,0,0,0.08),
    inset 0 2px 3px rgba(0,0,0,0.08) !important;
}

/* ── SIDEBAR ────────────────────────────────────────────── */
.liquid-glass-enabled aside {
  backdrop-filter: blur(20px) saturate(140%) !important;
  -webkit-backdrop-filter: blur(20px) saturate(140%) !important;
  background: rgba(255,255,255,0.05) !important;
  border-right: 1px solid rgba(255,255,255,0.10) !important;
}

/* ── HEADER / NAV ───────────────────────────────────────── */
.liquid-glass-enabled header,
.liquid-glass-enabled nav {
  backdrop-filter: blur(24px) saturate(150%) !important;
  -webkit-backdrop-filter: blur(24px) saturate(150%) !important;
  background: rgba(255,255,255,0.06) !important;
  border-bottom: 1px solid rgba(255,255,255,0.10) !important;
}

/* ── DROPDOWNS / POPOVERS ───────────────────────────────── */
.liquid-glass-enabled [data-radix-popper-content-wrapper] > div,
.liquid-glass-enabled [role="menu"],
.liquid-glass-enabled [role="listbox"] {
  backdrop-filter: blur(32px) saturate(180%) brightness(1.05) !important;
  -webkit-backdrop-filter: blur(32px) saturate(180%) brightness(1.05) !important;
  background: rgba(255,255,255,0.80) !important;
  border: 1px solid rgba(255,255,255,0.50) !important;
  box-shadow:
    0 16px 48px rgba(0,0,0,0.14),
    inset 0 1px 0 rgba(255,255,255,0.70) !important;
  border-radius: 14px !important;
}
`;

export function injectLiquidGlassCSS() {
  const styleId = 'liquid-glass-style';
  let el = document.getElementById(styleId);
  if (!el) { el = document.createElement('style'); el.id = styleId; document.head.appendChild(el); }
  el.textContent = LIQUID_GLASS_CSS;
}

export function removeLiquidGlassCSS() {
  document.getElementById('liquid-glass-style')?.remove();
}

export default function useLiquidGlass() {
  useEffect(() => {
    if (localStorage.getItem('liquid_glass_enabled') === 'true') {
      document.documentElement.classList.add('liquid-glass-enabled');
      injectLiquidGlassCSS();
    }
  }, []);
}