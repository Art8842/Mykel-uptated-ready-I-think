import { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';

const ICE_SERVERS = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

function waitIce(pc) {
  return new Promise((resolve) => {
    if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') return resolve();
    const check = () => {
      if (pc.iceGatheringState === 'complete') {
        pc.removeEventListener('icegatheringstatechange', check);
        resolve();
      }
    };
    pc.addEventListener('icegatheringstatechange', check);
    setTimeout(resolve, 2000);
  });
}

export function useMeetRoom({ room, userId, userEmail, displayName, onLeave }) {
  const [status, setStatus] = useState('idle');
  const [participants, setParticipants] = useState({});
  const [localStream, setLocalStream] = useState(null);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [error, setError] = useState('');

  const pcRef = useRef({});
  const localStreamRef = useRef(null);
  const activeVideoRef = useRef(null);
  const remoteStreamsRef = useRef({});
  const unsubRef = useRef(null);
  const userIdRef = useRef(userId);
  const leftRef = useRef(false);

  useEffect(() => { userIdRef.current = userId; }, [userId]);

  const sendSignal = useCallback(async (kind, toId, payload = {}) => {
    try {
      await base44.entities.MeetSignal.create({
        room, from_id: userIdRef.current, from_email: userEmail,
        to_id: toId || '', kind, payload,
      });
    } catch {}
  }, [room, userEmail]);

  const createPeer = useCallback((peerId) => {
    if (pcRef.current[peerId]) return pcRef.current[peerId];
    const pc = new RTCPeerConnection(ICE_SERVERS);
    pcRef.current[peerId] = peerId;

    const stream = remoteStreamsRef.current[peerId] || new MediaStream();
    remoteStreamsRef.current[peerId] = stream;

    pc.ontrack = (ev) => {
      const s = remoteStreamsRef.current[peerId];
      if (ev.track.kind === 'video') {
        const old = s.getVideoTracks()[0];
        if (old) s.removeTrack(old);
        s.addTrack(ev.track);
      } else {
        const old = s.getAudioTracks()[0];
        if (old) s.removeTrack(old);
        s.addTrack(ev.track);
      }
      setParticipants(prev => ({ ...prev, [peerId]: { ...(prev[peerId] || {}), stream: s } }));
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate) sendSignal('ice', peerId, { candidate: ev.candidate.toJSON() });
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
        setParticipants(prev => { const n = { ...prev }; delete n[peerId]; return n; });
      }
    };

    pcRef.current[peerId] = pc;
    return pc;
  }, [sendSignal]);

  const handleSignal = useCallback(async (sig) => {
    if (sig.from_id === userIdRef.current) return;
    const peerId = sig.from_id;

    if (sig.kind === 'leave') {
      const pc = pcRef.current[peerId];
      if (pc) { try { pc.close(); } catch {} }
      delete pcRef.current[peerId];
      delete remoteStreamsRef.current[peerId];
      setParticipants(prev => { const n = { ...prev }; delete n[peerId]; return n; });
      return;
    }

    if (sig.kind === 'hello') {
      if (!pcRef.current[peerId]) {
        const pc = createPeer(peerId);
        const ls = localStreamRef.current;
        if (ls) {
          ls.getAudioTracks().forEach(t => pc.addTrack(t, ls));
          const vt = activeVideoRef.current || ls.getVideoTracks()[0];
          if (vt) pc.addTrack(vt, ls);
        }
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await waitIce(pc);
        sendSignal('offer', peerId, { sdp: pc.localDescription });
      }
      return;
    }

    const pc = pcRef.current[peerId] || createPeer(peerId);

    if (sig.kind === 'offer') {
      await pc.setRemoteDescription(new RTCSessionDescription(sig.payload.sdp));
      const ls = localStreamRef.current;
      if (ls) {
        ls.getAudioTracks().forEach(t => { if (!pc.getSenders().some(s => s.track === t)) pc.addTrack(t, ls); });
        const vt = activeVideoRef.current || ls.getVideoTracks()[0];
        if (vt && !pc.getSenders().some(s => s.track === vt)) pc.addTrack(vt, ls);
      }
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await waitIce(pc);
      sendSignal('answer', peerId, { sdp: pc.localDescription });
    } else if (sig.kind === 'answer') {
      if (pc.signalingState !== 'stable') await pc.setRemoteDescription(new RTCSessionDescription(sig.payload.sdp));
    } else if (sig.kind === 'ice') {
      try { await pc.addIceCandidate(new RTCIceCandidate(sig.payload.candidate)); } catch {}
    }
  }, [createPeer, sendSignal]);

  const join = useCallback(async () => {
    setError('');
    leftRef.current = false;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      localStreamRef.current = stream;
      activeVideoRef.current = stream.getVideoTracks()[0] || null;
      setLocalStream(stream);
      setMicOn(true);
      setCamOn(true);
    } catch (e) {
      // fallback: audio-only
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localStreamRef.current = stream;
        activeVideoRef.current = null;
        setLocalStream(stream);
        setCamOn(false);
        setMicOn(true);
      } catch (err) {
        setError('Impossible d\'accéder à la caméra/micro. Vérifiez les permissions.');
        return;
      }
    }

    setStatus('connected');
    sendSignal('hello', '');
  }, [sendSignal]);

  const leave = useCallback(() => {
    if (leftRef.current) return;
    leftRef.current = true;
    sendSignal('leave', '');
    setTimeout(() => {
      try { base44.entities.MeetSignal.deleteMany({ room }); } catch {}
    }, 1500);
    Object.values(pcRef.current).forEach(pc => { try { pc.close(); } catch {} });
    pcRef.current = {};
    remoteStreamsRef.current = {};
    localStreamRef.current?.getTracks().forEach(t => t.stop());
    localStreamRef.current = null;
    setLocalStream(null);
    setParticipants({});
    setStatus('idle');
    onLeave?.();
  }, [sendSignal, onLeave]);

  const toggleMic = useCallback(() => {
    const s = localStreamRef.current;
    if (!s) return;
    const next = !micOn;
    s.getAudioTracks().forEach(t => { t.enabled = next; });
    setMicOn(next);
  }, [micOn]);

  const toggleCam = useCallback(() => {
    const s = localStreamRef.current;
    if (!s) return;
    const next = !camOn;
    s.getVideoTracks().forEach(t => { t.enabled = next; });
    setCamOn(next);
  }, [camOn]);

  const toggleScreenShare = useCallback(async () => {
    const s = localStreamRef.current;
    if (!s) return;
    const oldVideo = activeVideoRef.current;
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      const newTrack = display.getVideoTracks()[0];
      activeVideoRef.current = newTrack;
      Object.values(pcRef.current).forEach(pc => {
        const sender = pc.getSenders().find(sd => sd.track && sd.track.kind === 'video');
        if (sender) sender.replaceTrack(newTrack);
      });
      setLocalStream(new MediaStream([newTrack, ...s.getAudioTracks()]));
      newTrack.onended = async () => {
        activeVideoRef.current = oldVideo;
        if (oldVideo) {
          Object.values(pcRef.current).forEach(pc => {
            const sender = pc.getSenders().find(sd => sd.track && sd.track.kind === 'video');
            if (sender) sender.replaceTrack(oldVideo);
          });
          setLocalStream(new MediaStream([oldVideo, ...s.getAudioTracks()]));
        }
      };
    } catch {}
  }, []);

  useEffect(() => {
    if (!room || !userId) return;
    const unsub = base44.entities.MeetSignal.subscribe((event) => {
      if (event.type === 'create') handleSignal(event.data);
    });
    unsubRef.current = unsub;
    return () => { unsub?.(); };
  }, [room, userId, handleSignal]);

  useEffect(() => () => { leave(); }, []);

  return {
    status, participants, localStream, micOn, camOn, error,
    join, leave, toggleMic, toggleCam, toggleScreenShare,
  };
}