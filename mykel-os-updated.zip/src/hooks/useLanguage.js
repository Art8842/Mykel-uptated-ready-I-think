// Re-export from global LanguageContext for backward compatibility
export { useLanguage, LANGUAGES } from '@/lib/LanguageContext';