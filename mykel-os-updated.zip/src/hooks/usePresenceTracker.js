import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

const PASSIVE_AFTER = 30 * 1000;    // 30 secondes
const OFFLINE_AFTER = 100 * 1000;   // 1 min 40
const HEARTBEAT = 60 * 1000;        // 1 minute

// Présence utilisateur. N'écrit en base QUE lorsque le statut / la page change,
// plus un battement par minute. (Avant : une écriture à chaque mouvement de
// souris ou frappe, ce qui saturait la limite de requêtes et faisait échouer
// les sauvegardes des documents.)
export function usePresenceTracker(user, currentPage, activityLabel = null) {
  const idRef = useRef(null);
  const lookupRef = useRef(null);
  const statusRef = useRef(null);
  const lastKeyRef = useRef('');

  useEffect(() => {
    if (!user?.email) return undefined;
    let passiveTimer = null;
    let offlineTimer = null;
    let lastActivity = 0;

    const ensureId = (data) => {
      if (!lookupRef.current) {
        lookupRef.current = base44.entities.UserPresence.filter({ user_email: user.email })
          .then((list) => list[0]?.id || base44.entities.UserPresence.create(data).then((c) => c.id));
      }
      return lookupRef.current;
    };

    const write = async (status, label, force = false) => {
      const key = `${status}|${currentPage}|${label}`;
      if (!force && key === lastKeyRef.current) return;
      lastKeyRef.current = key;
      statusRef.current = status;
      const data = {
        user_email: user.email,
        user_name: user.full_name || user.email,
        last_activity: new Date().toISOString(),
        current_page: currentPage || '',
        activity_label: label || (currentPage ? `Sur ${currentPage}` : 'En ligne'),
        status,
      };
      try {
        if (!idRef.current) idRef.current = await ensureId(data);
        await base44.entities.UserPresence.update(idRef.current, data);
      } catch {
        lookupRef.current = null;
        lastKeyRef.current = '';
      }
    };

    const schedule = () => {
      clearTimeout(passiveTimer);
      clearTimeout(offlineTimer);
      passiveTimer = setTimeout(() => {
        write('passive', activityLabel);
        offlineTimer = setTimeout(() => write('offline', null), OFFLINE_AFTER - PASSIVE_AFTER);
      }, PASSIVE_AFTER);
    };

    const onActivity = () => {
      const now = Date.now();
      if (now - lastActivity < 2000) return;
      lastActivity = now;
      if (statusRef.current !== 'active') write('active', activityLabel);
      schedule();
    };

    write('active', activityLabel);
    schedule();

    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
    events.forEach((e) => window.addEventListener(e, onActivity, { passive: true }));
    const heartbeat = setInterval(() => {
      if (statusRef.current === 'active') write('active', activityLabel, true);
    }, HEARTBEAT);
    const onPageHide = () => write('offline', null, true);
    window.addEventListener('pagehide', onPageHide);

    return () => {
      clearTimeout(passiveTimer);
      clearTimeout(offlineTimer);
      clearInterval(heartbeat);
      events.forEach((e) => window.removeEventListener(e, onActivity));
      window.removeEventListener('pagehide', onPageHide);
    };
  }, [user?.email, currentPage, activityLabel]);
}