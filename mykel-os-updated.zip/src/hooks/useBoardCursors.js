import { useEffect, useRef, useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';

// Curseurs des collaborateurs en temps réel (abonnement live, sans polling)
export default function useBoardCursors(boardId, myEmail, myName) {
  const [cursors, setCursors] = useState({});
  const myCursorId = useRef(null);
  const lastSent = useRef(0);

  useEffect(() => {
    if (!boardId) return undefined;
    const upsert = (c) => {
      if (!c || c.board_id !== boardId || c.user_email === myEmail) return;
      setCursors(prev => ({ ...prev, [c.id]: { x: c.x, y: c.y, name: c.user_name || c.user_email, seen: Date.now() } }));
    };
    base44.entities.WhiteboardCursor.filter({ board_id: boardId })
      .then(list => list.filter(c => Date.now() - new Date(c.last_seen).getTime() < 10000).forEach(upsert))
      .catch(() => {});
    const unsubscribe = base44.entities.WhiteboardCursor.subscribe((ev) => {
      if (ev.type === 'delete') {
        setCursors(prev => { const next = { ...prev }; delete next[ev.id]; return next; });
        return;
      }
      if (ev.data) upsert({ ...ev.data, id: ev.id });
    });
    const prune = setInterval(() => {
      setCursors(prev => {
        const now = Date.now();
        const next = Object.fromEntries(Object.entries(prev).filter(([, v]) => now - v.seen < 8000));
        return Object.keys(next).length === Object.keys(prev).length ? prev : next;
      });
    }, 3000);
    return () => { unsubscribe?.(); clearInterval(prune); };
  }, [boardId, myEmail]);

  useEffect(() => () => {
    if (myCursorId.current) base44.entities.WhiteboardCursor.delete(myCursorId.current).catch(() => {});
  }, []);

  const sendCursor = useCallback((x, y) => {
    if (!boardId) return;
    const now = Date.now();
    if (now - lastSent.current < 1000) return;
    lastSent.current = now;
    const data = { x, y, last_seen: new Date().toISOString() };
    if (myCursorId.current) {
      base44.entities.WhiteboardCursor.update(myCursorId.current, data).catch(() => {});
      return;
    }
    if (myCursorId.current === false) return; // création en cours
    myCursorId.current = false;
    base44.entities.WhiteboardCursor.create({ board_id: boardId, user_email: myEmail, user_name: myName, ...data })
      .then(c => { myCursorId.current = c.id; })
      .catch(() => { myCursorId.current = null; });
  }, [boardId, myEmail, myName]);

  return { cursors, sendCursor };
}