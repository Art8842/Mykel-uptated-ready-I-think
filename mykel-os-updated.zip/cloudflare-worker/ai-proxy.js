// Cloudflare Worker - AI Proxy for Mykel
// Deploy this on Cloudflare Workers (free tier) and set the worker URL in Admin Panel > Store & Apps > IA Proxy
//
// Setup:
// 1. Go to https://dash.cloudflare.com > Workers & Pages
// 2. Create a new Worker
// 3. Paste this code
// 4. Add environment variable MISTRAL_API_KEY with your Mistral API key
// 5. Deploy and copy the worker URL (e.g. https://mykel-ai-proxy.your-subdomain.workers.dev)
// 6. Set the URL in Mykel Admin Panel > Store & Apps > IA Proxy URL

export default {
  async fetch(request, env) {
    // CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type',
        },
      });
    }

    if (request.method !== 'POST') {
      return new Response('Method not allowed', {
        status: 405,
        headers: { 'Access-Control-Allow-Origin': '*' },
      });
    }

    try {
      const body = await request.json();
      const response = await fetch('https://api.mistral.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.MISTRAL_API_KEY}`,
        },
        body: JSON.stringify({
          model: body.model || 'mistral-large-latest',
          messages: body.messages,
          max_tokens: body.max_tokens || 2048,
          ...(body.response_format ? { response_format: body.response_format } : {}),
        }),
      });

      const data = await response.json();
      return new Response(JSON.stringify(data), {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      });
    }
  },
};